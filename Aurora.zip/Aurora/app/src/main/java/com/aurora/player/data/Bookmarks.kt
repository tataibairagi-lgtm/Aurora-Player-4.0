package com.aurora.player.data

/** Plain-text (CSV) export / import for bookmarks, so they survive a reinstall and can be shared. */
object BookmarkIo {
    private fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    fun toText(list: List<Bookmark>, library: List<Track>): String {
        val byId = library.associateBy { it.id }
        val sb = StringBuilder("id,track_id,position_ms,note,created,title,artist\n")
        for (b in list) {
            val t = byId[b.trackId]
            sb.append(b.id).append(',').append(b.trackId).append(',').append(b.posMs).append(',').append(q(b.note))
                .append(',').append(b.created).append(',').append(q(t?.title ?: "")).append(',').append(q(t?.artist ?: "")).append('\n')
        }
        return sb.toString()
    }

    private fun parseLine(line: String): List<String> {
        val out = ArrayList<String>(); val cur = StringBuilder(); var inQ = false; var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                inQ && ch == '"' && i + 1 < line.length && line[i + 1] == '"' -> { cur.append('"'); i++ }
                ch == '"' -> inQ = !inQ
                ch == ',' && !inQ -> { out.add(cur.toString()); cur.clear() }
                else -> cur.append(ch)
            }
            i++
        }
        out.add(cur.toString())
        return out
    }

    fun fromText(text: String, library: List<Track>): List<Bookmark> {
        val res = ArrayList<Bookmark>()
        for ((n, line) in text.lines().withIndex()) {
            if (n == 0 || line.isBlank()) continue
            val p = parseLine(line)
            if (p.size < 5) continue
            var tid = p[1].toLongOrNull() ?: continue
            // the song's id can change after a reinstall: match by title and artist when the id is gone
            if (library.none { it.id == tid }) {
                val m = library.firstOrNull { it.title == p.getOrNull(5) && it.artist == p.getOrNull(6) } ?: continue
                tid = m.id
            }
            res.add(Bookmark(p[0].ifBlank { "bm" + System.nanoTime() + n }, tid, p[2].toLongOrNull() ?: 0L, p[3], p[4].toLongOrNull() ?: 0L))
        }
        return res
    }
}
