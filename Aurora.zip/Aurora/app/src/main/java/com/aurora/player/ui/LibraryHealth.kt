package com.aurora.player.ui

import android.media.MediaMetadataRetriever
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.albumKey
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/** Scans the library once: files that cannot be opened, and albums with no cover (neither inside the file nor a cover picture in its folder). */
@Composable
fun LibraryHealthDialog(c: PlayerController, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var done by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    var broken by remember { mutableStateOf<List<Track>>(emptyList()) }
    var noCover by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) } // album, artist
    var tab by remember { mutableIntStateOf(0) }
    var confirm by remember { mutableStateOf(false) }
    val actions = LocalActions.current
    val total = c.library.size

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val bad = ArrayList<Track>()
            val coverless = LinkedHashMap<String, Pair<String, String>>()
            val folderHasCover = HashMap<String, Boolean>()
            val r = MediaMetadataRetriever()
            val seenAlbums = HashSet<String>()
            try {
                for ((i, t) in c.library.withIndex()) {
                    if (!isActive) break
                    var ok = true
                    var art = false
                    try {
                        r.setDataSource(t.path)
                        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                        if (dur <= 0L) ok = false
                        // one cover check per album is enough
                        val key = t.albumKey()
                        if (ok && seenAlbums.add(key)) {
                            art = r.embeddedPicture != null
                            if (!art) {
                                val dir = t.folder
                                art = folderHasCover.getOrPut(dir) {
                                    java.io.File(dir).listFiles()?.any { f ->
                                        val n = f.name.lowercase()
                                        (n.endsWith(".jpg") || n.endsWith(".jpeg") || n.endsWith(".png")) &&
                                            (n.startsWith("cover") || n.startsWith("folder") || n.startsWith("front") || n.startsWith("album"))
                                    } == true
                                }
                            }
                            if (!art) coverless[key] = (t.album.ifBlank { "Unknown album" }) to t.artist
                        }
                    } catch (_: Throwable) { ok = false }
                    if (!ok) bad += t
                    if (i % 20 == 0) { done = i; broken = bad.toList(); noCover = coverless.values.toList() }
                }
            } finally { try { r.release() } catch (_: Throwable) {} }
            broken = bad; noCover = coverless.values.toList(); done = total
        }
        finished = true
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Library health") },
        text = {
            Column {
                if (!finished) {
                    Text("Checking $done of $total songs…", style = MaterialTheme.typography.bodySmall)
                    LinearProgressIndicator(progress = { if (total == 0) 0f else done.toFloat() / total }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(bottom = 8.dp)) {
                    FilterChip(tab == 0, { tab = 0 }, label = { Text("Broken files (${broken.size})") })
                    FilterChip(tab == 1, { tab = 1 }, label = { Text("No cover (${noCover.size})") })
                }
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    if (tab == 0) {
                        if (broken.isEmpty()) Text(if (finished) "Every file opens fine." else "None so far.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        broken.forEach { t ->
                            Column(Modifier.padding(vertical = 5.dp)) {
                                Text(t.title, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(t.path, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } else {
                        if (noCover.isEmpty()) Text(if (finished) "Every album has a cover." else "None so far.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        noCover.forEach { (al, ar) ->
                            Column(Modifier.padding(vertical = 5.dp)) {
                                Text(al, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(ar, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Text("To add a cover: put cover.jpg in the album's folder, or use Edit tags on a song.", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } },
        dismissButton = { if (finished && broken.isNotEmpty() && tab == 0) TextButton({ confirm = true }) { Text("Delete broken files") } },
    )
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Delete ${broken.size} broken files?") },
        text = { Text("These files could not be opened. They are permanently removed from your device. This can't be undone.") },
        confirmButton = { TextButton({ confirm = false; actions.deleteTracks(broken); onDismiss() }) { Text("Delete") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } },
    )
}
