package com.aurora.player.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap

private val accentMarks = Regex("\\p{InCombiningDiacriticalMarks}+")
private val nonWord = Regex("[^\\p{L}\\p{N} ]+")

/** Lower-case, without accents or punctuation: "Beyoncé – Halo!" becomes "beyonce halo". */
fun normalizeForSearch(s: String): String =
    nonWord.replace(accentMarks.replace(Normalizer.normalize(s, Normalizer.Form.NFD), ""), " ").lowercase()

private val haystacks = ConcurrentHashMap<Long, String>()

private fun haystack(t: Track): String = haystacks.getOrPut(t.id) {
    normalizeForSearch(listOf(t.title, t.artist, t.album, t.genre, t.path.substringAfterLast('/').substringBeforeLast('.')).joinToString(" "))
}

/** Every word you type must appear somewhere in the title, artist, album, genre or file name (any order, accents ignored). */
fun searchMatches(t: Track, q: String): Boolean {
    if (q.isBlank()) return true
    val words = normalizeForSearch(q).split(' ').filter { it.isNotEmpty() }
    if (words.isEmpty()) return true
    val h = haystack(t)
    return words.all { it in h }
}

/** Search box that opens with the keyboard up, has a clear button and closes the keyboard on Search. */
@Composable
fun SearchField(
    value: String, onChange: (String) -> Unit, placeholder: String,
    modifier: Modifier = Modifier, autoFocus: Boolean = false, focusOnRequest: Boolean = false,
) {
    val focus = remember { FocusRequester() }
    val fm = LocalFocusManager.current
    // a double tap on the Search tab icon asks for the keyboard straight away
    val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    if (focusOnRequest) LaunchedEffect(SearchRequest.pending) {
        if (SearchRequest.pending) {
            // the tab is still sliding in and the field may not be on screen yet, so try for a moment until the keyboard is really up
            var tries = 0
            while (tries < 8) {
                kotlinx.coroutines.delay(if (tries == 0) 120L else 160L)
                try { focus.requestFocus(); keyboard?.show() } catch (_: Exception) {}
                tries++
            }
            SearchRequest.pending = false
        }
    }
    if (autoFocus) LaunchedEffect(Unit) { try { focus.requestFocus() } catch (_: Exception) {} }
    OutlinedTextField(
        value, onChange, singleLine = true, placeholder = { Text(placeholder) },
        leadingIcon = { Icon(Icons.Rounded.Search, "Search") },
        trailingIcon = if (value.isNotEmpty()) ({
            IconButton({ onChange("") }) { Icon(Icons.Rounded.Close, "Clear") }
        }) else null,
        shape = RoundedCornerShape(28.dp),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
        keyboardActions = KeyboardActions(onSearch = { fm.clearFocus() }),
        modifier = modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).focusRequester(focus),
    )
}

object SearchRequest {
    var pending by androidx.compose.runtime.mutableStateOf(false)
}
