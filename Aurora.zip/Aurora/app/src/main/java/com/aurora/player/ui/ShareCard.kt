package com.aurora.player.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.provider.MediaStore
import android.text.TextPaint
import android.text.TextUtils

/** One colour scheme for the share picture: [bg] is the background, [fg] the text and accents. */
class SharePal(val bg: Int, val fg: Int)

val SHARE_PALETTES = listOf(
    SharePal(0xFF000000.toInt(), 0xFF9CC5BA.toInt()), SharePal(0xFF9CC5BA.toInt(), 0xFF0A1412.toInt()),
    SharePal(0xFF69F6A0.toInt(), 0xFF002112.toInt()), SharePal(0xFF00150A.toInt(), 0xFF69F6A0.toInt()),
    SharePal(0xFFE6E56A.toInt(), 0xFF2B2A00.toInt()), SharePal(0xFF14130A.toInt(), 0xFFFFD60A.toInt()),
    SharePal(0xFFFFD9E0.toInt(), 0xFF8C0030.toInt()), SharePal(0xFF8C0030.toInt(), 0xFFFFD9E0.toInt()),
    SharePal(0xFFCFE5FF.toInt(), 0xFF004A77.toInt()), SharePal(0xFF004A77.toInt(), 0xFFCFE5FF.toInt()),
    SharePal(0xFFE0E3E1.toInt(), 0xFF00504A.toInt()), SharePal(0xFF00504A.toInt(), 0xFF9CF0E6.toInt()),
    SharePal(0xFF1B1B1B.toInt(), 0xFFFFDDA0.toInt()), SharePal(0xFFFFDEA0.toInt(), 0xFF261A00.toInt()),
    SharePal(0xFFFFFBFF.toInt(), 0xFFC0161B.toInt()), SharePal(0xFF9B0A0E.toInt(), 0xFFFFDAD6.toInt()),
    SharePal(0xFFA8FF4C.toInt(), 0xFF133300.toInt()), SharePal(0xFF141A0C.toInt(), 0xFF8BDB22.toInt()),
    SharePal(0xFFFFFFFF.toInt(), 0xFFF07000.toInt()), SharePal(0xFF201508.toInt(), 0xFFFF9A1A.toInt()),
    SharePal(0xFFFBFDFF.toInt(), 0xFF00677F.toInt()), SharePal(0xFF0B141A.toInt(), 0xFF00B8F4.toInt()),
    SharePal(0xFFFFFFFF.toInt(), 0xFFA100C8.toInt()), SharePal(0xFF1D1020.toInt(), 0xFFF1A0FF.toInt()),
    SharePal(0xFFFFFFFF.toInt(), 0xFF000000.toInt()), SharePal(0xFF2B2B2B.toInt(), 0xFFFFFFFF.toInt()),
)

class SongRow(val title: String, val artist: String, val plays: Int, val art: Bitmap?)
class ArtistRow(val name: String, val pct: String, val frac: Float)

/** Draws the Most played pictures (songs page and artists page) with plain Canvas: works on every Android version. */
object ShareCard {
    private const val W = 1080
    private const val PAD = 64

    private fun tp(size: Float, color: Int, bold: Boolean = false) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun fit(s: String, p: TextPaint, maxW: Float) = TextUtils.ellipsize(s, p, maxW, TextUtils.TruncateAt.END).toString()

    private fun logo(cv: Canvas, x: Float, y: Float, size: Float, pal: SharePal) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.fg; pathEffect = CornerPathEffect(size * 0.14f) }
        val tri = Path().apply { moveTo(x, y); lineTo(x, y + size); lineTo(x + size * 1.05f, y + size / 2); close() }
        cv.drawPath(tri, fill)
        val note = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.bg }
        cv.drawCircle(x + size * 0.36f, y + size * 0.70f, size * 0.12f, note)
        cv.drawRect(x + size * 0.44f, y + size * 0.26f, x + size * 0.5f, y + size * 0.70f, note)
        cv.drawRect(x + size * 0.44f, y + size * 0.26f, x + size * 0.66f, y + size * 0.36f, note)
    }

    /** Draws the outlined chips, wrapping onto new lines. Returns the y just below them. */
    private fun chips(cv: Canvas?, labels: List<String>, y0: Float, pal: SharePal, withClock: Boolean): Float {
        val text = tp(34f, pal.fg).apply { letterSpacing = 0.08f }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.fg; style = Paint.Style.STROKE; strokeWidth = 3f }
        var x = PAD.toFloat(); var y = y0
        val h = 76f
        labels.forEachIndexed { i, l ->
            val icon = if (i == 0 && withClock) 52f else 0f
            val w = text.measureText(l) + 56f + icon
            if (x + w > W - PAD && x > PAD) { x = PAD.toFloat(); y += h + 16f }
            cv?.let {
                it.drawRoundRect(RectF(x, y, x + w, y + h), h / 2, h / 2, line)
                var tx = x + 28f
                if (icon > 0f) {
                    it.drawCircle(tx + 16f, y + h / 2 + 3f, 14f, line)
                    it.drawLine(tx + 16f, y + h / 2 + 3f, tx + 16f, y + h / 2 - 7f, line)
                    it.drawLine(tx + 10f, y + 24f, tx + 22f, y + 24f, line)
                    tx += icon
                }
                it.drawText(l, tx, y + h / 2 + 12f, text)
            }
            x += w + 16f
        }
        return y + h
    }

    private fun footerChip(cv: Canvas, y: Float, pal: SharePal) {
        val text = tp(34f, pal.fg).apply { letterSpacing = 0.08f }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.fg; style = Paint.Style.STROKE; strokeWidth = 3f }
        val label = "Aurora"
        val w = text.measureText(label) + 56f + 52f
        cv.drawRoundRect(RectF(PAD.toFloat(), y, PAD + w, y + 76f), 38f, 38f, line)
        cv.drawCircle(PAD + 48f, y + 34f, 13f, line)
        cv.drawLine(PAD + 57f, y + 43f, PAD + 68f, y + 54f, line)
        cv.drawText(label, PAD + 28f + 52f, y + 50f, text)
    }

    private fun header(cv: Canvas, sub: String, pal: SharePal) {
        logo(cv, PAD.toFloat(), 56f, 120f, pal)
        cv.drawText("Aurora", 230f, 108f, tp(52f, pal.fg, true))
        cv.drawText(sub, 230f, 172f, tp(52f, pal.fg, true))
    }

    private fun base(h: Int, pal: SharePal): Pair<Bitmap, Canvas> {
        val b = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(b)
        cv.drawColor(pal.bg)
        return b to cv
    }

    fun songs(rows: List<SongRow>, period: String, listened: String, artistChips: List<String>, pal: SharePal): Bitmap {
        val labels = listOf(listened) + artistChips
        val chipsBottom = chips(null, labels, 240f, pal, true)
        val rowH = 118f
        val top = chipsBottom + 50f
        val h = (top + rows.size * rowH + 60f + 76f + 70f).toInt()
        val (bmp, cv) = base(h, pal)
        header(cv, "Most played • $period", pal)
        chips(cv, labels, 240f, pal, true)
        val rank = tp(36f, pal.fg)
        val bold = tp(44f, pal.fg, true)
        val reg = tp(44f, pal.fg)
        val badge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.fg }
        val badgeText = tp(40f, pal.bg, true).apply { textAlign = Paint.Align.CENTER }
        rows.forEachIndexed { i, r ->
            val y = top + i * rowH
            cv.drawText((i + 1).toString(), PAD.toFloat(), y + 62f, rank)
            val art = RectF(150f, y + 6f, 150f + 100f, y + 106f)
            if (r.art != null) cv.drawBitmap(r.art, null, art, Paint(Paint.FILTER_BITMAP_FLAG))
            else cv.drawRoundRect(art, 8f, 8f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.fg; alpha = 70 })
            val x = 280f
            val maxW = W - PAD - 110f - x
            val dot = " • "
            val tw = bold.measureText(r.title)
            if (tw + reg.measureText(dot) > maxW) {
                cv.drawText(fit(r.title, bold, maxW), x, y + 70f, bold)
            } else {
                cv.drawText(r.title, x, y + 70f, bold)
                cv.drawText(fit(dot + r.artist, reg, maxW - tw), x + tw, y + 70f, reg)
            }
            val n = r.plays.toString()
            val bw = maxOf(70f, bold.measureText(n) + 36f)
            val right = (W - PAD).toFloat()
            cv.drawRoundRect(RectF(right - bw, y + 22f, right, y + 90f), 6f, 6f, badge)
            cv.drawText(n, right - bw / 2, y + 71f, badgeText)
        }
        footerChip(cv, top + rows.size * rowH + 40f, pal)
        return bmp
    }

    fun artists(rows: List<ArtistRow>, period: String, listened: String, pal: SharePal): Bitmap {
        val chipsBottom = chips(null, listOf(listened), 240f, pal, true)
        val rowH = 124f
        val top = chipsBottom + 64f
        val h = (top + rows.size * rowH + 60f + 76f + 70f).toInt()
        val (bmp, cv) = base(h, pal)
        header(cv, "Most played • $period", pal)
        chips(cv, listOf(listened), 240f, pal, true)
        val rank = tp(36f, pal.fg)
        val name = tp(48f, pal.fg, true)
        val pct = tp(40f, pal.fg, true).apply { textAlign = Paint.Align.RIGHT }
        val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.fg; alpha = 90; strokeWidth = 5f; strokeCap = Paint.Cap.ROUND }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.fg; strokeWidth = 5f; strokeCap = Paint.Cap.ROUND }
        rows.forEachIndexed { i, r ->
            val y = top + i * rowH
            cv.drawText((i + 1).toString(), PAD.toFloat(), y + 50f, rank)
            val x = 190f
            val lineEnd = W - PAD - 190f
            cv.drawText(fit(r.name, name, lineEnd - x), x, y + 54f, name)
            cv.drawLine(x, y + 78f, lineEnd, y + 78f, track)
            cv.drawLine(x, y + 78f, x + (lineEnd - x) * r.frac.coerceIn(0.015f, 1f), y + 78f, fill)
            cv.drawText(r.pct, (W - PAD).toFloat(), y + 56f, pct)
        }
        footerChip(cv, top + rows.size * rowH + 30f, pal)
        return bmp
    }

    /** Saves the picture to Pictures/Aurora (no storage permission needed on Android 10+). */
    fun save(ctx: Context, bmp: Bitmap, name: String): Uri? = try {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name.replace('/', '_') + ".png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Aurora")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v)!!
        ctx.contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        v.clear(); v.put(MediaStore.Images.Media.IS_PENDING, 0)
        ctx.contentResolver.update(uri, v, null, null)
        uri
    } catch (_: Exception) {
        null
    }

    fun share(ctx: Context, uri: Uri) {
        val i = Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
