package com.aurora.player.player

import android.content.Context
import android.os.Bundle
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat.DecoratedMediaCustomViewStyle
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import com.aurora.player.R
import com.aurora.player.controller
import com.google.common.collect.ImmutableList

/** The standard media notification plus an "Upcoming songs" list in its expanded view. */
@UnstableApi
class AuroraNotificationProvider(private val ctx: Context) : MediaNotification.Provider {
    private val base = DefaultMediaNotificationProvider.Builder(ctx).build().also { it.setSmallIcon(R.drawable.ic_stat_aurora) }

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback,
    ): MediaNotification {
        val n = base.createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
        return try {
            val c = ctx.controller
            val upcoming = c.queue.drop(c.currentIndex + 1).take(2)
            if (upcoming.isEmpty()) return n
            val rv = RemoteViews(ctx.packageName, R.layout.notif_upcoming)
            fun line(i: Int) = upcoming.getOrNull(i)?.let { it.title + " - " + it.artist } ?: ""
            rv.setTextViewText(R.id.up1, line(0))
            rv.setTextViewText(R.id.up2, line(1))
            val b = NotificationCompat.Builder.recoverBuilder(ctx, n.notification)
            b.setCustomBigContentView(rv)
            b.setStyle(DecoratedMediaCustomViewStyle().setMediaSession(mediaSession.sessionCompatToken).setShowActionsInCompactView(0, 1, 2))
            MediaNotification(n.notificationId, b.build())
        } catch (_: Throwable) {
            n
        }
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        base.handleCustomCommand(session, action, extras)
}
