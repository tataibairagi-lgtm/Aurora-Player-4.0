package com.aurora.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.SMART_FIELDS
import com.aurora.player.data.SmartList
import com.aurora.player.data.SmartRule
import com.aurora.player.data.smartFieldLabel
import com.aurora.player.data.smartNeedsValue
import com.aurora.player.data.smartTracks
import com.aurora.player.player.PlayerController
import java.util.UUID

/** Lists the smart playlists; tap one to open it, or create / edit / delete them. */
@Composable
fun SmartListsDialog(c: PlayerController, onDismiss: () -> Unit, onOpen: (String) -> Unit) {
    var editing by remember { mutableStateOf<SmartList?>(null) }
    val d = c.store.data
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Smart playlists") },
        text = {
            Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                Text("A smart playlist fills itself from rules, such as rock songs from the 90s that you rated 4 stars or more.", style = MaterialTheme.typography.bodySmall)
                if (d.smartLists.isEmpty()) Text("None yet.", Modifier.padding(vertical = 16.dp))
                d.smartLists.forEach { sl ->
                    val n = remember(sl, c.library, d.ratings, d.playCounts, d.favourites) { smartTracks(c.library, sl, d).size }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { onOpen(sl.id) }.padding(vertical = 6.dp)) {
                            Text(sl.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("$n songs · ${sl.rules.size} rules", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton({ editing = sl }) { Text("Edit") }
                    }
                }
            }
        },
        confirmButton = { TextButton({ editing = SmartList(UUID.randomUUID().toString(), "", listOf(SmartRule("artist", ""))) }) { Text("New") } },
        dismissButton = { TextButton(onDismiss) { Text("Close") } },
    )
    editing?.let { sl ->
        SmartListEditor(sl, isNew = d.smartLists.none { it.id == sl.id }, onDismiss = { editing = null }, onDelete = {
            c.store.update { s -> s.copy(smartLists = s.smartLists.filter { it.id != sl.id }) }; editing = null
        }) { saved ->
            c.store.update { s ->
                s.copy(smartLists = if (s.smartLists.any { it.id == saved.id }) s.smartLists.map { if (it.id == saved.id) saved else it } else s.smartLists + saved)
            }
            editing = null
        }
    }
}

@Composable
private fun SmartListEditor(sl: SmartList, isNew: Boolean, onDismiss: () -> Unit, onDelete: () -> Unit, onSave: (SmartList) -> Unit) {
    var name by remember { mutableStateOf(sl.name) }
    var all by remember { mutableStateOf(sl.matchAll) }
    var limit by remember { mutableStateOf(if (sl.limit > 0) sl.limit.toString() else "") }
    val rules = remember { mutableStateListOf<SmartRule>().also { it.addAll(sl.rules) } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "New smart playlist" else "Edit smart playlist") },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(all, { all = true }, label = { Text("Match all rules") })
                    FilterChip(!all, { all = false }, label = { Text("Match any rule") })
                }
                rules.forEachIndexed { i, r ->
                    var menu by remember { mutableStateOf(false) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(smartFieldLabel(r.field), Modifier.clickable { menu = true }.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                            DropdownMenu(menu, { menu = false }) {
                                SMART_FIELDS.forEach { (id, label) ->
                                    DropdownMenuItem(text = { Text(label) }, onClick = { rules[i] = r.copy(field = id); menu = false })
                                }
                            }
                            if (smartNeedsValue(r.field)) OutlinedTextField(r.value, { rules[i] = r.copy(value = it) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        }
                        TextButton({ rules.removeAt(i) }) { Text("Remove") }
                    }
                }
                TextButton({ rules.add(SmartRule("artist", "")) }) { Text("Add a rule") }
                OutlinedTextField(limit, { limit = it.filter { ch -> ch.isDigit() }.take(4) }, label = { Text("Maximum songs (empty = no limit)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton({ onSave(sl.copy(name = name.trim().ifEmpty { "Smart playlist" }, rules = rules.toList(), matchAll = all, limit = limit.toIntOrNull() ?: 0)) }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (!isNew) TextButton(onDelete) { Text("Delete") }
                TextButton(onDismiss) { Text("Cancel") }
            }
        },
    )
}
