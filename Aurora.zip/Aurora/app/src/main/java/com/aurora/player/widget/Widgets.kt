package com.aurora.player.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

open class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.update(context)
    }

    override fun onEnabled(context: Context) {
        WidgetUpdater.update(context)
    }
}

class MiniWidget : BaseWidget()
class StandardWidget : BaseWidget()
class SquareWidget : BaseWidget()
class LargeWidget : BaseWidget()
class QueueWidget : BaseWidget()
