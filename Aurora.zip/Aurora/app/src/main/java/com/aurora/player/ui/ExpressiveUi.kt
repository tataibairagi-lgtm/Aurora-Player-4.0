package com.aurora.player.ui

import com.aurora.player.data.UI_SQUIGGLY
import com.aurora.player.data.UI_WAVE_ONEUI
import com.aurora.player.data.UI_MORPH
import com.aurora.player.data.UI_SPEC
import com.aurora.player.data.UI_MARQUEE
import com.aurora.player.data.UI_AMOLED
import com.aurora.player.data.UI_CAROUSEL
import com.aurora.player.data.UI_MINI
import com.aurora.player.data.UI_PILL
import com.aurora.player.data.UI_QCHIPS
import com.aurora.player.data.UI_FASTSCROLL
import com.aurora.player.data.UI_COLLAPSE
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.launch

/** Small bits of UI state shared between screens (the floating tab pill hides while a list scrolls). */
object ExpressiveState {
    var pillHidden by mutableStateOf(false)
    /** the Now playing screen takes the pill away completely while its lyrics are open */
    var pillForcedOff by mutableStateOf(false)
    /** the Now playing screen (lyrics closed) keeps the pill on screen, whatever the hide options say */
    var pillPinned by mutableStateOf(false)
    /** On the queue tab the pill stays up (scrolling the queue must not hide it) unless it was hidden with "Hide Tab Pill". */
    var queuePinned by mutableStateOf(false)
    /** the person hid the pill on purpose (menu or swipe down): that wins over the Now Playing pin */
    var pillManual by mutableStateOf(false)
    /** landscape Now Playing: the root draws the background across the whole screen (also beside the notch), so the screens skip their own */
    var rootBackdrop by mutableStateOf(false)
    val pillGone: Boolean get() = (pillHidden && (!(pillPinned || queuePinned) || pillManual)) || pillForcedOff
    /** the mini-player is on screen (so the swipe handle of a hidden pill sits above it, not under it) */
    var miniShown by mutableStateOf(false)
    /** counts every finger-down on the screen, so the floating pill can hide itself after a few seconds of no touching */
    var touch by mutableStateOf(0)
    /** the colours of the Now playing screen (taken from the cover), so the tab pill and the mini-player can match it */
    var npScheme by mutableStateOf<androidx.compose.material3.ColorScheme?>(null)
}

/** The app's own colours, provided by Now playing so its menus and dialogs keep normal readable colours when the screen itself is tinted. */
val LocalBaseScheme = androidx.compose.runtime.staticCompositionLocalOf<androidx.compose.material3.ColorScheme?> { null }

@Composable
fun BaseTheme(content: @Composable () -> Unit) {
    val b = LocalBaseScheme.current
    if (b == null) content() else MaterialTheme(colorScheme = b, content = content)
}

/** Font pairings: name to the family used for every text style. */
val FONT_PRESETS = listOf("Aurora (default)", "Editorial (serif)", "Techy (monospace)", "Playful (cursive)", "Compact (condensed)")

fun fontFamilyFor(i: Int): FontFamily? = when (i) {
    1 -> FontFamily.Serif
    2 -> FontFamily.Monospace
    3 -> FontFamily.Cursive
    4 -> FontFamily(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.NORMAL))
    else -> null
}

fun typographyFor(i: Int): androidx.compose.material3.Typography {
    val b = androidx.compose.material3.Typography()
    val f = fontFamilyFor(i) ?: return b
    return b.copy(
        displayLarge = b.displayLarge.copy(fontFamily = f), displayMedium = b.displayMedium.copy(fontFamily = f), displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f), headlineMedium = b.headlineMedium.copy(fontFamily = f), headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f), titleMedium = b.titleMedium.copy(fontFamily = f), titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f), bodyMedium = b.bodyMedium.copy(fontFamily = f), bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f), labelMedium = b.labelMedium.copy(fontFamily = f), labelSmall = b.labelSmall.copy(fontFamily = f),
    )
}

val ACCENT_PRESETS = listOf(
    "Aurora blue" to 0xFF007CC3L, "Coral" to 0xFFFF6B5EL, "Mint" to 0xFF2BB58AL, "Violet" to 0xFF7C5CFFL, "Amber" to 0xFFF5A524L,
    "Rose" to 0xFFE84C88L, "Teal" to 0xFF0FA3B1L, "Lime" to 0xFF8BC34AL, "Slate" to 0xFF5C6B7AL, "Crimson" to 0xFFC62828L,
)

/** A-Z strip on the right edge of a long list. Drag along it to jump; a big letter bubble shows where you are. */
@Composable
fun AlphaScroller(titles: List<String>, state: LazyListState, modifier: Modifier = Modifier) =
    AlphaScrollerCore(titles, state.isScrollInProgress, modifier) { state.scrollToItem(it) }

/** The same strip for a grid. */
@Composable
fun AlphaScrollerGrid(titles: List<String>, state: androidx.compose.foundation.lazy.grid.LazyGridState, modifier: Modifier = Modifier) =
    AlphaScrollerCore(titles, state.isScrollInProgress, modifier) { state.scrollToItem(it) }

/** The A-Z strip, shown for a list of names that is in ascending order and long enough to need it. */
@Composable
fun NameScroller(names: List<String>, state: LazyListState?, grid: androidx.compose.foundation.lazy.grid.LazyGridState?, on: Boolean, modifier: Modifier = Modifier) {
    if (!on || names.size <= 30) return
    val ascending = remember(names) { names.zipWithNext().count { (a, b) -> a.lowercase() <= b.lowercase() } >= (names.size - 1) * 0.95 }
    if (!ascending) return
    if (state != null) AlphaScroller(names, state, modifier) else if (grid != null) AlphaScrollerGrid(names, grid, modifier)
}

@Composable
fun AlphaScrollerCore(titles: List<String>, scrolling: Boolean, modifier: Modifier = Modifier, scrollTo: suspend (Int) -> Unit) {
    val letters = remember { ('A'..'Z').toList() + '#' }
    val firstAt = remember(titles) {
        val m = HashMap<Char, Int>()
        titles.forEachIndexed { i, t ->
            val ch = t.trim().firstOrNull()?.uppercaseChar()?.takeIf { it in 'A'..'Z' } ?: '#'
            if (ch !in m) m[ch] = i
        }
        m
    }
    val scope = rememberCoroutineScope()
    var active by remember { mutableStateOf<Char?>(null) }
    val strength by animateFloatAsState(if (active != null || scrolling) 1f else 0.35f, label = "alphaStrip")
    fun jump(frac: Float) {
        val ch = letters[(frac * letters.size).toInt().coerceIn(0, letters.lastIndex)]
        active = ch
        // letters with no song fall through to the next letter that has one
        val target = letters.drop(letters.indexOf(ch)).firstNotNullOfOrNull { firstAt[it] } ?: firstAt.values.maxOrNull() ?: return
        scope.launch { scrollTo(target) }
    }
    Box(modifier.fillMaxHeight().padding(vertical = 8.dp), contentAlignment = Alignment.CenterEnd) {
        active?.let { ch ->
            Box(
                Modifier.padding(end = 44.dp).size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) { Text(ch.toString(), color = MaterialTheme.colorScheme.onPrimary, fontSize = 30.sp, fontWeight = FontWeight.Bold) }
        }
        Column(
            Modifier.fillMaxHeight().width(30.dp).graphicsLayer { alpha = strength }
                .pointerInput(titles) {
                    detectVerticalDragGestures(
                        onDragStart = { p -> jump(p.y / size.height) },
                        onDragEnd = { active = null }, onDragCancel = { active = null },
                    ) { change, _ -> change.consume(); jump(change.position.y / size.height) }
                }
                .pointerInput(titles) { detectTapGestures(onPress = { p -> jump(p.y / size.height); tryAwaitRelease(); active = null }) },
            verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            letters.forEach { ch ->
                Text(ch.toString(), fontSize = 10.sp, fontWeight = if (ch == active) FontWeight.Bold else FontWeight.Medium,
                    color = if (ch == active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Quick switch between queues at the top of the queue screen. */
@Composable
fun QueueChips(c: PlayerController) {
    val qs = c.store.data.queues
    if (qs.size < 2) return
    LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(qs) { i, q ->
            FilterChip(
                c.viewQueue == i, { c.viewQueue = i },
                label = { Text("${i + 1}. ${q.name}", maxLines = 1) },
                leadingIcon = if (i == c.activeQueue) ({ androidx.compose.material3.Icon(Icons.Rounded.GraphicEq, null, Modifier.size(16.dp)) }) else null,
            )
        }
    }
}

/** Previous and next covers peek in beside the current one; drag moves them together, the current cover lags a little (parallax). */
@Composable
fun CarouselCovers(c: PlayerController, dragPx: Float) {
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val side = minOf(maxWidth, maxHeight) * 0.78f
        val gap = 14.dp
        val i = c.currentIndex
        val prev = c.queue.getOrNull(i - 1)
        val next = c.queue.getOrNull(i + 1)
        val s by animateFloatAsState(if (c.isPlaying) 1f else 0.9f, label = "carS")
        if (prev != null) AlbumArt(prev, Modifier.size(side).offset(-(side + gap)).graphicsLayer { scaleX = 0.82f; scaleY = 0.82f; alpha = 0.55f }, RoundedCornerShape(26.dp), 48.dp, 480)
        if (next != null) AlbumArt(next, Modifier.size(side).offset(side + gap).graphicsLayer { scaleX = 0.82f; scaleY = 0.82f; alpha = 0.55f }, RoundedCornerShape(26.dp), 48.dp, 480)
        AlbumArt(
            c.current, Modifier.size(side).graphicsLayer { scaleX = s; scaleY = s; translationX = -dragPx * 0.18f; shadowElevation = 40f; shape = RoundedCornerShape(26.dp); clip = true },
            RoundedCornerShape(26.dp), 72.dp, 800,
        )
    }
}

/** Settings page: every opt-in look. All of them are off by default, so Aurora's own look stays as it is. */
@Composable
fun ExpressivePage(c: PlayerController) {
    val d = c.store.data
    Text(
        "Optional looks inspired by Material 3 Expressive. Everything here is off by default.",
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    CollapsibleGroup("Now playing", startOpen = true) {
        SwitchRow("Wavy seek bar", "The played part ripples while music plays and goes flat when paused", d.uiSquiggly) { v -> c.store.update { it.withUi(UI_SQUIGGLY, v) } }
        DepSwitchRow("Thin wave style", "Soft layered hills rise out of the played line and end at a round handle with a white rim. Off = the bold wave with a tall handle", d.uiWaveOne, d.uiSquiggly, "Wavy seek bar") { v -> c.store.update { it.withUi(UI_WAVE_ONEUI, v) } }
        SwitchRow("Morphing play button", "Softer square while playing, circle when paused, with a bounce and a tap buzz", d.uiMorphPlay) { v -> c.store.update { it.withUi(UI_MORPH, v) } }
        ChipRow("Song row spacing") {
            listOf("Compact", "Normal", "Roomy").forEachIndexed { i, n -> FilterChip(d.rowDensity == i, { c.store.update { it.copy(rowDensity = i) } }, label = { Text(n) }) }
        }
        SliderSetting("Text size", d.fontScalePct.toFloat(), 80f..130f, 9, "${d.fontScalePct}%") { v -> c.store.update { it.copy(fontScalePct = (kotlin.math.round(v / 5f) * 5).toInt()) } }
        SwitchRow("Jump-to-playing button", "A small button in song lists that scrolls back to the song that is playing", d.goToCurrent) { v -> c.store.update { it.copy(goToCurrent = v) } }
        SwitchRow("Up next strip", "A slim strip under the controls showing the next song; tap it to open the queue", d.npUpNext) { v -> c.store.update { it.copy(npUpNext = v) } }
        SwitchRow("Audio format pill", "Format, sample rate and bitrate above the seek bar; tap for song info", d.uiSpecPill) { v -> c.store.update { it.withUi(UI_SPEC, v) } }
        SwitchRow("Scrolling long titles", "Title and artist slide sideways when they do not fit", d.uiMarquee) { v -> c.store.update { it.withUi(UI_MARQUEE, v) } }
        SwitchRow("Cover carousel", "Previous and next covers peek in beside the current one while you swipe (square cover style)", d.uiCarousel) { v -> c.store.update { it.withUi(UI_CAROUSEL, v) } }
        DepSwitchRow("Pure black for Fluid mesh", "True black behind the Fluid mesh background", d.uiAmoled, d.nowBg == 7, "Fluid mesh background (Now Playing, palette button)") { v -> c.store.update { it.withUi(UI_AMOLED, v) } }
    }
    CollapsibleGroup("Library", startOpen = false) {
        SwitchRow("Fast scroller", "A-Z strip with a letter bubble on long song lists", d.uiFastScroll) { v -> c.store.update { it.withUi(UI_FASTSCROLL, v) } }
        SwitchRow("Collapsing headers", "Album and artist pages open with a big cover that shrinks as you scroll, plus a Shuffle button", d.uiCollapseHeader) { v -> c.store.update { it.withUi(UI_COLLAPSE, v) } }
    }
    CollapsibleGroup("Fonts", startOpen = false) {
        ChipRow("Font pairing") {
            FONT_PRESETS.forEachIndexed { i, n -> FilterChip(d.uiFont == i, { c.store.update { it.copy(uiFont = i) } }, label = { Text(n) }) }
        }
    }
}

/** What a cover gesture can do. The index is the stored code. */
val COVER_ACTIONS = listOf("Nothing", "Next song", "Previous song", "Forward", "Back", "Favourite", "Lyrics", "Play / pause", "Shuffle")

fun coverAction(c: PlayerController, code: Int, openLyrics: () -> Unit) {
    when (code) {
        1 -> c.next()
        2 -> c.previous()
        3 -> c.fastForward()
        4 -> c.rewind()
        5 -> c.current?.let { c.store.toggleFavourite(it.id) }
        6 -> openLyrics()
        7 -> c.togglePlay()
        8 -> c.toggleShuffle()
    }
}
