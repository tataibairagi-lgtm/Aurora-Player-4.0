package com.aurora.player.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.rounded.Check
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

/** Things only the Activity can do (permission flows, system pickers). */
class Actions(
    val editTags: (Track, com.aurora.player.data.TagData) -> Unit,
    val importLyrics: () -> Unit,
    val importPlaylist: () -> Unit,
    val exportPlaylist: (String, List<Track>) -> Unit,
    val toggleOverlay: (Boolean) -> Unit,
    val rescan: () -> Unit,
    val chooseBackupFolder: () -> Unit,
    val backupNow: () -> Unit,
    val openRestore: () -> Unit,
    val browseBackup: () -> Unit,
    val loadBackup: (android.net.Uri, String) -> Unit,
    val applyRestore: (com.aurora.player.backup.LoadedBackup, com.aurora.player.backup.RestoreOptions) -> Unit,
    val ensureOverlayPermission: () -> Boolean,
    val pickBackground: () -> Unit,
    val saveText: (String, String, String) -> Unit, // file name, mime ("text/csv" or "audio/x-mpegurl"), content
    val saveArt: (Track) -> Unit,
    val deleteTracks: (List<Track>) -> Unit,
    val copyTracks: (List<Track>) -> Unit,
    val batchTags: (List<Track>, com.aurora.player.data.TagData) -> Unit,
    val embedArt: (List<Track>) -> Unit,
    val renameTrack: (Track, String) -> Unit,
    val moveTracks: (List<Track>, String) -> Unit,
    val renameFolder: (List<Track>, String, String) -> Unit, // tracks, old dir, new dir (both with trailing slash)
    val exportHistory: () -> Unit,
    val exportBookmarks: () -> Unit,
    val importBookmarks: () -> Unit,
    val pinShortcut: (String, String, String) -> Unit, // id, label, route
)

val LocalActions = compositionLocalOf<Actions> { error("Actions not provided") }

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun TrackRow(
    t: Track,
    c: PlayerController,
    modifier: Modifier = Modifier,
    extraMenu: List<Pair<String, () -> Unit>> = emptyList(),
    playCount: Int? = null,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    leading: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
) {
    val isCurrent = c.current?.id == t.id
    val picked = selected || t.id in c.selectedIdSet
    val toggleGlobal = { if (c.selection.any { it.id == t.id }) c.selection.removeAll { it.id == t.id } else c.selection.add(t); Unit }
    val bg by animateColorAsState(
        if (picked) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
        else if (isCurrent) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.background.copy(alpha = 0f),
        tween(300), label = "rowBg",
    )
    var menu by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    var tagDialog by remember { mutableStateOf(false) }
    var renameDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var infoDialog by remember { mutableStateOf(false) }
    val actions = LocalActions.current

    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .background(bg, RoundedCornerShape(14.dp))
            .combinedClickable(
                onClick = { if (onLongClick == null && c.selection.isNotEmpty()) toggleGlobal() else onClick() },
                onLongClick = onLongClick ?: toggleGlobal,
            )
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        leading?.invoke()
        Box(contentAlignment = Alignment.Center) {
            AlbumArt(t, Modifier.size(48.dp), RoundedCornerShape(12.dp), 22.dp)
            if (picked) {
                Box(
                    Modifier.size(48.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.7f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center,
                ) { Icon(androidx.compose.material.icons.Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.onPrimary) }
            } else if (isCurrent) {
                Box(
                    Modifier.size(48.dp).background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    EqualizerBars(c.isPlaying, androidx.compose.ui.graphics.Color.White, Modifier.size(20.dp))
                }
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Text(
                "${t.artist} · ${t.album}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (c.store.isFavourite(t.id)) {
            Icon(Icons.Rounded.Favorite, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
        }
        if (playCount != null) {
            // how many times it was played, as a coloured badge with the duration under it (like Musicolet)
            Column(Modifier.padding(start = 6.dp), horizontalAlignment = Alignment.End) {
                Box(
                    Modifier.defaultMinSize(minWidth = 26.dp, minHeight = 26.dp)
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(5.dp))
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(playCount.toString(), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                }
                Text(
                    formatTime(t.durationMs), style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp),
                )
            }
        } else {
            Text(
                formatTime(t.durationMs), style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 6.dp),
            )
        }
        Box {
            Box(Modifier.size(36.dp).bounceClick { menu = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.MoreVert, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Play next") }, onClick = { menu = false; c.playNext(t) })
                DropdownMenuItem(text = { Text("Add to queue") }, onClick = { menu = false; c.addToQueue(t) })
                DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { menu = false; addDialog = true })
                DropdownMenuItem(
                    text = { Text(if (c.store.isFavourite(t.id)) "Remove from favourites" else "Add to favourites") },
                    onClick = { menu = false; c.store.toggleFavourite(t.id) },
                )
                DropdownMenuItem(text = { Text("Song info") }, onClick = { menu = false; infoDialog = true })
                DropdownMenuItem(text = { Text("Edit tags") }, onClick = { menu = false; tagDialog = true })
                DropdownMenuItem(text = { Text("Rename file") }, onClick = { menu = false; renameDialog = true })
                DropdownMenuItem(text = { Text("Delete from device") }, onClick = { menu = false; deleteDialog = true })
                extraMenu.forEach { (label, act) ->
                    DropdownMenuItem(text = { Text(label) }, onClick = { menu = false; act() })
                }
            }
        }
    }
    if (infoDialog) SongInfoDialog(c, t, { tagDialog = true }) { infoDialog = false }
    if (deleteDialog) androidx.compose.material3.AlertDialog(
        onDismissRequest = { deleteDialog = false },
        title = { Text("Delete this song?") },
        text = { Text("“${t.title}” will be permanently removed from your device. This can't be undone.") },
        confirmButton = { androidx.compose.material3.TextButton({ deleteDialog = false; actions.deleteTracks(listOf(t)) }) { Text("Delete") } },
        dismissButton = { androidx.compose.material3.TextButton({ deleteDialog = false }) { Text("Cancel") } },
    )
    if (addDialog) AddToPlaylistDialog(c, listOf(t.id)) { addDialog = false }
    if (renameDialog) NameDialog("Rename file", t.path.substringAfterLast('/').substringBeforeLast('.'), "Rename", { renameDialog = false }) { n ->
        renameDialog = false; actions.renameTrack(t, n)
    }
    if (tagDialog) TagEditorDialog(t, { tagDialog = false }) { data ->
        tagDialog = false
        actions.editTags(t, data)
    }
}

@Composable
fun AddToPlaylistDialog(c: PlayerController, ids: List<Long>, onDismiss: () -> Unit) {
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist") },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 240.dp)) {
                    items(c.store.data.playlists, key = { it.id }) { p ->
                        Text(
                            "${p.name}  (${p.trackIds.size})",
                            Modifier.fillMaxWidth().clickable { c.store.addToPlaylist(p.id, ids); onDismiss() }.padding(vertical = 12.dp),
                        )
                    }
                }
                OutlinedTextField(
                    newName, { newName = it }, label = { Text("New playlist") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (newName.isNotBlank()) { c.store.createPlaylist(newName, ids); onDismiss() } },
                enabled = newName.isNotBlank(),
            ) { Text("Create & add") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun TagEditorDialog(t: Track, onDismiss: () -> Unit, onSave: (com.aurora.player.data.TagData) -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val loaded by androidx.compose.runtime.produceState<com.aurora.player.data.TagData?>(null, t.id) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { com.aurora.player.data.TagIo.read(ctx, t) }
    }
    val d = loaded
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit tags") },
        text = {
            if (d == null) {
                Text("Reading tags…")
            } else {
                var title by remember { mutableStateOf(d.title) }
                var artist by remember { mutableStateOf(d.artist) }
                var album by remember { mutableStateOf(d.album) }
                var albumArtist by remember { mutableStateOf(d.albumArtist) }
                var genre by remember { mutableStateOf(d.genre) }
                var year by remember { mutableStateOf(d.year) }
                var track by remember { mutableStateOf(d.track) }
                var lyrics by remember { mutableStateOf(d.lyrics) }
                var disc by remember { mutableStateOf(d.disc) }
                var composer by remember { mutableStateOf(d.composer) }
                // keep the latest edits where the confirm button can reach them
                androidx.compose.runtime.SideEffect {
                    pending = d.copy(title = title, artist = artist, album = album, albumArtist = albumArtist, genre = genre, year = year, track = track, lyrics = lyrics, disc = disc, composer = composer)
                }
                Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(artist, { artist = it }, label = { Text("Artist") }, singleLine = true)
                    OutlinedTextField(album, { album = it }, label = { Text("Album") }, singleLine = true)
                    OutlinedTextField(albumArtist, { albumArtist = it }, label = { Text("Album artist") }, singleLine = true)
                    OutlinedTextField(genre, { genre = it }, label = { Text("Genre") }, singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(year, { year = it }, label = { Text("Year") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(track, { track = it }, label = { Text("Track #") }, singleLine = true, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(disc, { disc = it }, label = { Text("Disc #") }, singleLine = true, modifier = Modifier.weight(1f))
                        OutlinedTextField(composer, { composer = it }, label = { Text("Composer") }, singleLine = true, modifier = Modifier.weight(1.6f))
                    }
                    OutlinedTextField(lyrics, { lyrics = it }, label = { Text("Embedded lyrics") }, minLines = 3, maxLines = 6)
                    TextButton({
                        title = cleanTag(title); artist = cleanTag(artist); album = cleanTag(album)
                        albumArtist = cleanTag(albumArtist); genre = cleanTag(genre)
                    }) { Text("Remove website names and junk from tags") }
                    Text(
                        "Saved inside the audio file (and in the media library). Android will ask for permission once per file.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        },
        confirmButton = { TextButton({ pending?.let(onSave) }, enabled = d != null) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

private var pending: com.aurora.player.data.TagData? = null

private val junk = Regex(
    "(?i)(https?://\\S+|www\\.\\S+|\\b[\\w-]+\\.(com|net|org|info|biz|in|co|me|io|ru|pk|ws|cc|tv|fm|to)\\b|downloaded\\s+(from|by)\\s+\\S+|\\[\\s*\\]|\\(\\s*\\))"
)

/** Strips website addresses, "downloaded from…" and empty brackets from a tag value. */
fun cleanTag(s: String): String =
    s.replace(junk, " ").replace(Regex("\\s{2,}"), " ").trim().trim('-', '_', '|', '~', ' ')


@Composable
fun NameDialog(title: String, initial: String = "", confirm: String = "OK", onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton({ if (v.isNotBlank()) onOk(v) }, enabled = v.isNotBlank()) { Text(confirm) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

/** Edits several songs at once. Fields left empty are not touched. */
@Composable
fun BatchTagDialog(count: Int, onDismiss: () -> Unit, onSave: (com.aurora.player.data.TagData) -> Unit) {
    var artist by remember { mutableStateOf("") }
    var album by remember { mutableStateOf("") }
    var albumArtist by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    var composer by remember { mutableStateOf("") }
    var disc by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit tags of $count songs") },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Only the fields you fill in are changed.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(artist, { artist = it }, label = { Text("Artist") }, singleLine = true)
                OutlinedTextField(album, { album = it }, label = { Text("Album") }, singleLine = true)
                OutlinedTextField(albumArtist, { albumArtist = it }, label = { Text("Album artist") }, singleLine = true)
                OutlinedTextField(genre, { genre = it }, label = { Text("Genre") }, singleLine = true)
                OutlinedTextField(composer, { composer = it }, label = { Text("Composer") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(year, { year = it }, label = { Text("Year") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(disc, { disc = it }, label = { Text("Disc #") }, singleLine = true, modifier = Modifier.weight(1f))
                }
            }
        },
        confirmButton = {
            TextButton({
                onSave(com.aurora.player.data.TagData(artist = artist.trim(), album = album.trim(), albumArtist = albumArtist.trim(), genre = genre.trim(), year = year.trim(), composer = composer.trim(), disc = disc.trim()))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}
