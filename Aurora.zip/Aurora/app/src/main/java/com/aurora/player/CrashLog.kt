package com.aurora.player

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps the last crash / playback error in a small file so it can be read in Settings > About (no computer needed). */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_error.txt")

    fun install(ctx: Context) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            write(ctx, "Crash in thread ${t.name}", e)
            try {
                ctx.startActivity(
                    android.content.Intent(ctx, CrashActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        .putExtra("trace", "Crash in thread ${t.name}\n" + android.util.Log.getStackTraceString(e).take(12000)),
                )
                Thread.sleep(1500)
            } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    /**
     * Android remembers why an app's last process ended. A sudden stop with no error message is usually the system
     * killing the app (low memory, battery saver) or an app-not-responding; this notes that so it shows in Settings > About.
     */
    fun recordLastExit(ctx: Context) {
        if (android.os.Build.VERSION.SDK_INT < 30) return
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val r = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 1).firstOrNull() ?: return
            val why = when (r.reason) {
                android.app.ApplicationExitInfo.REASON_ANR -> "The app stopped responding (ANR)"
                android.app.ApplicationExitInfo.REASON_CRASH -> "A crash in the app"
                android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "A native (low-level) crash"
                android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> "Android closed the app because the phone ran low on memory"
                android.app.ApplicationExitInfo.REASON_SIGNALED -> "Android ended the app process"
                android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "Android closed the app for using too many resources"
                android.app.ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "A system service the app needs stopped"
                android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "The app failed to start"
                else -> return // closed by the user or by the app itself: nothing to report
            }
            val f = file(ctx)
            if (f.exists() && f.lastModified() >= r.timestamp) return // a crash was already written for this one
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(r.timestamp))
            f.writeText("$time\nLast time Aurora stopped: $why\n${r.description.orEmpty()}")
        } catch (_: Throwable) {}
    }

    fun write(ctx: Context, what: String, e: Throwable) {
        try {
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val text = "$time\n$what\n${android.util.Log.getStackTraceString(e).take(8000)}"
            file(ctx).writeText(text)
            copyToDownloads(ctx, text)
        } catch (_: Throwable) {}
    }

    /** Also leaves the report in Downloads as Aurora_crash.txt, so it can be opened from the Files app even when Aurora will not start. */
    private fun copyToDownloads(ctx: Context, text: String) {
        try {
            val r = ctx.contentResolver
            val coll = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI
            r.query(coll, arrayOf(android.provider.MediaStore.MediaColumns._ID), "${android.provider.MediaStore.MediaColumns.DISPLAY_NAME}=?", arrayOf("Aurora_crash.txt"), null)?.use { c ->
                while (c.moveToNext()) try { r.delete(android.content.ContentUris.withAppendedId(coll, c.getLong(0)), null, null) } catch (_: Throwable) {}
            }
            val v = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "Aurora_crash.txt")
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = r.insert(coll, v) ?: return
            r.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
        } catch (_: Throwable) {}
    }

    fun read(ctx: Context): String = try { file(ctx).takeIf { it.exists() }?.readText().orEmpty() } catch (_: Throwable) { "" }
    fun clear(ctx: Context) { try { file(ctx).delete() } catch (_: Throwable) {} }
}
