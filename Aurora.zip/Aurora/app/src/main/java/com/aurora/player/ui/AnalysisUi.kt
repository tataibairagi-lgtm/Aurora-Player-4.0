package com.aurora.player.ui

import androidx.compose.animation.core.withInfiniteAnimationFrameNanos
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurora.player.data.AutoEqRule
import com.aurora.player.data.UI_VIS_MIRROR
import com.aurora.player.data.UI_VIS_TALL
import com.aurora.player.data.UI_WAVE_THIN
import com.aurora.player.player.BpmAnalyzer
import com.aurora.player.player.PlayerController
import com.aurora.player.player.Waveform

/** A seek bar drawn as the song's own waveform: played bars are tinted, tap or drag to seek. */
@Composable
fun WaveformSeek(
    c: PlayerController, value: Float, max: Float, color: Color, trackColor: Color,
    onChange: (Float) -> Unit, onDone: () -> Unit,
) {
    val ctx = LocalContext.current
    val t = c.current
    val wave by produceState<FloatArray?>(null, t?.id) { this.value = if (t == null) null else Waveform.load(ctx, t) }
    Canvas(
        Modifier.fillMaxWidth().height(56.dp)
            .pointerInput(max) {
                detectTapGestures { p -> onChange((p.x / size.width).coerceIn(0f, 1f) * max); onDone() }
            }
            .pointerInput(max) {
                detectHorizontalDragGestures(
                    onDragStart = { p -> onChange((p.x / size.width).coerceIn(0f, 1f) * max) },
                    onDragEnd = { onDone() }, onDragCancel = { onDone() },
                ) { change, _ -> change.consume(); onChange((change.position.x / size.width).coerceIn(0f, 1f) * max) }
            },
    ) {
        val w = wave
        val n = w?.size ?: Waveform.BARS
        val slot = size.width / n
        val thin = c.store.data.uiWaveThin
        val bw = (slot * (if (thin) 0.3f else 0.62f)).coerceAtLeast(1.5f)
        val frac = if (max > 0f) (value / max).coerceIn(0f, 1f) else 0f
        for (i in 0 until n) {
            val a = w?.get(i) ?: 0.18f
            val h = (size.height * a).coerceAtLeast(4f)
            val x = i * slot + (slot - bw) / 2f
            drawRoundRect(
                if ((i + 0.5f) / n <= frac) color else trackColor,
                Offset(x, (size.height - h) / 2f), Size(bw, h), CornerRadius(bw / 2f),
            )
        }
    }
}

/** Live spectrum bars. Only analyses the sound while it is on screen. */
@Composable
fun SpectrumBars(c: PlayerController, modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary) {
    var tick by remember { mutableLongStateOf(0L) }
    DisposableEffect(Unit) { c.setVisualizer(true); onDispose { c.setVisualizer(false) } }
    LaunchedEffect(c.isPlaying) {
        while (true) { withInfiniteAnimationFrameNanos { tick = it }; if (!c.isPlaying) break }
    }
    val mirror = c.store.data.uiVisMirror
    val tall = c.store.data.uiVisTall
    Canvas(modifier.fillMaxWidth().height(if (tall) 72.dp else 40.dp)) {
        tick.let { }
        drawBars(c.spectrum(), color, mirror)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawBars(sp: FloatArray, color: Color, mirror: Boolean) {
    val n = sp.size.coerceAtLeast(1)
    val slot = size.width / n
    val bw = slot * 0.6f
    for (i in 0 until n) {
        val v = sp.getOrElse(i) { 0f }.coerceIn(0f, 1f)
        val h = (size.height * v).coerceAtLeast(3f)
        // quieter bars are fainter, loud ones glow
        val col = color.copy(alpha = 0.45f + 0.5f * v)
        val top = if (mirror) (size.height - h) / 2f else size.height - h
        drawRoundRect(col, Offset(i * slot + (slot - bw) / 2f, top), Size(bw, h), CornerRadius(bw / 2f))
    }
}

/** A small moving sample for the settings page, so the options show what they do. */
@Composable
private fun VisualizerPreview(mirror: Boolean, tall: Boolean) {
    var tick by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) { while (true) withInfiniteAnimationFrameNanos { tick = it } }
    val color = MaterialTheme.colorScheme.primary
    Canvas(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp).height(if (tall) 72.dp else 40.dp)) {
        val t = tick / 1_000_000_000f
        val sp = FloatArray(32) { i -> (0.55f + 0.45f * kotlin.math.sin(t * 3f + i * 0.5f)) * (1f - i / 48f) * (0.6f + 0.4f * kotlin.math.sin(t * 1.7f + i * 1.3f)) }
        drawBars(sp, color, mirror)
    }
}

@Composable
private fun WaveformPreview(thin: Boolean) {
    val color = MaterialTheme.colorScheme.primary
    val rest = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f)
    Canvas(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp).height(48.dp)) {
        val n = 56
        val slot = size.width / n
        val bw = slot * (if (thin) 0.3f else 0.62f)
        for (i in 0 until n) {
            val a = 0.25f + 0.7f * kotlin.math.abs(kotlin.math.sin(i * 0.37f) * kotlin.math.cos(i * 0.11f + 1f))
            val h = size.height * a
            drawRoundRect(if (i < 22) color else rest, Offset(i * slot + (slot - bw) / 2f, (size.height - h) / 2f), Size(bw, h), CornerRadius(bw / 2f))
        }
    }
}

@Composable
fun AnalysisPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    Text(
        "Extras for the player and the equalizer. Everything here is off by default.",
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    CollapsibleGroup("Seek bar", startOpen = true) {
        SwitchWithOptions(
            "Waveform seek bar", "Shows the song's own waveform as the seek bar. It is drawn the first time a song plays", d.uiWaveform,
            { v -> c.store.update { it.copy(uiWaveform = v) } },
        ) {
            WaveformPreview(d.uiWaveThin)
            SwitchRow("Thin lines", "Narrower bars with more space between them", d.uiWaveThin) { v -> c.store.update { it.withUi(UI_WAVE_THIN, v) } }
        }
    }
    CollapsibleGroup("Tempo scan (BPM)") {
        val scanned = d.bpm.size
        ActionRow(
            if (BpmAnalyzer.running) "Stop scanning" else "Scan my library for tempo",
            if (BpmAnalyzer.running) "${BpmAnalyzer.done} of ${BpmAnalyzer.total} songs" else "$scanned of ${c.library.size} songs done. Runs while the app is open; adds the Workout and Late night mixes",
        ) { if (BpmAnalyzer.running) BpmAnalyzer.stop() else BpmAnalyzer.start(c, ctx) }
        if (BpmAnalyzer.running && BpmAnalyzer.total > 0) {
            LinearProgressIndicator(
                progress = { BpmAnalyzer.done.toFloat() / BpmAnalyzer.total }, modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 4.dp),
            )
        }
    }
    CollapsibleGroup("Auto equalizer", startOpen = d.autoEqOn) {
        var adding by remember { mutableStateOf(false) }
        SwitchWithOptions(
            "Pick the equalizer automatically", "Switch to a preset when a device is connected or a genre plays. The first matching rule wins", d.autoEqOn,
            { v -> c.store.update { it.copy(autoEqOn = v) }; c.applyActiveProfile() },
        ) {
            d.autoEq.forEachIndexed { i, r ->
                ActionRow(
                    (if (r.kind == "device") "Device: " else "Genre: ") + r.match, "Use ${r.preset}. Tap to remove",
                ) { c.store.update { it.copy(autoEq = it.autoEq.filterIndexed { j, _ -> j != i }) }; c.applyActiveProfile() }
            }
            ActionRow("Add a rule", "For example: device 'Sony' uses Bass, genre 'Classical' uses Classic") { adding = true }
        }
        if (adding) AddRuleDialog(c, onClose = { adding = false })
    }
}

@Composable
private fun AddRuleDialog(c: PlayerController, onClose: () -> Unit) {
    var kind by remember { mutableStateOf("device") }
    var match by remember { mutableStateOf("") }
    var preset by remember { mutableStateOf("Bass") }
    val names = EQ_PRESETS.map { it.first } + c.store.data.customPresets.map { it.name }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("New equalizer rule") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(kind == "device", { kind = "device" }, label = { Text("Device") })
                    FilterChip(kind == "genre", { kind = "genre" }, label = { Text("Genre") })
                }
                OutlinedTextField(
                    match, { match = it }, singleLine = true,
                    label = { Text(if (kind == "device") "Part of the device name" else "Part of the genre") },
                )
                Text("Preset", style = MaterialTheme.typography.labelLarge)
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(names.size) { i ->
                        FilterChip(preset == names[i], { preset = names[i] }, label = { Text(names[i]) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                if (match.isNotBlank()) {
                    c.store.update { it.copy(autoEq = it.autoEq + AutoEqRule(kind, match.trim(), preset)) }
                    c.applyActiveProfile()
                }
                onClose()
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClose) { Text("Cancel") } },
    )
}
