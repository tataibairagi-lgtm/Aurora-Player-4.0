package com.aurora.player.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File

/**
 * Saves .lrc files next to songs through a music folder the person picked once (Android's folder picker).
 * Android 10 and later do not let an app write plain files into other apps' folders without that, so this is the way
 * that works without the "All files access" switch.
 */
object LrcTree {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("aurora_lrc", Context.MODE_PRIVATE)

    fun trees(ctx: Context): List<Uri> = prefs(ctx).getStringSet("trees", emptySet()).orEmpty().map { Uri.parse(it) }

    fun add(ctx: Context, uri: Uri) {
        val all = prefs(ctx).getStringSet("trees", emptySet()).orEmpty().toMutableSet()
        all.add(uri.toString())
        prefs(ctx).edit().putStringSet("trees", all).apply()
    }

    /** Writes (or, for blank text, removes) the .lrc next to [t]. False if no picked folder covers the song or Android refused. */
    fun write(ctx: Context, t: Track, text: String): Boolean {
        val file = File(t.path)
        val dir = file.parent ?: return false
        val name = file.nameWithoutExtension + ".lrc"
        val cr = ctx.contentResolver
        for (tree in trees(ctx)) {
            try {
                val docId = DocumentsContract.getTreeDocumentId(tree)
                val vol = docId.substringBefore(':')
                val base = docId.substringAfter(':').trim('/')
                val root = if (vol == "primary") "/storage/emulated/0" else "/storage/$vol"
                val basePath = if (base.isEmpty()) root else "$root/$base"
                if (dir != basePath && !dir.startsWith("$basePath/")) continue
                val rel = dir.removePrefix(basePath).trim('/')
                val parentId = when {
                    rel.isEmpty() -> docId
                    docId.endsWith(":") -> docId + rel
                    else -> "$docId/$rel"
                }
                val fileId = if (parentId.endsWith(":")) parentId + name else "$parentId/$name"
                val fileUri = DocumentsContract.buildDocumentUriUsingTree(tree, fileId)
                val exists = try { cr.query(fileUri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { it.moveToFirst() } == true } catch (_: Throwable) { false }
                if (text.isBlank()) {
                    if (exists) DocumentsContract.deleteDocument(cr, fileUri)
                    return true
                }
                val target = if (exists) fileUri else {
                    val parentUri = DocumentsContract.buildDocumentUriUsingTree(tree, parentId)
                    DocumentsContract.createDocument(cr, parentUri, "application/octet-stream", name) ?: continue
                }
                cr.openOutputStream(target, "wt")?.use { it.write(text.toByteArray()) } ?: continue
                return true
            } catch (_: Throwable) { /* try the next folder */ }
        }
        return false
    }
}
