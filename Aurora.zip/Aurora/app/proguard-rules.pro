# Aurora R8 rules
-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod
-dontwarn java.awt.**
-dontwarn javax.imageio.**
-dontwarn javax.swing.**
-dontwarn java.beans.**
-dontwarn org.jaudiotagger.**
-keep class org.jaudiotagger.** { *; }
-keep class com.aurora.player.data.** { *; }
-keep class com.aurora.player.backup.** { *; }
-keepclassmembers class **$$serializer { *; }
-keepclasseswithmembers class * { kotlinx.serialization.KSerializer serializer(...); }
-dontwarn kotlinx.serialization.**

# Media3: keep the player library intact (reflection-based renderers/extractors), and Aurora's own player classes
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**
-keep class com.aurora.player.player.** { *; }
-keep class com.aurora.player.CrashLog { *; }
