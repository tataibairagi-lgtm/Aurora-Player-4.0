package com.aurora.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Bookmark
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

/** Saves the current position of the playing song with an optional note. */
@Composable
fun AddBookmarkDialog(c: PlayerController, onDismiss: () -> Unit) {
    val t = c.current ?: run { onDismiss(); return }
    val pos = remember { c.positionMs }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add bookmark at ${formatTime(pos)}") },
        text = {
            Column {
                Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    note, { note = it }, label = { Text("Note (optional)") }, minLines = 2, maxLines = 5,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            TextButton({
                val b = Bookmark("bm" + System.currentTimeMillis(), t.id, pos, note.trim(), System.currentTimeMillis())
                c.store.update { it.copy(bookmarks = it.bookmarks + b) }
                onDismiss()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

/** All bookmarks. Tap one to jump to that spot in the song. */
@Composable
fun BookmarksDialog(c: PlayerController, onDismiss: () -> Unit) {
    val actions = LocalActions.current
    val list = c.store.data.bookmarks.sortedByDescending { it.created }
    val byId = c.library.associateBy { it.id }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bookmarks (${list.size})") },
        text = {
            if (list.isEmpty()) {
                Text("No bookmarks yet. Use “Add bookmark” in the ⋮ menu on Now playing to mark a spot and write a note.")
            } else {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(list, key = { it.id }) { b ->
                        val t = byId[b.trackId]
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = t != null) {
                                if (t != null) { c.playFromSource("Bookmark", listOf(t), 0, false); c.seekTo(b.posMs); onDismiss() }
                            }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(t?.title ?: "(song not found)", maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    formatTime(b.posMs) + if (b.note.isNotBlank()) "  ·  " + b.note else "",
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2,
                                )
                            }
                            Icon(
                                Icons.Rounded.Close, "Delete",
                                Modifier.size(22.dp).clickable { c.store.update { p -> p.copy(bookmarks = p.bookmarks.filter { it.id != b.id }) } },
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } },
        dismissButton = {
            Row {
                TextButton({ actions.exportBookmarks() }) { Text("Export") }
                TextButton({ actions.importBookmarks() }) { Text("Import") }
            }
        },
    )
}
