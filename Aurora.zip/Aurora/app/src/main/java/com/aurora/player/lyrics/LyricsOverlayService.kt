package com.aurora.player.lyrics

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.aurora.player.controller
import com.aurora.player.data.indexAt

/**
 * Floating "desktop lyrics": a small draggable window over every app.
 * Built from plain Android views (no Compose) so it is light, never leaks and can't crash the host.
 */
class LyricsOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var title: TextView
    private lateinit var prev: TextView
    private lateinit var cur: TextView
    private lateinit var next: TextView
    private lateinit var playBtn: TextView
    private lateinit var lockBtn: TextView

    private var lastKey = ""
    private var lastSp = -1
    private var lastColor = 0

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

    private fun button(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        gravity = Gravity.CENTER
        val p = dp(9f).toInt()
        setPadding(p, p / 2, p, p / 2)
        setOnClickListener { onClick() }
    }

    private fun lineView(): TextView = TextView(this).apply {
        gravity = Gravity.CENTER
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val c = controller
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val bg = GradientDrawable().apply { cornerRadius = dp(20f); setColor(0xCC0D0D17.toInt()) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            val p = dp(12f).toInt()
            setPadding(p, p / 2, p, p)
        }

        title = TextView(this).apply {
            setTextColor(0x99FFFFFF.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        playBtn = button("▶") { c.togglePlay() }
        val strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title)
            addView(button("⏮") { c.previous() })
            addView(playBtn)
            addView(button("⏭") { c.next() })
            addView(button("A−") { c.store.update { it.copy(overlayTextSp = (it.overlayTextSp - 2).coerceAtLeast(12)) } })
            addView(button("A+") { c.store.update { it.copy(overlayTextSp = (it.overlayTextSp + 2).coerceAtMost(48)) } })
            lockBtn = button(if (c.store.data.overlayLocked) "🔒" else "🔓") {
                val now = !c.store.data.overlayLocked
                c.store.update { it.copy(overlayLocked = now) }
                lockBtn.text = if (now) "🔒" else "🔓"
            }
            addView(lockBtn)
            addView(button("✕") { stopSelf() })
        }
        prev = lineView(); cur = lineView(); next = lineView()
        cur.setTypeface(Typeface.DEFAULT_BOLD)
        box.addView(strip)
        box.addView(prev); box.addView(cur); box.addView(next)

        // dragging: touch anywhere on the card that isn't a button
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> if (c.store.data.overlayLocked) false else { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; true }
                MotionEvent.ACTION_MOVE -> if (c.store.data.overlayLocked) false else {
                    lp.x = startX + (e.rawX - downX).toInt()
                    lp.y = startY + (e.rawY - downY).toInt()
                    try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { c.store.update { it.copy(overlayX = lp.x, overlayY = lp.y) }; true }
                else -> false
            }
        }

        val width = (resources.displayMetrics.widthPixels * 0.94f).toInt()
        lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = c.store.data.overlayX.coerceAtLeast(0)
            y = c.store.data.overlayY
        }
        root = box
        try { wm.addView(box, lp) } catch (_: Exception) { stopSelf(); return }
        c.overlayActive = true
        handler.post(tick)
    }

    /** Redraws only what changed, a few times a second. */
    private val tick = object : Runnable {
        override fun run() {
            try { refresh() } catch (_: Exception) {}
            handler.postDelayed(this, 250)
        }
    }

    private fun refresh() {
        val c = controller
        val d = c.store.data
        if (d.overlayTextSp != lastSp || d.overlayColor.toInt() != lastColor) {
            lastSp = d.overlayTextSp; lastColor = d.overlayColor.toInt()
            val col = d.overlayColor.toInt()
            cur.setTextColor(col); prev.setTextColor((col and 0x00FFFFFF) or 0x66000000); next.setTextColor((col and 0x00FFFFFF) or 0x66000000)
            cur.setTextSize(TypedValue.COMPLEX_UNIT_SP, d.overlayTextSp.toFloat())
            prev.setTextSize(TypedValue.COMPLEX_UNIT_SP, d.overlayTextSp * 0.62f)
            next.setTextSize(TypedValue.COMPLEX_UNIT_SP, d.overlayTextSp * 0.62f)
        }
        playBtn.text = if (c.isPlaying) "⏸" else "▶"
        val t = c.current
        title.text = t?.let { it.title + " · " + it.artist } ?: "Aurora"

        val lyr = c.lyrics
        val p: String; val n: String; val m: String
        if (lyr == null || lyr.lines.isEmpty()) {
            p = ""; n = ""
            m = if (c.lyricsLoading) "Looking for lyrics…" else "No lyrics for this song"
        } else if (!lyr.synced) {
            p = ""; n = ""; m = lyr.lines.first().text
        } else {
            val i = lyr.indexAt(c.positionMs)
            p = lyr.lines.getOrNull(i - 1)?.text.orEmpty()
            m = if (i < 0) "♪" else lyr.lines[i].text.ifBlank { "♪" }
            n = lyr.lines.getOrNull(i + 1)?.text.orEmpty()
        }
        val key = "$p\u0000$m\u0000$n"
        if (key != lastKey) {
            lastKey = key
            prev.text = p; cur.text = m; next.text = n
            prev.visibility = if (p.isEmpty()) View.GONE else View.VISIBLE
            next.visibility = if (n.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != null && ::lockBtn.isInitialized) {
            lockBtn.text = if (controller.store.data.overlayLocked) "🔒" else "🔓"
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        controller.overlayActive = false
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_LOCK = "aurora.overlay.LOCK"
        const val ACTION_UNLOCK = "aurora.overlay.UNLOCK"

        fun start(ctx: Context) { ctx.startService(Intent(ctx, LyricsOverlayService::class.java)) }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, LyricsOverlayService::class.java)) }

        fun setLocked(ctx: Context, locked: Boolean) {
            ctx.controller.store.update { it.copy(overlayLocked = locked) }
            ctx.startService(Intent(ctx, LyricsOverlayService::class.java).setAction(if (locked) ACTION_LOCK else ACTION_UNLOCK))
        }
    }
}
