package com.aurora.player.player

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.aurora.player.lock.LockScreenActivity
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.CommandButton
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.aurora.player.MainActivity
import com.aurora.player.R
import com.aurora.player.controller

/** Keeps playback alive in the background and provides the media notification / lock-screen controls. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    /** When the screen turns off while music plays, queue up Aurora's lock-screen player (if enabled). */
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val c = context.controller
            if (!c.store.data.lockScreenPlayer || !c.isPlaying) return
            if (!Settings.canDrawOverlays(context)) return // this permission is what lets us start it from the background
            try {
                context.startActivity(
                    Intent(context, LockScreenActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            } catch (_: Exception) {
            }
        }
    }

    private val favCmd = SessionCommand("aurora.fav", Bundle.EMPTY)
    private val closeCmd = SessionCommand("aurora.close", Bundle.EMPTY)

    /** Heart (favourite) and close buttons shown next to the playback controls in the notification. */
    private fun layout(): ImmutableList<CommandButton> {
        val cur = controller.current
        val fav = cur != null && controller.store.isFavourite(cur.id)
        return ImmutableList.of(
            CommandButton.Builder().setDisplayName("Favourite")
                .setIconResId(if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart)
                .setSessionCommand(favCmd).build(),
            CommandButton.Builder().setDisplayName("Close")
                .setIconResId(R.drawable.ic_close)
                .setSessionCommand(closeCmd).build(),
        )
    }

    private val sessionCallback = object : MediaSession.Callback {
        override fun onConnect(session: MediaSession, info: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon().add(favCmd).add(closeCmd).build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session).setAvailableSessionCommands(cmds).build()
        }

        override fun onCustomCommand(
            session: MediaSession, info: MediaSession.ControllerInfo, customCommand: SessionCommand, args: Bundle,
        ): ListenableFuture<SessionResult> {
            val c = this@PlaybackService.controller
            when (customCommand.customAction) {
                "aurora.fav" -> {
                    c.current?.let { c.store.toggleFavourite(it.id) }
                    session.setCustomLayout(layout())
                }
                "aurora.close" -> {
                    c.player.pause()
                    stopSelf()
                }
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }

    override fun onCreate() {
        super.onCreate()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        setMediaNotificationProvider(AuroraNotificationProvider(this))
        val s = MediaSession.Builder(this, controller.player)
            .setSessionActivity(pi)
            .setCallback(sessionCallback)
            .setCustomLayout(layout())
            .build()
        session = s
        controller.player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { session?.setCustomLayout(layout()) }
        })
        addSession(s)
        ContextCompat.registerReceiver(this, screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (controller.store.data.stopOnTaskRemoved) {
            p?.pause()
            stopSelf()
        } else if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenOff) } catch (_: Exception) {}
        session?.release()
        session = null
        super.onDestroy()
    }
}
