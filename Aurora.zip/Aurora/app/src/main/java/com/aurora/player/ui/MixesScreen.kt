package com.aurora.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController
import kotlin.random.Random

class Mix(val name: String, val note: String, val tracks: List<Track>)

/** Builds the automatic mixes from the library, play counts, favourites and recent plays. [seed] changes the random picks. */
fun buildMixes(c: PlayerController, seed: Int): List<Mix> {
    val d = c.store.data
    val rnd = Random(seed)
    val lib = c.library
    if (lib.isEmpty()) return emptyList()
    val counts = d.playCounts
    val played = lib.filter { (counts[it.id] ?: 0) > 0 }.sortedByDescending { counts[it.id] ?: 0 }
    val favs = d.favourites.mapNotNull { c.track(it) }
    val recent = d.lastPlayed.take(60).toHashSet()
    val out = ArrayList<Mix>()
    fun add(name: String, note: String, list: List<Track>, min: Int = 5) {
        val l = list.distinctBy { it.id }
        if (l.size >= min) out += Mix(name, note, l)
    }

    // a bit of everything you like, plus a few surprises
    val daily = (played.take(80).shuffled(rnd).take(15) + favs.shuffled(rnd).take(9) + lib.shuffled(rnd).take(6)).distinctBy { it.id }.shuffled(rnd)
    add("Daily mix", "Your favourites and most played, with a few surprises", daily)
    add("Heavy rotation", "What you play the most", played.take(40).shuffled(rnd))
    add("Rediscover", "Songs you used to play a lot, not heard lately", played.filter { it.id !in recent }.take(60).shuffled(rnd).take(40))
    val month = System.currentTimeMillis() / 1000 - 30L * 86400
    add("Fresh finds", "Recently added songs you haven't played yet", lib.filter { it.dateAdded >= month && (counts[it.id] ?: 0) == 0 }.shuffled(rnd).take(40))
    add("Favourites mix", "Your hearted songs, shuffled", favs.shuffled(rnd).take(60))

    // top artists by plays
    val byArtist = HashMap<String, Int>()
    for (t in played) byArtist[t.artist] = (byArtist[t.artist] ?: 0) + (counts[t.id] ?: 0)
    byArtist.entries.sortedByDescending { it.value }.take(3).forEach { (a, _) ->
        add("$a mix", "More of $a", lib.filter { it.artist == a }.shuffled(rnd).take(30), 3)
    }
    // biggest genres
    lib.filter { it.genre.isNotBlank() }.groupBy { it.genre }.entries.sortedByDescending { it.value.size }.take(3).forEach { (g, l) ->
        add("$g mix", "$g songs from your library", l.shuffled(rnd).take(40), 8)
    }
    // decades
    lib.filter { it.year in 1950..2100 }.groupBy { it.year / 10 * 10 }.entries.sortedByDescending { it.value.size }.take(3).forEach { (dec, l) ->
        add("${dec}s mix", "Songs from the ${dec}s", l.shuffled(rnd).take(40), 10)
    }
    add("Quick 20", "Twenty random songs", lib.shuffled(rnd).take(20))
    return out
}

@Composable
fun MixesScreen(c: PlayerController, back: () -> Unit) {
    var seed by remember { mutableIntStateOf((System.currentTimeMillis() % 100000).toInt()) }
    val mixes = remember(c.library, seed, c.store.data.playCounts.size, c.store.data.favourites.size) { buildMixes(c, seed) }
    val colors = listOf(
        MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer,
        MaterialTheme.colorScheme.secondaryContainer,
    )
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).bounceClick(back), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Text("Smart mixes", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Box(Modifier.size(48.dp).bounceClick { seed += 1 }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Refresh, null) }
        }
        Text(
            "Made from your own listening. Tap refresh for a new set of picks.",
            Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (mixes.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Add some music and play a few songs, then your mixes will appear here.", Modifier.padding(32.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 140.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(mixes, key = { _, m -> m.name }) { i, m ->
                Row(
                    Modifier.fillMaxWidth().staggerIn(i).clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(listOf(colors[i % colors.size], MaterialTheme.colorScheme.surfaceVariant)))
                        .bounceClick { c.playFromSource(m.name, m.tracks, 0, false) }
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box {
                        AlbumArt(m.tracks.firstOrNull(), Modifier.size(84.dp), RoundedCornerShape(18.dp), 36.dp, px = 256)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                            Text(m.name, Modifier.padding(start = 6.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Text(m.note, Modifier.padding(top = 2.dp), style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${m.tracks.size} songs · ${formatTime(m.tracks.sumOf { it.durationMs })}", Modifier.padding(top = 4.dp),
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Box(
                        Modifier.size(40.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surface)
                            .bounceClick { c.playFromSource(m.name, m.tracks.shuffled(), 0, true) },
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.Shuffle, null, Modifier.size(20.dp)) }
                }
            }
        }
    }
}
