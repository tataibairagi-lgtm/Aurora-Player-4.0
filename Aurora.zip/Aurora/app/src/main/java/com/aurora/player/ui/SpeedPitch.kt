package com.aurora.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.aurora.player.player.PlayerController
import kotlin.math.roundToInt

private fun r2(v: Float) = (v * 100).roundToInt() / 100f

/** Play speed and pitch, for all songs or just for the playing one (like Musicolet). */
@Composable
fun SpeedPitchDialog(c: PlayerController, onDismiss: () -> Unit) {
    var advanced by remember { mutableStateOf(c.hasOwnSpeed) }
    var forFile by remember { mutableStateOf(c.hasOwnSpeed) }
    var overrideOwn by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var sp by remember { mutableStateOf(c.speed) }
    var pt by remember { mutableStateOf(c.pitch) }

    fun apply(s: Float, p: Float) {
        sp = r2(s.coerceIn(0.25f, 3f)); pt = r2(p.coerceIn(0.5f, 2f))
        if (advanced && forFile) c.setSpeedPitchForTrack(sp, pt) else c.setSpeedPitchForAll(sp, pt, advanced && overrideOwn)
    }

    @Composable
    fun Stepper(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
        Text(label, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(top = 10.dp))
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton({ onChange(value - 0.05f) }, shape = RoundedCornerShape(8.dp)) { Text("−") }
            Text("%.2f".format(value), Modifier.width(110.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleLarge)
            OutlinedButton({ onChange(value + 0.05f) }, shape = RoundedCornerShape(8.dp)) { Text("+") }
        }
        Slider(value.coerceIn(range.start, range.endInclusive), { onChange(it) }, valueRange = range)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (advanced) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(!forFile, { forFile = false; apply(c.store.data.speed, c.store.data.pitch); c.clearTrackSpeed() }, label = { Text("For all files") })
                        FilterChip(forFile, { forFile = true; apply(sp, pt) }, label = { Text("For this file only") })
                    }
                    if (!forFile) {
                        Box(Modifier.padding(top = 8.dp)) {
                            OutlinedButton({ menu = true }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(8.dp)) {
                                Text(
                                    if (overrideOwn) "including those files which have their own settings" else "but excluding those files which already have their own settings.",
                                    Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium,
                                )
                                Icon(Icons.Rounded.KeyboardArrowDown, null)
                            }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem(text = { Text("but excluding those files which already have their own settings.") }, onClick = { overrideOwn = false; menu = false })
                                DropdownMenuItem(text = { Text("including those files which have their own settings") }, onClick = { overrideOwn = true; menu = false; apply(sp, pt) })
                            }
                        }
                    }
                }
                Stepper("Play speed", sp, 0.25f..3f) { apply(it, pt) }
                Stepper("Pitch", pt, 0.5f..2f) { apply(sp, it) }
            }
        },
        confirmButton = {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!advanced, { advanced = false; forFile = false }, label = { Text("Simple") })
                FilterChip(advanced, { advanced = true }, label = { Text("Advanced") })
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton({ apply(1f, 1f) }, shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                        Icon(Icons.Rounded.RestartAlt, "Reset")
                    }
                    OutlinedButton(onDismiss, Modifier.padding(start = 8.dp), shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                        Icon(Icons.Rounded.Check, "OK")
                    }
                }
            }
        },
    )
}
