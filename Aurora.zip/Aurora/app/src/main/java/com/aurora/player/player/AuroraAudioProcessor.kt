package com.aurora.player.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/** Mono mix-down and left/right balance for 16-bit stereo audio. Other formats pass through untouched. */
@UnstableApi
class AuroraAudioProcessor : BaseAudioProcessor() {
    @Volatile var mono = false
    @Volatile var balance = 0 // -100 (left only) .. +100 (right only)

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        return if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT && inputAudioFormat.channelCount == 2) inputAudioFormat
        else AudioProcessor.AudioFormat.NOT_SET
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val out = replaceOutputBuffer(inputBuffer.remaining())
        val m = mono
        val b = balance
        val gl = if (b > 0) (100 - b) / 100f else 1f
        val gr = if (b < 0) (100 + b) / 100f else 1f
        while (inputBuffer.remaining() >= 4) {
            var l = inputBuffer.short.toInt()
            var r = inputBuffer.short.toInt()
            if (m) { val x = (l + r) / 2; l = x; r = x }
            out.putShort((l * gl).toInt().toShort())
            out.putShort((r * gr).toInt().toShort())
        }
        out.flip()
    }
}
