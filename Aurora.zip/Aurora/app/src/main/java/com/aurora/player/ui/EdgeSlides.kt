package com.aurora.player.ui

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** Slide up/down along the left edge for screen brightness and along the right edge for music volume. */
@Composable
fun EdgeSlides(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    var hud by remember { mutableStateOf<String?>(null) }
    var stamp by remember { mutableStateOf(0L) }
    LaunchedEffect(stamp) { if (stamp != 0L) { delay(900); hud = null } }
    Box(modifier.fillMaxSize()) {
        // brightness (left)
        Box(
            Modifier.align(Alignment.CenterStart).width(34.dp).fillMaxHeight(0.5f).pointerInput(Unit) {
                var cur = 0.5f
                detectVerticalDragGestures(
                    onDragStart = {
                        val w = (ctx as? Activity)?.window
                        val b = w?.attributes?.screenBrightness ?: -1f
                        cur = if (b < 0f) 0.5f else b
                    },
                    onVerticalDrag = { ch, dy ->
                        ch.consume()
                        cur = (cur - dy / size.height).coerceIn(0.02f, 1f)
                        (ctx as? Activity)?.window?.let { w -> val a = w.attributes; a.screenBrightness = cur; w.attributes = a }
                        hud = "Brightness ${(cur * 100).toInt()}%"; stamp = System.currentTimeMillis()
                    },
                )
            },
        )
        // volume (right)
        Box(
            Modifier.align(Alignment.CenterEnd).width(34.dp).fillMaxHeight(0.5f).pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() },
                    onVerticalDrag = { ch, dy ->
                        ch.consume()
                        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        acc = (acc - dy / size.height * max * 1.4f).coerceIn(0f, max.toFloat())
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, acc.toInt(), 0)
                        hud = "Volume ${(acc / max * 100).toInt()}%"; stamp = System.currentTimeMillis()
                    },
                )
            },
        )
        AnimatedVisibility(hud != null, Modifier.align(Alignment.TopCenter).padding(top = 110.dp), enter = fadeIn(), exit = fadeOut()) {
            Row(Modifier.background(Color.Black.copy(alpha = 0.72f), RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
                Text(hud ?: "", color = Color.White)
            }
        }
    }
}
