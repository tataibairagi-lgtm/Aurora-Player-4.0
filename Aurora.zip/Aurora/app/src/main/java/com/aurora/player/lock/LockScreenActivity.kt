package com.aurora.player.lock

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.layout.layout
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import com.aurora.player.controller
import com.aurora.player.data.formatTime
import com.aurora.player.data.indexAt
import com.aurora.player.player.PlayerController
import com.aurora.player.ui.AddToPlaylistDialog
import com.aurora.player.ui.AlbumArt
import com.aurora.player.ui.AuroraTheme
import com.aurora.player.ui.bounceClick
import com.aurora.player.ui.dominantColor
import com.aurora.player.ui.rememberArt
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Aurora's own lock-screen player: drawn over the system lock screen while music is playing. */
class LockScreenActivity : ComponentActivity() {
    private val unlocked = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        @Suppress("DEPRECATION")
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(7001) } catch (_: Exception) {}
        enableEdgeToEdge()
        ContextCompat.registerReceiver(this, unlocked, IntentFilter(Intent.ACTION_USER_PRESENT), ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent {
            AuroraTheme(2) { LockContent(controller, onUnlock = ::unlock) }
        }
    }

    private fun unlock() {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) {
            finish()
            return
        }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
        })
    }

    override fun onDestroy() {
        try { unregisterReceiver(unlocked) } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
private fun LockContent(c: PlayerController, onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val track = c.current
    var addDialog by remember { mutableStateOf(false) }
    val bmp = rememberArt(track)
    val accent by animateColorAsState((if (c.store.data.lockAdapt) bmp?.dominantColor() else null) ?: Color(0xFF4A3F8F), tween(800), label = "lockAccent")

    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(10_000) }
    }
    val time = remember(now) { DateFormat.getTimeFormat(ctx).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now)) }

    var showQueue by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    androidx.activity.compose.BackHandler(enabled = showLyrics || showQueue) { showLyrics = false; showQueue = false }
    val bob = rememberInfiniteTransition(label = "bob")
    val bobY by bob.animateFloat(0f, -14f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "bobY")

    Box(
        Modifier.fillMaxSize()
            .background(Color(0xFF0B0A12))
            .pointerInput(Unit) {
                var total = 0f
                var totalV = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total > 260f) onUnlock(); total = 0f },
                ) { _, dx -> total += dx }
            },
    ) {
        // background adapted from the cover: blurred art (Android 12+; plain art below that), tinted by its dominant colour
        if (c.store.data.lockAdapt) bmp?.let {
            // Modifier.blur does nothing below Android 12, so blur by shrinking and stretching the cover there
            val soft = androidx.compose.runtime.remember(it) {
                if (android.os.Build.VERSION.SDK_INT >= 31) it else try {
                    val small = android.graphics.Bitmap.createScaledBitmap(it, 12, 12, true)
                    android.graphics.Bitmap.createScaledBitmap(small, 96, 96, true)
                } catch (_: Throwable) { it }
            }
            androidx.compose.foundation.Image(
                soft.asImageBitmap(), null,
                if (android.os.Build.VERSION.SDK_INT >= 31) Modifier.fillMaxSize().blur(48.dp) else Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(accent.copy(alpha = 0.55f), Color(0xB30B0A12), Color(0xE60B0A12))),
            ),
        )
        val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val head: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Text(time, color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(top = 18.dp))
            Text(date, color = Color.White.copy(alpha = 0.75f), fontSize = 15.sp)

            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 18.dp), contentAlignment = Alignment.Center) {
                val scale by animateFloatAsState(if (c.isPlaying) 1f else 0.9f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "lockArt")
                AnimatedContent(
                    track?.id,
                    transitionSpec = { (scaleIn(tween(450), 0.85f) + fadeIn(tween(450))) togetherWith (scaleOut(tween(300), 0.85f) + fadeOut(tween(250))) },
                    label = "lockArtSwap",
                ) {
                    AlbumArt(track, Modifier.fitSquare(0.8f).scale(scale), RoundedCornerShape(30.dp), 72.dp, 800)
                }
            }

        }
        val body: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            AnimatedContent(
                track?.id,
                transitionSpec = {
                    (slideInVertically(tween(350)) { it / 2 } + fadeIn(tween(350))) togetherWith
                        (slideOutVertically(tween(250)) { -it / 2 } + fadeOut(tween(200)))
                },
                label = "lockTitle",
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(track?.title ?: "Nothing playing", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track?.artist ?: "", color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (track != null && track.album.isNotBlank()) Text(track.album, color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            // current + next lyric line (own composable so the per-tick position doesn't recompose the whole screen)
            LockLyrics(c) { showLyrics = true }

            var drag by remember { mutableStateOf<Float?>(null) }
            val dur = c.durationMs.coerceAtLeast(1L).toFloat()
            Slider(
                value = (drag ?: c.positionMs.toFloat()).coerceIn(0f, dur),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { c.seekTo(it.toLong()) }; drag = null },
                valueRange = 0f..dur,
                colors = run {
                    // the bar follows the app's appearance colour (lightened if it would vanish on the dark lock screen)
                    val base = c.store.data.accentColor.let { if (it != 0L) Color(it) else MaterialTheme.colorScheme.primary }
                    val on = if (androidx.core.graphics.ColorUtils.calculateLuminance(base.toArgb()) < 0.18) androidx.compose.ui.graphics.lerp(base, Color.White, 0.45f) else base
                    androidx.compose.material3.SliderDefaults.colors(thumbColor = on, activeTrackColor = on, inactiveTrackColor = on.copy(alpha = 0.28f))
                },
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime((drag ?: c.positionMs.toFloat()).toLong()), color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text(formatTime(c.durationMs), color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
            ) {
                LockIcon(Icons.Rounded.Shuffle, if (c.shuffle) Color.White else Color.White.copy(alpha = 0.45f)) { c.toggleShuffle() }
                LockIcon(Icons.Rounded.SkipPrevious, Color.White, 40.dp) { c.previous() }
                Box(
                    Modifier.size(72.dp).clip(CircleShape).background(Color.White).bounceClick { c.togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    AnimatedContent(
                        c.isPlaying,
                        transitionSpec = { (scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
                        label = "lockPlay",
                    ) { p -> Icon(if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color(0xFF0B0A12), modifier = Modifier.size(40.dp)) }
                }
                LockIcon(Icons.Rounded.SkipNext, Color.White, 40.dp) { c.next() }
                LockIcon(
                    if (c.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    if (c.repeatMode != Player.REPEAT_MODE_OFF) Color.White else Color.White.copy(alpha = 0.45f),
                ) { c.cycleRepeat() }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                LockIcon(Icons.AutoMirrored.Rounded.QueueMusic, Color.White.copy(alpha = 0.8f)) { showQueue = !showQueue }
                if (track != null) {
                    val fav = c.store.isFavourite(track.id)
                    LockIcon(
                        if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (fav) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.7f),
                    ) { c.store.toggleFavourite(track.id) }
                    LockIcon(Icons.AutoMirrored.Rounded.PlaylistAdd, Color.White.copy(alpha = 0.7f)) { addDialog = true }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp).offset { IntOffset(bobY.roundToInt().let { -it }, 0) },
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Swipe right to unlock", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                Icon(Icons.Rounded.KeyboardArrowRight, null, tint = Color.White.copy(alpha = 0.6f))
            }
        }
        if (land) {
            // landscape: clock and cover on the left, the player controls on the right
            Row(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 26.dp),
                horizontalArrangement = Arrangement.spacedBy(28.dp),
            ) {
                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) { head() }
                Column(
                    Modifier.weight(1f).fillMaxHeight().verticalScroll(androidx.compose.foundation.rememberScrollState()),
                    verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
                ) { body() }
            }
        } else {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) { head(); body() }
        }
        // queue viewer: slides over the lower part of the screen, tap a song to jump to it
        androidx.compose.animation.AnimatedVisibility(
            showQueue, modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(tween(300)) { it } + fadeIn(), exit = slideOutVertically(tween(250)) { it } + fadeOut(),
        ) {
            LockQueue(c) { showQueue = false }
        }
        // full-screen lyrics: tap the lyric lines under the album to open, tap the cross (or back) to close
        androidx.compose.animation.AnimatedVisibility(showLyrics, enter = fadeIn(tween(250)), exit = fadeOut(tween(200))) {
            LockLyricsFull(c) { showLyrics = false }
        }
        if (addDialog && track != null) AddToPlaylistDialog(c, listOf(track.id)) { addDialog = false }
    }
}

@Composable
private fun LockQueue(c: PlayerController, onClose: () -> Unit) {
    val state = androidx.compose.foundation.lazy.rememberLazyListState()
    androidx.compose.runtime.LaunchedEffect(Unit) { if (c.currentIndex > 2) state.scrollToItem(c.currentIndex - 1) }
    Column(
        Modifier.fillMaxWidth().fillMaxHeight(0.62f).clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
            .background(Color(0xF2121018)).navigationBarsPadding().padding(top = 8.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(c.store.data.queues.getOrNull(c.activeQueue)?.name ?: "Queue", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${c.queue.size} songs · ${formatTime(c.queue.sumOf { it.durationMs })}",
                    color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp,
                )
            }
            Box(Modifier.size(44.dp).bounceClick(onClose), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
        }
        androidx.compose.foundation.lazy.LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
            itemsIndexed(c.queue) { i, t ->
                val cur = i == c.currentIndex
                Row(
                    Modifier.fillMaxWidth().bounceClick { c.jumpTo(i) }
                        .background(if (cur) Color.White.copy(alpha = 0.12f) else Color.Transparent).padding(horizontal = 18.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        (i + 1).toString(), Modifier.width(34.dp).padding(end = 8.dp), color = if (cur) Color.White else Color.White.copy(alpha = 0.55f),
                        fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End, maxLines = 1,
                    )
                    AlbumArt(t, Modifier.size(44.dp), RoundedCornerShape(10.dp), 20.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(t.title, color = Color.White, fontWeight = if (cur) FontWeight.Bold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(t.artist, color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(formatTime(t.durationMs), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun LockIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, size: androidx.compose.ui.unit.Dp = 28.dp, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size))
    }
}

@Composable
private fun LockLyrics(c: PlayerController, onOpen: () -> Unit) {
    val lyr = c.lyrics
    if (!c.store.data.lockShowLyrics || lyr == null || !lyr.synced || lyr.lines.isEmpty()) {
        Spacer(Modifier.height(96.dp))
        return
    }
    val idx by remember(lyr) { androidx.compose.runtime.derivedStateOf { lyr.indexAt(c.lyricPosMs) } }
    androidx.compose.animation.AnimatedContent(
        targetState = idx,
        modifier = Modifier.padding(top = 10.dp).fillMaxWidth().height(104.dp).clickable { onOpen() },
        transitionSpec = { com.aurora.player.ui.lyricMotion(c.store.data.lyricMotion) },
        label = "lockLyricLines",
    ) { i ->
        val cur = lyr.lines.getOrNull(i)?.text.orEmpty().ifBlank { "♪" }
        val next = lyr.lines.getOrNull(i + 1)?.text.orEmpty()
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                cur, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Text(
                next, color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp, fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}


@Composable
private fun LockLyricsFull(c: PlayerController, onClose: () -> Unit) {
    val lyr = c.lyrics
    val state = androidx.compose.foundation.lazy.rememberLazyListState()
    val idx by remember(lyr) { androidx.compose.runtime.derivedStateOf { lyr?.indexAt(c.lyricPosMs) ?: -1 } }
    androidx.compose.runtime.LaunchedEffect(idx) { if (idx >= 0) try { state.animateScrollToItem((idx - 3).coerceAtLeast(0)) } catch (_: Throwable) {} }
    Column(Modifier.fillMaxSize().background(Color(0xF20B0A12)).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(c.current?.title ?: "", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(c.current?.artist ?: "", color = Color.White.copy(alpha = 0.65f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(Modifier.size(48.dp).bounceClick(onClose), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
        }
        if (lyr == null || lyr.lines.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("No lyrics for this song", color = Color.White.copy(alpha = 0.6f)) }
        } else androidx.compose.foundation.lazy.LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxWidth(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 26.dp, vertical = 40.dp)) {
            itemsIndexed(lyr.lines) { i, l ->
                val cur = i == idx
                Text(
                    l.text.ifBlank { "♪" }, Modifier.fillMaxWidth().padding(vertical = 9.dp),
                    color = if (cur || !lyr.synced) Color.White else Color.White.copy(alpha = 0.45f),
                    fontSize = if (cur) 26.sp else 22.sp, fontWeight = if (cur) FontWeight.Bold else FontWeight.Medium, textAlign = TextAlign.Center,
                )
            }
        }
    }
}

/** A square that fits the available width or height, whichever is smaller, times [frac]. */
private fun Modifier.fitSquare(frac: Float): Modifier = this.layout { m, c ->
    val side = (minOf(c.maxWidth, c.maxHeight) * frac).toInt().coerceAtLeast(0)
    val p = m.measure(androidx.compose.ui.unit.Constraints.fixed(side, side))
    layout(side, side) { p.place(0, 0) }
}
