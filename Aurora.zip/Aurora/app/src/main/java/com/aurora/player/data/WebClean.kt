package com.aurora.player.data

/** Removes website names and other junk ("[www.site.com]", "Downloaded from site.net", ...) from song tags, like Musicolet's "Hide extra things from tags". */
object WebClean {
    @Volatile var on = false

    private val tld = "(?:com|net|org|info|biz|xyz|pk|in|cc|me|fm|co|io|ws|tv)"
    private val site = Regex("(?i)(?:https?://|www\\.)[^\\s\\]\\)\\}]*|\\b[a-z0-9][a-z0-9-]{1,}\\.(?:com|net|org|info|biz|xyz|pk)\\b(?:/[^\\s\\]\\)\\}]*)?")
    private val bracketed = Regex("(?i)\\s*[\\[(\\{][^\\]\\)\\}]*(?:https?://|www\\.|\\.$tld\\b|download|free mp3)[^\\]\\)\\}]*[\\]\\)\\}]")
    private val lead = Regex("^[\\s\\-–—|_:~*.]+")
    private val trail = Regex("[\\s\\-–—|_:~*]+$")

    fun clean(s: String): String {
        if (!on || s.isEmpty()) return s
        var t = bracketed.replace(s, "")
        t = site.replace(t, "")
        t = t.replace(Regex("\\(\\s*\\)|\\[\\s*\\]"), "").replace(Regex("\\s{2,}"), " ")
        t = lead.replace(t, ""); t = trail.replace(t, "").trim()
        return if (t.isEmpty()) s else t
    }
}
