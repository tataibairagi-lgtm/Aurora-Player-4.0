package com.aurora.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.aurora.player.data.albumKey
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController
import kotlin.random.Random

class Mix(val name: String, val note: String, val tracks: List<Track>, val kind: String = "you")

/** Builds the automatic mixes from the library, play counts, favourites and recent plays. [seed] changes the random picks. */
fun buildMixes(c: PlayerController, seed: Int): List<Mix> {
    val d = c.store.data
    val rnd = Random(seed)
    // folders and playlists the user left out of Smart mixes
    val offIds = d.playlists.filter { it.id in d.mixExcludePlaylists }.flatMap { it.trackIds }.toHashSet()
    val lib = c.library.filter { t ->
        t.id !in offIds && d.mixExcludeFolders.none { f -> t.path.startsWith("$f/") }
    }
    if (lib.isEmpty()) return emptyList()
    val libIds = lib.map { it.id }.toHashSet()
    val size = d.mixSize.coerceIn(10, 100)
    val counts = d.playCounts
    val played = lib.filter { (counts[it.id] ?: 0) > 0 }.sortedByDescending { counts[it.id] ?: 0 }
    val favs = d.favourites.mapNotNull { c.track(it) }.filter { it.id in libIds }
    val recent = d.lastPlayed.take(60).toHashSet()
    val out = ArrayList<Mix>()
    fun add(name: String, note: String, list: List<Track>, min: Int = 5, kind: String = "you") {
        val l = list.distinctBy { it.id }
        if (l.size >= min) out += Mix(name, note, l, kind)
    }

    // a bit of everything you like, plus a few surprises
    val daily = (played.take(80).shuffled(rnd).take(15) + favs.shuffled(rnd).take(9) + lib.shuffled(rnd).take(6)).distinctBy { it.id }.shuffled(rnd)
    add("Daily mix", "Your favourites and most played, with a few surprises", daily)
    add("Heavy rotation", "What you play the most", played.take(size).shuffled(rnd))
    add("Rediscover", "Songs you used to play a lot, not heard lately", played.filter { it.id !in recent }.take(60).shuffled(rnd).take(size))
    val month = System.currentTimeMillis() / 1000 - 30L * 86400
    add("Fresh finds", "Recently added songs you haven't played yet", lib.filter { it.dateAdded >= month && (counts[it.id] ?: 0) == 0 }.shuffled(rnd).take(size))
    add("Favourites mix", "Your hearted songs, shuffled", favs.shuffled(rnd).take(size + 20))

    // top artists by plays
    val byArtist = HashMap<String, Int>()
    for (t in played) byArtist[t.artist] = (byArtist[t.artist] ?: 0) + (counts[t.id] ?: 0)
    byArtist.entries.sortedByDescending { it.value }.take(3).forEach { (a, _) ->
        add("$a mix", "More of $a", lib.filter { it.artist == a }.shuffled(rnd).take(30), 3, "artist")
    }
    // deep cuts of your top artists
    val topArtists = byArtist.entries.sortedByDescending { it.value }.take(5).map { it.key }.toHashSet()
    add("Deep cuts", "Songs you haven't played by the artists you love", lib.filter { it.artist in topArtists && (counts[it.id] ?: 0) == 0 }.shuffled(rnd).take(size), 5, "artist")
    // top albums
    val byAlbum = HashMap<String, Int>()
    for (t in played) byAlbum[t.albumKey()] = (byAlbum[t.albumKey()] ?: 0) + (counts[t.id] ?: 0)
    byAlbum.entries.sortedByDescending { it.value }.take(3).forEach { (k, _) ->
        val l = lib.filter { it.albumKey() == k }
        if (l.size >= 4) add(l.first().album.ifBlank { "Album" } + " (album)", "The whole album, in order", l.sortedBy { it.trackNo }, 4, "artist")
    }
    // biggest genres
    lib.filter { it.genre.isNotBlank() }.groupBy { it.genre }.entries.sortedByDescending { it.value.size }.take(3).forEach { (g, l) ->
        add("$g mix", "$g songs from your library", l.shuffled(rnd).take(size), 8, "genre")
    }
    // decades
    lib.filter { it.year in 1950..2100 }.groupBy { it.year / 10 * 10 }.entries.sortedByDescending { it.value.size }.take(3).forEach { (dec, l) ->
        add("${dec}s mix", "Songs from the ${dec}s", l.shuffled(rnd).take(size), 10, "genre")
    }
    // time based: what you actually played recently, and at this time of day
    val now = System.currentTimeMillis()
    val byId = lib.associateBy { it.id }
    val ev = c.playLog.events.filter { it.id in libIds }
    val weekCounts = ev.filter { it.at >= now - 7L * 86400_000 }.groupingBy { it.id }.eachCount()
    add("Last week on repeat", "What you played most in the last 7 days", weekCounts.entries.sortedByDescending { it.value }.mapNotNull { byId[it.key] }.take(size), 5)
    val monthCounts = ev.filter { it.at >= now - 30L * 86400_000 }.groupingBy { it.id }.eachCount()
    add("This month's top", "Your most played songs of the last 30 days", monthCounts.entries.sortedByDescending { it.value }.mapNotNull { byId[it.key] }.take(size), 8)
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    fun part(h: Int) = when (h) { in 5..11 -> 0; in 12..16 -> 1; in 17..21 -> 2; else -> 3 }
    val cal = java.util.Calendar.getInstance()
    val nowPart = part(hour)
    val atThisTime = ev.filter { cal.timeInMillis = it.at; part(cal.get(java.util.Calendar.HOUR_OF_DAY)) == nowPart }.groupingBy { it.id }.eachCount()
    val partName = listOf("Morning", "Afternoon", "Evening", "Late night")[nowPart]
    add("$partName mix", "Songs you tend to play at this time of day", atThisTime.entries.sortedByDescending { it.value }.mapNotNull { byId[it.key] }.shuffled(rnd).take(size), 6)
    // based on what is playing right now
    c.current?.let { cur ->
        if (cur.artist.isNotBlank()) add("More like ${cur.title}", "Same artist or genre as the song playing now", lib.filter { it.id != cur.id && (it.artist == cur.artist || (cur.genre.isNotBlank() && it.genre == cur.genre)) }.shuffled(rnd).take(size), 6)
    }
    add("Hidden gems", "Songs you have played only once or twice", lib.filter { (counts[it.id] ?: 0) in 1..2 }.shuffled(rnd).take(size), 8)
    add("Throwback", "The songs that have been in your library the longest", lib.sortedBy { it.dateAdded }.take(150).shuffled(rnd).take(size), 10)
    add("Unheard gems", "Songs you have never played", lib.filter { (counts[it.id] ?: 0) == 0 }.shuffled(rnd).take(size), 10, "quick")
    add("Short and sweet", "Songs under three minutes", lib.filter { it.durationMs in 30_000..179_999 }.shuffled(rnd).take(size), 10, "quick")
    add("Long listens", "Songs over five minutes", lib.filter { it.durationMs >= 300_000 }.shuffled(rnd).take(30), 6, "quick")
    add("Quick 20", "Twenty random songs", lib.shuffled(rnd).take(20), 5, "quick")
    return out
}

/** Four album covers in a 2x2 collage (or one cover when the mix has fewer albums). */
@Composable
internal fun MixCover(tracks: List<Track>, modifier: Modifier, radius: androidx.compose.ui.unit.Dp = 20.dp) {
    val arts = remember(tracks) { tracks.distinctBy { it.albumKey() }.take(4) }
    Box(modifier.clip(RoundedCornerShape(radius)), contentAlignment = Alignment.Center) {
        if (arts.size < 4) AlbumArt(tracks.firstOrNull(), Modifier.fillMaxSize(), RoundedCornerShape(0.dp), 36.dp, px = 384)
        else Column(Modifier.fillMaxSize()) {
            for (r in 0..1) Row(Modifier.weight(1f).fillMaxWidth()) {
                for (cI in 0..1) AlbumArt(arts[r * 2 + cI], Modifier.weight(1f).fillMaxSize(), RoundedCornerShape(0.dp), 18.dp, px = 192)
            }
        }
    }
}

@Composable
private fun mixColor(name: String): Color {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val hue = (name.hashCode().mod(360)).toFloat()
    return Color.hsl(hue, if (dark) 0.40f else 0.55f, if (dark) 0.22f else 0.90f)
}

@Composable
fun MixesScreen(c: PlayerController, back: () -> Unit) {
    var seed by remember { mutableIntStateOf((System.currentTimeMillis() % 100000).toInt()) }
    var showFilter by remember { androidx.compose.runtime.mutableStateOf(false) }
    val dd = c.store.data
    val mixes = remember(c.library, seed, dd.playCounts.size, dd.favourites.size, dd.mixExcludeFolders, dd.mixExcludePlaylists, dd.mixSize, c.playLog.events.size) { buildMixes(c, seed) }
    if (showFilter) MixFilterDialog(c) { showFilter = false }
    val hero = mixes.firstOrNull()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val sections = listOf(
        "Made for you" to mixes.drop(1).filter { it.kind == "you" },
        "Your artists" to mixes.filter { it.kind == "artist" },
        "Genres and decades" to mixes.filter { it.kind == "genre" },
        "Quick picks" to mixes.filter { it.kind == "quick" },
    ).filter { it.second.isNotEmpty() }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).bounceClick(back), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Text("Smart mixes", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Box(Modifier.size(48.dp).bounceClick { showFilter = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Tune, null) }
            Box(Modifier.size(48.dp).bounceClick { seed += 1 }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Refresh, null) }
        }
        if (hero == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Add some music and play a few songs, then your mixes will appear here.", Modifier.padding(32.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else LazyVerticalGrid(
            columns = GridCells.Fixed(2), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 140.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // the big card for the first mix
            item(span = { GridItemSpan(maxLineSpan) }) {
                val bg = mixColor(hero.name)
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                        .background(Brush.linearGradient(listOf(bg, MaterialTheme.colorScheme.surfaceVariant)))
                        .padding(16.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        MixCover(hero.tracks, Modifier.size(128.dp))
                        Column(Modifier.weight(1f).padding(start = 16.dp)) {
                            Text("MADE FOR YOU", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text(hero.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(hero.note, Modifier.padding(top = 2.dp), style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${hero.tracks.size} songs · ${formatTime(hero.tracks.sumOf { it.durationMs })}", Modifier.padding(top = 6.dp),
                                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                    Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primary)
                                .bounceClick { c.playFromSource(hero.name, hero.tracks, 0, false) }.padding(horizontal = 22.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.PlayArrow, null, tint = MaterialTheme.colorScheme.onPrimary)
                            Text("Play", Modifier.padding(start = 6.dp), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.SemiBold)
                        }
                        Row(
                            Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surface)
                                .bounceClick { c.store.createPlaylist(hero.name, hero.tracks.map { it.id }); android.widget.Toast.makeText(ctx, "Saved as a playlist", android.widget.Toast.LENGTH_SHORT).show() }.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.Save, null, Modifier.size(20.dp))
                            Text("Save", Modifier.padding(start = 6.dp), fontWeight = FontWeight.SemiBold)
                        }
                        Row(
                            Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surface)
                                .bounceClick { c.playFromSource(hero.name, hero.tracks.shuffled(), 0, true) }.padding(horizontal = 18.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.Shuffle, null, Modifier.size(20.dp))
                            Text("Shuffle", Modifier.padding(start = 6.dp), fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            sections.forEach { (title, list) ->
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(title, Modifier.padding(top = 10.dp, start = 4.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                items(list.size, key = { "${list[it].name}#$it" }) { i ->
                    val m = list[i]
                    Column(
                        Modifier.fillMaxWidth().staggerIn(i).clip(RoundedCornerShape(24.dp))
                            .background(mixColor(m.name)).bounceClick { c.playFromSource(m.name, m.tracks, 0, false) }.padding(10.dp),
                    ) {
                        Box {
                            MixCover(m.tracks, Modifier.fillMaxWidth().aspectRatio(1f))
                            Box(
                                Modifier.align(Alignment.BottomEnd).padding(8.dp).size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center,
                            ) { Icon(Icons.Rounded.PlayArrow, null, tint = MaterialTheme.colorScheme.onPrimary) }
                        }
                        Text(m.name, Modifier.padding(top = 8.dp, start = 4.dp), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            "${m.tracks.size} songs · ${formatTime(m.tracks.sumOf { it.durationMs })}", Modifier.padding(start = 4.dp, bottom = 2.dp),
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}

/** Choose which folders and playlists Smart mixes must ignore, and how long a mix is. */
@Composable
private fun MixFilterDialog(c: PlayerController, onClose: () -> Unit) {
    val d = c.store.data
    val folders = remember(c.library) { c.library.map { it.path.substringBeforeLast('/', "") }.filter { it.isNotEmpty() }.distinct().sorted() }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Smart mix settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Songs per mix: ${d.mixSize}", fontWeight = FontWeight.SemiBold)
                androidx.compose.material3.Slider(
                    d.mixSize.toFloat(), { v -> c.store.update { it.copy(mixSize = (Math.round(v / 5f) * 5)) } },
                    valueRange = 10f..100f, steps = 17,
                )
                Text("Exclude playlists", Modifier.padding(top = 8.dp), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                if (d.playlists.isEmpty()) Text("No playlists yet", style = MaterialTheme.typography.bodySmall)
                d.playlists.forEach { p ->
                    ExRow(p.name, p.id in d.mixExcludePlaylists) { on ->
                        c.store.update { it.copy(mixExcludePlaylists = if (on) (it.mixExcludePlaylists + p.id).distinct() else it.mixExcludePlaylists - p.id) }
                    }
                }
                Text("Exclude folders", Modifier.padding(top = 12.dp), fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                folders.forEach { f ->
                    ExRow(f.substringAfterLast('/') + "\n" + f, f in d.mixExcludeFolders) { on ->
                        c.store.update { it.copy(mixExcludeFolders = if (on) (it.mixExcludeFolders + f).distinct() else it.mixExcludeFolders - f) }
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onClose) { Text("Done") } },
    )
}

@Composable
private fun ExRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }, verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.material3.Checkbox(checked, onChange)
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}
