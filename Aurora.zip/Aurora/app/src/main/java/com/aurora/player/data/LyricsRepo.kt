package com.aurora.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object LrcParser {
    private val tag = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")

    private val wordTag = Regex("""<(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?>""")

    private fun toMs(min: String, sec: String, frac: String): Long =
        min.toLong() * 60_000 + sec.toLong() * 1000 + (if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong())

    /** Enhanced LRC: "<00:12.40>word <00:12.90>word" gives per-word times. */
    private fun splitWords(body: String): Pair<String, List<LyricWord>?> {
        val ms = wordTag.findAll(body).toList()
        if (ms.isEmpty()) return body to null
        val words = ArrayList<LyricWord>()
        val pre = body.substring(0, ms[0].range.first)
        for ((k, m) in ms.withIndex()) {
            val end = if (k + 1 < ms.size) ms[k + 1].range.first else body.length
            var txt = body.substring(m.range.last + 1, end)
            if (k == 0) txt = pre + txt
            if (txt.isEmpty()) continue
            words += LyricWord(toMs(m.groupValues[1], m.groupValues[2], m.groupValues[3]), txt)
        }
        val text = words.joinToString("") { it.text }.trim()
        return text to words.takeIf { it.isNotEmpty() }
    }

    fun parse(text: String): Lyrics? {
        val synced = ArrayList<LyricLine>()
        val plain = ArrayList<String>()
        for (raw in text.lines()) {
            val matches = tag.findAll(raw).toList()
            if (matches.isEmpty()) {
                val t = raw.trim()
                if (t.isNotEmpty() && !t.startsWith("[")) plain += t
                continue
            }
            val rawBody = raw.substring(matches.last().range.last + 1)
            val (body, words) = splitWords(rawBody.trim())
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                synced += LyricLine(min * 60_000 + sec * 1000 + ms, body, words)
            }
        }
        if (synced.isNotEmpty()) {
            // bilingual files repeat a timestamp: the second line (translation) rides along with the first
            val merged = ArrayList<LyricLine>()
            for (l in synced.sortedBy { it.timeMs }) {
                val prev = merged.lastOrNull()
                if (prev != null && prev.timeMs == l.timeMs && prev.text.isNotBlank() && l.text.isNotBlank() && prev.sub == null) merged[merged.lastIndex] = prev.copy(sub = l.text)
                else merged += l
            }
            return Lyrics(merged, true)
        }
        if (plain.isNotEmpty()) return Lyrics(plain.map { LyricLine(-1, it) }, false)
        return null
    }
}

class LyricsRepo(ctx: Context) {
    private val appCtx: Context = ctx.applicationContext
    val dir: File = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    private fun lrc(t: Track) = File(dir, "${t.id}.lrc")

    fun hasLocal(t: Track) = lrc(t).exists()

    fun save(t: Track, text: String) {
        lrc(t).writeText(text)
    }

    fun delete(t: Track) {
        lrc(t).delete()
    }

    /** Where Aurora writes the .lrc file: next to the song, same name. */
    private fun sidecar(t: Track) = File(t.path.substringBeforeLast('.') + ".lrc")

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    /**
     * The .lrc file for a song, looked for in this order: the same file name as the song, then the song's name,
     * then "song - artist" / "artist - song" for each artist (a song can have several), then the whole artist text.
     */
    private fun sidecarFound(t: Track): File? {
        val same = sidecar(t)
        try { if (same.exists() && same.canRead()) return same } catch (_: Exception) {}
        val folder = same.parentFile ?: return null
        val files = try { folder.listFiles { f -> f.isFile && f.name.endsWith(".lrc", ignoreCase = true) } } catch (_: Exception) { null } ?: return null
        if (files.isEmpty()) return null
        val byName = HashMap<String, File>()
        for (f in files) byName.putIfAbsent(norm(f.name.substringBeforeLast('.')), f)
        val title = t.title
        val artists = t.artist.split(Regex("""\s*(?:,|;|&|/|\bfeat\.?|\bft\.?|\bwith\b|\band\b|\bx\b)\s*""", RegexOption.IGNORE_CASE))
            .map { it.trim() }.filter { it.isNotEmpty() }
        val keys = ArrayList<String>()
        keys.add(norm(title))
        for (a in artists) { keys.add(norm("$title $a")); keys.add(norm("$a $title")) }
        if (t.artist.isNotBlank()) { keys.add(norm("$title ${t.artist}")); keys.add(norm("${t.artist} $title")) }
        for (k in keys) if (k.isNotEmpty()) byName[k]?.let { return it }
        return null
    }

    /** Text of the .lrc file next to the song, or null. */
    fun readSidecar(t: Track): String? = try { sidecarFound(t)?.readText() } catch (_: Exception) { null }

    /** Text saved/imported inside Aurora, or null. */
    fun readSaved(t: Track): String? = try { lrc(t).takeIf { it.exists() }?.readText() } catch (_: Exception) { null }

    /** Writes the .lrc file next to the song. Returns false if the system doesn't let Aurora write there. */
    fun writeSidecar(t: Track, text: String): Boolean = try {
        val f = sidecar(t)
        if (text.isBlank()) { if (f.exists()) f.delete() else true } else { f.writeText(text); true }
    } catch (_: Throwable) {
        false
    }

    /** Which sources have lyrics for this song right now (online is always "maybe"). */
    suspend fun available(t: Track): Map<String, Boolean> = withContext(Dispatchers.IO) {
        mapOf(
            "saved" to lrc(t).exists(),
            "file" to try { sidecarFound(t) != null } catch (_: Exception) { false },
            "embedded" to (TagIo.embeddedLyrics(appCtx, t) != null),
        )
    }

    private fun fromSource(t: Track, src: String, force: Boolean): Lyrics? = try {
        when (src) {
            "saved" -> lrc(t).takeIf { it.exists() }?.let { LrcParser.parse(it.readText()) }
            "file" -> sidecarFound(t)?.let { LrcParser.parse(it.readText()) }
            "embedded" -> TagIo.embeddedLyrics(appCtx, t)?.let { LrcParser.parse(it) }
            else -> null
        }
    } catch (_: Exception) {
        null
    }

    /** Tries the sources in [order] ("saved", "file", "embedded"); the first that has lyrics wins. */
    suspend fun load(t: Track, order: List<String>, allowOnline: Boolean, force: Boolean = false): Lyrics? =
        withContext(Dispatchers.IO) {
            for (src in order) {
                fromSource(t, src, force)?.let { return@withContext it }
            }
            null
        }

}
