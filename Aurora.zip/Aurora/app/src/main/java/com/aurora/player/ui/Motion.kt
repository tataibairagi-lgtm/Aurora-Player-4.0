package com.aurora.player.ui

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.graphicsLayer
import com.aurora.player.data.Persisted
import kotlinx.coroutines.delay

/** App-wide motion settings, kept in plain fields so any animation can read them cheaply. Updated whenever settings change. */
object Motion {
    val SPEEDS = listOf("Off", "Relaxed", "Normal", "Snappy")
    val NAV = listOf("Slide", "Fade", "Zoom", "Rise")
    val LIST = listOf("None", "Rise", "Pop", "Slide in", "Fade")
    val PRESS = listOf("Off", "Soft", "Normal", "Strong")

    /** Duration multiplier: 0 = animations off. */
    @Volatile var scale = 1f
    @Volatile var nav = 0
    @Volatile var list = 1
    @Volatile var stagger = true
    @Volatile var press = 2
    @Volatile var artFade = true

    /** Items already animated on the current screen, so scrolling back doesn't replay them. */
    val seen = HashSet<Any>()

    fun sync(d: Persisted) {
        scale = when (d.motionSpeed) { 0 -> 0f; 1 -> 1.5f; 3 -> 0.6f; else -> 1f }
        nav = d.navStyle; list = d.listAnim; stagger = d.listStagger; press = d.pressMode; artFade = d.artFade
    }

    fun ms(base: Int): Int = (base * scale).toInt()
}

/** The screen-to-screen transition chosen in Settings → Motion. */
fun navTransition(push: Boolean): ContentTransform {
    if (Motion.scale == 0f) return EnterTransition.None togetherWith ExitTransition.None
    val d = Motion.ms(360)
    val e = FastOutSlowInEasing
    return when (Motion.nav) {
        1 -> fadeIn(tween(d)) togetherWith fadeOut(tween(d / 2))
        2 -> (scaleIn(tween(d, easing = e), if (push) 0.9f else 1.08f) + fadeIn(tween(d))) togetherWith
            (scaleOut(tween(d, easing = e), if (push) 1.08f else 0.9f) + fadeOut(tween(d / 2)))
        3 -> if (push) (slideInVertically(tween(d, easing = e)) { it / 4 } + fadeIn(tween(d))) togetherWith fadeOut(tween(d / 2))
        else fadeIn(tween(d)) togetherWith (slideOutVertically(tween(d, easing = e)) { it / 4 } + fadeOut(tween(d / 2)))
        else -> if (push) {
            (slideInHorizontally(tween(d, easing = e)) { it / 3 } + fadeIn(tween(d * 8 / 9))) togetherWith
                (slideOutHorizontally(tween(d, easing = e)) { -it / 5 } + fadeOut(tween(d * 6 / 11)))
        } else {
            (slideInHorizontally(tween(d, easing = e)) { -it / 5 } + fadeIn(tween(d * 8 / 9))) togetherWith
                (slideOutHorizontally(tween(d, easing = e)) { it / 3 } + fadeOut(tween(d * 6 / 11)))
        }
    }
}

/**
 * List-item entrance in the chosen style. With a [key] an item only animates the first time it shows on a screen
 * (so scrolling back doesn't replay it) and the stagger follows the order items appear in.
 */
fun Modifier.staggerIn(index: Int, key: Any? = null): Modifier = composed {
    val style = Motion.list
    val order = remember { if (key != null) Motion.seen.size else index }
    val play = remember { style != 0 && Motion.scale > 0f && (key == null || Motion.seen.add(key)) }
    val a = remember { Animatable(if (play) 0f else 1f) }
    if (play) LaunchedEffect(Unit) {
        if (Motion.stagger) delay((order.coerceAtMost(12) * 35 * Motion.scale).toLong())
        a.animateTo(1f, tween(Motion.ms(380), easing = FastOutSlowInEasing))
    }
    if (!play) Modifier else Modifier.graphicsLayer {
        val v = a.value
        alpha = v
        when (style) {
            1 -> { translationY = (1f - v) * 36f; val s = 0.93f + 0.07f * v; scaleX = s; scaleY = s }
            2 -> { val s = 0.7f + 0.3f * v; scaleX = s; scaleY = s }
            3 -> translationX = (1f - v) * -size.width * 0.35f
            else -> {}
        }
    }
}
