package com.aurora.player.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.aurora.player.controller

/** Fires at the idle-close deadline, even when the phone is asleep. */
class IdleStopReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try { context.applicationContext.controller.idleStopIfDue() } catch (_: Throwable) {}
    }
}
