package com.aurora.player.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

/** Long text scrolls sideways only when it does not fit. Off = unchanged. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.marqueeIf(on: Boolean): Modifier = if (on) this.basicMarquee(iterations = Int.MAX_VALUE) else this

/**
 * A seek bar drawn as a wave: it ripples while the song plays and flattens when paused.
 * [onChange] reports the position while dragging; [onDone] fires when the finger lifts or taps.
 */
@Composable
fun SquigglySeek(
    value: Float, max: Float, playing: Boolean, color: Color, trackColor: Color,
    onChange: (Float) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier,
) {
    val amp by animateFloatAsState(if (playing) 1f else 0f, tween(500), label = "waveAmp")
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart), label = "wavePhase")
    Canvas(
        modifier.fillMaxWidth().height(40.dp)
            .pointerInput(max) { detectTapGestures { p -> onChange((p.x / size.width * max).coerceIn(0f, max)); onDone() } }
            .pointerInput(max) {
                detectHorizontalDragGestures(
                    onDragStart = { p -> onChange((p.x / size.width * max).coerceIn(0f, max)) },
                    onDragEnd = { onDone() }, onDragCancel = { onDone() },
                ) { change, _ -> change.consume(); onChange((change.position.x / size.width * max).coerceIn(0f, max)) }
            },
    ) {
        val w = size.width; val h = size.height; val mid = h / 2
        val pad = 8.dp.toPx()                       // room for the round thumb at both ends
        val span = (w - 2 * pad).coerceAtLeast(1f)
        val x = pad + (value / max.coerceAtLeast(1f)).coerceIn(0f, 1f) * span
        val waveStroke = 4.dp.toPx()
        val thumbR = 7.dp.toPx()
        val gap = thumbR + 4.dp.toPx()
        // the part still to play: a thin straight line with a small gap before the thumb
        if (x + gap < w - pad) drawLine(trackColor, Offset(x + gap, mid), Offset(w - pad, mid), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
        // the part already played: a smooth, flowing wave that eases in from the left edge
        val wave = Path()
        val a = 4.5.dp.toPx() * amp
        val len = 30.dp.toPx()
        val ease = 22.dp.toPx()
        val end = (x - gap * 0.6f).coerceAtLeast(pad)
        var px = pad
        wave.moveTo(pad, mid)
        while (px < end) {
            val k = ((px - pad) / ease).coerceIn(0f, 1f)
            wave.lineTo(px, mid + a * k * sin((px - pad) / len * 2f * PI.toFloat() - phase))
            px += 2f
        }
        val k = ((end - pad) / ease).coerceIn(0f, 1f)
        wave.lineTo(end, mid + a * k * sin((end - pad) / len * 2f * PI.toFloat() - phase))
        drawPath(wave, color, style = Stroke(waveStroke, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
        // round thumb sitting on the line
        drawCircle(color, thumbR, Offset(x, mid))
    }
}

/** "FLAC • 96 kHz • 1024 kbps": what is really being played. Tap to open the song info. */
@Composable
fun AudioSpecPill(c: PlayerController, t: Track, onClick: () -> Unit) {
    val spec by produceState("", t.id, c.isPlaying) {
        // the decoder reports its format a moment after the song starts
        for (wait in longArrayOf(0, 400, 1200)) {
            delay(wait)
            val f = try { c.player.audioFormat } catch (_: Throwable) { null }
            val ext = t.path.substringAfterLast('.', "").uppercase().ifEmpty { "AUDIO" }
            val parts = ArrayList<String>()
            parts.add(ext)
            val rate = f?.sampleRate?.takeIf { it > 0 }
            if (rate != null) parts.add(if (rate % 1000 == 0) "${rate / 1000} kHz" else "%.1f kHz".format(rate / 1000.0))
            val kbps = f?.bitrate?.takeIf { it > 0 }?.let { it / 1000 }
                ?: if (t.durationMs > 0 && t.size > 0) (t.size * 8 / t.durationMs).toInt() else null
            if (kbps != null && kbps > 0) parts.add("$kbps kbps")
            value = parts.joinToString(" • ")
            if (rate != null) break
        }
    }
    if (spec.isNotEmpty()) Box(
        Modifier.padding(top = 8.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) { Text(spec, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}
