package com.aurora.player.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

private val MONTHS = listOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
private val WEEKDAYS = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")

/** Everything the play log knows about one calendar year, or null when nothing was played. */
private fun buildReview(c: PlayerController, year: Int): CardPictures.Review? {
    val cal = Calendar.getInstance()
    val perSong = HashMap<Long, Int>()
    val months = IntArray(12); val days = IntArray(7); val hours = IntArray(24)
    var plays = 0
    var ms = 0L
    for (e in c.playLog.events) {
        cal.timeInMillis = e.at
        if (cal.get(Calendar.YEAR) != year) continue
        val t = c.track(e.id) ?: continue
        plays++
        perSong[e.id] = (perSong[e.id] ?: 0) + 1
        months[cal.get(Calendar.MONTH)]++
        days[cal.get(Calendar.DAY_OF_WEEK) - 1]++
        hours[cal.get(Calendar.HOUR_OF_DAY)]++
        ms += t.durationMs
    }
    if (plays == 0) return null
    val songs = perSong.entries.sortedByDescending { it.value }.mapNotNull { (id, n) -> c.track(id)?.let { it to n } }
    val byArtist = HashMap<String, Int>()
    val byGenre = HashMap<String, Int>()
    for ((t, n) in songs) {
        for (a in artistsOf(t, true, c.store.data.artistSeparators)) byArtist[a] = (byArtist[a] ?: 0) + n
        if (t.genre.isNotBlank()) byGenre[t.genre] = (byGenre[t.genre] ?: 0) + n
    }
    fun maxIdx(a: IntArray): Int { var b = 0; for (i in a.indices) if (a[i] > a[b]) b = i; return b }
    return CardPictures.Review(
        year, plays, songs.size, byArtist.size, ms / 3_600_000.0,
        songs.take(5).map { (t, n) -> "${t.title} · ${t.artist}" to n },
        byArtist.entries.sortedByDescending { it.value }.take(5).map { it.key to it.value },
        byGenre.entries.maxByOrNull { it.value }?.key ?: "-",
        MONTHS[maxIdx(months)], WEEKDAYS[maxIdx(days)], maxIdx(hours),
    )
}

/** Full-screen "Your year in music", built from the play log; can be shared as a picture. */
@Composable
fun YearInReviewScreen(c: PlayerController, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val years = remember(c.playLog.events.size) {
        val cal = Calendar.getInstance()
        c.playLog.events.map { cal.timeInMillis = it.at; cal.get(Calendar.YEAR) }.distinct().sortedDescending()
    }
    var year by remember { mutableIntStateOf(years.firstOrNull() ?: Calendar.getInstance().get(Calendar.YEAR)) }
    val review = remember(year, c.playLog.events.size) { buildReview(c, year) }
    var palIdx by remember { mutableIntStateOf(0) }
        Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Year in review", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                TextButton(onDismiss) { Text("Close") }
            }
            if (years.size > 1) Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                years.forEach { y -> FilterChip(year == y, { year = y }, label = { Text("$y") }) }
            }
            if (review == null) {
                Text(
                    "No plays recorded in $year yet. Aurora keeps a play log from the moment you start listening, so this fills up as you play music.",
                    Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Stat("${review.plays}", "plays", Modifier.weight(1f))
                    Stat("%.0f".format(review.hours), "hours", Modifier.weight(1f))
                    Stat("${review.songs}", "songs", Modifier.weight(1f))
                    Stat("${review.artists}", "artists", Modifier.weight(1f))
                }
                ListCard("Top songs", review.topSongs.map { it.first to "${it.second}" })
                ListCard("Top artists", review.topArtists.map { it.first to "${it.second}" })
                ListCard("Habits", listOf(
                    "Top genre" to review.topGenre, "Busiest month" to review.busiestMonth,
                    "Favourite day" to review.busiestDay, "Peak hour" to "%02d:00".format(review.peakHour),
                ))
                Text("Picture colours", Modifier.padding(start = 20.dp, top = 12.dp), fontWeight = FontWeight.Medium)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SHARE_PALETTES.take(12).forEachIndexed { i, p ->
                        Box(
                            Modifier.size(if (i == palIdx) 42.dp else 34.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Color(p.bg))
                                .clickable { palIdx = i },
                            contentAlignment = Alignment.Center,
                        ) { Box(Modifier.size(14.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Color(p.fg))) }
                    }
                }
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    androidx.compose.material3.Button({
                        scope.launch {
                            val uri = withContext(Dispatchers.IO) {
                                val bmp = CardPictures.year(review, SHARE_PALETTES[palIdx])
                                ShareCard.save(ctx, bmp, "Aurora_${review.year}_in_review")
                            }
                            if (uri != null) ShareCard.share(ctx, uri)
                        }
                    }) { Text("Share as picture") }
                }
            }
        }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier) {
    Column(
        modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)).padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ListCard(title: String, rows: List<Pair<String, String>>) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)).padding(16.dp)) {
        Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        rows.forEachIndexed { i, (a, b) ->
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(a, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(b, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 12.dp))
            }
        }
    }
}

/** The Now Playing song as a picture, ready to save or share. */
@Composable
fun SongCardDialog(c: PlayerController, t: Track, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val art = rememberArt(t, 900)
    var palIdx by remember { mutableIntStateOf(0) }
    val bmp = remember(art, palIdx, t.id) { CardPictures.song(t, art, SHARE_PALETTES[palIdx]) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Share as picture") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 380.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp)), contentScale = ContentScale.Fit)
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SHARE_PALETTES.take(12).forEachIndexed { i, p ->
                        Box(
                            Modifier.size(if (i == palIdx) 40.dp else 32.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Color(p.bg)).clickable { palIdx = i },
                            contentAlignment = Alignment.Center,
                        ) { Box(Modifier.size(13.dp).clip(CircleShape).background(androidx.compose.ui.graphics.Color(p.fg))) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                scope.launch {
                    val uri = withContext(Dispatchers.IO) { ShareCard.save(ctx, bmp, "Aurora_" + t.title.take(30)) }
                    if (uri != null) ShareCard.share(ctx, uri)
                    onDismiss()
                }
            }) { Text("Share") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Close") } },
    )
}
