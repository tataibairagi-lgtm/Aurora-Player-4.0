package com.aurora.player.ui

import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager

/** Where the sound is going right now: "Phone speaker", the Bluetooth device's name, "Wired headphones", and so on. */
fun currentOutputName(ctx: Context): String {
    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val devs = try { am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList() } catch (_: Throwable) { emptyList() }
    fun name(d: AudioDeviceInfo) = d.productName?.toString()?.takeIf { it.isNotBlank() }
    devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLE_HEADSET }?.let { return name(it) ?: "Bluetooth" }
    devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET }?.let { return "Wired headphones" }
    devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_USB_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_DEVICE }?.let { return "USB audio" }
    return "Phone speaker"
}

/** True when the sound is going to a Bluetooth or wired device (used to pick an equalizer profile). */
fun currentOutputKey(ctx: Context): String {
    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val devs = try { am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList() } catch (_: Throwable) { emptyList() }
    devs.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLE_HEADSET }?.let { return "bt:" + (it.productName?.toString() ?: "") }
    if (devs.any { it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_HEADSET }) return "wired"
    return "speaker"
}

/** Opens Android's own "Media output" chooser (speaker / Bluetooth / wired); falls back to the volume panel, then Bluetooth settings. */
fun openOutputSwitcher(ctx: Context) {
    val tries = listOf(
        Intent("com.android.settings.panel.action.MEDIA_OUTPUT").putExtra("com.android.settings.panel.extra.PACKAGE_NAME", ctx.packageName),
        Intent(android.provider.Settings.Panel.ACTION_VOLUME),
        Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS),
    )
    for (i in tries) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Throwable) {}
    }
}
