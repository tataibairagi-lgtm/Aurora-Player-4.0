package com.aurora.player.backup

import android.database.sqlite.SQLiteDatabase
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.io.File
import java.io.InputStream
import java.net.URLDecoder
import java.util.zip.ZipInputStream
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * Reads a Musicolet backup (.zip). Every file inside it is encrypted separately with Blowfish
 * (ECB, PKCS5 padding) using a fixed key, so a backup made on one phone opens on any other.
 * Favourites, playlists, queues and play counts are converted; Musicolet's settings use its own
 * private keys and are not mapped.
 */
object MusicoletImport {
    private val key = SecretKeySpec("JSTMUSIC_2".toByteArray(), "Blowfish")

    fun looksLikeMusicolet(names: Collection<String>) = "0.musicolet.backup" in names || "hash" in names

    private fun decrypt(b: ByteArray): ByteArray {
        if (b.isEmpty()) return b
        val c = Cipher.getInstance("Blowfish/ECB/PKCS5Padding")
        c.init(Cipher.DECRYPT_MODE, key)
        return c.doFinal(b)
    }

    /** A Musicolet song address looks like file:///storage/emulated/0/Music/a%20b.mp3 */
    private fun toPath(s: String): String =
        try { URLDecoder.decode(s.replace("+", "%2B").removePrefix("file://"), "UTF-8") } catch (_: Exception) { s.removePrefix("file://") }

    private fun strs(o: JsonObject, k: String): List<String> =
        (o[k] as? JsonArray)?.map { it.jsonPrimitive.contentOrNull ?: "" } ?: emptyList()

    private fun longs(o: JsonObject, k: String): List<Long> =
        (o[k] as? JsonArray)?.map { it.jsonPrimitive.longOrNull ?: 0L } ?: emptyList()

    /** {"S_P":[...paths], "S_T":[titles], "S_AL":[albums], "S_AR":[artists], "S_D":[durations]} */
    private fun refs(o: JsonObject): List<TrackRef> {
        val p = strs(o, "S_P"); val t = strs(o, "S_T"); val al = strs(o, "S_AL"); val ar = strs(o, "S_AR"); val d = longs(o, "S_D")
        return p.indices.map { i ->
            TrackRef(toPath(p[i]), t.getOrElse(i) { "" }, ar.getOrElse(i) { "" }, al.getOrElse(i) { "" }, d.getOrElse(i) { 0L })
        }
    }

    private fun parse(bytes: ByteArray): JsonObject? =
        try { Json.parseToJsonElement(bytes.toString(Charsets.UTF_8)).jsonObject } catch (_: Exception) { null }

    /** Opens an (already decrypted) SQLite file from the backup, read-only, for the length of [block]. */
    private fun withDb(bytes: ByteArray, block: (SQLiteDatabase) -> Unit) {
        if (bytes.isEmpty()) return
        val tmp = File.createTempFile("mc_", ".db")
        try {
            tmp.writeBytes(bytes)
            val db = SQLiteDatabase.openDatabase(tmp.path, null, SQLiteDatabase.OPEN_READONLY)
            try { block(db) } finally { db.close() }
        } catch (_: Exception) {
        } finally { tmp.delete() }
    }

    fun read(input: InputStream): LoadedBackup? {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (e.isDirectory) continue
                files[e.name.substringAfterLast('/')] = zip.readBytes()
            }
        }
        if (!looksLikeMusicolet(files.keys)) return null
        val plain = HashMap<String, ByteArray>()
        for ((n, b) in files) if (n != "hash") plain[n] = try { decrypt(b) } catch (_: Exception) { continue }

        val created = plain["0.musicolet.backup"]?.let { parse(it) }?.get("time")?.jsonPrimitive?.longOrNull ?: 0L

        val favs = plain["0.favs"]?.let { parse(it) }?.let { refs(it) } ?: emptyList()

        val lists = plain.keys.filter { it.endsWith(".mpl") && it != "curropt.mpl" }.sorted().mapNotNull { n ->
            val o = parse(plain.getValue(n)) ?: return@mapNotNull null
            BPlaylist(n.removeSuffix(".mpl"), refs(o))
        }

        // queues: every entry only stores song paths (no titles), so they are matched by path
        val queues = ArrayList<BQueue>()
        var active = 0
        plain["0.qstk"]?.let { parse(it) }?.let { q ->
            active = q["S0_CPQ"]?.jsonPrimitive?.intOrNull ?: 0
            (q["S0_PQ"] as? JsonArray)?.forEach { e ->
                val o = e.jsonObject
                val tr = (o["S0_PQ_OQS"] as? JsonObject)?.let { refs(it) } ?: emptyList()
                queues += BQueue(
                    o["S0_PQ_T"]?.jsonPrimitive?.contentOrNull ?: "Queue", tr,
                    o["S0_PQ_CPS"]?.jsonPrimitive?.intOrNull ?: 0, 0L,
                )
            }
        }

        // play counts and recently played come from Musicolet's song database
        val counts = ArrayList<BCount>()
        val last = ArrayList<Pair<Long, TrackRef>>()
        val refByPath = HashMap<String, TrackRef>()
        val lastAt = HashMap<String, Long>()
        plain["DB_SONGS_LOG"]?.let { b ->
            withDb(b) { db ->
                db.rawQuery(
                    "SELECT COL_PATH, COL_TITLE, COL_ARTIST, COL_ALBUM, COL_DURATION, COL_NUM_PLAYED, COL_LAST_PLAYED FROM TABLE_SONGS", null,
                ).use { c ->
                    while (c.moveToNext()) {
                        val raw = c.getString(0) ?: continue
                        val r = TrackRef(toPath(raw), c.getString(1) ?: "", c.getString(2) ?: "", c.getString(3) ?: "", c.getLong(4))
                        refByPath[raw] = r
                        if (c.getInt(5) > 0) counts += BCount(r, c.getInt(5))
                        if (c.getLong(6) > 0) { last += c.getLong(6) to r; lastAt[raw] = c.getLong(6) }
                    }
                }
            }
        }

        // Musicolet only keeps play counts per month (PCs_M_<year>.<month 0-11>), not every play's time, so each month's plays are
        // spread over that month; the song's real "last played" moment is kept exactly.
        val plays = ArrayList<BPlay>()
        val cal = java.util.Calendar.getInstance()
        val usedLast = HashSet<String>()
        for ((name, bytes) in plain.entries.sortedBy { it.key }) {
            if (!name.startsWith("PCs_M_") || bytes.isEmpty()) continue
            val ym = name.removePrefix("PCs_M_").split('.')
            val year = ym.getOrNull(0)?.toIntOrNull() ?: continue
            val month = ym.getOrNull(1)?.toIntOrNull() ?: continue
            cal.clear(); cal.set(year, month, 1, 12, 0, 0)
            val days = cal.getActualMaximum(java.util.Calendar.DAY_OF_MONTH)
            val start = cal.timeInMillis
            withDb(bytes) { db ->
                db.rawQuery("SELECT COL_PATH, COL_NUM_PLAYED FROM TABLE_SONGS", null).use { c ->
                    while (c.moveToNext()) {
                        val raw = c.getString(0) ?: continue
                        var n = c.getInt(1)
                        val ref = refByPath[raw] ?: TrackRef(toPath(raw), "", "", "", 0L)
                        val la = lastAt[raw]
                        if (la != null && la >= start && la < start + days * 86_400_000L && raw !in usedLast) {
                            usedLast += raw; plays += BPlay(ref, la); n -= 1
                        }
                        val h = raw.hashCode().let { if (it < 0) -(it + 1) else it }
                        for (k in 0 until n) plays += BPlay(ref, start + ((h + k * 7) % days) * 86_400_000L + (k % 8) * 1_800_000L)
                    }
                }
            }
        }
        for ((raw, at) in lastAt) if (raw !in usedLast) refByPath[raw]?.let { plays += BPlay(it, at) }

        val data = BackupData(
            app = "Musicolet", createdAt = created,
            favourites = favs, playlists = lists, playCounts = counts, playLog = plays,
            lastPlayed = last.sortedByDescending { it.first }.take(100).map { it.second },
            queues = queues.filter { it.tracks.isNotEmpty() },
            activeQueue = active,
        )
        return LoadedBackup(data, emptyMap())
    }
}
