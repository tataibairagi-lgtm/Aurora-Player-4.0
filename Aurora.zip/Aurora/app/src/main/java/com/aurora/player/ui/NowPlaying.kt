package com.aurora.player.ui

import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.layout.layout
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.collectLatest
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.automirrored.rounded.VolumeDown
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameNanos
import androidx.media3.common.Player
import com.aurora.player.data.formatTime
import com.aurora.player.data.indexAt
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun NowPlayingScreen(
    c: PlayerController, onClose: () -> Unit, openQueue: () -> Unit, openEq: () -> Unit, embedded: Boolean = false,
    openArtist: (String) -> Unit = {}, openAlbum: (com.aurora.player.data.Track) -> Unit = {},
) {
    val track = c.current
    val bmp = rememberArt(track)
    val surface = MaterialTheme.colorScheme.background
    val accent by animateColorAsState(
        bmp?.dominantColor() ?: MaterialTheme.colorScheme.primary, tween(800), label = "accent",
    )
    var showLyrics by remember { mutableStateOf(false) }
    var sleepDialog by remember { mutableStateOf(false) }
    var artMenu by remember { mutableStateOf(false) }
    var artFull by remember { mutableStateOf(false) }
    var tagDialog by remember { mutableStateOf(false) }
    var bmAdd by remember { mutableStateOf(false) }
    var playMode by remember { mutableStateOf(false) }
    var spDialog by remember { mutableStateOf(false) }
    var bmList by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    var npMenu by remember { mutableStateOf(false) }
    var infoDialog by remember { mutableStateOf(false) }
    var queueDialog by remember { mutableStateOf(false) }
    var deleteNp by remember { mutableStateOf(false) }
    val actions = LocalActions.current

    val bgMode = c.store.data.nowBg
    val darkBg = bgMode in listOf(1, 2, 4, 5)
    val cs = MaterialTheme.colorScheme
    val screenScheme = if (darkBg) cs.copy(
        onSurface = Color.White, onBackground = Color.White, onSurfaceVariant = Color(0xCCFFFFFF),
        primary = if (c.store.data.accentColor == 0L) Color(0xFFB4A8FF) else cs.primary,
    ) else cs
    val view = androidx.compose.ui.platform.LocalView.current
    val keepOn = c.store.data.keepScreenOn
    androidx.compose.runtime.DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }
    MaterialTheme(colorScheme = screenScheme) {
    androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides screenScheme.onBackground) {
    Box(Modifier.fillMaxSize()) {
        NowBackground(c, bmp, accent, surface)
        Column(
            Modifier.fillMaxSize().then(if (embedded) Modifier else Modifier.statusBarsPadding().navigationBarsPadding()).padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // top bar
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (embedded) Spacer(Modifier.size(44.dp)) else Box(Modifier.size(44.dp).bounceClick(onClose), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.KeyboardArrowDown, null, modifier = Modifier.size(30.dp))
                }
                Text(
                    "Now playing", Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if ("palette" !in c.store.data.hideNp) Box(Modifier.size(44.dp).bounceClick {
                    val hasCustom = c.store.data.customBgUri.isNotEmpty()
                    var n = (c.store.data.nowBg + 1) % 6
                    if (n == 5 && !hasCustom) n = 0
                    c.store.update { it.copy(nowBg = n) }
                }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Palette, null)
                }
                if ("queue" !in c.store.data.hideNp) Box(Modifier.size(44.dp).bounceClick(openQueue), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Rounded.QueueMusic, null)
                }
                Box {
                    Box(Modifier.size(44.dp).bounceClick { artMenu = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.MoreVert, null)
                    }
                }
            }

            val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
            val artBox: @Composable (Modifier) -> Unit = { m ->
                Box(m.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                    Crossfade(showLyrics, animationSpec = tween(400), label = "artOrLyrics") { lyr ->
                        if (lyr) LyricsPane(c) { showLyrics = false } else ArtPane(c, accent) { showLyrics = true }
                    }
                }
            }
            val controls: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            // title, artist and album, centred with small icons (Musicolet style)
            AnimatedContent(
                track?.id, Modifier.fillMaxWidth(),
                transitionSpec = {
                    (slideInVertically(tween(350)) { it / 2 } + fadeIn(tween(350))) togetherWith
                        (slideOutVertically(tween(250)) { -it / 2 } + fadeOut(tween(200)))
                },
                label = "title",
            ) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        track?.title ?: "Nothing playing", maxLines = 1, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                    )
                    if (track != null) {
                        var artistMenu by remember { mutableStateOf(false) }
                        val names = artistsOf(track, c.store.data.splitArtists, c.store.data.artistSeparators)
                        Box {
                            Row(
                                Modifier.padding(top = 6.dp).clip(RoundedCornerShape(10.dp))
                                    .clickable { if (names.size > 1) artistMenu = true else openArtist(names.firstOrNull() ?: track.artist) }
                                    .padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(Icons.Rounded.Person, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    "  " + track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge,
                                )
                            }
                            DropdownMenu(artistMenu, { artistMenu = false }) {
                                names.forEach { n -> DropdownMenuItem(text = { Text(n) }, onClick = { artistMenu = false; openArtist(n) }) }
                            }
                        }
                        Row(
                            Modifier.padding(top = 2.dp).clip(RoundedCornerShape(10.dp)).clickable { openAlbum(track) }.padding(horizontal = 8.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Rounded.Album, null, Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                "  " + track.album, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                    } else Text("Pick a song from your library", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            // icon row: favourite, info, lyrics, add to playlist, sleep, more ... | A-B, play mode, shuffle
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val fav = track != null && c.store.isFavourite(track.id)
                    val hide = c.store.data.hideNp
                    if ("fav" !in hide) ToggleIcon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, fav) { track?.let { c.store.toggleFavourite(it.id) } }
                    if ("info" !in hide) ToggleIcon(Icons.Rounded.Info, false) { if (track != null) infoDialog = true }
                    if ("lyrics" !in hide) ToggleIcon(Icons.Rounded.Subtitles, showLyrics) { showLyrics = !showLyrics }
                    if ("overlay" !in hide) ToggleIcon(Icons.Rounded.PictureInPictureAlt, c.overlayActive) { actions.toggleOverlay(!c.overlayActive) }
                    if ("addpl" !in hide) ToggleIcon(Icons.AutoMirrored.Rounded.PlaylistAdd, false) { if (track != null) addDialog = true }
                    if ("sleep" !in hide) Row(verticalAlignment = Alignment.CenterVertically) {
                        ToggleIcon(Icons.Rounded.Bedtime, c.sleepActive) { sleepDialog = true }
                        if (c.sleepLeftMs > 0) Text(formatTime(c.sleepLeftMs), style = MaterialTheme.typography.labelSmall)
                    }
                    if ("more" !in hide) ToggleIcon(Icons.Rounded.MoreHoriz, false) { if (track != null) npMenu = true }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if ("ab" !in c.store.data.hideNp) TextToggle("A–B", c.abA >= 0) { c.markAB() }
                    if ("mode" !in c.store.data.hideNp) ToggleIcon(
                        if (c.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                        c.repeatMode != Player.REPEAT_MODE_OFF,
                    ) { playMode = true }
                    if ("shuffle" !in c.store.data.hideNp) ToggleIcon(Icons.Rounded.Shuffle, c.shuffle) { c.toggleShuffle() }
                }
            }

            // seek bar: its own composable so the 5-per-second position updates don't recompose the whole screen
            SeekSection(c)

            // transport
            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
            ) {
                run {
                    val vctx = androidx.compose.ui.platform.LocalContext.current
                    if ("vol" !in c.store.data.hideNp) ToggleIcon(Icons.AutoMirrored.Rounded.VolumeDown, false) {
                        try { (vctx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager).adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.ADJUST_SAME, android.media.AudioManager.FLAG_SHOW_UI) } catch (_: Exception) {}
                    }
                }
                Box(Modifier.size(52.dp).bounceClick { c.previous() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SkipPrevious, null, modifier = Modifier.size(38.dp))
                }
                val pulse by animateFloatAsState(if (c.isPlaying) 1f else 0.94f, spring(Spring.DampingRatioMediumBouncy), label = "playScale")
                Box(
                    Modifier.size(76.dp).scale(pulse).clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary).bounceClick { c.togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    AnimatedContent(
                        c.isPlaying,
                        transitionSpec = { (scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
                        label = "playPause",
                    ) { playing ->
                        Icon(
                            if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null,
                            tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(42.dp),
                        )
                    }
                }
                Box(Modifier.size(52.dp).bounceClick { c.next() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SkipNext, null, modifier = Modifier.size(38.dp))
                }
                if ("eq" !in c.store.data.hideNp) ToggleIcon(Icons.Rounded.Equalizer, false, openEq)
            }

            }
            if (land) {
                // landscape: art / lyrics on the left, the controls on the right
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    artBox(Modifier.weight(1f).fillMaxHeight())
                    Column(
                        Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally,
                    ) { controls() }
                }
            } else {
                artBox(Modifier.weight(1f).fillMaxWidth())
                controls()
            }
        }
    }
    }
    }

    if (infoDialog && track != null) SongInfoDialog(c, track, { tagDialog = true }) { infoDialog = false }
    if (npMenu && track != null) {
        @Composable
        fun Row1(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) {
            Row(
                Modifier.fillMaxWidth().clickable { npMenu = false; onClick() }.padding(vertical = 13.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(icon, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text, Modifier.padding(start = 22.dp))
            }
        }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { npMenu = false },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Row1(Icons.Rounded.Subtitles, "Show lyrics") { showLyrics = true }
                    Row1(Icons.Rounded.Bookmark, "Bookmarks/Notes") { bmList = true }
                    Row1(Icons.Rounded.Repeat, "A-B repeat") { c.markAB() }
                    Row1(Icons.Rounded.Speed, "Play speed and Pitch") { spDialog = true }
                    Row1(Icons.Rounded.Subtitles, if (c.overlayActive) "Hide desktop lyrics" else "Desktop lyrics") { actions.toggleOverlay(!c.overlayActive) }
                    androidx.compose.material3.HorizontalDivider()
                    Row1(Icons.AutoMirrored.Rounded.QueueMusic, "Add to a queue") { queueDialog = true }
                    Row1(Icons.AutoMirrored.Rounded.PlaylistAdd, "Add to playlists") { addDialog = true }
                    androidx.compose.material3.HorizontalDivider()
                    Row1(Icons.Rounded.Info, "Song info") { infoDialog = true }
                    Row1(Icons.Rounded.Edit, "Edit tags") { tagDialog = true }
                    Row1(Icons.Rounded.DriveFileMove, "Copy to a folder") { actions.copyTracks(listOf(track)) }
                    Row1(Icons.Rounded.Image, "View album art") { artFull = true }
                    Row1(Icons.Rounded.Delete, "Delete permanently") { deleteNp = true }
                }
            },
            confirmButton = { androidx.compose.material3.TextButton({ npMenu = false }) { Text("Close") } },
        )
    }
    if (artMenu && track != null) androidx.compose.ui.window.Dialog(onDismissRequest = { artMenu = false }) {
        androidx.compose.material3.Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Column(Modifier.padding(vertical = 16.dp)) {
                Row(Modifier.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    AlbumArt(track, Modifier.size(48.dp), RoundedCornerShape(12.dp), 22.dp)
                    Column(Modifier.padding(start = 14.dp)) {
                        Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold)
                        Text(track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                androidx.compose.material3.HorizontalDivider(Modifier.padding(top = 10.dp, bottom = 4.dp))
                @Composable
                fun Item(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
                    Row(
                        Modifier.fillMaxWidth().clickable { artMenu = false; onClick() }.padding(horizontal = 24.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(label, Modifier.padding(start = 18.dp))
                    }
                }
                Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState())) {
                    Item(Icons.Rounded.Image, "View album art") { artFull = true }
                    Item(Icons.Rounded.Image, "Save album art to gallery") { actions.saveArt(track) }
                    Item(Icons.Rounded.Image, "Embed cover art from an image") { actions.embedArt(listOf(track)) }
                    androidx.compose.material3.HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    Item(Icons.Rounded.Edit, "Edit tags") { tagDialog = true }
                    Item(Icons.Rounded.Bookmark, "Add bookmark here") { bmAdd = true }
                    Item(Icons.Rounded.Bookmark, "Bookmarks") { bmList = true }
                    androidx.compose.material3.HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    Item(Icons.Rounded.DriveFileMove, "Copy song to a folder") { actions.copyTracks(listOf(track)) }
                    Item(Icons.AutoMirrored.Rounded.PlaylistAdd, "Add to playlist") { addDialog = true }
                }
            }
        }
    }
    if (queueDialog && track != null) androidx.compose.material3.AlertDialog(
        onDismissRequest = { queueDialog = false },
        title = { Text("Add to a queue") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                c.store.data.queues.forEachIndexed { i, q ->
                    Text(
                        "${i + 1}. ${q.name}", Modifier.fillMaxWidth().clickable { c.addToOtherQueue(i, listOf(track)); queueDialog = false }.padding(vertical = 12.dp),
                    )
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ queueDialog = false }) { Text("Cancel") } },
    )
    if (deleteNp && track != null) androidx.compose.material3.AlertDialog(
        onDismissRequest = { deleteNp = false },
        title = { Text("Delete this song?") },
        text = { Text("“${track.title}” will be permanently removed from your device.") },
        confirmButton = { androidx.compose.material3.TextButton({ deleteNp = false; actions.deleteTracks(listOf(track)) }) { Text("Delete") } },
        dismissButton = { androidx.compose.material3.TextButton({ deleteNp = false }) { Text("Cancel") } },
    )
    if (artFull && track != null) ArtFullscreen(bmp) { artFull = false }
    if (tagDialog && track != null) TagEditorDialog(track, { tagDialog = false }) { d -> tagDialog = false; actions.editTags(track, d) }
    if (addDialog && track != null) AddToPlaylistDialog(c, listOf(track.id)) { addDialog = false }
    if (sleepDialog) SleepDialog(c) { sleepDialog = false }
    if (playMode) PlayModeDialog(c) { playMode = false }
    if (spDialog) SpeedPitchDialog(c) { spDialog = false }
    if (bmAdd) AddBookmarkDialog(c) { bmAdd = false }
    if (bmList) BookmarksDialog(c) { bmList = false }
}

@Composable
private fun ToggleIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, on: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(
        if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, tween(250), label = "tg",
    )
    Box(Modifier.size(44.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun TextToggle(label: String, on: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(
        if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, tween(250), label = "tt",
    )
    Box(Modifier.size(width = 48.dp, height = 44.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Text(label, color = tint, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

// -------------------------------------------------------------------------------------------------
// Album art: spinning vinyl disc (or breathing square), swipe left/right to change song
// -------------------------------------------------------------------------------------------------

@Composable
private fun ArtPane(c: PlayerController, accent: Color, onTap: () -> Unit) {
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(0f) }
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(c.isPlaying) {
        if (c.isPlaying) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                angle = (angle + (now - last) / 1_000_000_000f * 24f) % 360f
                last = now
            }
        }
    }
    val glow = rememberInfiniteTransition(label = "glow")
    val pulse by glow.animateFloat(
        0.9f, 1.08f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "pulse",
    )
    val intensity by animateFloatAsState(if (c.isPlaying) 1f else 0f, tween(600), label = "glowI")
    val disc = c.store.data.discArt

    Box(
        Modifier.fillMaxSize()
            .offset { IntOffset(offset.value.roundToInt(), 0) }
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (offset.value < -160f) c.next() else if (offset.value > 160f) c.previous()
                            offset.animateTo(0f, spring(Spring.DampingRatioMediumBouncy))
                        }
                    },
                    onDragCancel = { scope.launch { offset.animateTo(0f) } },
                ) { change, dx ->
                    change.consume()
                    scope.launch { offset.snapTo(offset.value + dx) }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            c.current?.id,
            transitionSpec = {
                (scaleIn(tween(450), 0.8f) + fadeIn(tween(450))) togetherWith (scaleOut(tween(300), 0.8f) + fadeOut(tween(250)))
            },
            label = "artSwap",
        ) {
            if (disc) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    // pulsing glow
                    Box(
                        Modifier.fitSquare(0.92f).scale(pulse)
                            .background(
                                Brush.radialGradient(listOf(accent.copy(alpha = 0.45f * intensity), Color.Transparent)),
                                CircleShape,
                            )
                    )
                    Box(Modifier.fitSquare(0.86f).rotate(angle), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            drawCircle(Color(0xFF0B0B10))
                            val r = size.minDimension / 2
                            var rr = r * 0.97f
                            while (rr > r * 0.66f) {
                                drawCircle(Color.White.copy(alpha = 0.05f), rr, style = Stroke(1.2f))
                                rr -= r * 0.035f
                            }
                        }
                        AlbumArt(c.current, Modifier.fitSquare(0.62f), CircleShape, 56.dp, 800)
                    }
                }
            } else {
                val s by animateFloatAsState(if (c.isPlaying) 1f else 0.86f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "sq")
                Box(
                    Modifier.fitSquare(0.9f).scale(s)
                        .graphicsLayer { shadowElevation = 40f; shape = RoundedCornerShape(28.dp); clip = true },
                ) {
                    AlbumArt(c.current, Modifier.fillMaxSize(), RoundedCornerShape(28.dp), 72.dp, 800)
                }
            }
        }
    }
}

private fun Modifier.aspectSquare(): Modifier = this.aspectRatio(1f)

/** A square that fits the available space (width or height, whichever is smaller) times [frac]; keeps the cover square in landscape. */
private fun Modifier.fitSquare(frac: Float): Modifier = this.layout { m, c ->
    val side = (minOf(c.maxWidth, c.maxHeight) * frac).toInt().coerceAtLeast(0)
    val p = m.measure(androidx.compose.ui.unit.Constraints.fixed(side, side))
    layout(side, side) { p.place(0, 0) }
}

// -------------------------------------------------------------------------------------------------
// Lyrics view with animated scrolling + highlighted line
// -------------------------------------------------------------------------------------------------

@androidx.compose.runtime.Immutable
private class LyricOpts(
    val scale: Float, val align: TextAlign, val family: androidx.compose.ui.text.font.FontFamily, val bold: Boolean,
    val blur: Boolean, val smooth: Boolean, val words: Boolean, val accent: Boolean, val spacing: Float,
    val color: Int, val dim: Float, val inScale: Float, val anchor: Float, val scrollMs: Int, val estimate: Boolean, val wordDim: Float,
)

@Composable
private fun LyricsPane(c: PlayerController, onClose: () -> Unit) {
    val lyr = c.lyrics
    var sourceDialog by remember { mutableStateOf(false) }
    if (sourceDialog) LyricsSourceDialog(c) { sourceDialog = false }
    var styleDialog by remember { mutableStateOf(false) }
    if (styleDialog) LyricsStyleDialog(c) { styleDialog = false }
    val sd = c.store.data
    val opts = remember(sd.lyricScale, sd.lyricAlignC, sd.lyricSerif, sd.lyricBold, sd.lyricBlur, sd.lyricSmooth, sd.lyricWordSync, sd.lyricAccent, sd.lyricSpacing, sd.lyricColor, sd.lyricDim, sd.lyricInactiveScale, sd.lyricAnchor, sd.lyricScrollMs, sd.lyricEstimate, sd.lyricWordDim) {
        LyricOpts(
            sd.lyricScale / 100f,
            when (sd.lyricAlignC) { 0 -> TextAlign.Start; 2 -> TextAlign.End; else -> TextAlign.Center },
            if (sd.lyricSerif) androidx.compose.ui.text.font.FontFamily.Serif else androidx.compose.ui.text.font.FontFamily.Default,
            sd.lyricBold, sd.lyricBlur && sd.lyricSmooth, sd.lyricSmooth, sd.lyricWordSync, sd.lyricAccent, sd.lyricSpacing / 100f,
            sd.lyricColor.toInt(), sd.lyricDim / 100f, sd.lyricInactiveScale / 100f, sd.lyricAnchor / 100f, sd.lyricScrollMs, sd.lyricEstimate, sd.lyricWordDim / 100f,
        )
    }
    Column(Modifier.fillMaxSize()) {
        c.current?.takeIf { sd.lyricShowSong }?.let { t ->
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                AlbumArt(t, Modifier.size(46.dp), RoundedCornerShape(10.dp), 20.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                val fav = c.store.isFavourite(t.id)
                Icon(
                    if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null,
                    Modifier.size(40.dp).clip(CircleShape).clickable { c.store.toggleFavourite(t.id) }.padding(8.dp),
                    tint = if (fav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("Cover", Icons.Rounded.KeyboardArrowDown, false) { onClose() }
            PillButton("Source", Icons.Rounded.Lyrics, false) { sourceDialog = true }
            PillButton("Customise", Icons.Rounded.Tune, false) { styleDialog = true }
        }
        when {
            c.lyricsLoading -> CenterNote("Looking for lyrics…")
            lyr == null -> CenterNote("No lyrics found.\nTap Source to import an .lrc file,\nput one next to the song,\nor add lyrics in Song info.")
            lyr.synced -> {
                val state = rememberLazyListState()
                var idx by androidx.compose.runtime.remember(lyr) { androidx.compose.runtime.mutableIntStateOf(lyr.indexAt(c.lyricPosMs)) }
                // follow the song without recomposing the pane on every position tick
                // Where a centred line's centre sits in the list's own coordinates; measured once after a snap, so the
                // glide never depends on guessing how the list counts its padding.
                val centre = remember(lyr, opts.anchor) { floatArrayOf(Float.NaN) }
                LaunchedEffect(lyr, opts.smooth, opts.scrollMs, opts.anchor) {
                    suspend fun snap(i: Int) {
                        val vis = state.layoutInfo.visibleItemsInfo
                        val size = vis.firstOrNull { it.index == i }?.size ?: (if (vis.isEmpty()) 90 else vis.sumOf { it.size } / vis.size)
                        state.scrollToItem(i, size / 2)
                        androidx.compose.runtime.withFrameNanos { }
                        state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == i }?.let { centre[0] = it.offset + it.size / 2f }
                    }
                    androidx.compose.runtime.snapshotFlow { lyr.indexAt(c.lyricPosMs) }
                        .distinctUntilChanged()
                        .collectLatest { i ->
                            val far = kotlin.math.abs(i - idx) > 4
                            idx = i
                            if (i >= 0) {
                                val item = state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == i }
                                val c0 = centre[0]
                                if (item != null && !far && opts.smooth && !c0.isNaN()) {
                                    state.animateScrollBy(item.offset + item.size / 2f - c0, androidx.compose.animation.core.tween(opts.scrollMs, easing = androidx.compose.animation.core.LinearOutSlowInEasing))
                                } else snap(i)
                            }
                        }
                }
                val onSeek = remember(c) { { ms: Long -> c.seekTo(ms) } }
                val pos = remember(c) { { c.lyricPosMs } }
                androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxSize()) {
                    val padTop = maxHeight * opts.anchor
                    val padBottom = maxHeight * (1f - opts.anchor)
                    LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(top = padTop, bottom = padBottom)) {
                        itemsIndexed(lyr.lines, key = { i, _ -> i }, contentType = { _, _ -> "line" }) { i, line ->
                            LyricRow(
                                line, lyr.lines.getOrNull(i + 1)?.timeMs ?: -1L, i == idx,
                                kotlin.math.abs(i - idx).coerceAtMost(3), opts, pos, onSeek,
                            )
                        }
                    }
                }
            }
            else -> LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(lyr.lines) { _, line ->
                    Text(line.text, fontSize = (18 * opts.scale).sp, textAlign = opts.align, fontFamily = opts.family, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
                }
            }
        }
    }
}

/** One lyric line: the playing one is big and bright (word by word when timing exists), the others shrink and fade with distance. */
@Composable
private fun LyricRow(
    line: com.aurora.player.data.LyricLine, nextMs: Long, active: Boolean, distance: Int, o: LyricOpts, pos: () -> Long, onSeek: (Long) -> Unit,
) {
    val actState = androidx.compose.animation.core.animateFloatAsState(
        if (active) 1f else 0f, if (o.smooth) androidx.compose.animation.core.tween(if (android.os.Build.VERSION.SDK_INT < 31) 180 else 260) else androidx.compose.animation.core.snap(), label = "lyAct",
    )
    val dim = if (distance <= 1) o.dim * 1.35f else o.dim
    // every line except the one being sung is blurred, a little more the further away it is
    val blurTarget = if (!o.blur || active || android.os.Build.VERSION.SDK_INT < 31) 0f else 2.5f + minOf(distance, 5) * 0.9f
    val blurAnim by androidx.compose.animation.core.animateFloatAsState(blurTarget, if (o.smooth) androidx.compose.animation.core.tween(220) else androidx.compose.animation.core.snap(), label = "lyBlur")
    val blurDp = blurAnim.dp
    val origin = when (o.align) {
        TextAlign.Start -> androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
        TextAlign.End -> androidx.compose.ui.graphics.TransformOrigin(1f, 0.5f)
        else -> androidx.compose.ui.graphics.TransformOrigin(0.5f, 0.5f)
    }
    val base = MaterialTheme.colorScheme.onSurface
    val lit = if (o.color != 0) androidx.compose.ui.graphics.Color(o.color) else if (o.accent) MaterialTheme.colorScheme.primary else base

    // word-by-word: real word times from an enhanced .lrc, otherwise estimated across the line
    val words = if (o.words && active && line.text.isNotBlank()) remember(line, nextMs) { line.words ?: if (o.estimate) com.aurora.player.data.estimateWords(line, nextMs) else null } else null
    var wi by remember(line) { androidx.compose.runtime.mutableIntStateOf(-1) }
    if (words != null && words.size > 1) {
        LaunchedEffect(words) {
            androidx.compose.runtime.snapshotFlow { val p = pos(); words.indexOfLast { it.timeMs <= p } }
                .distinctUntilChanged().collect { wi = it }
        }
    }
    val shown: androidx.compose.ui.text.AnnotatedString = if (words != null && words.size > 1) {
        androidx.compose.ui.text.buildAnnotatedString {
            words.forEachIndexed { k, w ->
                pushStyle(androidx.compose.ui.text.SpanStyle(color = if (k <= wi) lit else base.copy(alpha = o.wordDim)))
                append(w.text)
                pop()
            }
        }
    } else androidx.compose.ui.text.AnnotatedString(line.text.ifBlank { "♪" })

    Text(
        shown,
        color = if (active && (words == null || words.size <= 1)) lit else base,
        fontSize = (26 * o.scale).sp, lineHeight = (32 * o.scale * o.spacing).sp,
        textAlign = o.align, fontFamily = o.family, fontWeight = if (o.bold) FontWeight.Bold else FontWeight.Medium,
        modifier = Modifier.fillMaxWidth().clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null) { onSeek(line.timeMs) }.padding(vertical = (8 * o.spacing).dp)
            .graphicsLayer {
                val a = actState.value
                val s = o.inScale + (1f - o.inScale) * a
                scaleX = s; scaleY = s
                alpha = dim.coerceAtMost(1f) + (1f - dim.coerceAtMost(1f)) * a
                transformOrigin = origin
            }
            .then(if (blurDp.value < 0.1f) Modifier else Modifier.blur(blurDp)),
    )
}

@Composable
private fun CenterNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// -------------------------------------------------------------------------------------------------
// Background (Settings > Now Playing background, or the palette button on the Now Playing screen)
// -------------------------------------------------------------------------------------------------

private fun loadBackgroundImage(ctx: android.content.Context, uri: String): android.graphics.Bitmap? = try {
    val u = android.net.Uri.parse(uri)
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
    ctx.contentResolver.openInputStream(u)?.use {
        android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
    }
} catch (_: Exception) {
    null
}

@Composable
private fun NowBackground(c: PlayerController, bmp: android.graphics.Bitmap?, accent: Color, surface: Color) {
    val d = c.store.data
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val custom by androidx.compose.runtime.produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, d.customBgUri) {
        value = if (d.customBgUri.isEmpty()) null
        else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { loadBackgroundImage(ctx, d.customBgUri)?.asImageBitmap() }
    }
    // a tiny copy scaled up with filtering gives a soft blur on every Android version
    val blurred = remember(bmp) {
        bmp?.let { android.graphics.Bitmap.createScaledBitmap(it, 40, 40, true).asImageBitmap() }
    }
    val dim = (d.nowBgDim / 100f).coerceIn(0f, 0.8f)

    Box(Modifier.fillMaxSize()) {
        when (d.nowBg) {
            1 -> {
                Crossfade(blurred, animationSpec = tween(600), label = "bgBlur") { img ->
                    if (img != null) {
                        androidx.compose.foundation.Image(
                            img, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            filterQuality = androidx.compose.ui.graphics.FilterQuality.Low,
                        )
                    } else Box(Modifier.fillMaxSize().background(Color(0xFF0F0D1A)))
                }
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
            }
            2 -> {
                val t = rememberInfiniteTransition(label = "aurora")
                val shift by t.animateFloat(
                    0f, 1f, infiniteRepeatable(tween(14000, easing = androidx.compose.animation.core.LinearEasing), RepeatMode.Reverse), label = "shift",
                )
                BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF0A1236))) {
                    val w = constraints.maxWidth.toFloat()
                    val h = constraints.maxHeight.toFloat()
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.radialGradient(
                                listOf(Color(0xFF7C5CFF).copy(alpha = 0.55f), Color.Transparent),
                                center = androidx.compose.ui.geometry.Offset(w * (0.2f + 0.5f * shift), h * 0.25f), radius = w * 0.9f,
                            )
                        )
                    )
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.radialGradient(
                                listOf(Color(0xFF2EE6C5).copy(alpha = 0.40f), Color.Transparent),
                                center = androidx.compose.ui.geometry.Offset(w * (0.9f - 0.6f * shift), h * 0.6f), radius = w * 0.9f,
                            )
                        )
                    )
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.radialGradient(
                                listOf(Color(0xFF55F28A).copy(alpha = 0.30f), Color.Transparent),
                                center = androidx.compose.ui.geometry.Offset(w * (0.3f + 0.3f * shift), h * 0.95f), radius = w * 0.8f,
                            )
                        )
                    )
                }
            }
            3 -> Box(Modifier.fillMaxSize().background(surface))
            4 -> Box(Modifier.fillMaxSize().background(Color.Black))
            5 -> {
                val img = custom
                if (img != null) {
                    androidx.compose.foundation.Image(
                        img, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    )
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
                } else Box(Modifier.fillMaxSize().background(Color.Black))
            }
            else -> Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.6f), surface, surface))))
        }
    }
}

/** Lets the user choose where this song's lyrics come from (embedded in the file, a .lrc file, saved copy, online). */
@Composable
fun LyricsSourceDialog(c: PlayerController, onDismiss: () -> Unit) {
    val actions = LocalActions.current
    val t = c.current ?: run { onDismiss(); return }
    val chosen = c.store.data.lyricsSource[t.id] ?: "auto"
    val avail by androidx.compose.runtime.produceState<Map<String, Boolean>?>(null, t.id) {
        value = c.lyricsRepo.available(t)
    }
    val rows = listOf(
        Triple("auto", "Automatic", "Uses your preferred order from Settings"),
        Triple("embedded", "Embedded in the song", "Lyrics stored inside the audio file's tags"),
        Triple("file", "Lyrics file (.lrc)", "A .lrc file with the same name next to the song"),
        Triple("saved", "Saved / imported copy", "Lyrics you imported or downloaded earlier"),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lyrics source") },
        text = {
            Column {
                rows.forEach { (id, name, sub) ->
                    val has = avail?.get(id)
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).bounceClick { c.setLyricsSource(id); onDismiss() }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        androidx.compose.material3.RadioButton(chosen == id, null)
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(name, fontWeight = FontWeight.Medium)
                            Text(
                                sub + when (has) { true -> if (id == "auto") "" else " · found"; false -> " · not found"; null -> "" },
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } },
        dismissButton = { TextButton({ actions.importLyrics(); onDismiss() }) { Text("Import .lrc file") } },
    )
}

/** Full-screen album art with pinch-to-zoom and drag. */
@Composable
private fun ArtFullscreen(bmp: android.graphics.Bitmap?, onDismiss: () -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        var scale by remember { mutableFloatStateOf(1f) }
        var pan by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
        Box(
            Modifier.fillMaxSize().background(Color.Black)
                .pointerInput(Unit) {
                    detectTransformGestures { _, p, z, _ ->
                        scale = (scale * z).coerceIn(1f, 6f)
                        pan = if (scale > 1f) pan + p else androidx.compose.ui.geometry.Offset.Zero
                    }
                }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { scale = 1f; pan = androidx.compose.ui.geometry.Offset.Zero }) },
            contentAlignment = Alignment.Center,
        ) {
            if (bmp != null) {
                androidx.compose.foundation.Image(
                    bmp.asImageBitmap(), null,
                    Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = pan.x; translationY = pan.y },
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                )
            } else Text("No album art", color = Color.White)
            Box(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp).size(44.dp).bounceClick(onDismiss), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Close, null, tint = Color.White)
            }
        }
    }
}

/** Sleep timer: minutes, end of this song, after N songs, or after a chosen song in the queue. */
@Composable
private fun SleepDialog(c: PlayerController, onDismiss: () -> Unit) {
    var pick by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf("") }
    if (pick) {
        AlertDialog(
            onDismissRequest = { pick = false },
            title = { Text("Stop after which song?") },
            text = {
                androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    itemsIndexed(c.queue) { i, t ->
                        Text(
                            "${i + 1}. ${t.title}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (i == c.currentIndex) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().clickable { c.setSleepAfterSong(t.id); onDismiss() }.padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = { TextButton({ pick = false }) { Text("Back") } },
        )
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep timer") },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                if (c.sleepActive) {
                    val what = when {
                        c.sleepLeftMs > 0 -> "in ${formatTime(c.sleepLeftMs)}"
                        c.sleepSongsLeft > 0 -> "after ${c.sleepSongsLeft} more song(s)"
                        c.sleepStopAtId != 0L -> "after “${c.track(c.sleepStopAtId)?.title ?: "the chosen song"}”"
                        else -> "at the end of this song"
                    }
                    Text("Music stops $what", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
                }
                Text("After a time", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(5, 15, 30, 45, 60, 90).forEach { m ->
                        androidx.compose.material3.AssistChip({ c.setSleepMinutes(m); onDismiss() }, label = { Text("$m min") })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.OutlinedTextField(
                        custom, { custom = it.filter { ch -> ch.isDigit() }.take(4) }, singleLine = true,
                        label = { Text("Minutes") }, modifier = Modifier.weight(1f),
                    )
                    TextButton({ custom.toIntOrNull()?.takeIf { it > 0 }?.let { c.setSleepMinutes(it); onDismiss() } }) { Text("Start") }
                }
                Text("After a number of songs", Modifier.padding(top = 10.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(1, 2, 3, 5, 10, 15).forEach { n ->
                        androidx.compose.material3.AssistChip({ c.setSleepSongs(n); onDismiss() }, label = { Text("$n song${if (n > 1) "s" else ""}") })
                    }
                }
                Text("After a specific song", Modifier.padding(top = 10.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                TextButton({ c.setSleepEndOfTrack(); onDismiss() }, Modifier.fillMaxWidth()) { Text("End of this song") }
                TextButton({ pick = true }, Modifier.fillMaxWidth(), enabled = c.queue.isNotEmpty()) { Text("Choose a song from the queue…") }
                if (c.sleepActive) TextButton({ c.cancelSleep(); onDismiss() }, Modifier.fillMaxWidth()) { Text("Cancel timer") }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } },
    )
}

@Composable
private fun LyricsStyleDialog(c: PlayerController, onDismiss: () -> Unit) {
    val d = c.store.data
    @Composable
    fun Seg(count: Int, selected: Int, label: @Composable (Int) -> Unit, onPick: (Int) -> Unit) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(8.dp))) {
            for (i in 0 until count) {
                Box(
                    Modifier.weight(1f).height(40.dp)
                        .background(if (i == selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .clickable { onPick(i) },
                    contentAlignment = Alignment.Center,
                ) { label(i) }
            }
        }
    }
    @Composable
    fun Sw(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
        Row(Modifier.fillMaxWidth().clickable { onChange(!on) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Medium)
                Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            androidx.compose.material3.Switch(on, onChange)
        }
    }
    @Composable
    fun Sl(title: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>, steps: Int, onChange: (Float) -> Unit) {
        Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            Row { Text(title, Modifier.weight(1f), fontWeight = FontWeight.Medium); Text(value, color = MaterialTheme.colorScheme.primary) }
            Slider(v, onChange, valueRange = range, steps = steps)
        }
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lyrics customisation") },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                Sl("Text size", "${d.lyricScale}%", d.lyricScale.toFloat(), 60f..170f, 10) { v -> c.store.update { it.copy(lyricScale = v.toInt() / 5 * 5) } }
                Sl("Line spacing", "${d.lyricSpacing}%", d.lyricSpacing.toFloat(), 70f..160f, 8) { v -> c.store.update { it.copy(lyricSpacing = v.toInt() / 5 * 5) } }
                Text("Alignment", Modifier.padding(top = 8.dp), fontWeight = FontWeight.Medium)
                Seg(3, d.lyricAlignC, { i -> Text(listOf("Left", "Center", "Right")[i]) }) { v -> c.store.update { it.copy(lyricAlignC = v) } }
                Text("Font", Modifier.padding(top = 4.dp), fontWeight = FontWeight.Medium)
                Seg(2, if (d.lyricSerif) 1 else 0, { i ->
                    Text("Abc", fontFamily = if (i == 1) androidx.compose.ui.text.font.FontFamily.Serif else androidx.compose.ui.text.font.FontFamily.Default)
                }) { v -> c.store.update { it.copy(lyricSerif = v == 1) } }
                Sw("Bold text", "Heavier lyric lines", d.lyricBold) { v -> c.store.update { it.copy(lyricBold = v) } }
                Sw("Highlight in accent colour", "Current line / sung words use the theme colour", d.lyricAccent) { v -> c.store.update { it.copy(lyricAccent = v) } }
                Sw("Word-by-word sync", "Only for songs whose lyrics carry word times (enhanced .lrc)", d.lyricWordSync) { v -> c.store.update { it.copy(lyricWordSync = v) } }
                Sw("Estimate word timing", "Also animate words in songs without word times (a guess)", d.lyricEstimate) { v -> c.store.update { it.copy(lyricEstimate = v) } }
                Sl("Unsung word brightness", "${d.lyricWordDim}%", d.lyricWordDim.toFloat(), 10f..90f, 15) { v -> c.store.update { it.copy(lyricWordDim = v.toInt() / 5 * 5) } }
                Text("Highlight colour", Modifier.padding(top = 8.dp), fontWeight = FontWeight.Medium)
                Row(Modifier.padding(vertical = 6.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(0L, 0xFFFFFFFF, 0xFFFFE066, 0xFF7FE3D0, 0xFFFF8FB1, 0xFF9CFF8A, 0xFFB4A8FF, 0xFF64B5F6).forEach { col ->
                        val sel = d.lyricColor == col
                        Box(
                            Modifier.size(36.dp).clip(CircleShape)
                                .background(if (col == 0L) MaterialTheme.colorScheme.onSurface else androidx.compose.ui.graphics.Color(col))
                                .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline, CircleShape)
                                .clickable { c.store.update { it.copy(lyricColor = col) } },
                            contentAlignment = Alignment.Center,
                        ) { if (col == 0L) Text("A", color = MaterialTheme.colorScheme.surface, fontWeight = FontWeight.Bold) }
                    }
                }
                var hex by androidx.compose.runtime.remember { mutableStateOf("") }
                androidx.compose.material3.OutlinedTextField(
                    hex, { v -> hex = v.filter { ch -> ch.isLetterOrDigit() }.take(6); if (hex.length == 6) hex.toLongOrNull(16)?.let { rgb -> c.store.update { it.copy(lyricColor = 0xFF000000 or rgb) } } },
                    label = { Text("Custom colour (hex, e.g. FF5C8A)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Sl("Other lines brightness", "${d.lyricDim}%", d.lyricDim.toFloat(), 10f..90f, 15) { v -> c.store.update { it.copy(lyricDim = v.toInt() / 5 * 5) } }
                Sl("Other lines size", "${d.lyricInactiveScale}%", d.lyricInactiveScale.toFloat(), 60f..100f, 7) { v -> c.store.update { it.copy(lyricInactiveScale = v.toInt() / 5 * 5) } }
                Sl("Current line position", "${d.lyricAnchor}% from top", d.lyricAnchor.toFloat(), 20f..80f, 11) { v -> c.store.update { it.copy(lyricAnchor = v.toInt() / 5 * 5) } }
                Sl("Scroll speed", "${d.lyricScrollMs} ms", d.lyricScrollMs.toFloat(), 100f..800f, 13) { v -> c.store.update { it.copy(lyricScrollMs = v.toInt() / 50 * 50) } }
                Sw("Show song title", "Cover, title and heart above the lyrics", d.lyricShowSong) { v -> c.store.update { it.copy(lyricShowSong = v) } }
                Sw("Smooth animations", "Turn off for the lightest, fastest lyrics on older phones", d.lyricSmooth) { v -> c.store.update { it.copy(lyricSmooth = v) } }
                Sw("Blur distant lines", "Android 12+ only", d.lyricBlur) { v -> c.store.update { it.copy(lyricBlur = v) } }
                Sl("Lyrics timing", (if (d.lyricOffsetMs >= 0) "+" else "") + "${d.lyricOffsetMs} ms", d.lyricOffsetMs.toFloat(), -1000f..1500f, 49) { v -> c.store.update { it.copy(lyricOffsetMs = (v / 50).toInt() * 50) } }
                Text("Positive = lyrics appear earlier. Increase it if lines feel late.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        dismissButton = {
            TextButton({ c.store.update { it.copy(lyricScale = 100, lyricSpacing = 100, lyricAlignC = 1, lyricSerif = false, lyricBold = true, lyricAccent = false, lyricWordSync = true, lyricEstimate = false, lyricSmooth = true, lyricBlur = true, lyricOffsetMs = 200, lyricColor = 0, lyricDim = 40, lyricInactiveScale = 84, lyricAnchor = 50, lyricScrollMs = 300, lyricWordDim = 38, lyricShowSong = true) } }) { Text("Reset") }
        },
        confirmButton = { TextButton(onDismiss) { Text("Done") } },
    )
}

@Composable
private fun SeekSection(c: PlayerController) {
    Column(Modifier.fillMaxWidth()) {
        var drag by remember { mutableStateOf<Float?>(null) }
        val dur = c.durationMs.coerceAtLeast(1L).toFloat()
        Slider(
            value = (drag ?: c.positionMs.toFloat()).coerceIn(0f, dur),
            onValueChange = { drag = it },
            onValueChangeFinished = { drag?.let { c.seekTo(it.toLong()) }; drag = null },
            valueRange = 0f..dur,
        )
        Row(Modifier.fillMaxWidth()) {
            Text("-" + formatTime((c.durationMs - (drag ?: c.positionMs.toFloat()).toLong()).coerceAtLeast(0)), Modifier.width(64.dp), style = MaterialTheme.typography.labelMedium)
            if (c.abA >= 0) {
                Text(
                    if (c.abB >= 0) "A–B  ${formatTime(c.abA)} – ${formatTime(c.abB)}" else "A  ${formatTime(c.abA)}",
                    Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary,
                )
            } else Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                if (c.store.data.showSeekButtons) {
                Box(Modifier.size(36.dp).bounceClick { c.rewind() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.FastRewind, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(Modifier.size(36.dp).bounceClick { c.fastForward() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.FastForward, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                }
            }
            Text(formatTime(c.durationMs), Modifier.width(64.dp), textAlign = TextAlign.End, style = MaterialTheme.typography.labelMedium)
        }


    }
}
