package com.aurora.player.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import com.aurora.player.player.EQ_FREQS
import com.aurora.player.player.OUTPUTS
import com.aurora.player.player.PlayerController
import kotlin.math.roundToInt

@Composable
fun EqualizerScreen(c: PlayerController, back: () -> Unit) {
    val d = c.store.data
    // Which output's profile is being edited. The active output's profile is the one actually heard.
    var key by remember { mutableStateOf(c.activeOutput) }
    val p = c.profile(key)
    val editingActive = key == c.activeOutput
    var saveDialog by remember { mutableStateOf(false) }

    var page by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).bounceClick(back), contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, null)
            }
            Text("Equalizer", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Switch(p.enabled, { v -> c.editProfile(key) { it.copy(enabled = v) } }, Modifier.padding(end = 16.dp))
        }

        // One profile per output, like Musicolet. The one currently playing gets a pulsing dot.
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(OUTPUTS) { (k, name) ->
                FilterChip(
                    selected = key == k, onClick = { key = k },
                    label = { Text(name) },
                    leadingIcon = if (k == c.activeOutput) ({ ActiveDot() }) else null,
                )
            }
        }
        Text(
            if (editingActive) "Applies to your current output (${OUTPUTS.first { it.first == key }.second}). It switches automatically when you plug in or connect something else."
            else "Not your current output, these settings are used when you switch to ${OUTPUTS.first { it.first == key }.second}.",
            Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (page == 1) KnobsPage(c, key) else {
            var countMenu by remember { mutableStateOf(false) }
            var presetMenu by remember { mutableStateOf(false) }
            var bandCount by remember { mutableStateOf(31) }

            Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box {
                    FilterChip(false, { countMenu = true }, label = { Text("≋  $bandCount") })
                    androidx.compose.material3.DropdownMenu(countMenu, { countMenu = false }) {
                        listOf(31, 15, 10, 5).forEach { n ->
                            androidx.compose.material3.DropdownMenuItem(text = { Text("$n bands") }, onClick = { bandCount = n; countMenu = false })
                        }
                    }
                }
                Box {
                    FilterChip(false, { presetMenu = true }, label = { Text(p.preset) })
                    androidx.compose.material3.DropdownMenu(presetMenu, { presetMenu = false }, Modifier.heightIn(max = 420.dp)) {
                        EQ_PRESETS.forEach { (name, _) ->
                            androidx.compose.material3.DropdownMenuItem(text = { Text(name) }, onClick = {
                                presetMenu = false
                                c.editProfile(key) { it.copy(levels = eqPresetLevels(name), preset = name) }
                            })
                        }
                        d.customPresets.forEach { cp ->
                            androidx.compose.material3.DropdownMenuItem(text = { Text(cp.name) }, onClick = {
                                presetMenu = false
                                val lv = if (cp.levels.size == EQ_FREQS.size) cp.levels else List(EQ_FREQS.size) { 0 }
                                c.editProfile(key) { it.copy(levels = lv, preset = cp.name) }
                            })
                        }
                    }
                }
                PillButton("Save", Icons.Rounded.Save, false) { saveDialog = true }
                PillButton("Reset", Icons.Rounded.RestartAlt, false) {
                    c.editProfile(key) { it.copy(levels = List(EQ_FREQS.size) { 0 }, preset = "Flat", bass = 0, virtualizer = 0, loudness = 0) }
                }
            }
            if (d.customPresets.any { it.name == p.preset }) {
                Box(Modifier.padding(horizontal = 16.dp)) { PillButton("Delete this preset", Icons.Rounded.Delete, false) { c.deleteCustomPreset(p.preset) } }
            }

            ResponseCurve(
                p.levels, -1200, 1200, MaterialTheme.colorScheme.primary,
                Modifier.fillMaxWidth().height(70.dp).padding(horizontal = 20.dp, vertical = 4.dp),
            )

            // one horizontal slider per band; with fewer bands each slider moves its group of neighbours
            val shown = if (bandCount >= 31) (0 until 31).toList() else (0 until bandCount).map { (it * 30f / (bandCount - 1)).roundToInt() }
            shown.forEachIndexed { si, bi ->
                val level = p.levels.getOrNull(bi) ?: 0
                val freq = EQ_FREQS[bi]
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (freq == freq.toInt().toDouble()) (if (freq >= 1000) "${(freq / 1000).toInt()}k" else "${freq.toInt()}") else (if (freq >= 1000) "${freq / 1000}k" else "$freq"),
                        Modifier.width(48.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Slider(
                        level.toFloat(), { v ->
                            val mb = (v / 10f).roundToInt() * 10
                            c.editProfile(key) { cur ->
                                val l = cur.levels.toMutableList()
                                if (bandCount >= 31) l[bi] = mb
                                else {
                                    val lo = if (si == 0) 0 else (shown[si - 1] + bi) / 2 + 1
                                    val hi = if (si == shown.lastIndex) 30 else (bi + shown[si + 1]) / 2
                                    for (j in lo..hi) l[j] = mb
                                }
                                cur.copy(levels = l, preset = "Custom")
                            }
                        },
                        valueRange = -1200f..1200f, modifier = Modifier.weight(1f).height(34.dp),
                    )
                    Text("%.1f".format(level / 100f), Modifier.width(48.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End, style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        if (page == 0) {
        Text(
            "Playback", Modifier.padding(start = 20.dp, top = 20.dp, bottom = 4.dp),
            style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
        )
        SliderRow("Speed", c.speed, 0.5f..2f, "%.2fx".format(c.speed)) { c.setSpeedPitch((it * 20).roundToInt() / 20f, c.pitch) }
        SliderRow("Pitch", c.pitch, 0.5f..2f, "%.2f".format(c.pitch)) { c.setSpeedPitch(c.speed, (it * 20).roundToInt() / 20f) }
        SliderRow("Fade between songs", d.fadeSec.toFloat(), 0f..12f, if (d.fadeSec == 0) "Off" else "${d.fadeSec}s", steps = 11) {
            c.setFadeSeconds(it.roundToInt())
        }
        Text(
            "Fade softly lowers the volume at the end of a song and raises it at the start of the next. Gapless playback is always on.",
            Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Box(Modifier.height(24.dp))
        }
    }
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        listOf(Icons.Rounded.Tune, Icons.Rounded.RadioButtonChecked).forEachIndexed { i, ic ->
            Box(Modifier.size(52.dp).bounceClick { page = i }, contentAlignment = Alignment.Center) {
                Icon(ic, null, Modifier.size(28.dp), tint = if (page == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    }

    if (saveDialog) NameDialog("Save preset", if (p.preset == "Custom") "" else p.preset, "Save", { saveDialog = false }) { name ->
        c.saveCustomPreset(name, p.levels)
        c.editProfile(key) { it.copy(preset = name.trim()) }
        saveDialog = false
    }
}

@Composable
private fun ActiveDot() {
    val t = rememberInfiniteTransition(label = "dot")
    val s by t.animateFloat(0.7f, 1.2f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "dotScale")
    Box(Modifier.size(10.dp).scale(s).background(MaterialTheme.colorScheme.secondary, CircleShape))
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, display: String, steps: Int = 0, onChange: (Float) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        Row {
            Text(label, Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text(display, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(value, onChange, valueRange = range, steps = steps)
    }
}

/** Smooth frequency-response curve that animates as the sliders move. */
@Composable
private fun ResponseCurve(levels: List<Int>, minMb: Int, maxMb: Int, color: Color, modifier: Modifier) {
    val animated = levels.mapIndexed { i, l -> animateFloatAsState(l.toFloat(), spring(), label = "curve$i").value }
    Canvas(modifier.clip(RoundedCornerShape(16.dp))) {
        if (animated.size < 2) return@Canvas
        val n = animated.size
        val range = (maxMb - minMb).coerceAtLeast(1).toFloat()
        val pts = animated.mapIndexed { i, v ->
            Offset(size.width * i / (n - 1), size.height * (1f - (v - minMb) / range))
        }
        val line = Path().apply {
            moveTo(pts[0].x, pts[0].y)
            for (i in 1 until n) {
                val a = pts[i - 1]
                val b = pts[i]
                val mx = (a.x + b.x) / 2
                cubicTo(mx, a.y, mx, b.y, b.x, b.y)
            }
        }
        val fill = Path().apply {
            addPath(line)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        val zeroY = size.height * (1f - (0 - minMb) / range)
        drawLine(color.copy(alpha = 0.25f), Offset(0f, zeroY), Offset(size.width, zeroY), strokeWidth = 2f)
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(line, color, style = Stroke(width = 5f, cap = StrokeCap.Round))
    }
}

/** A slider rotated to run bottom-to-top. */
@Composable
private fun VerticalSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Slider(
        value = value.coerceIn(range.start, range.endInclusive),
        onValueChange = onChange,
        valueRange = range,
        modifier = Modifier
            .graphicsLayer { rotationZ = 270f }
            .layout { measurable, constraints ->
                val p = measurable.measure(
                    Constraints(
                        minWidth = constraints.minHeight, maxWidth = constraints.maxHeight,
                        minHeight = constraints.minWidth, maxHeight = constraints.maxWidth,
                    )
                )
                layout(p.height, p.width) {
                    p.place(-(p.width / 2 - p.height / 2), -(p.height / 2 - p.width / 2))
                }
            },
    )
}

/** Musicolet-style round knob: drag around the circle. [value] is 0..1 (7 o'clock to 5 o'clock). */
@Composable
private fun Knob(value: Float, size: androidx.compose.ui.unit.Dp, onChange: (Float) -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val fill = MaterialTheme.colorScheme.surfaceVariant
    val rim = MaterialTheme.colorScheme.outline
    val latest = androidx.compose.runtime.rememberUpdatedState(onChange)
    Canvas(
        Modifier.size(size).pointerInput(Unit) {
            detectDragGestures { change, _ ->
                val cx = this.size.width / 2f
                val cy = this.size.height / 2f
                val ang = Math.toDegrees(Math.atan2((change.position.x - cx).toDouble(), -(change.position.y - cy).toDouble())).toFloat()
                latest.value(((ang.coerceIn(-135f, 135f)) + 135f) / 270f)
            }
        },
    ) {
        val r = this.size.minDimension / 2f
        drawCircle(fill, r - 3f)
        drawCircle(rim, r - 3f, style = Stroke(width = 5f))
        val ang = Math.toRadians((-135.0 + 270.0 * value.coerceIn(0f, 1f)))
        val dx = Math.sin(ang).toFloat()
        val dy = -Math.cos(ang).toFloat()
        val c0 = center
        drawLine(primary, Offset(c0.x + dx * r * 0.35f, c0.y + dy * r * 0.35f), Offset(c0.x + dx * r * 0.7f, c0.y + dy * r * 0.7f), strokeWidth = 8f, cap = StrokeCap.Round)
    }
}

/** Second page of the equalizer: bass, surround, preamp, volume, stereo/mono and balance. */
@Composable
private fun KnobsPage(c: PlayerController, key: String) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val p = c.profile(key)
    val d = c.store.data
    val am = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableStateOf(am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) / maxVol.toFloat()) }

    Column(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob(p.bass / 1000f, 130.dp) { v -> c.editProfile(key) { it.copy(bass = (v * 1000).roundToInt()) } }
                Text("Bass boost", Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
                Text("${p.bass / 10}%", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob(p.virtualizer / 1000f, 130.dp) { v -> c.editProfile(key) { it.copy(virtualizer = (v * 1000).roundToInt()) } }
                Text("Surround Sound", Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
                Text("${p.virtualizer / 10}%", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 40.dp, vertical = 16.dp))
        Text("Preamp", fontWeight = FontWeight.Bold)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(-600 to "Headroom\n-6 dB", 0 to "Off\n0 dB", 900 to "Boost\n+9 dB").forEach { (mb, label) ->
                FilterChip(p.loudness == mb, { c.editProfile(key) { it.copy(loudness = mb) } }, label = { Text(label, textAlign = androidx.compose.ui.text.style.TextAlign.Center) })
            }
        }
        Slider(
            p.loudness.toFloat().coerceIn(-600f, 900f), { v -> c.editProfile(key) { it.copy(loudness = (v / 50f).roundToInt() * 50) } },
            valueRange = -600f..900f, modifier = Modifier.padding(horizontal = 36.dp),
        )
        Text("%+.1f dB".format(p.loudness / 100f), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        if (!c.store.data.soundEngine) Text(
            "Aurora sound engine is off, so the preamp only uses the phone's own loudness booster. Turn the engine on in Settings > Audio and restart Aurora for a stronger preamp.",
            Modifier.padding(horizontal = 32.dp, vertical = 6.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
        )
        androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 40.dp, vertical = 16.dp))
        Text("Reverb", fontWeight = FontWeight.Bold)
        val rp = c.store.data.reverbPreset
        Row(Modifier.padding(top = 8.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Off", "Small room", "Medium room", "Large hall", "Plate").forEachIndexed { i, n ->
                FilterChip(rp == i, { c.setReverb(i, c.store.data.reverbLevel) }, label = { Text(n) })
            }
        }
        if (rp != 0) {
            Slider(
                c.store.data.reverbLevel.toFloat(), { v -> c.setReverb(rp, v.roundToInt()) },
                valueRange = 0f..100f, modifier = Modifier.padding(horizontal = 36.dp),
            )
            Text("Effect level ${c.store.data.reverbLevel}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 40.dp, vertical = 16.dp))
        Text("Volume", fontWeight = FontWeight.Bold)
        Slider(
            vol, { v -> vol = v; try { am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (v * maxVol).roundToInt(), 0) } catch (_: Exception) {} },
            modifier = Modifier.padding(horizontal = 36.dp),
        )
        androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 40.dp, vertical = 16.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!d.mono, { c.setMono(false) }, label = { Text("Stereo") })
                FilterChip(d.mono, { c.setMono(true) }, label = { Text("Mono") })
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob((d.balance + 100) / 200f, 120.dp) { v ->
                    val b = (v * 200f - 100f).roundToInt()
                    c.setBalance(if (kotlin.math.abs(b) < 6) 0 else b)
                }
                Text("Audio channel balance", Modifier.padding(top = 10.dp), fontWeight = FontWeight.Bold)
                Text("Left:${100 - maxOf(0, d.balance)}, Right:${100 + minOf(0, d.balance)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Box(Modifier.height(24.dp))
    }
}

/** Preset name to the 31 band levels (millibels), built from smooth bass / mid / treble shapes. */
val EQ_PRESETS: List<Pair<String, Unit>> = listOf(
    "Flat", "Bass", "Mids", "Treble", "Bass and Treble", "Full Bass", "Full Mids", "Full Treble",
    "Reduced Bass", "Reduced Mids", "Reduced Treble", "No Bass", "No Mids", "No Treble",
    "Classic", "Dance", "Live", "Pop", "Rock", "Jazz", "Vocal", "Loudness",
).map { it to Unit }

private fun region(lo: Int, hi: Int, mb: Int): IntArray = IntArray(31) { i ->
    when {
        i in lo..hi -> mb
        i == lo - 1 || i == hi + 1 -> mb / 2
        i == lo - 2 || i == hi + 2 -> mb / 4
        else -> 0
    }
}

private fun sum(vararg a: IntArray): List<Int> = List(31) { i -> a.sumOf { it[i] }.coerceIn(-1200, 1200) }

fun eqPresetLevels(name: String): List<Int> {
    val bass = 0 to 9; val mids = 10 to 21; val treble = 22 to 30
    fun r(z: Pair<Int, Int>, mb: Int) = region(z.first, z.second, mb)
    return when (name) {
        "Bass" -> sum(r(bass, 600))
        "Mids" -> sum(r(mids, 500))
        "Treble" -> sum(r(treble, 600))
        "Bass and Treble" -> sum(r(bass, 600), r(treble, 600))
        "Full Bass" -> sum(r(bass, 1100))
        "Full Mids" -> sum(r(mids, 1000))
        "Full Treble" -> sum(r(treble, 1100))
        "Reduced Bass" -> sum(r(bass, -600))
        "Reduced Mids" -> sum(r(mids, -500))
        "Reduced Treble" -> sum(r(treble, -600))
        "No Bass" -> sum(r(bass, -1200))
        "No Mids" -> sum(r(mids, -1200))
        "No Treble" -> sum(r(treble, -1200))
        "Classic" -> sum(r(0 to 6, 400), r(24 to 30, 500), r(11 to 17, -200))
        "Dance" -> sum(r(2 to 10, 800), r(13 to 18, -300), r(24 to 30, 400))
        "Live" -> sum(r(0 to 6, -300), r(12 to 19, 300), r(22 to 28, 400))
        "Pop" -> sum(r(0 to 5, -200), r(13 to 20, 400), r(24 to 30, 300))
        "Rock" -> sum(r(0 to 9, 600), r(13 to 18, -300), r(22 to 30, 600))
        "Jazz" -> sum(r(2 to 9, 400), r(12 to 18, -200), r(24 to 30, 300))
        "Vocal" -> sum(r(0 to 8, -400), r(14 to 22, 600), r(26 to 30, -200))
        "Loudness" -> sum(r(0 to 9, 700), r(24 to 30, 600), r(13 to 18, -200))
        else -> List(31) { 0 }
    }
}
