package com.aurora.player.ui

import android.content.Intent
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

private enum class Period { Week, Month, Year, All }

private class Range(val from: Long, val to: Long, val label: String)

/** Start/end of the week, month or year that is [offset] periods away from now (0 = current, -1 = previous...). */
private fun rangeFor(p: Period, offset: Int): Range {
    val cal = Calendar.getInstance().apply {
        firstDayOfWeek = Calendar.MONDAY
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    val label: String
    when (p) {
        Period.Week -> {
            cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            cal.add(Calendar.WEEK_OF_YEAR, offset)
            label = if (offset == 0) "This week" else "Week of " + SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(cal.time)
        }
        Period.Month -> {
            cal.set(Calendar.DAY_OF_MONTH, 1)
            cal.add(Calendar.MONTH, offset)
            label = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)
        }
        Period.Year -> {
            cal.set(Calendar.DAY_OF_YEAR, 1)
            cal.add(Calendar.YEAR, offset)
            label = SimpleDateFormat("yyyy", Locale.getDefault()).format(cal.time)
        }
        Period.All -> return Range(0, Long.MAX_VALUE, "All time")
    }
    val from = cal.timeInMillis
    when (p) {
        Period.Week -> cal.add(Calendar.WEEK_OF_YEAR, 1)
        Period.Month -> cal.add(Calendar.MONTH, 1)
        else -> cal.add(Calendar.YEAR, 1)
    }
    return Range(from, cal.timeInMillis, label)
}

private class ArtistStat(val name: String, val plays: Int, val songs: List<Pair<Track, Int>>)

private fun pct(n: Int, total: Int) = if (total == 0) "0%" else "%.1f%%".format(n * 100.0 / total)

@Composable
fun MostPlayedScreen(c: PlayerController, push: (Route) -> Unit, back: () -> Unit) {
    val ctx = LocalContext.current
    var period by remember { mutableStateOf(Period.All) }
    var offset by remember { mutableIntStateOf(0) }
    var showArtists by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var saveDialog by remember { mutableStateOf(false) }
    var shareDlg by remember { mutableIntStateOf(0) } // 1 songs, 2 artists
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val accent = MaterialTheme.colorScheme.primary.toArgb()

    val range = remember(period, offset) { rangeFor(period, offset) }
    val events = c.playLog.events
    val totals = c.store.data.playCounts

    // id -> number of plays inside the chosen period
    val counts: Map<Long, Int> = remember(period, offset, events, totals) {
        if (period == Period.All) totals
        else events.asSequence().filter { it.at >= range.from && it.at < range.to }.groupingBy { it.id }.eachCount()
    }
    val songs: List<Pair<Track, Int>> = remember(counts, c.library) {
        counts.entries.mapNotNull { e -> c.track(e.key)?.let { it to e.value } }
            .filter { it.second > 0 }.sortedByDescending { it.second }
    }
    // artists are always separated here ("A & B; C" counts for A, B and C), using your separator list
    val seps = c.store.data.artistSeparators.ifEmpty { ",;/&" }
    val artists = remember(songs, seps) {
        val m = LinkedHashMap<String, MutableList<Pair<Track, Int>>>()
        for (e in songs) for (a in artistsOf(e.first, true, seps)) m.getOrPut(a) { ArrayList() }.add(e)
        m.map { (name, list) -> ArtistStat(name, list.sumOf { it.second }, list) }.sortedByDescending { it.plays }
    }
    val artistTotal = remember(artists) { artists.sumOf { it.plays } }
    val totalPlays = remember(songs) { songs.sumOf { it.second } }
    val listened = remember(songs) { songs.sumOf { it.first.durationMs * it.second } }
    val shown = remember(songs, query) {
        if (query.isBlank()) songs
        else songs.filter { (t, _) -> searchMatches(t, query) }
    }

    val now = remember { Calendar.getInstance() }
    val monthName = remember { SimpleDateFormat("MMMM", Locale.getDefault()).format(now.time) }

    fun share(text: String) {
        ctx.startActivity(
            Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Share list",
            )
        )
    }
    fun songsText() = buildString {
        append("Most played · ${range.label}\n")
        songs.forEachIndexed { i, (t, n) -> append("${i + 1}. ${t.title} – ${t.artist} (${n}×)\n") }
    }
    fun artistsText() = buildString {
        append("Most played · Artists · ${range.label}\n")
        artists.forEachIndexed { i, a -> append("${i + 1}. ${a.name} – ${pct(a.plays, artistTotal)} (${a.plays}×)\n") }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).bounceClick(back), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Text("Most played", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Box(Modifier.size(44.dp).bounceClick { searching = !searching; if (!searching) query = "" }, contentAlignment = Alignment.Center) {
                Icon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, null)
            }
        }

        // period tabs, like Musicolet: This week | <month> | <year> | All time
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                Period.Week to "This week", Period.Month to monthName,
                Period.Year to now.get(Calendar.YEAR).toString(), Period.All to "All time",
            ).forEach { (p, label) ->
                FilterChip(period == p, { period = p; offset = 0 }, label = { Text(label) })
            }
        }
        if (period != Period.All) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).bounceClick { offset-- }, contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, null)
                }
                Text(range.label, Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.SemiBold)
                Box(Modifier.size(44.dp).then(if (offset < 0) Modifier.bounceClick { offset++ } else Modifier), contentAlignment = Alignment.Center) {
                    Icon(
                        Icons.AutoMirrored.Rounded.KeyboardArrowRight, null,
                        tint = if (offset < 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.25f),
                    )
                }
            }
        }

        if (searching) {
            OutlinedTextField(
                query, { query = it }, singleLine = true, placeholder = { Text("Search in this list…") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) }, shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }

        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    when {
                        query.isNotBlank() -> "No matches."
                        period == Period.All -> "Nothing played yet."
                        else -> "Nothing was played in this period."
                    },
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(32.dp),
                )
            }
        } else {
            val podium = if (query.isBlank() && shown.size >= 3) 3 else 0
            val animTotal by animateIntAsState(totalPlays, tween(700), label = "plays")
            LazyColumn(contentPadding = PaddingValues(bottom = 140.dp, top = 4.dp)) {
                item(key = "hero") {
                    Box(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                            .clip(RoundedCornerShape(28.dp))
                            .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer)))
                            .padding(20.dp),
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.LocalFireDepartment, null, Modifier.size(34.dp), tint = MaterialTheme.colorScheme.primary)
                                Text(
                                    "$animTotal", Modifier.padding(start = 8.dp),
                                    style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.ExtraBold,
                                )
                                Text(
                                    if (totalPlays == 1) " play" else " plays", Modifier.padding(start = 4.dp, top = 12.dp),
                                    style = MaterialTheme.typography.titleMedium,
                                )
                            }
                            Text(
                                "${songs.size} ${if (songs.size == 1) "song" else "songs"} · ${formatTime(listened)} listened",
                                Modifier.padding(top = 4.dp), style = MaterialTheme.typography.bodyMedium,
                            )
                            if (artists.isNotEmpty()) {
                                Text(
                                    "Top artist: ${artists.first().name} (${artists.first().plays}×)",
                                    Modifier.padding(top = 2.dp), style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                PillButton("Play", Icons.Rounded.PlayArrow, true) { c.playTracks(songs.map { it.first }, 0, false) }
                                PillButton("Shuffle", Icons.Rounded.Shuffle, false) { c.playTracks(songs.map { it.first }.shuffled(), 0, true) }
                                PillButton("Artists", Icons.Rounded.Person, false) { showArtists = true }
                            }
                        }
                    }
                }
                if (podium == 3) {
                    item(key = "podium") {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom,
                        ) {
                            listOf(1, 0, 2).forEach { idx ->
                                val (t, n) = shown[idx]
                                val big = idx == 0
                                Column(
                                    Modifier.weight(1f).bounceClick { c.playTracks(shown.map { it.first }, idx) },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                ) {
                                    Box(contentAlignment = Alignment.BottomCenter) {
                                        AlbumArt(t, Modifier.size(if (big) 104.dp else 80.dp), RoundedCornerShape(if (big) 28.dp else 22.dp), px = 320)
                                        Box(
                                            Modifier.offset(y = 10.dp).size(26.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                                            contentAlignment = Alignment.Center,
                                        ) {
                                            Text("${idx + 1}", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                        }
                                    }
                                    Text(
                                        t.title, Modifier.padding(top = 16.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
                                    )
                                    Text(
                                        "$n×", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelLarge,
                                    )
                                }
                            }
                        }
                    }
                }
                item(key = "tools") {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (podium == 3) "Rest of the list" else "Songs", Modifier.weight(1f).padding(start = 4.dp),
                            fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Box(Modifier.size(44.dp).bounceClick { shareDlg = 1 }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Share, null) }
                        Box {
                            Box(Modifier.size(44.dp).bounceClick { menu = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MoreVert, null) }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem(text = { Text("Add all to queue") }, onClick = { menu = false; c.addAllToQueue(songs.map { it.first }) })
                                DropdownMenuItem(text = { Text("Save as playlist") }, onClick = { menu = false; if (songs.isNotEmpty()) saveDialog = true })
                            }
                        }
                    }
                }
                itemsIndexed(shown.drop(podium), key = { _, s -> s.first.id }) { i, (t, n) ->
                    TrackRow(t, c, Modifier.animateItem(), playCount = n) { c.playTracks(shown.map { it.first }, i + podium) }
                }
            }
        }
    }

    if (showArtists) {
        AlertDialog(
            onDismissRequest = { showArtists = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.LocalFireDepartment, null, Modifier.size(30.dp))
                    Text("Most played · Artists · ${range.label}", Modifier.padding(start = 12.dp), style = MaterialTheme.typography.titleMedium)
                }
            },
            text = {
                if (artists.isEmpty()) Text("Nothing played in this period.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                else LazyColumn(Modifier.heightIn(max = 460.dp)) {
                    itemsIndexed(artists, key = { _, a -> a.name }) { i, a ->
                        Row(
                            Modifier.fillMaxWidth().clickable { showArtists = false; push(Route.Detail("artist", a.name)) }.padding(vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("${i + 1}", Modifier.width(30.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelLarge)
                            Column(Modifier.weight(1f)) {
                                Text(a.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                LinearProgressIndicator(
                                    progress = { if (artistTotal == 0) 0f else a.plays.toFloat() / artistTotal },
                                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                )
                            }
                            Text(
                                pct(a.plays, artistTotal), Modifier.width(60.dp).padding(start = 8.dp), textAlign = TextAlign.End,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold,
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton({ if (artists.isNotEmpty()) shareDlg = 2 }) { Text("SAVE / SHARE") } },
            dismissButton = { TextButton({ showArtists = false }) { Text("CLOSE") } },
        )
    }
    if (saveDialog) NameDialog("Save as playlist", "Most played · ${range.label}", "Save", { saveDialog = false }) {
        c.store.createPlaylist(it, songs.map { s -> s.first.id }); saveDialog = false
    }

    if (shareDlg != 0) {
        ShareScreen(
            c, songs, artists.map { it.name to it.plays }, artistTotal, range.label, listened,
            startPage = if (shareDlg == 2) 1 else 0, onClose = { shareDlg = 0 },
        )
    }
}
