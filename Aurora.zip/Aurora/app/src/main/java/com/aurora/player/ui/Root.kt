package com.aurora.player.ui

import com.aurora.player.data.albumKey
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.player.PlayerController

@Composable
fun AuroraRoot(c: PlayerController, route: String? = null, onRouteHandled: () -> Unit = {}) {
    var stack by remember { mutableStateOf<List<Route>>(listOf(Route.Library)) }
    var showNow by remember { mutableStateOf(false) }
    var tabRequest by remember { mutableStateOf<String?>(null) }
    // the tab you were on when the app closed is where it opens next time
    val uiPrefs = androidx.compose.ui.platform.LocalContext.current.getSharedPreferences("aurora_ui", android.content.Context.MODE_PRIVATE)
    // a fresh start (the app was swiped away from recents) opens Home; coming back while it is still alive returns to where you were
    var libTab by remember { mutableStateOf(AppSession.tab ?: "home") }
    val tabHistory = remember { mutableListOf<String>() }
    var backNav by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    val activity = androidx.compose.ui.platform.LocalContext.current as? android.app.Activity
    val openNow = {
        if ("now" in visibleTabs(c.store.data)) {
            stack = listOf(Route.Library); tabRequest = "now"
        } else { showNow = true }
    }
    val prevSize = remember { mutableIntStateOf(1) }
    val pushing = stack.size >= prevSize.intValue
    SideEffect { prevSize.intValue = stack.size }

    var addPlFor by remember { mutableStateOf<Long?>(null) }
    addPlFor?.let { id -> AddToPlaylistDialog(c, listOf(id)) { addPlFor = null } }
    LaunchedEffect(route) {
        when (route) {
            "queue" -> {
                c.queueScrollTick++
                activity?.applicationContext?.let { com.aurora.player.widget.WidgetUpdater.scrollQueueToCurrent(it) }
                showNow = false
                if ("queues" in visibleTabs(c.store.data)) { stack = listOf(Route.Library); tabRequest = "queues" }
                else { stack = listOf(Route.Library, Route.Queue) }
            }
            "addpl" -> addPlFor = c.current?.id
            "alarms" -> { SettingsRequest.page = "alarms"; showNow = false; stack = listOf(Route.Library, Route.Settings) }
            "now" -> openNow()
            "shuffle" -> { if (c.library.isNotEmpty()) c.playFromSource("All songs", c.library.shuffled(), 0, true); openNow() }
            "mostplayed" -> { showNow = false; stack = listOf(Route.Library, Route.MostPlayed) }
            else -> if (route != null && route.startsWith("detail|")) {
                val p = route.split('|', limit = 3)
                if (p.size == 3) { showNow = false; stack = listOf(Route.Library, Route.Detail(p[1], p[2])) }
            } else if (route != null && route.startsWith("tab|")) {
                showNow = false; stack = listOf(Route.Library); tabRequest = route.removePrefix("tab|")
            }
        }
        if (route != null) onRouteHandled()
    }

    BackHandler(enabled = showNow) { showNow = false }
    BackHandler(enabled = !showNow && stack.size > 1) { stack = stack.dropLast(1) }
    // back on the first tab of the library: go to it first, then (optionally) confirm before leaving
    val firstTab = visibleTabs(c.store.data).first()
    val modeNow = c.store.data.backMode == 1
    // mode 0: step back through the tabs you visited; mode 1: jump to "Now playing", then exit
    val tabBack = libTab.isNotEmpty() && (if (modeNow) libTab != "now" else tabHistory.isNotEmpty())
    BackHandler(enabled = !showNow && stack.size == 1 && tabBack) {
        backNav = true
        if (modeNow) tabRequest = "now" else tabRequest = tabHistory.removeAt(tabHistory.lastIndex)
    }
    BackHandler(enabled = !showNow && stack.size == 1 && !tabBack && c.store.data.confirmExit) { confirmExit = true }

    val push = { r: Route -> Motion.seen.clear(); stack = stack + r }
    val pop = { Motion.seen.clear(); stack = stack.dropLast(1) }

    // landscape: the strip beside the camera notch is black on Now playing (like a bezel) instead of a bright bar next to the dark screen
    val rootLand = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val rootOnNow = rootLand && (showNow || (stack.size == 1 && libTab == "now"))
    val rootBg = if (rootOnNow) androidx.compose.ui.graphics.Color.Black else MaterialTheme.colorScheme.background
    Box(Modifier.fillMaxSize().background(rootBg)) {
    // the Now Playing background also fills the strip beside the camera notch, so nothing looks cut off
    SideEffect { ExpressiveState.rootBackdrop = rootOnNow }
    if (rootOnNow) NowBackdrop(c)
    Box(
        Modifier.fillMaxSize().imePadding()
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val e = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                        if (e.changes.any { it.pressed && !it.previousPressed }) ExpressiveState.touch++
                    }
                }
            }
            // landscape: keep content clear of the notch and of a side navigation bar
            .windowInsetsPadding(WindowInsets.systemBars.union(WindowInsets.displayCutout).only(WindowInsetsSides.Horizontal)),
    ) {
        AnimatedContent(
            stack.last(),
            transitionSpec = { navTransition(pushing) },
            label = "nav",
        ) { route ->
            when (route) {
                Route.Library -> LibraryScreen(
                    c, push, tabRequest, { tabRequest = null }, { t -> if (backNav) backNav = false else if (libTab.isNotEmpty() && libTab != t) { tabHistory.remove(libTab); tabHistory.add(libTab) }; Motion.seen.clear(); libTab = t; if (t.isNotEmpty()) AppSession.tab = t }, startTab = libTab,
                    nowPage = { close, openQueue ->
                        NowPlayingScreen(
                            c, onClose = close, openQueue = openQueue, openEq = { push(Route.Equalizer) }, embedded = true,
                            openArtist = { n -> push(Route.Detail("artist", n)) },
                            openAlbum = { t -> push(Route.Detail("album", t.albumKey())) },
                        )
                    },
                )
                is Route.Detail -> DetailScreen(c, route.kind, route.key, pop)
                Route.Queue -> QueueScreen(c, pop)
                Route.Equalizer -> EqualizerScreen(c, pop)
                Route.Settings -> SettingsScreen(c, pop) { push(Route.Equalizer) }
                Route.MostPlayed -> MostPlayedScreen(c, push, pop)
                Route.Mixes -> MixesScreen(c, pop)
                Route.YearReview -> YearInReviewScreen(c, pop)
            }
        }

        val miniOn = c.current != null && !showNow && !c.store.data.uiMiniHide && run {
            val top = stack.last()
            (stack.size == 1 && (libTab == "albums" || libTab == "artists")) ||
                (top is Route.Detail && (top.kind == "album" || top.kind == "artist"))
        }
        androidx.compose.runtime.SideEffect { ExpressiveState.miniShown = miniOn }
        // sits right above the tab pill while the pill is out (the pill is never under it), and drops to the bottom when the pill tucks away
        val pillUp = stack.size == 1 && c.store.data.uiPillNav && !ExpressiveState.pillGone
        val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val navInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        val miniLift by androidx.compose.animation.core.animateDpAsState(
            if (pillUp) (if (land) 42.dp else 68.dp) + navInset
            else if (stack.size == 1 && !c.store.data.uiPillNav && c.store.data.tabsBottom) 56.dp + navInset else navInset,
            androidx.compose.animation.core.spring(Spring.DampingRatioNoBouncy, Spring.StiffnessMediumLow), label = "miniLift",
        )
        AnimatedVisibility(
            miniOn,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = miniLift),
            enter = slideInVertically(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { it } + fadeIn(),
            exit = slideOutVertically(tween(250)) { it } + fadeOut(tween(200)),
        ) {
            MiniPlayer(c) { openNow() }
        }

        if (c.selection.isNotEmpty() && !showNow && !(stack.size == 1 && libTab == "queues") && stack.last().let { it !is Route.Detail && it !is Route.Queue }) {
            SelectionBar(
                c, c.selection.toList(), inQueue = false, onRemove = {}, onSelectAll = {}, onInvert = {},
                onCancel = { c.selection.clear() }, showAdvanced = false,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = if (stack.size == 1 && c.store.data.uiPillNav) (if (ExpressiveState.pillGone) 0.dp else 78.dp) else if (stack.size == 1 && c.store.data.tabsBottom) 56.dp else 0.dp),
            )
        }
        c.playbackError?.let { msg ->
            val clip = androidx.compose.ui.platform.LocalClipboardManager.current
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { c.playbackError = null },
                title = { Text("Can't play this song") },
                text = {
                    androidx.compose.foundation.layout.Column(Modifier.heightIn(max = 320.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                        Text(msg, style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { androidx.compose.material3.TextButton({ clip.setText(androidx.compose.ui.text.AnnotatedString(msg)); c.playbackError = null }) { Text("Copy") } },
                dismissButton = { androidx.compose.material3.TextButton({ c.playbackError = null }) { Text("Close") } },
            )
        }
        c.resumeAsk?.let { (t, p) ->
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { c.answerResume(false) },
                title = { Text("Resume from ${com.aurora.player.data.formatTime(p)}?") },
                text = { Text("“${t.title}” was stopped at ${com.aurora.player.data.formatTime(p)}.") },
                confirmButton = { androidx.compose.material3.TextButton({ c.answerResume(true) }) { Text("Resume") } },
                dismissButton = { androidx.compose.material3.TextButton({ c.answerResume(false) }) { Text("Start over") } },
            )
        }
        if (!c.store.data.welcomeSeen) WelcomeGuide { c.store.update { it.copy(welcomeSeen = true) } }
        BackupDialogs()
        if (confirmExit) androidx.compose.material3.AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Exit Aurora?") },
            text = { Text("Music keeps playing in the background if it is playing now.") },
            confirmButton = { androidx.compose.material3.TextButton({ confirmExit = false; activity?.finish() }) { Text("Exit") } },
            dismissButton = { androidx.compose.material3.TextButton({ confirmExit = false }) { Text("Stay") } },
        )

        AnimatedVisibility(
            showNow,
            enter = slideInVertically(tween(480, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300)),
            exit = slideOutVertically(tween(380, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(300)),
        ) {
            NowPlayingScreen(
                c, onClose = { showNow = false },
                openQueue = { showNow = false; push(Route.Queue) },
                openEq = { showNow = false; push(Route.Equalizer) },
                openArtist = { n -> showNow = false; push(Route.Detail("artist", n)) },
                openAlbum = { t -> showNow = false; push(Route.Detail("album", t.albumKey())) },
            )
        }

        // full-screen pages that sit above everything (the share pages): above the mini player and the tab pill too
        FullOverlay.content?.let { body ->
            androidx.activity.compose.BackHandler { FullOverlay.content = null }
            Box(Modifier.fillMaxSize()) { body() }
        }
    }
    }
}

@Composable
private fun MiniPlayer(c: PlayerController, onOpen: () -> Unit) {
    val t = c.current ?: return
    if (c.store.data.uiMiniHide) return
    Column(
        Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
            .shadow(14.dp, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onOpen)
            .then(
                if (!c.store.data.uiMiniExpand) Modifier else Modifier.pointerInput(Unit) {
                    // swipe up opens the player, swipe sideways skips
                    var dx = 0f; var dy = 0f
                    detectDragGestures(
                        onDragStart = { dx = 0f; dy = 0f },
                        onDragEnd = {
                            if (dy < -70f && kotlin.math.abs(dy) > kotlin.math.abs(dx)) onOpen()
                            else if (dx < -110f) c.next() else if (dx > 110f) c.previous()
                        },
                    ) { change, drag -> change.consume(); dx += drag.x; dy += drag.y }
                },
            ),
    ) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(t, Modifier.size(46.dp), CircleShape, 22.dp)
            AnimatedContent(
                t.id, Modifier.weight(1f).padding(horizontal = 12.dp),
                transitionSpec = {
                    (slideInVertically(tween(300)) { it / 2 } + fadeIn(tween(300))) togetherWith
                        (slideOutVertically(tween(200)) { -it / 2 } + fadeOut(tween(150)))
                },
                label = "miniTitle",
            ) {
                Column {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Box(Modifier.size(44.dp).bounceClick { c.togglePlay() }, contentAlignment = Alignment.Center) {
                AnimatedContent(
                    c.isPlaying,
                    transitionSpec = { (androidx.compose.animation.scaleIn() + fadeIn()) togetherWith (androidx.compose.animation.scaleOut() + fadeOut()) },
                    label = "miniPlay",
                ) { p -> Icon(if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, modifier = Modifier.size(30.dp)) }
            }
            Box(Modifier.size(44.dp).bounceClick { c.next() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.SkipNext, null, modifier = Modifier.size(28.dp))
            }
        }
        if (c.store.data.uiMiniExpand) {
            // hairline progress
            val frac = if (c.durationMs > 0) (c.positionMs.toFloat() / c.durationMs).coerceIn(0f, 1f) else 0f
            Box(Modifier.fillMaxWidth().height(2.dp).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f))) {
                Box(Modifier.fillMaxWidth(frac).height(2.dp).background(MaterialTheme.colorScheme.primary))
            }
        } else LinearProgressIndicator(
            progress = { if (c.durationMs > 0) (c.positionMs.toFloat() / c.durationMs).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth(),
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
    }
}

/** A page drawn over the whole app (status bar to navigation bar), above the mini player and the tab pill. */
object FullOverlay {
    var content by androidx.compose.runtime.mutableStateOf<(@Composable () -> Unit)?>(null)
}

/** Lives as long as the app's process: empty after the app is swiped away, so the next start opens Home. */
object AppSession {
    var tab: String? = null
    /** True once the music library has been read (or there is nothing to wait for). */
    var ready by androidx.compose.runtime.mutableStateOf(false)
}
