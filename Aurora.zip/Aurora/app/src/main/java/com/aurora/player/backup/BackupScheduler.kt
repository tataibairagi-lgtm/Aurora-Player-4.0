package com.aurora.player.backup

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.aurora.player.controller
import com.aurora.player.data.MediaScanner
import com.aurora.player.data.Persisted
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/** Automatic backups: a background job that writes a new zip into the chosen folder every N days. */
object BackupScheduler {
    private const val NAME = "aurora_auto_backup"

    fun apply(ctx: Context, d: Persisted) {
        val wm = WorkManager.getInstance(ctx.applicationContext)
        if (!d.autoBackup) {
            wm.cancelUniqueWork(NAME)
            return
        }
        val req = PeriodicWorkRequestBuilder<BackupWorker>(d.autoBackupDays.toLong().coerceAtLeast(1), TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiresStorageNotLow(true).build())
            .build()
        wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

class BackupWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext
        val c = app.controller
        if (c.library.isEmpty()) {
            if (!MediaScanner.hasAudioPermission(app)) return Result.failure()
            val list = withContext(Dispatchers.IO) { runCatching { MediaScanner.scan(app) }.getOrDefault(emptyList()) }
            withContext(Dispatchers.Main) { c.attachLibrary(list) }
        }
        val ok = withContext(Dispatchers.IO) { BackupManager.backupToFolder(app, c) }
        return when {
            ok -> Result.success()
            runAttemptCount >= 3 -> Result.failure()
            else -> Result.retry()
        }
    }
}
