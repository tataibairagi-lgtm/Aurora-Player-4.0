package com.aurora.player

import android.app.Application
import android.app.WallpaperManager
import android.content.ComponentCallbacks
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.aurora.player.backup.BackupUiState
import com.aurora.player.data.LyricsRepo
import com.aurora.player.data.Store
import com.aurora.player.player.PlayerController
import com.aurora.player.widget.WidgetUpdater

class AuroraApp : Application() {
    lateinit var controller: PlayerController
        private set
    val backupUi = BackupUiState()

    override fun onCreate() {
        super.onCreate()
        controller = PlayerController(this, Store(this), LyricsRepo(this))

        // The queue widget takes its colours from the wallpaper, so redraw it when either the wallpaper
        // or the light/dark mode changes (while Aurora's process is alive, e.g. during playback).
        if (Build.VERSION.SDK_INT >= 27) {
            try {
                WallpaperManager.getInstance(this).addOnColorsChangedListener(
                    WallpaperManager.OnColorsChangedListener { _, _ -> WidgetUpdater.update(this) },
                    Handler(Looper.getMainLooper()),
                )
            } catch (_: Exception) {
            }
        }
        registerComponentCallbacks(object : ComponentCallbacks {
            override fun onConfigurationChanged(newConfig: Configuration) { WidgetUpdater.update(this@AuroraApp) }
            override fun onLowMemory() {}
        })
    }
}

val Context.controller: PlayerController
    get() = (applicationContext as AuroraApp).controller

val Context.backupUi: BackupUiState
    get() = (applicationContext as AuroraApp).backupUi
