package com.aurora.player.player

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import kotlin.math.sqrt

/** Calls [onShake] when the phone is shaken. Only listens while it is started, so it costs nothing when the setting is off. */
class ShakeDetector(ctx: Context, private val onShake: () -> Unit) : SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private var running = false
    private var last = 0L
    @Volatile var threshold = 16f // m/s² above gravity; lower = more sensitive

    fun start() {
        if (running) return
        val s = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) ?: return
        running = sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI)
    }

    fun stop() {
        if (!running) return
        try { sm?.unregisterListener(this) } catch (_: Throwable) {}
        running = false
    }

    override fun onSensorChanged(e: SensorEvent) {
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) - SensorManager.GRAVITY_EARTH
        val now = SystemClock.elapsedRealtime()
        if (g > threshold && now - last > 1500) { last = now; onShake() }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
