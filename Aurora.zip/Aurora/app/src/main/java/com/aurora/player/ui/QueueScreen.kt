package com.aurora.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest
import androidx.compose.animation.animateContentSize
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

private fun csvCell(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

fun queueCsv(tracks: List<Track>): String = buildString {
    append("Position,Title,Artist,Album,Duration (s),Path\n")
    tracks.forEachIndexed { i, t ->
        append("${i + 1},${csvCell(t.title)},${csvCell(t.artist)},${csvCell(t.album)},${t.durationMs / 1000},${csvCell(t.path)}\n")
    }
}

fun queueM3u8(tracks: List<Track>): String = buildString {
    append("#EXTM3U\n")
    tracks.forEach { t -> append("#EXTINF:${t.durationMs / 1000},${t.artist} - ${t.title}\n${t.path}\n") }
}

/** Musicolet-style queues page: up to 20 queues, drag to reorder, multi-select with options, search, export. */
@Composable
fun QueueScreen(c: PlayerController, back: () -> Unit, embedded: Boolean = false) {
    val actions = LocalActions.current
    val state = rememberLazyListState()
    var query by remember { mutableStateOf("") }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var saveDialog by remember { mutableStateOf(false) }
    var newDialog by remember { mutableStateOf(false) }
    var renameDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    // --- drag & drop: while a finger is down nothing in the player changes, the rows only slide out of the way;
    // the move is committed once, when the finger lifts (so the playing song is never interrupted mid-drag)
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragDy by remember { mutableFloatStateOf(0f) }
    // top edge of the dragged row in screen terms: follows the finger no matter how the rows above it fold or the list scrolls
    var dragTop by remember { mutableFloatStateOf(0f) }
    var dragFrom by remember { mutableIntStateOf(-1) }
    var dragTo by remember { mutableIntStateOf(-1) }
    var dragH by remember { mutableFloatStateOf(0f) }
    var blockDrag by remember { mutableStateOf(false) }
    var settleKey by remember { mutableStateOf<String?>(null) }
    var settleY by remember { mutableFloatStateOf(0f) }
    var noAnim by remember { mutableStateOf(false) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val d = c.store.data
    val vq = c.viewQueue.coerceIn(0, (d.queues.size - 1).coerceAtLeast(0))
    val isLive = vq == c.activeQueue
    val vt = c.viewTracks(vq)
    val sel = IdSel(c, vt)
    val vIndex = c.viewIndex(vq)
    var queuesDialog by remember { mutableStateOf(false) }
    val qName = d.queues.getOrNull(vq)?.name ?: "Queue"

    BackHandler(enabled = sel.isNotEmpty()) { sel.clear() }
    LaunchedEffect(vq) {
        if (vIndex > 0) runCatching { state.scrollToItem(vIndex) }
    }

    // stable keys so a row keeps its identity while it is dragged to a new position
    val keys = remember(vt) {
        val seen = HashMap<Long, Int>()
        vt.map { t -> val n = (seen[t.id] ?: 0) + 1; seen[t.id] = n; if (n == 1) "${t.id}" else "${t.id}#$n" }
    }
    val shown = remember(vt, query) {
        vt.withIndex().filter { (_, t) ->
            searchMatches(t, query)
        }.map { it.index }
    }
    fun toggle(i: Int) { if (i in sel) sel.remove(i) else sel.add(i) }
    val selNow = rememberUpdatedState(sel)
    val vqNow = rememberUpdatedState(vq)

    /** Which row slot the dragged row's centre is over right now. */
    fun computeTarget() {
        val infos = state.layoutInfo.visibleItemsInfo.filter { it.size > 0 }
        if (infos.isEmpty()) return
        val cur = infos.firstOrNull { it.key == dragKey } ?: return
        val centre = dragTop + cur.size / 2f
        val t = infos.firstOrNull { centre >= it.offset && centre < it.offset + it.size }
            ?: if (centre < infos.first().offset) infos.first() else infos.last()
        dragTo = t.index
    }
    LaunchedEffect(settleKey) {
        if (settleKey != null) {
            androidx.compose.animation.core.animate(settleY, 0f, animationSpec = androidx.compose.animation.core.tween(170)) { v, _ -> settleY = v }
            settleKey = null
        }
    }
    // scroll the list when the dragged row is held near the top or bottom edge
    LaunchedEffect(dragKey) {
        if (dragKey == null) return@LaunchedEffect
        while (true) {
            androidx.compose.runtime.withFrameNanos { }
            val info = state.layoutInfo
            val cur = info.visibleItemsInfo.firstOrNull { it.key == dragKey } ?: continue
            val centre = dragTop + cur.size / 2f
            val h = info.viewportSize.height.toFloat()
            val edge = h * 0.18f
            val v = when {
                centre < edge -> -(edge - centre) / edge * 26f
                centre > h - edge -> (centre - (h - edge)) / edge * 26f
                else -> 0f
            }
            if (v != 0f) { state.scrollBy(v); computeTarget() }
        }
    }

    Column(Modifier.fillMaxSize().then(if (embedded) Modifier else Modifier.statusBarsPadding())) {
        // ---- queue picker ----
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!embedded) Box(Modifier.size(44.dp).bounceClick(back), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Box(Modifier.weight(1f)) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .clickable { queuesDialog = true }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${vq + 1}. $qName", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Icon(Icons.Rounded.KeyboardArrowDown, null)
                }
            }
            Box(Modifier.size(44.dp).bounceClick { deleteDialog = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Close, null) }
        }

        // ---- controls ----
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).bounceClick { if (isLive) c.togglePlay() else c.playViewed(vq, null) }, contentAlignment = Alignment.Center) {
                Icon(if (isLive && c.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
            }
            Box {
                Box(Modifier.size(48.dp).bounceClick { sortMenu = true }, contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.Sort, null) }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf<Pair<String, (List<Track>) -> List<Track>>>(
                        "Sort by title" to { l -> l.sortedBy { it.title.lowercase() } },
                        "Sort by artist" to { l -> l.sortedBy { it.artist.lowercase() } },
                        "Sort by album" to { l -> l.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo })) },
                        "Sort by duration" to { l -> l.sortedBy { it.durationMs } },
                        "Sort by date added" to { l -> l.sortedByDescending { it.dateAdded } },
                        "Reverse order" to { l -> l.reversed() },
                        "Randomize" to { l -> l },
                    ).forEach { (label, f) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { sortMenu = false; if (label == "Randomize") { if (isLive) c.randomizeQueue() else c.viewReorder(vq, vt.shuffled()) } else c.viewReorder(vq, f(vt)) })
                    }
                }
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "${if (vIndex >= 0 && vt.isNotEmpty()) vIndex + 1 else 0} / ${vt.size}",
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Timer, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        " " + formatTime(vt.sumOf { it.durationMs }),
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Box(Modifier.size(48.dp).bounceClick { if (vt.isNotEmpty()) saveDialog = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Save, null)
            }
            Box {
                Box(Modifier.size(48.dp).bounceClick { moreMenu = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MoreHoriz, null) }
                DropdownMenu(moreMenu, { moreMenu = false }) {
                    DropdownMenuItem(text = { Text("Export as .csv") }, onClick = {
                        moreMenu = false
                        actions.saveText("$qName.csv", "text/csv", queueCsv(vt))
                    })
                    DropdownMenuItem(text = { Text("Export as .m3u8") }, onClick = {
                        moreMenu = false
                        actions.saveText("$qName.m3u8", "audio/x-mpegurl", queueM3u8(vt))
                    })
                    DropdownMenuItem(text = { Text("Select all") }, onClick = { moreMenu = false; sel.clear(); sel.addAll(vt.indices) })
                    DropdownMenuItem(text = { Text("New queue…") }, enabled = d.queues.size < c.maxQueues, onClick = { moreMenu = false; newDialog = true })
                    DropdownMenuItem(text = { Text("Clear this queue") }, onClick = { moreMenu = false; c.viewReorder(vq, emptyList()) })
                }
            }
        }

        // ---- list ----
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vt.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("This queue is empty.\nPlay a song or use “Add to queue”.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            } else {
                val lineColor = MaterialTheme.colorScheme.primary
                LazyColumn(state = state, contentPadding = PaddingValues(bottom = 24.dp)) {
                    itemsIndexed(shown, key = { _, idx -> keys.getOrElse(idx) { "x$idx" } }, contentType = { _, _ -> "row" }) { _, idx ->
                        val t = vt.getOrNull(idx) ?: return@itemsIndexed
                        val key = keys.getOrElse(idx) { "x$idx" }
                        val dragging = dragKey == key
                        val idxState = rememberUpdatedState(idx)
                        // the other rows glide out of the way (one short animation per row, no recomposition while it runs)
                        val slide = remember { androidx.compose.animation.core.Animatable(0f) }
                        LaunchedEffect(Unit) {
                            androidx.compose.runtime.snapshotFlow {
                                val i = idxState.value
                                when {
                                    dragKey == null -> 0f
                                    dragFrom < dragTo && i in (dragFrom + 1)..dragTo -> -dragH
                                    dragFrom > dragTo && i in dragTo until dragFrom -> dragH
                                    else -> 0f
                                }
                            }.collectLatest { target ->
                                if (dragKey == null) slide.snapTo(0f) else slide.animateTo(target, androidx.compose.animation.core.tween(130))
                            }
                        }
                        // while a group is being dragged its other songs fold away, leaving ONE row that stands for all of them
                        val folded = blockDrag && dragKey != null && !dragging && idx in sel
                        Box(
                            Modifier
                                .then(if (dragKey != null || noAnim) Modifier else Modifier.animateItem())
                                .zIndex(if (dragging || key == settleKey) 1f else 0f)
                                .graphicsLayer {
                                    translationY = when {
                                        dragging -> dragTop - (state.layoutInfo.visibleItemsInfo.firstOrNull { it.key == key }?.offset ?: dragTop.toInt()).toFloat()
                                        key == settleKey -> settleY
                                        dragKey == null -> 0f
                                        else -> slide.value
                                    }
                                    alpha = 1f
                                    if (dragging) { shadowElevation = 12f; scaleX = 1.02f; scaleY = 1.02f }
                                }
                                .background(MaterialTheme.colorScheme.background),
                        ) {
                            Box(Modifier.animateContentSize(androidx.compose.animation.core.tween(150))) {
                            if (!folded) TrackRow(
                                t, c,
                                selected = idx in sel,
                                onLongClick = { toggle(idx) },
                                leading = {
                                    if (query.isBlank()) Box(
                                        Modifier.size(40.dp).pointerInput(key) {
                                            detectDragGestures(
                                                onDragStart = {
                                                    val info = state.layoutInfo.visibleItemsInfo.firstOrNull { it.key == key }
                                                    try { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress) } catch (_: Throwable) {}
                                                    dragKey = key; dragDy = 0f; dragTop = (info?.offset ?: 0).toFloat()
                                                    dragFrom = idxState.value; dragTo = dragFrom
                                                    dragH = (info?.size ?: 0).toFloat()
                                                    blockDrag = idxState.value in selNow.value && selNow.value.size > 1
                                                },
                                                onDragEnd = {
                                                    computeTarget()
                                                    val from = dragFrom; val to = dragTo
                                                    val infos = state.layoutInfo.visibleItemsInfo
                                                    val cur = infos.firstOrNull { it.key == key }
                                                    val tgt = infos.firstOrNull { it.index == to }
                                                    noAnim = true
                                                    if (blockDrag) {
                                                        if (to >= 0) {
                                                            // the selection is kept by song, so it stays selected after the move
                                                            c.viewMoveBlockAt(vqNow.value, selNow.value.toList(), to, to > from)
                                                        }
                                                    } else if (from >= 0 && to >= 0 && from != to && cur != null && tgt != null) {
                                                        val landing = if (to > from) tgt.offset + tgt.size - cur.size else tgt.offset
                                                        settleY = dragTop - landing
                                                        settleKey = key
                                                        c.viewMove(vqNow.value, from, to)
                                                    }
                                                    dragKey = null; dragDy = 0f; dragFrom = -1; dragTo = -1; blockDrag = false
                                                    scope.launch { kotlinx.coroutines.delay(90); noAnim = false }
                                                },
                                                onDragCancel = { dragKey = null; dragDy = 0f; dragFrom = -1; dragTo = -1; blockDrag = false },
                                            ) { change, amount ->
                                                change.consume()
                                                dragDy += amount.y
                                                dragTop += amount.y
                                                computeTarget()
                                            }
                                        },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Icon(Icons.Rounded.DragHandle, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                extraMenu = buildList {
                                    add("Remove from queue" to { c.viewRemove(vq, listOf(idxState.value)) })
                                    add((if (c.sleepStopAtId == t.id) "Cancel stop after this song" else "Stop after this song") to {
                                        if (c.sleepStopAtId == t.id) c.cancelSleep() else c.setSleepAfterSong(t.id)
                                    })
                                    add("Move to top" to { c.viewMove(vq, idxState.value, 0) })
                                    add("Move to end" to { c.viewMove(vq, idxState.value, vt.lastIndex) })
                                },
                            ) { if (sel.isNotEmpty()) toggle(idx) else c.playViewed(vq, idx) }
                            if (dragging && blockDrag && !folded) Box(
                                Modifier.matchParentSize().padding(horizontal = 8.dp, vertical = 2.dp)
                                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)).padding(horizontal = 16.dp),
                                contentAlignment = Alignment.CenterStart,
                            ) {
                                Column {
                                    Text("${selNow.value.size} songs", fontWeight = FontWeight.Bold)
                                    Text("Drop to move them together", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            }
                        }
                    }
                }
            }
        }

        if (sel.isNotEmpty()) {
            SelectionBar(
                c, c.selection.toList(), inQueue = true,
                onRemove = { c.viewRemove(vq, sel.toList()); sel.clear() },
                onSelectAll = { sel.clear(); sel.addAll(vt.indices) },
                onDeselectAll = { sel.clear() },
                onBetween = { val lo = sel.min(); val hi = sel.max(); sel.clear(); sel.addAll(lo..hi) },
                onInvert = { val all = vt.indices.filter { it !in sel }; sel.clear(); sel.addAll(all) },
                onCancel = { sel.clear() },
            )
        }
        SearchField(query, { query = it }, "Search in this queue…")
    }

    if (queuesDialog) QueuesDialog(c) { queuesDialog = false }
    if (saveDialog) NameDialog("Save queue as playlist", qName, "Save", { saveDialog = false }) {
        c.store.createPlaylist(it, vt.map { t -> t.id }); saveDialog = false
    }
    if (newDialog) NameDialog("New queue", "Queue ${d.queues.size + 1}", "Create", { newDialog = false }) { c.newQueue(it); newDialog = false }
    if (renameDialog) NameDialog("Rename queue", qName, "Rename", { renameDialog = false }) { c.renameQueue(vq, it); renameDialog = false }
    if (deleteDialog) AlertDialog(
        onDismissRequest = { deleteDialog = false },
        title = { Text(if (d.queues.size > 1) "Delete this queue?" else "Clear this queue?") },
        text = { Text("“$qName” with ${vt.size} songs.") },
        confirmButton = { TextButton({ c.deleteQueue(vq); deleteDialog = false }) { Text(if (d.queues.size > 1) "Delete" else "Clear") } },
        dismissButton = { TextButton({ deleteDialog = false }) { Text("Cancel") } },
    )
}
