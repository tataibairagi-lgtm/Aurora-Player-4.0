package com.aurora.player.player

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.aurora.player.lock.LockScreenActivity
import android.os.Bundle
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.CommandButton
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.aurora.player.MainActivity
import com.aurora.player.R
import com.aurora.player.controller

/** Keeps playback alive in the background and provides the media notification / lock-screen controls. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    /** When the screen turns off/on while music plays and the phone is locked, show Aurora's lock-screen player (if enabled). */
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val c = context.controller
            if (!c.store.data.lockScreenPlayer || c.current == null) return
            if (!c.isPlaying && !c.store.data.lockAlways) return
            if (!c.isPlaying && c.store.data.lockSkipPaused && c.pausedForMs > 60_000L) return
            val km = context.getSystemService(Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            if (intent.action == Intent.ACTION_SCREEN_ON && !km.isKeyguardLocked) return
            val launch = Intent(context, LockScreenActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            var started = false
            if (Settings.canDrawOverlays(context)) { // this permission is what lets us start it from the background (Android 10+)
                try { context.startActivity(launch); started = true } catch (_: Exception) {}
            }
            if (!started) showFullScreenFallback(context, launch)
        }
    }

    /** Android 10 blocks background activity starts; a full-screen-intent notification is the allowed way to show a lock-screen UI. */
    private fun showFullScreenFallback(context: Context, launch: Intent) {
        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(android.app.NotificationChannel("aurora_lock", "Lock screen player", android.app.NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
            }
            val pi = PendingIntent.getActivity(context, 7, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = androidx.core.app.NotificationCompat.Builder(context, "aurora_lock")
                .setSmallIcon(R.drawable.ic_qs_tile)
                .setContentTitle("Aurora")
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_MAX)
                .setCategory(androidx.core.app.NotificationCompat.CATEGORY_CALL)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .setTimeoutAfter(4000)
                .build()
            nm.notify(7001, n)
        } catch (_: Exception) {
        }
    }

    private val favCmd = SessionCommand("aurora.fav", Bundle.EMPTY)
    private val closeCmd = SessionCommand("aurora.close", Bundle.EMPTY)
    private val repeatCmd = SessionCommand("aurora.repeat", Bundle.EMPTY)
    private val shuffleCmd = SessionCommand("aurora.shuffle", Bundle.EMPTY)
    private val overlayCmd = SessionCommand("aurora.overlay", Bundle.EMPTY)

    /** Heart (favourite) and close buttons shown next to the playback controls in the notification. */
    private var notifProvider: AuroraNotificationProvider? = null

    private fun layout(): ImmutableList<CommandButton> {
        val cur = controller.current
        val fav = cur != null && controller.store.isFavourite(cur.id)
        val out = ArrayList<CommandButton>()
        for (k in controller.store.data.notifButtons) when (k) {
            "fav" -> out += CommandButton.Builder().setDisplayName("Favourite")
                .setIconResId(if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart).setSessionCommand(favCmd).build()
            "repeat" -> out += CommandButton.Builder().setDisplayName("Repeat")
                .setIconResId(R.drawable.ic_repeat).setSessionCommand(repeatCmd).build()
            "shuffle" -> out += CommandButton.Builder().setDisplayName("Shuffle")
                .setIconResId(R.drawable.ic_shuffle).setSessionCommand(shuffleCmd).build()
            "overlay" -> out += CommandButton.Builder().setDisplayName("Desktop lyrics")
                .setIconResId(R.drawable.ic_overlay_lyrics).setSessionCommand(overlayCmd).build()
            "close" -> out += CommandButton.Builder().setDisplayName("Close")
                .setIconResId(R.drawable.ic_close).setSessionCommand(closeCmd).build()
        }
        return ImmutableList.copyOf(out)
    }

    @Volatile private var lastDeviceAdded = 0L
    private var earClicks = 0
    private val earHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val earRun = Runnable {
        val n = earClicks; earClicks = 0
        val c = controller
        val a = when { n <= 1 -> 2; n == 2 -> c.store.data.earDouble; n == 3 -> c.store.data.earTriple; else -> 3 }
        when (a) {
            0 -> c.next(); 1 -> c.previous(); 2 -> c.togglePlay(); 3 -> c.fastForward(); 4 -> c.rewind()
            5 -> c.toggleShuffle(); 6 -> c.toggleFavouriteCurrent()
        }
    }
    private val deviceCallback = object : android.media.AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) { lastDeviceAdded = android.os.SystemClock.elapsedRealtime() }
    }

    private val sessionCallback = object : MediaSession.Callback {
        override fun onConnect(session: MediaSession, info: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon().add(favCmd).add(closeCmd).add(repeatCmd).add(shuffleCmd).add(overlayCmd).build()
            // "Advanced external control" off: other apps and devices (not Aurora itself or the system notification) can't change repeat or shuffle
            val outsider = !this@PlaybackService.controller.store.data.externalControl && !info.isTrusted && info.packageName != packageName
            if (outsider) {
                val pc = MediaSession.ConnectionResult.DEFAULT_PLAYER_COMMANDS.buildUpon()
                    .remove(Player.COMMAND_SET_REPEAT_MODE).remove(Player.COMMAND_SET_SHUFFLE_MODE).build()
                return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                    .setAvailableSessionCommands(MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS).setAvailablePlayerCommands(pc).build()
            }
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session).setAvailableSessionCommands(cmds).build()
        }

        /** Headset / remote Next and Previous keys act as fast-forward / rewind when the setting is on. */
        override fun onMediaButtonEvent(session: MediaSession, controllerInfo: MediaSession.ControllerInfo, intent: Intent): Boolean {
            val c = this@PlaybackService.controller
            @Suppress("DEPRECATION")
            val e = intent.getParcelableExtra<android.view.KeyEvent>(Intent.EXTRA_KEY_EVENT) ?: return false
            // some Bluetooth devices send a "play" key the moment they connect: ignore it when a device was added a moment ago
            if (c.store.data.preventAutoplay && e.keyCode == android.view.KeyEvent.KEYCODE_MEDIA_PLAY && !c.player.isPlaying &&
                android.os.SystemClock.elapsedRealtime() - lastDeviceAdded < 4000
            ) return true
            // earphone button with its own double / triple press actions (only when they differ from the usual next / previous)
            val sd = c.store.data
            if ((sd.earDouble != 0 || sd.earTriple != 1) &&
                (e.keyCode == android.view.KeyEvent.KEYCODE_HEADSETHOOK || e.keyCode == android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            ) {
                if (e.action == android.view.KeyEvent.ACTION_DOWN && e.repeatCount == 0) {
                    earClicks++
                    earHandler.removeCallbacks(earRun)
                    earHandler.postDelayed(earRun, 380)
                }
                return true
            }
            if (!c.store.data.nextPrevSeek) return false
            if (e.keyCode != android.view.KeyEvent.KEYCODE_MEDIA_NEXT && e.keyCode != android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS) return false
            if (e.action == android.view.KeyEvent.ACTION_DOWN) {
                if (e.keyCode == android.view.KeyEvent.KEYCODE_MEDIA_NEXT) c.fastForward() else c.rewind()
            }
            return true
        }

        override fun onCustomCommand(
            session: MediaSession, info: MediaSession.ControllerInfo, customCommand: SessionCommand, args: Bundle,
        ): ListenableFuture<SessionResult> {
            val c = this@PlaybackService.controller
            when (customCommand.customAction) {
                "aurora.fav" -> {
                    c.current?.let { c.store.toggleFavourite(it.id) }
                    session.setCustomLayout(layout())
                }
                "aurora.repeat" -> c.cycleRepeat()
                "aurora.shuffle" -> c.toggleShuffle()
                "aurora.overlay" -> com.aurora.player.lyrics.LyricsOverlayService.toggle(this@PlaybackService)
                "aurora.close" -> {
                    c.player.pause()
                    stopSelf()
                }
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }

    override fun onCreate() {
        super.onCreate()
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        notifProvider = AuroraNotificationProvider(this)
        setMediaNotificationProvider(notifProvider!!)
        // started by a notification button or a widget after the app was closed: load the saved queue right away so the first press works
        val ctl = controller
        if (ctl.library.isEmpty()) {
            val appCtx = applicationContext
            Thread {
                val list = runCatching { com.aurora.player.data.MediaScanner.scan(appCtx, ctl.store.data.minDurationSec) }.getOrDefault(emptyList())
                if (list.isNotEmpty()) android.os.Handler(android.os.Looper.getMainLooper()).post { if (ctl.library.isEmpty()) ctl.attachLibrary(list) }
            }.start()
        }
        val s = MediaSession.Builder(this, controller.player)
            .setSessionActivity(pi)
            .setCallback(sessionCallback)
            .setCustomLayout(layout())
            .build()
        session = s
        controller.player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { session?.setCustomLayout(layout()) }
        })
        addSession(s)
        try { (getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager).registerAudioDeviceCallback(deviceCallback, null) } catch (_: Throwable) {}
        controller.onNotifSettingsChanged = {
            session?.setCustomLayout(layout())
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ notifProvider?.refresh() }, 250)
        }
        ContextCompat.registerReceiver(this, screenOff, IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) }, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (controller.store.data.stopOnTaskRemoved) {
            p?.pause()
            stopSelf()
        } else if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        try { (getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager).unregisterAudioDeviceCallback(deviceCallback) } catch (_: Throwable) {}
        try { unregisterReceiver(screenOff) } catch (_: Exception) {}
        controller.onNotifSettingsChanged = null
        session?.release()
        session = null
        super.onDestroy()
    }
}
