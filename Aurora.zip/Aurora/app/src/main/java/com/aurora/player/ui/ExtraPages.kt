package com.aurora.player.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aurora.player.automation.Automation
import com.aurora.player.data.AlarmItem
import com.aurora.player.data.BtRule
import com.aurora.player.data.Persisted
import com.aurora.player.data.ThemePreset
import com.aurora.player.player.PlayerController
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.roundToInt

private val MODE_NAMES = listOf("System", "Light", "Dark", "Black")

// ---------------------------------------------------------------------------------------------
// PIN
// ---------------------------------------------------------------------------------------------

private fun hashPin(pin: String, salt: String): String =
    MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }

fun pinMatches(d: Persisted, pin: String): Boolean = d.pinHash.isNotEmpty() && hashPin(pin, d.pinSalt) == d.pinHash

private fun setPin(c: PlayerController, pin: String) {
    val salt = UUID.randomUUID().toString()
    c.store.update { it.copy(pinHash = hashPin(pin, salt), pinSalt = salt, pinLen = pin.length) }
}

/** Full-screen PIN pad shown when the app opens (and when it comes back after being away). */
@Composable
fun PinScreen(c: PlayerController, onUnlocked: () -> Unit) {
    val d = c.store.data
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    fun press(ch: String) {
        if (pin.length >= d.pinLen) return
        wrong = false
        pin += ch
        if (pin.length == d.pinLen) {
            if (pinMatches(d, pin)) onUnlocked() else { wrong = true; pin = "" }
        }
    }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Rounded.Lock, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
        Text("Enter your PIN", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(Modifier.padding(vertical = 22.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            repeat(d.pinLen) { i ->
                Box(
                    Modifier.size(16.dp).clip(CircleShape)
                        .background(if (i < pin.length) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f)),
                )
            }
        }
        Text(if (wrong) "Wrong PIN, try again" else " ", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 10.dp))
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "<")).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.padding(vertical = 7.dp)) {
                row.forEach { k ->
                    Box(
                        Modifier.size(72.dp).clip(CircleShape)
                            .background(if (k.isEmpty()) Color.Transparent else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .clickable(enabled = k.isNotEmpty()) { if (k == "<") { pin = pin.dropLast(1); wrong = false } else press(k) },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (k == "<") Icon(Icons.Rounded.Backspace, "Delete")
                        else Text(k, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

/** Asks for digits; [onSubmit] returns an error text to keep the dialog open, or null when it worked. */
@Composable
private fun PinEntryDialog(title: String, label: String, onDismiss: () -> Unit, onSubmit: (String) -> String?) {
    var text by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    text, { text = it.filter { ch -> ch.isDigit() }.take(8); err = null },
                    label = { Text(label) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    isError = err != null, modifier = Modifier.fillMaxWidth(),
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)) }
            }
        },
        confirmButton = { TextButton({ err = onSubmit(text) }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun PrivacyPage(c: PlayerController) {
    val d = c.store.data
    // which step is open: "new", "repeat", "verifyChange", "verifyRemove"
    var step by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    Section("PIN lock")
    Text(
        "Aurora asks for a PIN when it opens, and again when you come back after being away. Music keeps playing while it is locked.",
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (d.pinHash.isEmpty()) {
        ActionRow("Set a PIN", "4 to 8 digits") { step = "new" }
    } else {
        ActionRow("Change PIN", "You will be asked for the current one first") { step = "verifyChange" }
        ActionRow("Remove PIN", "Turns the lock off") { step = "verifyRemove" }
        ChipRow("Ask again after being away for") {
            listOf(0 to "Right away", 30 to "30 s", 120 to "2 min", 600 to "10 min").forEach { (sec, label) ->
                FilterChip(d.pinRelockSec == sec, { c.store.update { it.copy(pinRelockSec = sec) } }, label = { Text(label) })
                androidx.compose.foundation.layout.Spacer(Modifier.size(6.dp))
            }
        }
        Text(
            "There is no way to get a forgotten PIN back. If it happens, the only way in is to clear Aurora's data in the phone's app settings, which also deletes your settings (a backup file keeps them).",
            Modifier.padding(horizontal = 24.dp, vertical = 10.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    when (step) {
        "new" -> PinEntryDialog("New PIN", "4 to 8 digits", { step = "" }) { v ->
            if (v.length < 4) "Use at least 4 digits" else { first = v; step = "repeat"; null }
        }
        "repeat" -> PinEntryDialog("Repeat the PIN", "Same digits again", { step = "" }) { v ->
            if (v != first) "The two PINs are not the same" else { setPin(c, v); first = ""; step = ""; null }
        }
        "verifyChange" -> PinEntryDialog("Current PIN", "Enter the PIN you use now", { step = "" }) { v ->
            if (pinMatches(d, v)) { step = "new"; null } else "Wrong PIN"
        }
        "verifyRemove" -> PinEntryDialog("Remove the PIN", "Enter the current PIN", { step = "" }) { v ->
            if (pinMatches(d, v)) { c.store.update { it.copy(pinHash = "", pinSalt = "") }; step = ""; null } else "Wrong PIN"
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Saved themes and the day / night schedule
// ---------------------------------------------------------------------------------------------

@Composable
fun ThemesPage(c: PlayerController) {
    val d = c.store.data
    var nameDlg by remember { mutableStateOf(false) }
    Section("Saved themes")
    Text(
        "Set the theme and accent colour you like in Theme and colours, then save it here. You can apply a saved theme with one tap or let the schedule switch between two of them.",
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    d.themePresets.forEach { p ->
        Row(Modifier.cardRow().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(28.dp).clip(CircleShape)
                    .background(if (p.accent != 0L) Color(p.accent) else MaterialTheme.colorScheme.primary),
            )
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(p.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(MODE_NAMES.getOrElse(p.mode) { "System" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton({ c.store.update { it.copy(themeMode = p.mode, accentColor = p.accent) } }) { Text("Apply") }
            TextButton({ c.store.update { it.copy(themePresets = it.themePresets.filter { x -> x.name != p.name }) } }) { Text("Delete") }
        }
    }
    ActionRow("Save the current look as a theme", "Light / dark / black and the accent colour you use now") { nameDlg = true }

    Section("Day and night")
    SwitchRow("Switch themes by time of day", "Uses your day theme in the daytime and your night theme in the evening", d.themeSchedule) { v ->
        c.store.update { it.copy(themeSchedule = v) }
    }
    if (d.themeSchedule) {
        if (d.themePresets.isEmpty()) Text("Save a theme first, then pick it here.", Modifier.padding(horizontal = 24.dp, vertical = 6.dp), color = MaterialTheme.colorScheme.error)
        ChipRow("Day theme") {
            d.themePresets.forEach { p ->
                FilterChip(d.dayTheme == p.name, { c.store.update { it.copy(dayTheme = p.name) } }, label = { Text(p.name) })
                androidx.compose.foundation.layout.Spacer(Modifier.size(6.dp))
            }
        }
        ChipRow("Night theme") {
            d.themePresets.forEach { p ->
                FilterChip(d.nightTheme == p.name, { c.store.update { it.copy(nightTheme = p.name) } }, label = { Text(p.name) })
                androidx.compose.foundation.layout.Spacer(Modifier.size(6.dp))
            }
        }
        SliderSetting("Day starts at", d.dayStartHour.toFloat(), 0f..23f, 22, "%02d:00".format(d.dayStartHour)) { v ->
            c.store.update { it.copy(dayStartHour = v.roundToInt().coerceIn(0, 23)) }
        }
        SliderSetting("Night starts at", d.nightStartHour.toFloat(), 0f..23f, 22, "%02d:00".format(d.nightStartHour)) { v ->
            c.store.update { it.copy(nightStartHour = v.roundToInt().coerceIn(0, 23)) }
        }
    }
    if (nameDlg) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { nameDlg = false },
            title = { Text("Name this theme") },
            text = { OutlinedTextField(name, { name = it.take(24) }, singleLine = true, label = { Text("For example Night blue") }) },
            confirmButton = {
                TextButton({
                    val n = name.trim().ifEmpty { "Theme ${d.themePresets.size + 1}" }
                    c.store.update { s -> s.copy(themePresets = s.themePresets.filter { it.name != n } + ThemePreset(n, s.themeMode, s.accentColor)) }
                    nameDlg = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton({ nameDlg = false }) { Text("Cancel") } },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Alarms and Bluetooth auto-play
// ---------------------------------------------------------------------------------------------

/** A short note in a soft rounded card, with an info icon. */
@Composable
private fun InfoCard(text: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)).padding(14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        androidx.compose.material3.Icon(Icons.Rounded.Info, null, Modifier.size(20.dp).padding(top = 1.dp), tint = MaterialTheme.colorScheme.primary)
        Text(text, Modifier.padding(start = 12.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private val DAY_LETTERS = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

private fun daysText(mask: Int) =
    if (mask == 0 || mask == 127) "Every day" else DAY_LETTERS.filterIndexed { i, _ -> ((mask shr i) and 1) == 1 }.joinToString(", ")

private fun playlistName(d: Persisted, id: String) = when (id) {
    "" -> "All songs"
    "fav" -> "Favourites"
    else -> d.playlists.firstOrNull { it.id == id }?.name ?: "Missing playlist"
}

@Composable
private fun PlaylistChips(d: Persisted, selected: String, onPick: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected == "", { onPick("") }, label = { Text("All songs") })
        FilterChip(selected == "fav", { onPick("fav") }, label = { Text("Favourites") })
        d.playlists.forEach { p -> FilterChip(selected == p.id, { onPick(p.id) }, label = { Text(p.name, maxLines = 1) }) }
    }
}

@Composable
fun AlarmsPage(c: PlayerController) {
    val ctx = LocalContext.current
    val d = c.store.data
    var editAlarm by remember { mutableStateOf<AlarmItem?>(null) }
    var editRule by remember { mutableStateOf<Pair<Int, BtRule>?>(null) } // index (-1 = new) and the rule

    fun saveAlarms(list: List<AlarmItem>) {
        d.alarms.filter { old -> list.none { it.id == old.id } }.forEach { Automation.cancel(ctx, it) }
        c.store.update { it.copy(alarms = list) }
        Automation.schedule(ctx, list)
    }

    Section("Playlist alarms")
    InfoCard("At the set time Aurora starts the playlist you choose, even if the app is closed. It shows as an alarm in the status bar.")
    d.alarms.forEach { a ->
        Row(Modifier.cardRow().clickable { editAlarm = a }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("%02d:%02d".format(a.hour, a.minute), fontSize = 26.sp, fontWeight = FontWeight.Light)
                Text("${playlistName(d, a.playlistId)} · ${daysText(a.days)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Switch(a.enabled, { v -> saveAlarms(d.alarms.map { if (it.id == a.id) it.copy(enabled = v) else it }) })
        }
    }
    ActionRow("Add an alarm", "Pick a time, a playlist and the days") { editAlarm = AlarmItem(UUID.randomUUID().toString(), 7, 0) }

    Section("Bluetooth auto-play")
    InfoCard("When a device you list here connects, Aurora starts the playlist you choose.")
    InfoCard("Tip: if Aurora was swiped away, Android may not let it start music by itself. It works best while Aurora is still in your recent apps or playing.")
    if (Build.VERSION.SDK_INT >= 31) {
        var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
        if (!granted) ActionRow("Allow Bluetooth access", "Android needs this so Aurora can notice a device connecting") { launcher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
    }
    d.btRules.forEachIndexed { i, r ->
        ActionRow(r.device, "Plays: ${playlistName(d, r.playlistId)}" + if (r.shuffle) " (shuffled)" else "") { editRule = i to r }
    }
    ActionRow("Add a device", "Choose a headphone, speaker or car and the playlist to start") { editRule = -1 to BtRule("", "", true) }

    editAlarm?.let { a ->
        var hour by remember(a.id) { mutableIntStateOf(a.hour) }
        var minute by remember(a.id) { mutableIntStateOf(a.minute) }
        var pl by remember(a.id) { mutableStateOf(a.playlistId) }
        var days by remember(a.id) { mutableIntStateOf(a.days) }
        var shuffle by remember(a.id) { mutableStateOf(a.shuffle) }
        val exists = d.alarms.any { it.id == a.id }
        AlertDialog(
            onDismissRequest = { editAlarm = null },
            title = { Text(if (exists) "Edit alarm" else "New alarm") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text("%02d:%02d".format(hour, minute), Modifier.fillMaxWidth(), fontSize = 44.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center)
                    Text("Hour")
                    Slider(hour.toFloat(), { hour = it.roundToInt() }, valueRange = 0f..23f, steps = 22)
                    Text("Minute")
                    Slider(minute.toFloat(), { minute = it.roundToInt() }, valueRange = 0f..59f, steps = 58)
                    Text("Playlist", Modifier.padding(top = 6.dp))
                    PlaylistChips(d, pl) { pl = it }
                    Text("Repeat on", Modifier.padding(top = 10.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DAY_LETTERS.forEachIndexed { i, n ->
                            val on = days == 0 || ((days shr i) and 1) == 1
                            FilterChip(on, {
                                // 0 means "every day", so turning one day off first expands it to all seven
                                val cur = if (days == 0) 127 else days
                                val nxt = cur xor (1 shl i)
                                days = if (nxt == 0 || nxt == 127) 0 else nxt
                            }, label = { Text(n) })
                        }
                    }
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Shuffle", Modifier.weight(1f))
                        Switch(shuffle, { shuffle = it })
                    }
                }
            },
            confirmButton = {
                TextButton({
                    val n = a.copy(hour = hour, minute = minute, playlistId = pl, days = days, shuffle = shuffle, enabled = true)
                    saveAlarms(if (exists) d.alarms.map { if (it.id == a.id) n else it } else d.alarms + n)
                    editAlarm = null
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    if (exists) TextButton({ saveAlarms(d.alarms.filter { it.id != a.id }); editAlarm = null }) { Text("Delete") }
                    TextButton({ editAlarm = null }) { Text("Cancel") }
                }
            },
        )
    }

    editRule?.let { (index, r) ->
        var name by remember(index) { mutableStateOf(r.device) }
        var pl by remember(index) { mutableStateOf(r.playlistId) }
        var shuffle by remember(index) { mutableStateOf(r.shuffle) }
        val connected = remember { Automation.connectedBluetooth(ctx) }
        AlertDialog(
            onDismissRequest = { editRule = null },
            title = { Text(if (index >= 0) "Edit device" else "Add a device") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(name, { name = it }, label = { Text("Device name, as shown in Bluetooth settings") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (connected.isNotEmpty()) {
                        Text("Connected now", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelMedium)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            connected.forEach { n -> FilterChip(name == n, { name = n }, label = { Text(n, maxLines = 1) }) }
                        }
                    }
                    Text("Playlist to start", Modifier.padding(top = 10.dp))
                    PlaylistChips(d, pl) { pl = it }
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Shuffle", Modifier.weight(1f))
                        Switch(shuffle, { shuffle = it })
                    }
                }
            },
            confirmButton = {
                TextButton({
                    if (name.isNotBlank()) {
                        val n = BtRule(name.trim(), pl, shuffle)
                        c.store.update { s -> s.copy(btRules = if (index >= 0) s.btRules.mapIndexed { i, x -> if (i == index) n else x } else s.btRules + n) }
                    }
                    editRule = null
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    if (index >= 0) TextButton({ c.store.update { s -> s.copy(btRules = s.btRules.filterIndexed { i, _ -> i != index }) }; editRule = null }) { Text("Delete") }
                    TextButton({ editRule = null }) { Text("Cancel") }
                }
            },
        )
    }
}
