package com.aurora.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.material.icons.rounded.Close
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import kotlinx.coroutines.flow.distinctUntilChanged
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameNanos
import androidx.media3.common.Player
import com.aurora.player.data.formatTime
import com.aurora.player.data.indexAt
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun NowPlayingScreen(c: PlayerController, onClose: () -> Unit, openQueue: () -> Unit, openEq: () -> Unit, embedded: Boolean = false) {
    val track = c.current
    val bmp = rememberArt(track)
    val surface = MaterialTheme.colorScheme.background
    val accent by animateColorAsState(
        bmp?.dominantColor() ?: MaterialTheme.colorScheme.primary, tween(800), label = "accent",
    )
    var showLyrics by remember { mutableStateOf(false) }
    var sleepDialog by remember { mutableStateOf(false) }
    var artMenu by remember { mutableStateOf(false) }
    var artFull by remember { mutableStateOf(false) }
    var tagDialog by remember { mutableStateOf(false) }
    var bmAdd by remember { mutableStateOf(false) }
    var playMode by remember { mutableStateOf(false) }
    var spDialog by remember { mutableStateOf(false) }
    var bmList by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    val actions = LocalActions.current

    val bgMode = c.store.data.nowBg
    val darkBg = bgMode in listOf(1, 2, 4, 5)
    val cs = MaterialTheme.colorScheme
    val screenScheme = if (darkBg) cs.copy(
        onSurface = Color.White, onBackground = Color.White, onSurfaceVariant = Color(0xCCFFFFFF),
        primary = if (c.store.data.accentColor == 0L) Color(0xFFB4A8FF) else cs.primary,
    ) else cs
    val view = androidx.compose.ui.platform.LocalView.current
    val keepOn = c.store.data.keepScreenOn
    androidx.compose.runtime.DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }
    MaterialTheme(colorScheme = screenScheme) {
    androidx.compose.runtime.CompositionLocalProvider(androidx.compose.material3.LocalContentColor provides screenScheme.onBackground) {
    Box(Modifier.fillMaxSize()) {
        NowBackground(c, bmp, accent, surface)
        Column(
            Modifier.fillMaxSize().then(if (embedded) Modifier else Modifier.statusBarsPadding().navigationBarsPadding()).padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // top bar
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (embedded) Spacer(Modifier.size(44.dp)) else Box(Modifier.size(44.dp).bounceClick(onClose), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.KeyboardArrowDown, null, modifier = Modifier.size(30.dp))
                }
                Text(
                    "Now playing", Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Box(Modifier.size(44.dp).bounceClick {
                    val hasCustom = c.store.data.customBgUri.isNotEmpty()
                    var n = (c.store.data.nowBg + 1) % 6
                    if (n == 5 && !hasCustom) n = 0
                    c.store.update { it.copy(nowBg = n) }
                }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Palette, null)
                }
                Box(Modifier.size(44.dp).bounceClick(openQueue), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Rounded.QueueMusic, null)
                }
                Box {
                    Box(Modifier.size(44.dp).bounceClick { artMenu = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.MoreVert, null)
                    }
                    androidx.compose.material3.DropdownMenu(artMenu, { artMenu = false }) {
                        androidx.compose.material3.DropdownMenuItem(text = { Text("View album art") }, onClick = { artMenu = false; if (track != null) artFull = true })
                        androidx.compose.material3.DropdownMenuItem(text = { Text("Save album art to gallery") }, onClick = { artMenu = false; track?.let { actions.saveArt(it) } })
                        androidx.compose.material3.DropdownMenuItem(text = { Text("Edit tags") }, onClick = { artMenu = false; if (track != null) tagDialog = true })
                        androidx.compose.material3.DropdownMenuItem(text = { Text("Add bookmark here") }, onClick = { artMenu = false; if (track != null) bmAdd = true })
                        androidx.compose.material3.DropdownMenuItem(text = { Text("Bookmarks") }, onClick = { artMenu = false; bmList = true })
                        androidx.compose.material3.DropdownMenuItem(text = { Text("Embed cover art from an image") }, onClick = { artMenu = false; track?.let { actions.embedArt(listOf(it)) } })
                        androidx.compose.material3.DropdownMenuItem(text = { Text("Copy song to a folder") }, onClick = { artMenu = false; track?.let { actions.copyTracks(listOf(it)) } })
                        androidx.compose.material3.DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { artMenu = false; if (track != null) addDialog = true })
                    }
                }
            }

            // art / lyrics
            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                Crossfade(showLyrics, animationSpec = tween(400), label = "artOrLyrics") { lyr ->
                    if (lyr) LyricsPane(c) { showLyrics = false } else ArtPane(c, accent) { showLyrics = true }
                }
            }

            // title
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AnimatedContent(
                    track?.id, Modifier.weight(1f),
                    transitionSpec = {
                        (slideInVertically(tween(350)) { it / 2 } + fadeIn(tween(350))) togetherWith
                            (slideOutVertically(tween(250)) { -it / 2 } + fadeOut(tween(200)))
                    },
                    label = "title",
                ) {
                    Column {
                        Text(
                            track?.title ?: "Nothing playing", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                        )
                        Text(
                            track?.let { "${it.artist} — ${it.album}" } ?: "Pick a song from your library",
                            maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (track != null) {
                    val fav = c.store.isFavourite(track.id)
                    Box(Modifier.size(48.dp).bounceClick { c.store.toggleFavourite(track.id) }, contentAlignment = Alignment.Center) {
                        AnimatedContent(
                            fav,
                            transitionSpec = { (scaleIn(spring(Spring.DampingRatioHighBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
                            label = "fav",
                        ) { f ->
                            Icon(
                                if (f) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null,
                                tint = if (f) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(28.dp),
                            )
                        }
                    }
                }
            }

            // seek bar
            var drag by remember { mutableStateOf<Float?>(null) }
            val dur = c.durationMs.coerceAtLeast(1L).toFloat()
            Slider(
                value = (drag ?: c.positionMs.toFloat()).coerceIn(0f, dur),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { c.seekTo(it.toLong()) }; drag = null },
                valueRange = 0f..dur,
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime((drag ?: c.positionMs.toFloat()).toLong()), style = MaterialTheme.typography.labelMedium)
                if (c.abA >= 0) {
                    Text(
                        if (c.abB >= 0) "A–B  ${formatTime(c.abA)} – ${formatTime(c.abB)}" else "A  ${formatTime(c.abA)}",
                        Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                } else Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    if (c.store.data.showSeekButtons) {
                    Box(Modifier.size(36.dp).bounceClick { c.rewind() }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.FastRewind, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Box(Modifier.size(36.dp).bounceClick { c.fastForward() }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.FastForward, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    }
                }
                Text(formatTime(c.durationMs), style = MaterialTheme.typography.labelMedium)
            }

            // transport
            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
            ) {
                ToggleIcon(Icons.Rounded.Shuffle, c.shuffle) { c.toggleShuffle() }
                Box(Modifier.size(52.dp).bounceClick { c.previous() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SkipPrevious, null, modifier = Modifier.size(38.dp))
                }
                val pulse by animateFloatAsState(if (c.isPlaying) 1f else 0.94f, spring(Spring.DampingRatioMediumBouncy), label = "playScale")
                Box(
                    Modifier.size(76.dp).scale(pulse).clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary).bounceClick { c.togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    AnimatedContent(
                        c.isPlaying,
                        transitionSpec = { (scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
                        label = "playPause",
                    ) { playing ->
                        Icon(
                            if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null,
                            tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(42.dp),
                        )
                    }
                }
                Box(Modifier.size(52.dp).bounceClick { c.next() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SkipNext, null, modifier = Modifier.size(38.dp))
                }
                ToggleIcon(
                    if (c.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    c.repeatMode != Player.REPEAT_MODE_OFF,
                ) { playMode = true }
            }

            // secondary row
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
            ) {
                ToggleIcon(Icons.Rounded.Lyrics, showLyrics) { showLyrics = !showLyrics }
                ToggleIcon(Icons.Rounded.Subtitles, c.overlayActive) { actions.toggleOverlay(!c.overlayActive) }
                TextToggle("A–B", c.abA >= 0) { c.markAB() }
                TextToggle("${"%.2f".format(c.speed).trimEnd('0').trimEnd('.')}x", c.speed != 1f || c.pitch != 1f) { spDialog = true }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ToggleIcon(Icons.Rounded.Bedtime, c.sleepActive) { sleepDialog = true }
                    if (c.sleepLeftMs > 0) Text(formatTime(c.sleepLeftMs), style = MaterialTheme.typography.labelSmall)
                }
                ToggleIcon(Icons.Rounded.Equalizer, false, openEq)
            }
        }
    }
    }
    }

    if (artFull && track != null) ArtFullscreen(bmp) { artFull = false }
    if (tagDialog && track != null) TagEditorDialog(track, { tagDialog = false }) { d -> tagDialog = false; actions.editTags(track, d) }
    if (addDialog && track != null) AddToPlaylistDialog(c, listOf(track.id)) { addDialog = false }
    if (sleepDialog) SleepDialog(c) { sleepDialog = false }
    if (playMode) PlayModeDialog(c) { playMode = false }
    if (spDialog) SpeedPitchDialog(c) { spDialog = false }
    if (bmAdd) AddBookmarkDialog(c) { bmAdd = false }
    if (bmList) BookmarksDialog(c) { bmList = false }
}

@Composable
private fun ToggleIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, on: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(
        if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, tween(250), label = "tg",
    )
    Box(Modifier.size(44.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun TextToggle(label: String, on: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(
        if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, tween(250), label = "tt",
    )
    Box(Modifier.size(width = 48.dp, height = 44.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Text(label, color = tint, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

// -------------------------------------------------------------------------------------------------
// Album art: spinning vinyl disc (or breathing square), swipe left/right to change song
// -------------------------------------------------------------------------------------------------

@Composable
private fun ArtPane(c: PlayerController, accent: Color, onTap: () -> Unit) {
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(0f) }
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(c.isPlaying) {
        if (c.isPlaying) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                angle = (angle + (now - last) / 1_000_000_000f * 24f) % 360f
                last = now
            }
        }
    }
    val glow = rememberInfiniteTransition(label = "glow")
    val pulse by glow.animateFloat(
        0.9f, 1.08f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "pulse",
    )
    val intensity by animateFloatAsState(if (c.isPlaying) 1f else 0f, tween(600), label = "glowI")
    val disc = c.store.data.discArt

    Box(
        Modifier.fillMaxSize()
            .offset { IntOffset(offset.value.roundToInt(), 0) }
            .pointerInput(Unit) { detectTapGestures(onTap = { onTap() }) }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (offset.value < -160f) c.next() else if (offset.value > 160f) c.previous()
                            offset.animateTo(0f, spring(Spring.DampingRatioMediumBouncy))
                        }
                    },
                    onDragCancel = { scope.launch { offset.animateTo(0f) } },
                ) { change, dx ->
                    change.consume()
                    scope.launch { offset.snapTo(offset.value + dx) }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            c.current?.id,
            transitionSpec = {
                (scaleIn(tween(450), 0.8f) + fadeIn(tween(450))) togetherWith (scaleOut(tween(300), 0.8f) + fadeOut(tween(250)))
            },
            label = "artSwap",
        ) {
            if (disc) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    // pulsing glow
                    Box(
                        Modifier.fillMaxWidth(0.92f).aspectSquare().scale(pulse)
                            .background(
                                Brush.radialGradient(listOf(accent.copy(alpha = 0.45f * intensity), Color.Transparent)),
                                CircleShape,
                            )
                    )
                    Box(Modifier.fillMaxWidth(0.86f).aspectSquare().rotate(angle), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            drawCircle(Color(0xFF0B0B10))
                            val r = size.minDimension / 2
                            var rr = r * 0.97f
                            while (rr > r * 0.66f) {
                                drawCircle(Color.White.copy(alpha = 0.05f), rr, style = Stroke(1.2f))
                                rr -= r * 0.035f
                            }
                        }
                        AlbumArt(c.current, Modifier.fillMaxWidth(0.62f).aspectSquare(), CircleShape, 56.dp)
                    }
                }
            } else {
                val s by animateFloatAsState(if (c.isPlaying) 1f else 0.86f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "sq")
                Box(
                    Modifier.fillMaxWidth(0.9f).aspectSquare().scale(s)
                        .graphicsLayer { shadowElevation = 40f; shape = RoundedCornerShape(28.dp); clip = true },
                ) {
                    AlbumArt(c.current, Modifier.fillMaxSize(), RoundedCornerShape(28.dp), 72.dp)
                }
            }
        }
    }
}

private fun Modifier.aspectSquare(): Modifier = this.aspectRatio(1f)

// -------------------------------------------------------------------------------------------------
// Lyrics view with animated scrolling + highlighted line
// -------------------------------------------------------------------------------------------------

@Composable
private fun LyricsPane(c: PlayerController, onClose: () -> Unit) {
    val lyr = c.lyrics
    val actions = LocalActions.current
    var sourceDialog by remember { mutableStateOf(false) }
    if (sourceDialog) LyricsSourceDialog(c) { sourceDialog = false }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("Cover", Icons.Rounded.KeyboardArrowDown, false) { onClose() }
            PillButton("Source", Icons.Rounded.Lyrics, false) { sourceDialog = true }
            PillButton("Import .lrc", Icons.Rounded.Subtitles, false) { actions.importLyrics() }
        }
        when {
            c.lyricsLoading -> CenterNote("Looking for lyrics…")
            lyr == null -> CenterNote("No lyrics found.\nImport an .lrc file, put one next to the song,\nor add lyrics in the tag editor (Edit tags).")
            lyr.synced -> {
                val state = rememberLazyListState()
                var idx by androidx.compose.runtime.remember(lyr) { androidx.compose.runtime.mutableIntStateOf(lyr.indexAt(c.positionMs)) }
                // follow the song without recomposing the pane on every position tick
                LaunchedEffect(lyr) {
                    androidx.compose.runtime.snapshotFlow { lyr.indexAt(c.positionMs) }
                        .distinctUntilChanged()
                        .collect { i ->
                            val far = kotlin.math.abs(i - idx) > 4
                            idx = i
                            if (i >= 0) {
                                val off = -(state.layoutInfo.viewportSize.height / 3)
                                if (far) state.scrollToItem(i, off) else state.animateScrollToItem(i, off)
                            }
                        }
                }
                val onSeek = remember(c) { { ms: Long -> c.seekTo(ms) } }
                LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 120.dp)) {
                    itemsIndexed(lyr.lines, key = { i, _ -> i }, contentType = { _, _ -> "line" }) { i, line ->
                        LyricLine(line.text, line.timeMs, i == idx, onSeek)
                    }
                }
            }
            else -> LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(lyr.lines) { _, line ->
                    Text(line.text, fontSize = 18.sp, modifier = Modifier.padding(vertical = 4.dp))
                }
            }
        }
    }
}

/** One lyric line. Only the lines whose active state changes are redrawn. */
@Composable
private fun LyricLine(text: String, timeMs: Long, active: Boolean, onSeek: (Long) -> Unit) {
    Text(
        text.ifBlank { "♪" },
        color = if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
        fontSize = if (active) 26.sp else 22.sp,
        fontWeight = FontWeight.Bold,
        lineHeight = if (active) 32.sp else 28.sp,
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { onSeek(timeMs) }.padding(vertical = 8.dp),
    )
}

@Composable
private fun CenterNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// -------------------------------------------------------------------------------------------------
// Background (Settings > Now Playing background, or the palette button on the Now Playing screen)
// -------------------------------------------------------------------------------------------------

private fun loadBackgroundImage(ctx: android.content.Context, uri: String): android.graphics.Bitmap? = try {
    val u = android.net.Uri.parse(uri)
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(u)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
    ctx.contentResolver.openInputStream(u)?.use {
        android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
    }
} catch (_: Exception) {
    null
}

@Composable
private fun NowBackground(c: PlayerController, bmp: android.graphics.Bitmap?, accent: Color, surface: Color) {
    val d = c.store.data
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val custom by androidx.compose.runtime.produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, d.customBgUri) {
        value = if (d.customBgUri.isEmpty()) null
        else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { loadBackgroundImage(ctx, d.customBgUri)?.asImageBitmap() }
    }
    // a tiny copy scaled up with filtering gives a soft blur on every Android version
    val blurred = remember(bmp) {
        bmp?.let { android.graphics.Bitmap.createScaledBitmap(it, 40, 40, true).asImageBitmap() }
    }
    val dim = (d.nowBgDim / 100f).coerceIn(0f, 0.8f)

    Box(Modifier.fillMaxSize()) {
        when (d.nowBg) {
            1 -> {
                Crossfade(blurred, animationSpec = tween(600), label = "bgBlur") { img ->
                    if (img != null) {
                        androidx.compose.foundation.Image(
                            img, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                            filterQuality = androidx.compose.ui.graphics.FilterQuality.Low,
                        )
                    } else Box(Modifier.fillMaxSize().background(Color(0xFF0F0D1A)))
                }
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
            }
            2 -> {
                val t = rememberInfiniteTransition(label = "aurora")
                val shift by t.animateFloat(
                    0f, 1f, infiniteRepeatable(tween(14000, easing = androidx.compose.animation.core.LinearEasing), RepeatMode.Reverse), label = "shift",
                )
                BoxWithConstraints(Modifier.fillMaxSize().background(Color(0xFF0A1236))) {
                    val w = constraints.maxWidth.toFloat()
                    val h = constraints.maxHeight.toFloat()
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.radialGradient(
                                listOf(Color(0xFF7C5CFF).copy(alpha = 0.55f), Color.Transparent),
                                center = androidx.compose.ui.geometry.Offset(w * (0.2f + 0.5f * shift), h * 0.25f), radius = w * 0.9f,
                            )
                        )
                    )
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.radialGradient(
                                listOf(Color(0xFF2EE6C5).copy(alpha = 0.40f), Color.Transparent),
                                center = androidx.compose.ui.geometry.Offset(w * (0.9f - 0.6f * shift), h * 0.6f), radius = w * 0.9f,
                            )
                        )
                    )
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.radialGradient(
                                listOf(Color(0xFF55F28A).copy(alpha = 0.30f), Color.Transparent),
                                center = androidx.compose.ui.geometry.Offset(w * (0.3f + 0.3f * shift), h * 0.95f), radius = w * 0.8f,
                            )
                        )
                    )
                }
            }
            3 -> Box(Modifier.fillMaxSize().background(surface))
            4 -> Box(Modifier.fillMaxSize().background(Color.Black))
            5 -> {
                val img = custom
                if (img != null) {
                    androidx.compose.foundation.Image(
                        img, null, Modifier.fillMaxSize(), contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    )
                    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
                } else Box(Modifier.fillMaxSize().background(Color.Black))
            }
            else -> Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.6f), surface, surface))))
        }
    }
}

/** Lets the user choose where this song's lyrics come from (embedded in the file, a .lrc file, saved copy, online). */
@Composable
fun LyricsSourceDialog(c: PlayerController, onDismiss: () -> Unit) {
    val t = c.current ?: run { onDismiss(); return }
    val chosen = c.store.data.lyricsSource[t.id] ?: "auto"
    val avail by androidx.compose.runtime.produceState<Map<String, Boolean>?>(null, t.id) {
        value = c.lyricsRepo.available(t)
    }
    val rows = listOf(
        Triple("auto", "Automatic", "Uses your preferred order from Settings"),
        Triple("embedded", "Embedded in the song", "Lyrics stored inside the audio file's tags"),
        Triple("file", "Lyrics file (.lrc)", "A .lrc file with the same name next to the song"),
        Triple("saved", "Saved / imported copy", "Lyrics you imported or downloaded earlier"),
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Lyrics source") },
        text = {
            Column {
                rows.forEach { (id, name, sub) ->
                    val has = avail?.get(id)
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).bounceClick { c.setLyricsSource(id); onDismiss() }.padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        androidx.compose.material3.RadioButton(chosen == id, null)
                        Column(Modifier.padding(start = 8.dp)) {
                            Text(name, fontWeight = FontWeight.Medium)
                            Text(
                                sub + when (has) { true -> if (id == "auto") "" else " · found"; false -> " · not found"; null -> "" },
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } },
    )
}

/** Full-screen album art with pinch-to-zoom and drag. */
@Composable
private fun ArtFullscreen(bmp: android.graphics.Bitmap?, onDismiss: () -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        var scale by remember { mutableFloatStateOf(1f) }
        var pan by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
        Box(
            Modifier.fillMaxSize().background(Color.Black)
                .pointerInput(Unit) {
                    detectTransformGestures { _, p, z, _ ->
                        scale = (scale * z).coerceIn(1f, 6f)
                        pan = if (scale > 1f) pan + p else androidx.compose.ui.geometry.Offset.Zero
                    }
                }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { scale = 1f; pan = androidx.compose.ui.geometry.Offset.Zero }) },
            contentAlignment = Alignment.Center,
        ) {
            if (bmp != null) {
                androidx.compose.foundation.Image(
                    bmp.asImageBitmap(), null,
                    Modifier.fillMaxSize().graphicsLayer { scaleX = scale; scaleY = scale; translationX = pan.x; translationY = pan.y },
                    contentScale = androidx.compose.ui.layout.ContentScale.Fit,
                )
            } else Text("No album art", color = Color.White)
            Box(Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(8.dp).size(44.dp).bounceClick(onDismiss), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Close, null, tint = Color.White)
            }
        }
    }
}

/** Sleep timer: minutes, end of this song, after N songs, or after a chosen song in the queue. */
@Composable
private fun SleepDialog(c: PlayerController, onDismiss: () -> Unit) {
    var pick by remember { mutableStateOf(false) }
    var custom by remember { mutableStateOf("") }
    if (pick) {
        AlertDialog(
            onDismissRequest = { pick = false },
            title = { Text("Stop after which song?") },
            text = {
                androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    itemsIndexed(c.queue) { i, t ->
                        Text(
                            "${i + 1}. ${t.title}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            fontWeight = if (i == c.currentIndex) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.fillMaxWidth().clickable { c.setSleepAfterSong(t.id); onDismiss() }.padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = { TextButton({ pick = false }) { Text("Back") } },
        )
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sleep timer") },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                if (c.sleepActive) {
                    val what = when {
                        c.sleepLeftMs > 0 -> "in ${formatTime(c.sleepLeftMs)}"
                        c.sleepSongsLeft > 0 -> "after ${c.sleepSongsLeft} more song(s)"
                        c.sleepStopAtId != 0L -> "after “${c.track(c.sleepStopAtId)?.title ?: "the chosen song"}”"
                        else -> "at the end of this song"
                    }
                    Text("Music stops $what", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
                }
                Text("After a time", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(5, 15, 30, 45, 60, 90).forEach { m ->
                        androidx.compose.material3.AssistChip({ c.setSleepMinutes(m); onDismiss() }, label = { Text("$m min") })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.OutlinedTextField(
                        custom, { custom = it.filter { ch -> ch.isDigit() }.take(4) }, singleLine = true,
                        label = { Text("Minutes") }, modifier = Modifier.weight(1f),
                    )
                    TextButton({ custom.toIntOrNull()?.takeIf { it > 0 }?.let { c.setSleepMinutes(it); onDismiss() } }) { Text("Start") }
                }
                Text("After a number of songs", Modifier.padding(top = 10.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                Row(Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(1, 2, 3, 5, 10, 15).forEach { n ->
                        androidx.compose.material3.AssistChip({ c.setSleepSongs(n); onDismiss() }, label = { Text("$n song${if (n > 1) "s" else ""}") })
                    }
                }
                Text("After a specific song", Modifier.padding(top = 10.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                TextButton({ c.setSleepEndOfTrack(); onDismiss() }, Modifier.fillMaxWidth()) { Text("End of this song") }
                TextButton({ pick = true }, Modifier.fillMaxWidth(), enabled = c.queue.isNotEmpty()) { Text("Choose a song from the queue…") }
                if (c.sleepActive) TextButton({ c.cancelSleep(); onDismiss() }, Modifier.fillMaxWidth()) { Text("Cancel timer") }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } },
    )
}
