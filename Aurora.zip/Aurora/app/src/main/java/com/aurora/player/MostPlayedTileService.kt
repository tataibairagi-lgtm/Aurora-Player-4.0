package com.aurora.player

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile that opens Aurora's Most played screen. */
class MostPlayedTileService : TileService() {
    override fun onStartListening() {
        val t = qsTile ?: return
        t.state = Tile.STATE_INACTIVE
        t.label = "Most played"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = "Aurora"
        t.updateTile()
    }

    override fun onClick() {
        val i = Intent(this, MainActivity::class.java)
            .setAction(Intent.ACTION_VIEW).putExtra("route", "mostplayed")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(i)
            }
        } catch (_: Throwable) {}
    }
}
