package com.aurora.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.player.R

/**
 * The loading screen: it only appears when starting takes longer than a moment (a quick start never flashes it),
 * stays long enough not to flicker, and fades away when the music library is ready.
 */
@Composable
fun LoadingGate(content: @Composable () -> Unit) {
    var slow by remember { mutableStateOf(false) }
    var shownAt by remember { mutableStateOf(0L) }
    val ready = AppSession.ready
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(350)
        if (!AppSession.ready) { slow = true; shownAt = System.currentTimeMillis() }
    }
    // never stuck: give up waiting after a while (for example when no permission was given)
    LaunchedEffect(Unit) { kotlinx.coroutines.delay(9000); AppSession.ready = true }
    var hold by remember { mutableStateOf(false) }
    LaunchedEffect(ready, slow) {
        if (ready && slow) {
            val left = 500 - (System.currentTimeMillis() - shownAt)
            if (left > 0) { hold = true; kotlinx.coroutines.delay(left); hold = false }
        }
    }
    Box(Modifier.fillMaxSize()) {
        content()
        AnimatedVisibility(slow && (!ready || hold), enter = fadeIn(tween(200)), exit = fadeOut(tween(350))) {
            val cs = MaterialTheme.colorScheme
            val pulse by rememberInfiniteTransition(label = "ld").animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(1100), RepeatMode.Reverse), label = "ldp")
            Box(Modifier.fillMaxSize().background(cs.background).clickable(enabled = false) {}, contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Image(painterResource(R.drawable.ic_logo), null, Modifier.size(96.dp).scale(pulse).clip(androidx.compose.foundation.shape.RoundedCornerShape(24.dp)))
                    Text("Aurora", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = cs.onBackground)
                    LinearProgressIndicator(Modifier.width(140.dp).padding(top = 2.dp), color = cs.primary, trackColor = cs.primary.copy(alpha = 0.18f))
                    Text("Loading your music…", fontSize = 13.sp, color = cs.onSurfaceVariant)
                }
            }
        }
    }
}
