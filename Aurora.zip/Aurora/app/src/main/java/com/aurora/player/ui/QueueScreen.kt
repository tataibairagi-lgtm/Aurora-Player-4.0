package com.aurora.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

private fun csvCell(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

fun queueCsv(tracks: List<Track>): String = buildString {
    append("Position,Title,Artist,Album,Duration (s),Path\n")
    tracks.forEachIndexed { i, t ->
        append("${i + 1},${csvCell(t.title)},${csvCell(t.artist)},${csvCell(t.album)},${t.durationMs / 1000},${csvCell(t.path)}\n")
    }
}

fun queueM3u8(tracks: List<Track>): String = buildString {
    append("#EXTM3U\n")
    tracks.forEach { t -> append("#EXTINF:${t.durationMs / 1000},${t.artist} - ${t.title}\n${t.path}\n") }
}

/** Musicolet-style queues page: up to 20 queues, drag to reorder, multi-select with options, search, export. */
@Composable
fun QueueScreen(c: PlayerController, back: () -> Unit, embedded: Boolean = false) {
    val actions = LocalActions.current
    val state = rememberLazyListState()
    var query by remember { mutableStateOf("") }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var saveDialog by remember { mutableStateOf(false) }
    var newDialog by remember { mutableStateOf(false) }
    var renameDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragDy by remember { mutableFloatStateOf(0f) }
    var blockDrag by remember { mutableStateOf(false) }
    val d = c.store.data
    val vq = c.viewQueue.coerceIn(0, (d.queues.size - 1).coerceAtLeast(0))
    val isLive = vq == c.activeQueue
    val vt = c.viewTracks(vq)
    val sel = IdSel(c, vt)
    val vIndex = c.viewIndex(vq)
    var queuesDialog by remember { mutableStateOf(false) }
    val qName = d.queues.getOrNull(vq)?.name ?: "Queue"

    BackHandler(enabled = sel.isNotEmpty()) { sel.clear() }
    LaunchedEffect(vq) {
        if (vIndex > 0) runCatching { state.scrollToItem(vIndex) }
    }

    // stable keys so a row keeps its identity while it is dragged to a new position
    val keys = remember(vt) {
        val seen = HashMap<Long, Int>()
        vt.map { t -> val n = (seen[t.id] ?: 0) + 1; seen[t.id] = n; if (n == 1) "${t.id}" else "${t.id}#$n" }
    }
    val shown = remember(vt, query) {
        vt.withIndex().filter { (_, t) ->
            searchMatches(t, query)
        }.map { it.index }
    }
    fun toggle(i: Int) { if (i in sel) sel.remove(i) else sel.add(i) }

    Column(Modifier.fillMaxSize().then(if (embedded) Modifier else Modifier.statusBarsPadding())) {
        // ---- queue picker ----
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!embedded) Box(Modifier.size(44.dp).bounceClick(back), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Box(Modifier.weight(1f)) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .clickable { queuesDialog = true }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${vq + 1}. $qName", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Icon(Icons.Rounded.KeyboardArrowDown, null)
                }
            }
            Box(Modifier.size(44.dp).bounceClick { deleteDialog = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Close, null) }
        }

        // ---- controls ----
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).bounceClick { if (isLive) c.togglePlay() else c.playViewed(vq, null) }, contentAlignment = Alignment.Center) {
                Icon(if (isLive && c.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
            }
            Box {
                Box(Modifier.size(48.dp).bounceClick { sortMenu = true }, contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.Sort, null) }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf<Pair<String, (List<Track>) -> List<Track>>>(
                        "Sort by title" to { l -> l.sortedBy { it.title.lowercase() } },
                        "Sort by artist" to { l -> l.sortedBy { it.artist.lowercase() } },
                        "Sort by album" to { l -> l.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo })) },
                        "Sort by duration" to { l -> l.sortedBy { it.durationMs } },
                        "Sort by date added" to { l -> l.sortedByDescending { it.dateAdded } },
                        "Reverse order" to { l -> l.reversed() },
                        "Randomize" to { l -> l },
                    ).forEach { (label, f) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { sortMenu = false; if (label == "Randomize") { if (isLive) c.randomizeQueue() else c.viewReorder(vq, vt.shuffled()) } else c.viewReorder(vq, f(vt)) })
                    }
                }
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "${if (vIndex >= 0 && vt.isNotEmpty()) vIndex + 1 else 0} / ${vt.size}",
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Timer, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        " " + formatTime(vt.sumOf { it.durationMs }),
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Box(Modifier.size(48.dp).bounceClick { if (vt.isNotEmpty()) saveDialog = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Save, null)
            }
            Box {
                Box(Modifier.size(48.dp).bounceClick { moreMenu = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MoreHoriz, null) }
                DropdownMenu(moreMenu, { moreMenu = false }) {
                    DropdownMenuItem(text = { Text("Export as .csv") }, onClick = {
                        moreMenu = false
                        actions.saveText("$qName.csv", "text/csv", queueCsv(vt))
                    })
                    DropdownMenuItem(text = { Text("Export as .m3u8") }, onClick = {
                        moreMenu = false
                        actions.saveText("$qName.m3u8", "audio/x-mpegurl", queueM3u8(vt))
                    })
                    DropdownMenuItem(text = { Text("Select all") }, onClick = { moreMenu = false; sel.clear(); sel.addAll(vt.indices) })
                    DropdownMenuItem(text = { Text("New queue…") }, enabled = d.queues.size < c.maxQueues, onClick = { moreMenu = false; newDialog = true })
                    DropdownMenuItem(text = { Text("Clear this queue") }, onClick = { moreMenu = false; c.viewReorder(vq, emptyList()) })
                }
            }
        }

        // ---- list ----
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vt.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("This queue is empty.\nPlay a song or use “Add to queue”.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            } else {
                LazyColumn(state = state, contentPadding = PaddingValues(bottom = 24.dp)) {
                    itemsIndexed(shown, key = { _, idx -> keys.getOrElse(idx) { "x$idx" } }) { _, idx ->
                        val t = vt.getOrNull(idx) ?: return@itemsIndexed
                        val key = keys.getOrElse(idx) { "x$idx" }
                        val dragging = dragKey == key
                        val idxState = rememberUpdatedState(idx)
                        Box(
                            Modifier
                                .then(if (dragging) Modifier else Modifier.animateItem())
                                .graphicsLayer { alpha = if (blockDrag && !dragging && idx in sel) 0f else 1f }
                                .zIndex(if (dragging) 1f else 0f)
                                .graphicsLayer { translationY = if (dragging) dragDy else 0f }
                                .background(MaterialTheme.colorScheme.background),
                        ) {
                            TrackRow(
                                t, c,
                                selected = idx in sel,
                                onLongClick = { toggle(idx) },
                                leading = {
                                    if (query.isBlank()) Box(
                                        Modifier.size(32.dp).pointerInput(key) {
                                            detectDragGestures(
                                                onDragStart = { dragKey = key; dragDy = 0f; blockDrag = idxState.value in sel && sel.size > 1 },
                                                onDragEnd = {
                                                    if (blockDrag) {
                                                        val infos = state.layoutInfo.visibleItemsInfo
                                                        val cur = infos.firstOrNull { it.key == dragKey }
                                                        if (cur != null) {
                                                            val center = cur.offset + cur.size / 2f + dragDy
                                                            val target = infos.firstOrNull { it.key != dragKey && center >= it.offset && center <= it.offset + it.size }
                                                            if (target != null) {
                                                                val moved = c.viewMoveBlock(vq, sel.toList(), target.index)
                                                                sel.clear(); sel.addAll(moved)
                                                            }
                                                        }
                                                    }
                                                    blockDrag = false; dragKey = null; dragDy = 0f
                                                },
                                                onDragCancel = { dragKey = null; dragDy = 0f },
                                            ) { change, amount ->
                                                change.consume()
                                                dragDy += amount.y
                                                if (blockDrag) return@detectDragGestures
                                                val infos = state.layoutInfo.visibleItemsInfo
                                                val cur = infos.firstOrNull { it.key == dragKey } ?: return@detectDragGestures
                                                val center = cur.offset + cur.size / 2f + dragDy
                                                val target = infos.firstOrNull { it.key != dragKey && center >= it.offset && center <= it.offset + it.size }
                                                if (target != null) {
                                                    val newOffset = if (target.index > cur.index) target.offset + target.size - cur.size else target.offset
                                                    c.viewMove(vq, cur.index, target.index)
                                                    dragDy -= (newOffset - cur.offset).toFloat()
                                                }
                                            }
                                        },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Icon(Icons.Rounded.DragHandle, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                extraMenu = buildList {
                                    add("Remove from queue" to { c.viewRemove(vq, listOf(idxState.value)) })
                                    add("Move to top" to { c.viewMove(vq, idxState.value, 0) })
                                    add("Move to end" to { c.viewMove(vq, idxState.value, vt.lastIndex) })
                                },
                            ) { if (sel.isNotEmpty()) toggle(idx) else c.playViewed(vq, idx) }
                            if (dragging && blockDrag) Box(
                                Modifier.matchParentSize().padding(horizontal = 8.dp, vertical = 2.dp)
                                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)).padding(horizontal = 16.dp),
                                contentAlignment = Alignment.CenterStart,
                            ) {
                                Column {
                                    Text("${sel.size} songs", fontWeight = FontWeight.Bold)
                                    Text("Move ${sel.size} songs at this position", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (sel.isNotEmpty()) {
            SelectionBar(
                c, c.selection.toList(), inQueue = true,
                onRemove = { c.viewRemove(vq, sel.toList()); sel.clear() },
                onSelectAll = { sel.clear(); sel.addAll(vt.indices) },
                onDeselectAll = { sel.clear() },
                onBetween = { val lo = sel.min(); val hi = sel.max(); sel.clear(); sel.addAll(lo..hi) },
                onInvert = { val all = vt.indices.filter { it !in sel }; sel.clear(); sel.addAll(all) },
                onCancel = { sel.clear() },
            )
        }
        SearchField(query, { query = it }, "Search in this queue…")
    }

    if (queuesDialog) QueuesDialog(c) { queuesDialog = false }
    if (saveDialog) NameDialog("Save queue as playlist", qName, "Save", { saveDialog = false }) {
        c.store.createPlaylist(it, vt.map { t -> t.id }); saveDialog = false
    }
    if (newDialog) NameDialog("New queue", "Queue ${d.queues.size + 1}", "Create", { newDialog = false }) { c.newQueue(it); newDialog = false }
    if (renameDialog) NameDialog("Rename queue", qName, "Rename", { renameDialog = false }) { c.renameQueue(vq, it); renameDialog = false }
    if (deleteDialog) AlertDialog(
        onDismissRequest = { deleteDialog = false },
        title = { Text(if (d.queues.size > 1) "Delete this queue?" else "Clear this queue?") },
        text = { Text("“$qName” with ${vt.size} songs.") },
        confirmButton = { TextButton({ c.deleteQueue(vq); deleteDialog = false }) { Text(if (d.queues.size > 1) "Delete" else "Clear") } },
        dismissButton = { TextButton({ deleteDialog = false }) { Text("Cancel") } },
    )
}
