package com.aurora.player.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.aurora.player.MainActivity
import com.aurora.player.controller
import com.aurora.player.data.AlarmItem
import com.aurora.player.data.MediaScanner
import com.aurora.player.player.PlaybackService
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

/** Playlist alarms and Bluetooth auto-play. */
object Automation {
    const val ACTION_ALARM = "com.aurora.player.ALARM"
    const val EXTRA_ID = "alarm_id"

    /** The next time [a] should ring, in epoch millis. */
    /** Tomorrow at the alarm's time. */
    fun tomorrowAt(a: AlarmItem, now: Long = System.currentTimeMillis()): Long =
        Calendar.getInstance().apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

    /** "7 h 12 min", "35 min", "less than a minute", "1 day 2 h" */
    fun ringsIn(ms: Long): String {
        val mins = ((ms + 59_999L) / 60_000L).coerceAtLeast(0)
        if (mins < 1) return "less than a minute"
        val d = mins / 1440; val h = (mins % 1440) / 60; val m = mins % 60
        return when {
            d > 0 -> "$d day${if (d > 1) "s" else ""}" + if (h > 0) " $h h" else ""
            h > 0 -> "$h h" + if (m > 0) " $m min" else ""
            else -> "$m min"
        }
    }

    fun nextTrigger(a: AlarmItem, now: Long = System.currentTimeMillis()): Long {
        if (a.once) return if (a.onceAt > now) a.onceAt else tomorrowAt(a, now)
        for (dayOff in 0..7) {
            val cal = Calendar.getInstance().apply {
                timeInMillis = now
                add(Calendar.DAY_OF_YEAR, dayOff)
                set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis <= now) continue
            val monday0 = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Mon = 0 ... Sun = 6
            if (a.days == 0 || ((a.days shr monday0) and 1) == 1) return cal.timeInMillis
        }
        return now + 24 * 3_600_000L
    }

    private fun pending(ctx: Context, a: AlarmItem): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, a.id.hashCode(),
            Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_ALARM).putExtra(EXTRA_ID, a.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    /** (Re)sets the system alarm of every enabled alarm and cancels the others. */
    fun schedule(ctx: Context, alarms: List<AlarmItem>) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (a in alarms) {
            try {
                if (!a.enabled || (a.once && a.onceAt <= System.currentTimeMillis())) { am.cancel(pending(ctx, a)); continue }
                val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                // an "alarm clock" alarm is exact and needs no special permission
                am.setAlarmClock(AlarmManager.AlarmClockInfo(nextTrigger(a), show), pending(ctx, a))
            } catch (_: Throwable) {}
        }
    }

    fun cancel(ctx: Context, a: AlarmItem) {
        try { (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx, a)) } catch (_: Throwable) {}
    }

    /** Starts a playlist ("" = all songs, "fav" = favourites). */
    fun startPlaylist(ctx: Context, c: PlayerController, playlistId: String, shuffle: Boolean, alarm: Boolean = false) {
        val d = c.store.data
        if (playlistId.startsWith("q:")) {
            // a saved queue: continue it where it was left
            val i = playlistId.removePrefix("q:").toIntOrNull() ?: return
            if (i !in d.queues.indices) return
            runCatching { ctx.startService(Intent(ctx, PlaybackService::class.java)) }
            c.switchQueue(i)
            if (alarm) c.setAlarmAudio(true)
            if (c.queue.isNotEmpty()) c.play()
            return
        }
        val tracks = when (playlistId) {
            "" -> c.library
            "fav" -> c.library.filter { it.id in d.favourites }
            else -> d.playlists.find { it.id == playlistId }?.trackIds?.mapNotNull { c.track(it) }.orEmpty()
        }
        if (tracks.isEmpty()) return
        runCatching { ctx.startService(Intent(ctx, PlaybackService::class.java)) }
        c.playTracks(if (shuffle) tracks.shuffled() else tracks, 0)
        if (alarm) c.setAlarmAudio(true)
    }

    /** Names of the Bluetooth audio devices connected right now (no permission needed). */
    fun connectedBluetooth(ctx: Context): List<String> {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || (Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET) }
            .map { it.productName.toString() }.filter { it.isNotBlank() }.distinct()
    }

    suspend fun ensureLibrary(ctx: Context, c: PlayerController) {
        if (c.library.isEmpty()) {
            val list = withContext(Dispatchers.IO) { runCatching { MediaScanner.scan(ctx) }.getOrDefault(emptyList()) }
            if (list.isNotEmpty()) c.attachLibrary(list)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val c = app.controller
                Automation.ensureLibrary(app, c)
                val a = c.store.data.alarms.firstOrNull { it.id == intent.getStringExtra(Automation.EXTRA_ID) }
                if (a != null && a.enabled) Automation.startPlaylist(app, c, a.playlistId, a.shuffle, alarm = true)
                // a "Tomorrow" alarm rings once and switches itself off
                if (a != null && a.once) c.store.update { st -> st.copy(alarms = st.alarms.map { if (it.id == a.id) it.copy(enabled = false, onceAt = 0L) else it }) }
                Automation.schedule(app, c.store.data.alarms) // set the next ring
            } finally { pending.finish() }
        }
    }
}

/** Sets the alarms again after the phone restarts. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = context.applicationContext
        try { Automation.schedule(app, app.controller.store.data.alarms) } catch (_: Throwable) {}
    }
}

class BtReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != BluetoothDevice.ACTION_ACL_CONNECTED) return
        val app = context.applicationContext
        val named = try {
            @Suppress("DEPRECATION")
            (intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE))?.name
        } catch (_: Throwable) { null }
        val pending = goAsync()
        // the audio route needs a moment to appear after the link comes up
        Handler(Looper.getMainLooper()).postDelayed({
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    val c = app.controller
                    val rules = c.store.data.btRules
                    if (rules.isNotEmpty()) {
                        val names = (listOfNotNull(named) + Automation.connectedBluetooth(app)).map { it.lowercase() }
                        val rule = rules.firstOrNull { r -> r.device.isNotBlank() && names.any { it == r.device.trim().lowercase() } }
                        if (rule != null) {
                            Automation.ensureLibrary(app, c)
                            Automation.startPlaylist(app, c, rule.playlistId, rule.shuffle)
                        }
                    }
                } finally { pending.finish() }
            }
        }, 3500)
    }
}
