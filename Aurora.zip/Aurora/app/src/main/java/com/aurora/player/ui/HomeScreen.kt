@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.aurora.player.ui

import androidx.compose.foundation.background
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.getValue
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Star
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.UnfoldMore
import com.aurora.player.data.albumKey
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

/** Everything on Home that takes a moment to work out. Kept for as long as the app lives, so coming back to Home is instant. */
private class HomeData(
    val artists: List<Triple<String, Int, Track>>, val albums: List<Track>, val mixes: List<Mix>,
    val most: List<Track>, val added: List<Track>, val genres: List<Pair<String, Int>>, val forgotten: List<Track>,
    val weekPlays: Int, val weekHours: Float, val todayPlays: Int, val weekArtist: String,
)

private object HomeCache { var key: String = ""; var data: HomeData? = null }

private fun computeHome(c: PlayerController, seed: Int): HomeData {
    val lim = 12
    val d = c.store.data
    val lib = c.library
    val counts = d.playCounts
    val most = lib.filter { (counts[it.id] ?: 0) > 0 }.sortedByDescending { counts[it.id] ?: 0 }.take(lim)
    val added = lib.sortedByDescending { it.dateAdded }.take(lim)
    val artists = lib.groupBy { it.artist }.filter { it.key.isNotBlank() }
        .map { (n, l) -> Triple(n, l.sumOf { counts[it.id] ?: 0 }, l.first()) }
        .filter { it.second > 0 }.sortedByDescending { it.second }.take(lim)
    val albums = lib.sortedByDescending { it.dateAdded }.distinctBy { it.albumKey() }.take(lim)
    val genres = lib.groupBy { it.genre }.filter { it.key.isNotBlank() && !it.key.equals("unknown", true) }
        .map { it.key to it.value.size }.sortedByDescending { it.second }.take(lim)
    val mixes = try { buildMixes(c, seed).take(lim) } catch (_: Throwable) { emptyList() }
    val now = System.currentTimeMillis()
    // "this week" is the calendar week starting Monday, the same as Most played → This week (not just the last 7 days)
    val weekAgo = java.util.Calendar.getInstance().apply {
        firstDayOfWeek = java.util.Calendar.MONDAY
        set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY)
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        if (timeInMillis > now) add(java.util.Calendar.WEEK_OF_YEAR, -1)
    }.timeInMillis
    val cal = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0) }
    val dayStart = cal.timeInMillis
    val byId = lib.associateBy { it.id }
    var wp = 0; var ms = 0L; var tp = 0
    val artistWeek = HashMap<String, Int>()
    val lastAt = HashMap<Long, Long>()
    for (e in c.playLog.events) {
        if (e.at > (lastAt[e.id] ?: 0L)) lastAt[e.id] = e.at
        if (e.at >= weekAgo) { val t = byId[e.id] ?: continue; wp++; ms += t.durationMs; artistWeek[t.artist] = (artistWeek[t.artist] ?: 0) + 1; if (e.at >= dayStart) tp++ }
    }
    val monthAgo = now - 30L * 86_400_000L
    val forgotten = lib.filter { (counts[it.id] ?: 0) >= 5 && (lastAt[it.id] ?: 0L) < monthAgo }.sortedByDescending { counts[it.id] ?: 0 }.take(lim)
    return HomeData(artists, albums, mixes, most, added, genres, forgotten, wp, ms / 3_600_000f, tp, artistWeek.maxByOrNull { it.value }?.key ?: "")
}

/** A cover collage: four covers when there are enough, otherwise one. */
@Composable
private fun Mosaic(tracks: List<Track>, size: androidx.compose.ui.unit.Dp, radius: androidx.compose.ui.unit.Dp = 18.dp) {
    val shape = RoundedCornerShape(radius)
    if (tracks.size >= 4) {
        Column(Modifier.size(size).clip(shape)) {
            Row(Modifier.weight(1f)) { AlbumArt(tracks[0], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp), 14.dp, 128); AlbumArt(tracks[1], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp), 14.dp, 128) }
            Row(Modifier.weight(1f)) { AlbumArt(tracks[2], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp), 14.dp, 128); AlbumArt(tracks[3], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp), 14.dp, 128) }
        }
    } else AlbumArt(tracks.firstOrNull(), Modifier.size(size), shape, 30.dp, 256)
}

/** The Home tab: a full-screen start page with what is playing and shelves of queues, mixes, playlists, artists and songs. */
@Composable
fun HomeScreen(c: PlayerController, push: (Route) -> Unit, goTab: (String) -> Unit, openNow: () -> Unit) {
    val d = c.store.data
    val cs = MaterialTheme.colorScheme
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val hello = when { hour < 5 -> "Good night"; hour < 12 -> "Good morning"; hour < 17 -> "Good afternoon"; hour < 22 -> "Good evening"; else -> "Good night" }
    // the glow behind the greeting follows the time of day: warm in the morning, your accent by day, rosy at dusk, deep blue at night
    val greetTint = androidx.compose.ui.graphics.lerp(cs.primary, when { hour < 5 -> Color(0xFF3F51B5); hour < 11 -> Color(0xFFFFA726); hour < 17 -> cs.primary; hour < 21 -> Color(0xFFEC6A8B); else -> Color(0xFF3F51B5) }, 0.6f)
    val byId = remember(c.library) { c.library.associateBy { it.id } }
    var editHome by remember { mutableStateOf(false) }

    // cheap, always live: what you played last, favourites, more from the artist playing now
    val recent = remember(d.lastPlayed, byId) { d.lastPlayed.mapNotNull { byId[it] }.distinctBy { it.id }.take(12) }
    val otd = remember(c.playLog.events, c.library) {
        val now = java.util.Calendar.getInstance(); val cal = java.util.Calendar.getInstance()
        c.playLog.events.filter { e ->
            cal.timeInMillis = e.at
            cal.get(java.util.Calendar.DAY_OF_YEAR) == now.get(java.util.Calendar.DAY_OF_YEAR) && cal.get(java.util.Calendar.YEAR) < now.get(java.util.Calendar.YEAR)
        }.map { it.id }.distinct().mapNotNull { c.track(it) }.take(20)
    }
    val favs = remember(d.favourites, byId) { d.favourites.mapNotNull { byId[it] }.take(12) }
    val cur = c.current
    val more = remember(cur?.id, c.library) {
        if (cur == null) emptyList() else c.library.filter { it.artist == cur.artist && it.id != cur.id }.shuffled().take(12)
    }

    // the heavy part is worked out in the background and kept: Home opens at once the next time and only refreshes behind the scenes
    var refreshN by remember { mutableIntStateOf(0) }
    var spin by remember { mutableStateOf(false) }
    val key = "$refreshN|${c.library.size}|${d.playCounts.size}|${d.playlists.size}|${c.playLog.events.size}|${System.currentTimeMillis() / 10_800_000L}"
    val data by androidx.compose.runtime.produceState(if (HomeCache.key.isNotEmpty()) HomeCache.data else null, key) {
        if (c.library.isEmpty()) return@produceState
        if (HomeCache.key != key || HomeCache.data == null) {
            val fresh = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { computeHome(c, (System.currentTimeMillis() / 10_800_000L).toInt() + refreshN * 7919) }
            HomeCache.key = key; HomeCache.data = fresh
            value = fresh
        } else value = HomeCache.data
        spin = false
    }

    @Composable
    fun Shelf(title: String, sub: String? = null, action: String? = null, onAction: () -> Unit = {}, id: String = title) {
        val folded = id in d.homeCollapsed
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 26.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).combinedClickable(onLongClick = { c.store.update { it.copy(hm = it.hm.copy(homeCollapsed = if (id in it.homeCollapsed) it.homeCollapsed - id else it.homeCollapsed + id)) } }, onClick = {})) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    if (folded) Icon(Icons.Rounded.UnfoldMore, "Collapsed. Hold the title to open", Modifier.padding(start = 6.dp).size(18.dp), tint = cs.onSurfaceVariant)
                }
                if (sub != null) Text(sub, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (action != null) Text(action, Modifier.clip(RoundedCornerShape(50)).background(cs.primary.copy(alpha = 0.12f)).bounceClick(onAction).padding(horizontal = 12.dp, vertical = 5.dp), color = cs.primary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
    }
    @Composable
    fun SongCard(t: Track, list: List<Track>, queueName: String) {
        Column(Modifier.width(128.dp).bounceClick { c.playInQueue(queueName, list, list.indexOf(t)) }) {
            Box {
                AlbumArt(t, Modifier.size(128.dp), RoundedCornerShape(20.dp), 32.dp, 256)
                Box(Modifier.align(Alignment.BottomEnd).padding(7.dp).size(28.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.PlayArrow, "Play", Modifier.size(18.dp), tint = Color.White)
                }
            }
            Text(t.title, Modifier.padding(top = 7.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
    }
    fun hue(name: String, light: Float = 0.42f, index: Int = -1): Brush {
        // names are mixed well before use (short names hash to nearly the same hue); a genre row also gets its own step round the colour wheel
        val mixed = (name.hashCode() * -1640531535) ushr 7
        val h = if (index >= 0) (index * 137.5f + (mixed % 40)) % 360f else (mixed % 360).toFloat()
        val a = Color(androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf(h, 0.58f, light)))
        val b = Color(androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf((h + 40f) % 360f, 0.62f, (light - 0.12f).coerceAtLeast(0.15f))))
        return Brush.linearGradient(listOf(a, b))
    }
    /** A square card: a cover collage with the name on a dark fade. Tap plays; hold opens. */
    @Composable
    fun CollageCard(title: String, sub: String, tracks: List<Track>, tint: Brush, onHold: (() -> Unit)? = null, onClick: () -> Unit) {
        val size = 150
        Box(
            Modifier.size(size.dp).clip(RoundedCornerShape(22.dp)).background(tint)
                .combinedClickable(onLongClick = onHold, onClick = onClick),
        ) {
            if (tracks.isNotEmpty()) Mosaic(tracks, size.dp, 22.dp)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.30f to Color.Transparent, 0.62f to Color.Black.copy(alpha = 0.72f), 1f to Color.Black.copy(alpha = 0.92f))))
            Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
                Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White, lineHeight = 17.sp, style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black, androidx.compose.ui.geometry.Offset(0f, 2f), 6f)))
                Text(sub, maxLines = 1, fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
            }
            Box(Modifier.align(Alignment.TopEnd).padding(8.dp).size(30.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.4f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.PlayArrow, "Play", Modifier.size(18.dp), tint = Color.White)
            }
        }
    }
    @Composable
    fun Skeleton() {
        val a by androidx.compose.animation.core.rememberInfiniteTransition(label = "sk").animateFloat(0.35f, 0.8f, androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(800), androidx.compose.animation.core.RepeatMode.Reverse), label = "ska")
        Column {
            repeat(2) {
                Box(Modifier.padding(start = 20.dp, top = 26.dp, bottom = 12.dp).width(140.dp).height(18.dp).clip(RoundedCornerShape(9.dp)).background(cs.onSurface.copy(alpha = a * 0.12f)))
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    repeat(3) { Box(Modifier.size(128.dp).clip(RoundedCornerShape(20.dp)).background(cs.onSurface.copy(alpha = a * 0.12f))) }
                }
            }
        }
    }

    val contin = remember(recent, d.positions) {
        d.lastPlayed.mapNotNull { byId[it] }.distinctBy { it.id }.filter { val p = d.positions[it.id] ?: 0L; p > 15_000L && p < it.durationMs - 15_000L }.take(10)
    }
    if (editHome) HomeEditor(c) { editHome = false }
    // pull down to get fresh mixes
    androidx.compose.material3.pulltorefresh.PullToRefreshBox(isRefreshing = spin, onRefresh = { spin = true; refreshN++ }, modifier = Modifier.fillMaxSize()) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 150.dp)) {
        // header: runs under the status bar
        item {
            Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(greetTint.copy(alpha = 0.30f), Color.Transparent))).statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 10.dp)) {
                Column {
                    Text(hello, fontSize = 32.sp, fontWeight = FontWeight.Black)
                    Text("${c.library.size} songs  ·  ${d.playlists.size} playlists  ·  ${d.queues.size} queues", color = cs.onSurfaceVariant, fontSize = 13.sp)
                }
            }
        }
        // now playing
        item {
            if (cur != null) Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(cs.primaryContainer, cs.secondaryContainer))).bounceClick(openNow).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AlbumArt(cur, Modifier.size(76.dp), RoundedCornerShape(20.dp), 28.dp, 256)
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(if (c.isPlaying) "NOW PLAYING" else "PAUSED  ·  ${formatTime(c.positionMs)} of ${formatTime(c.durationMs)}", fontSize = 10.sp, letterSpacing = 1.2.sp, color = cs.onPrimaryContainer.copy(alpha = 0.7f), fontWeight = FontWeight.Bold)
                    Text(cur.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = cs.onPrimaryContainer)
                    Text(cur.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = cs.onPrimaryContainer.copy(alpha = 0.75f))
                    // progress through the song, and what comes next
                    val prog = if (c.durationMs > 0) (c.positionMs.toFloat() / c.durationMs).coerceIn(0f, 1f) else 0f
                    androidx.compose.material3.LinearProgressIndicator({ prog }, Modifier.padding(top = 8.dp).fillMaxWidth().height(3.dp).clip(RoundedCornerShape(50)), color = cs.primary, trackColor = cs.onPrimaryContainer.copy(alpha = 0.15f))
                    c.queue.getOrNull(c.currentIndex + 1)?.let { nx -> Text("Next: ${nx.title}", Modifier.padding(top = 5.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = cs.onPrimaryContainer.copy(alpha = 0.65f)) }
                }
                Box(Modifier.size(50.dp).clip(CircleShape).background(cs.primary).bounceClick { c.togglePlay() }, contentAlignment = Alignment.Center) {
                    Icon(if (c.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(28.dp), tint = cs.onPrimary)
                }
                Box(Modifier.padding(start = 6.dp).size(40.dp).clip(CircleShape).background(cs.onPrimaryContainer.copy(alpha = 0.1f)).bounceClick { c.next() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SkipNext, "Next song", tint = cs.onPrimaryContainer)
                }
            }
        }
        // quick actions
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                @Composable
                fun Chip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, filled: Boolean = false, onClick: () -> Unit) = Row(
                    Modifier.clip(RoundedCornerShape(50)).background(if (filled) cs.primary else cs.surfaceVariant.copy(alpha = 0.6f)).bounceClick(onClick).padding(vertical = 10.dp, horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(icon, null, Modifier.size(18.dp), tint = if (filled) cs.onPrimary else cs.primary)
                    Text("  $text", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, color = if (filled) cs.onPrimary else cs.onSurface)
                }
                Chip(Icons.Rounded.Shuffle, "Shuffle all", true) { if (c.library.isNotEmpty()) c.playInQueue("Shuffle all", c.library.shuffled(), 0, true) }
                Chip(Icons.Rounded.Favorite, "Favorites") { push(Route.Detail("smart", "fav")) }
                Chip(Icons.Rounded.LocalFireDepartment, "Most played") { push(Route.MostPlayed) }
                Chip(Icons.Rounded.AutoAwesome, "Smart mixes") { push(Route.Mixes) }
                Chip(Icons.Rounded.Star, "Year in review") { push(Route.YearReview) }
                Chip(Icons.Rounded.Tune, "Customise Home") { editHome = true }
            }
        }
        // this week
        val dd = data
        val shelves = linkedMapOf<String, LazyListScope.() -> Unit>()
        shelves["week"] = {
        if (dd != null && dd.weekPlays > 0) item {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(cs.surfaceVariant.copy(alpha = 0.5f)).padding(vertical = 14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                @Composable
                fun Stat(v: String, l: String) = Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(v, fontSize = 20.sp, fontWeight = FontWeight.Black, color = cs.primary)
                    Text(l, fontSize = 11.sp, color = cs.onSurfaceVariant)
                }
                Stat("${dd.todayPlays}", "plays today")
                Stat("${dd.weekPlays}", "this week")
                Stat("%.1f h".format(dd.weekHours), "listened")
            }
            if (dd.weekArtist.isNotBlank()) Text("Your artist this week: ${dd.weekArtist}", Modifier.padding(horizontal = 24.dp), fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
        }
        shelves["picks"] = {
        // quick picks
        val picks = recent.take(6).ifEmpty { dd?.added?.take(6).orEmpty() }
        if (picks.isNotEmpty()) {
            item { Shelf("Quick picks", id = "picks") }
            if ("picks" !in d.homeCollapsed) item {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    picks.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { t ->
                                Row(
                                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant.copy(alpha = 0.5f))
                                        .bounceClick { c.playInQueue(if (recent.isNotEmpty()) "Recently played" else "Recently added", picks, picks.indexOf(t)) },
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    AlbumArt(t, Modifier.size(52.dp), RoundedCornerShape(16.dp), 20.dp, 128)
                                    Text(t.title, Modifier.padding(horizontal = 10.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 15.sp)
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        }
        shelves["queues"] = {
        // queues: tap plays the queue where it stopped; hold opens the Queues tab
        val qs = d.queues
        if (qs.any { it.trackIds.isNotEmpty() }) {
            item { Shelf("Your queues", "Tap to play  ·  hold to open", "Open", { goTab("queues") }, id = "queues") }
            if ("queues" !in d.homeCollapsed) item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(qs.indices.filter { qs[it].trackIds.isNotEmpty() }) { i ->
                        val q = qs[i]
                        val ts = remember(q.trackIds, byId) { q.trackIds.take(4).mapNotNull { byId[it] } }
                        CollageCard(q.name, "${q.trackIds.size} songs" + if (i == c.activeQueue) " · playing" else "", ts, hue(q.name + i), { c.switchQueue(i); goTab("queues") }) {
                            if (i == c.activeQueue) { if (!c.isPlaying) c.play() }
                            else { c.switchQueue(i); if (c.queue.isNotEmpty()) c.play() }
                        }
                    }
                }
            }
        }
        }
        shelves["continue"] = {
        // mixes
        if (contin.isNotEmpty()) {
            item { Shelf("Continue listening", "Songs you stopped part-way through", id = "continue") }
            if ("continue" !in d.homeCollapsed) item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(contin) { SongCard(it, contin, "Continue listening") } } }
        }
        }
        shelves["mixes"] = {
        if (dd != null && dd.mixes.isNotEmpty()) {
            item { Shelf("Made for you", "Refreshes through the day", "All mixes", { push(Route.Mixes) }, id = "mixes") }
            if ("mixes" !in d.homeCollapsed) item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(dd.mixes) { m -> CollageCard(m.name, "${m.tracks.size} songs", m.tracks.take(4), hue(m.name, 0.40f)) { c.playInQueue(m.name, m.tracks, 0, false) } }
                }
            }
        }
        }
        shelves["recent"] = {
        if (recent.size > 6) {
            item { Shelf("Jump back in", null, "All", { push(Route.Detail("smart", "played")) }, id = "recent") }
            if ("recent" !in d.homeCollapsed) item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(recent) { SongCard(it, recent, "Recently played") } } }
        }
        }
        shelves["more"] = {
        if (cur != null && more.isNotEmpty()) {
            item { Shelf("More from ${cur.artist}", "Because you are listening to ${cur.title}", id = "more") }
            if ("more" !in d.homeCollapsed) item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(more) { SongCard(it, more, "More from ${cur.artist}") } } }
        }
        }
        shelves["playlists"] = {
        // playlists
        if (d.playlists.isNotEmpty()) {
            item { Shelf("Playlists", "Tap to play  ·  hold to open", "All", { goTab("playlists") }, id = "playlists") }
            if ("playlists" !in d.homeCollapsed) item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(d.playlists.take(14)) { p ->
                        val ts = remember(p.trackIds, byId) { p.trackIds.mapNotNull { byId[it] } }
                        CollageCard(p.name, "${p.trackIds.size} songs", ts.take(4), hue(p.name), { push(Route.Detail("playlist", p.id)) }) { if (ts.isNotEmpty()) c.playInQueue(p.name, ts) }
                    }
                }
            }
        }
        }
        shelves["genres"] = {
        // genres
        if (dd != null && dd.genres.isNotEmpty()) {
            item { Shelf("Browse by genre", null, "All", { goTab("genres") }, id = "genres") }
            if ("genres" !in d.homeCollapsed) item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(dd.genres) { gi, (g, n) ->
                        Column(Modifier.clip(RoundedCornerShape(18.dp)).background(hue(g, 0.38f, gi)).bounceClick { push(Route.Detail("genre", g)) }.padding(horizontal = 18.dp, vertical = 14.dp)) {
                            Text(g, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Text("$n songs", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                        }
                    }
                }
            }
        }
        }
        shelves["artists"] = {
        // top artists
        if (dd != null && dd.artists.isNotEmpty()) {
            item { Shelf("Your top artists", null, "All", { goTab("artists") }, id = "artists") }
            if ("artists" !in d.homeCollapsed) item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(dd.artists) { (n, _, t) ->
                        Column(Modifier.width(96.dp).bounceClick { push(Route.Detail("artist", n)) }, horizontalAlignment = Alignment.CenterHorizontally) {
                            AlbumArt(t, Modifier.size(96.dp), CircleShape, 32.dp, 256)
                            Text(n, Modifier.padding(top = 7.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        }
        shelves["most"] = {
        if (dd != null && dd.most.isNotEmpty()) {
            item { Shelf("Most played", null, "More", { push(Route.MostPlayed) }, id = "most") }
            if ("most" !in d.homeCollapsed) item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(dd.most) { SongCard(it, dd.most, "Most played") } } }
        }
        }
        shelves["onthisday"] = {
        if (otd.isNotEmpty()) {
            item { Shelf("On this day", "Songs you played on this date in earlier years", id = "onthisday") }
            if ("onthisday" !in d.homeCollapsed) item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(otd) { SongCard(it, otd, "On this day") } } }
        }
        }
        shelves["forgotten"] = {
        if (dd != null && dd.forgotten.isNotEmpty()) {
            item { Shelf("Forgotten favourites", "Played a lot, not heard for a month", id = "forgotten") }
            if ("forgotten" !in d.homeCollapsed) item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(dd.forgotten) { SongCard(it, dd.forgotten, "Forgotten favourites") } } }
        }
        }
        shelves["albums"] = {
        if (dd != null && dd.albums.isNotEmpty()) {
            item { Shelf("New albums", null, "All", { goTab("albums") }, id = "albums") }
            if ("albums" !in d.homeCollapsed) item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(dd.albums) { t ->
                        Column(Modifier.width(128.dp).bounceClick { push(Route.Detail("album", t.albumKey())) }) {
                            AlbumArt(t, Modifier.size(128.dp), RoundedCornerShape(14.dp), 32.dp, 256)
                            Text(t.album, Modifier.padding(top = 7.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        }
        shelves["added"] = {
        if (dd != null && dd.added.isNotEmpty()) {
            item { Shelf("Recently added", null, "All", { push(Route.Detail("smart", "added")) }, id = "added") }
            if ("added" !in d.homeCollapsed) item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(dd.added) { SongCard(it, dd.added, "Recently added") } } }
        }
        }
        shelves["favs"] = {
        if (favs.isNotEmpty()) {
            item { Shelf("Favourites", null, "All", { push(Route.Detail("smart", "fav")) }, id = "favs") }
            if ("favs" !in d.homeCollapsed) item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(favs) { SongCard(it, favs, "Favourites") } } }
        }
        }
        if (dd == null && c.library.isNotEmpty()) item { Skeleton() }
        // shelves in the order you set (Customise Home), minus the ones you hid
        val shelfOrder = HOME_SHELVES.map { it.first }.let { all -> d.homeOrder.filter { it in all } + all.filter { it !in d.homeOrder } }
        for (id in shelfOrder) if (id !in d.homeHidden) shelves[id]?.invoke(this)
    }
    }
}

/** The Home shelves in their default order, with the names shown in Customise Home. */
internal val HOME_SHELVES = listOf(
    "week" to "This week", "picks" to "Quick picks", "queues" to "Your queues", "continue" to "Continue listening", "mixes" to "Made for you",
    "recent" to "Jump back in", "more" to "More from the artist", "playlists" to "Playlists", "genres" to "Browse by genre", "artists" to "Your top artists",
    "most" to "Most played", "onthisday" to "On this day", "forgotten" to "Forgotten favourites", "albums" to "New albums", "added" to "Recently added", "favs" to "Favourites",
)

/** Customise Home: switch shelves off and move them up or down. */
@Composable
private fun HomeEditor(c: PlayerController, onClose: () -> Unit) {
    val d = c.store.data
    val cs = MaterialTheme.colorScheme
    val all = HOME_SHELVES.map { it.first }
    val order = d.homeOrder.filter { it in all } + all.filter { it !in d.homeOrder }
    val names = HOME_SHELVES.toMap()
    fun move(id: String, by: Int) {
        val l = order.toMutableList(); val i = l.indexOf(id); val j = i + by
        if (i < 0 || j !in l.indices) return
        l.removeAt(i); l.add(j, id)
        c.store.update { it.copy(hm = it.hm.copy(homeOrder = l)) }
    }
    androidx.compose.ui.window.Dialog(onDismissRequest = onClose) {
        androidx.compose.material3.Surface(shape = RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh) {
            Column(Modifier.padding(vertical = 16.dp)) {
                Text("Customise Home", Modifier.padding(horizontal = 22.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Switch shelves off and move them up or down. Hold a shelf title on Home to fold it.", Modifier.padding(start = 22.dp, end = 22.dp, top = 4.dp, bottom = 8.dp), fontSize = 12.sp, color = cs.onSurfaceVariant)
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    order.forEachIndexed { i, id ->
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.Switch(id !in d.homeHidden, { on -> c.store.update { it.copy(hm = it.hm.copy(homeHidden = if (on) it.homeHidden - id else it.homeHidden + id)) } })
                            Text(names[id] ?: id, Modifier.weight(1f).padding(start = 12.dp), fontSize = 14.sp)
                            Icon(Icons.Rounded.ArrowUpward, "Move up", Modifier.size(36.dp).clip(CircleShape).clickable(enabled = i > 0) { move(id, -1) }.padding(8.dp), tint = if (i > 0) cs.onSurface else cs.onSurface.copy(alpha = 0.25f))
                            Icon(Icons.Rounded.ArrowDownward, "Move down", Modifier.size(36.dp).clip(CircleShape).clickable(enabled = i < order.lastIndex) { move(id, 1) }.padding(8.dp), tint = if (i < order.lastIndex) cs.onSurface else cs.onSurface.copy(alpha = 0.25f))
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(end = 12.dp, top = 6.dp), horizontalArrangement = Arrangement.End) {
                    androidx.compose.material3.TextButton({ c.store.update { it.copy(hm = it.hm.copy(homeOrder = emptyList(), homeHidden = emptyList(), homeCollapsed = emptyList())) } }) { Text("Reset") }
                    androidx.compose.material3.TextButton(onClose) { Text("Done") }
                }
            }
        }
    }
}
