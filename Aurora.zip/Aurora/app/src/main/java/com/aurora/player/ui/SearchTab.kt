package com.aurora.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.History
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.albumKey
import com.aurora.player.player.PlayerController

private class Hit(val key: String, val title: String, val sub: String, val art: Track?, val open: () -> Unit)

/** Search everything at once: artists, albums, playlists and songs. */
@Composable
fun SearchTab(c: PlayerController, push: (Route) -> Unit) {
    var q by remember { mutableStateOf("") }
    val d = c.store.data
    val words = remember(q) { normalizeForSearch(q).split(' ').filter { it.isNotEmpty() } }
    fun nameOk(name: String): Boolean { val n = normalizeForSearch(name); return words.all { it in n } }

    val songs = remember(c.library, q) { if (words.isEmpty()) emptyList() else c.library.filter { searchMatches(it, q) }.take(150) }
    val artists = remember(c.library, q, d.splitArtists, d.artistSeparators) {
        if (words.isEmpty()) emptyList() else {
            val m = LinkedHashMap<String, MutableList<Track>>()
            for (t in c.library) for (a in artistsOf(t, d.splitArtists, d.artistSeparators)) if (nameOk(a)) m.getOrPut(a) { ArrayList() }.add(t)
            m.entries.sortedByDescending { it.value.size }.take(6).map { e ->
                Hit("ar" + e.key, e.key, "${e.value.size} songs", e.value.first()) { push(Route.Detail("artist", e.key)) }
            }
        }
    }
    val albums = remember(c.library, q) {
        if (words.isEmpty()) emptyList() else c.library.filter { nameOk(it.album) }
            .groupBy { it.albumKey() }.values.take(8).map { l ->
                val f = l.first()
                Hit("al" + f.albumId + f.album, f.album, "${f.artist} · ${l.size} songs", f) {
                    push(Route.Detail("album", f.albumKey()))
                }
            }
    }
    val playlists = remember(d.playlists, q) {
        if (words.isEmpty()) emptyList() else d.playlists.filter { nameOk(it.name) }.map { p ->
            Hit("pl" + p.id, p.name, "${p.trackIds.size} songs", p.trackIds.firstNotNullOfOrNull { c.track(it) }) { push(Route.Detail("playlist", p.id)) }
        }
    }

    fun saveSearch(term: String) {
        val t = term.trim()
        if (t.length >= 2) c.store.update { it.copy(recentSearches = (listOf(t) + it.recentSearches.filter { r -> !r.equals(t, true) }).take(12)) }
    }
    val sugAlbums = remember(c.library) {
        c.library.sortedByDescending { it.dateAdded }.distinctBy { it.albumKey() }.take(10).map { f ->
            Hit("sa" + f.albumKey(), f.album.ifBlank { "Unknown album" }, f.artist, f) { push(Route.Detail("album", f.albumKey())) }
        }
    }
    val sugLists = remember(d.playlists) {
        d.playlists.take(8).map { p -> Hit("sp" + p.id, p.name, "${p.trackIds.size} songs", p.trackIds.firstNotNullOfOrNull { c.track(it) }) { push(Route.Detail("playlist", p.id)) } }
    }

    Column(Modifier.fillMaxSize()) {
        SearchField(q, { q = it }, "Search songs, albums, artists, playlists…", Modifier.padding(top = 6.dp), focusOnRequest = true)
        if (words.isEmpty()) {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 140.dp)) {
                if (d.recentSearches.isNotEmpty()) {
                    item(key = "hRecent") {
                        Row(Modifier.fillMaxWidth().padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { SectionTitle("Recent searches") }
                            Text("Clear", Modifier.clickable { c.store.update { it.copy(recentSearches = emptyList()) } }.padding(8.dp),
                                color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                    items(d.recentSearches, key = { "r$it" }) { r ->
                        Row(Modifier.fillMaxWidth().clickable { q = r }.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.Icon(Icons.Rounded.History, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(r, Modifier.weight(1f).padding(start = 16.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            androidx.compose.material3.Icon(Icons.Rounded.Close, "Remove", Modifier.size(20.dp).clickable { c.store.update { it.copy(recentSearches = it.recentSearches - r) } }, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                if (sugLists.isNotEmpty()) { item(key = "hPl") { SectionTitle("Your playlists") }; items(sugLists, key = { it.key }) { h -> ResultRow(h) } }
                if (sugAlbums.isNotEmpty()) { item(key = "hAl") { SectionTitle("Recently added albums") }; items(sugAlbums, key = { it.key }) { h -> ResultRow(h) } }
                item(key = "hint") {
                    Text("Every word you type must match.", Modifier.fillMaxWidth().padding(24.dp), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
        } else if (songs.isEmpty() && artists.isEmpty() && albums.isEmpty() && playlists.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No matches.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 140.dp)) {
                fun section(name: String, list: List<Hit>) {
                    if (list.isEmpty()) return
                    item(key = "h$name") { SectionTitle(name) }
                    items(list, key = { it.key }) { h -> ResultRow(h) { saveSearch(q) } }
                }
                section("Artists", artists)
                section("Albums", albums)
                section("Playlists", playlists)
                if (songs.isNotEmpty()) {
                    item(key = "hSongs") { SectionTitle("Songs") }
                    items(songs, key = { "s" + it.id }) { t ->
                        TrackRow(t, c) { saveSearch(q); c.playFromSource("Search", songs, songs.indexOf(t), false) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text, Modifier.padding(start = 20.dp, top = 14.dp, bottom = 4.dp),
        style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun ResultRow(h: Hit, onOpen: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().clickable { onOpen(); h.open() }.padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AlbumArt(h.art, Modifier.size(48.dp), RoundedCornerShape(10.dp), 22.dp)
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(h.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(h.sub, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
