package com.aurora.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Sell
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.PlayCircleFilled
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.NewReleases
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed interface Route {
    object Library : Route
    data class Detail(val kind: String, val key: String) : Route
    object Queue : Route
    object Equalizer : Route
    object Settings : Route
    object MostPlayed : Route
}

/** Items fade/slide/scale in one after another the first time they appear. */
fun Modifier.staggerIn(index: Int): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index.coerceAtMost(12) * 35L)
        a.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
    }
    graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * 36f
        val s = 0.93f + 0.07f * a.value
        scaleX = s; scaleY = s
    }
}

/** Sort choices per tab (the chosen index is remembered per tab in the settings store). */
private val SORTS = mapOf(
    "tracks" to listOf("Title", "Artist", "Album", "Recently added", "Duration", "Year", "File size", "Track number"),
    "albums" to listOf("Name", "Artist", "Year", "Number of songs", "Recently added"),
    "artists" to listOf("Name", "Number of songs", "Recently added"),
    "genres" to listOf("Name", "Number of songs"),
    "folders" to listOf("Name", "Number of songs", "Recently added"),
    "playlists" to listOf("Name", "Number of songs"),
)

private fun <T> List<T>.reversedIf(rev: Boolean): List<T> = if (rev) reversed() else this

val ALL_TABS = listOf(
    "queues" to "Queues", "now" to "Now playing", "albums" to "Albums", "artists" to "Artists",
    "playlists" to "Playlists", "search" to "Search", "folders" to "Folders", "genres" to "Genres", "tracks" to "All songs",
)

private fun tabIcon(id: String): androidx.compose.ui.graphics.vector.ImageVector = when (id) {
    "queues" -> Icons.AutoMirrored.Rounded.QueueMusic
    "now" -> Icons.Rounded.PlayCircleFilled
    "albums" -> Icons.Rounded.Album
    "artists" -> Icons.Rounded.Person
    "playlists" -> Icons.Rounded.LibraryMusic
    "search" -> Icons.Rounded.Search
    "folders" -> Icons.Rounded.Folder
    "genres" -> Icons.Rounded.Sell
    else -> Icons.Rounded.MusicNote
}

/** Tab ids in the user's order, minus hidden ones (never empty). Unknown/new ids are appended. */
fun visibleTabs(d: com.aurora.player.data.Persisted): List<String> {
    val known = ALL_TABS.map { it.first }
    var ordered = d.tabOrder.filter { it in known } + known.filter { it !in d.tabOrder }
    // the Search tab sits right after Playlists until the user arranges it somewhere else
    if ("search" !in d.tabOrder) {
        ordered = ordered.filter { it != "search" }
        val at = ordered.indexOf("playlists")
        ordered = if (at >= 0) ordered.toMutableList().also { it.add(at + 1, "search") } else ordered + "search"
    }
    return ordered.filter { it !in d.hiddenTabs }.ifEmpty { listOf("playlists") }
}

/** The individual artists of a song; with "split artists" on, "A & B; C" becomes A, B and C. */
fun artistsOf(t: Track, split: Boolean, seps: String): List<String> {
    if (!split || seps.isEmpty()) return listOf(t.artist)
    val parts = t.artist.split(*seps.toCharArray()).map { it.trim() }.filter { it.isNotEmpty() }
    return parts.ifEmpty { listOf(t.artist) }
}

/** Ignores a leading "The ", "A ", "An " when sorting, if the setting is on. */
private fun sortKey(s: String, ignore: Boolean): String {
    val l = s.lowercase().trim()
    if (!ignore) return l
    for (w in listOf("the ", "an ", "a ")) if (l.startsWith(w) && l.length > w.length) return l.substring(w.length)
    return l
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    c: PlayerController,
    push: (Route) -> Unit,
    tabRequest: String?,
    onTabRequestHandled: () -> Unit,
    onTabChanged: (String) -> Unit,
    nowPage: @Composable (close: () -> Unit, openQueue: () -> Unit) -> Unit,
) {
    val tabIds = visibleTabs(c.store.data)
    val pager = rememberPagerState { tabIds.size }
    val scope = rememberCoroutineScope()
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var arrange by remember { mutableStateOf(false) }
    val actions = LocalActions.current
    val bottom = c.store.data.tabsBottom
    val current = tabIds.getOrNull(pager.currentPage) ?: ""
    val canSearch = current != "queues" && current != "now" && current != "search"

    LaunchedEffect(current) { onTabChanged(current) }
    LaunchedEffect(tabRequest, tabIds) {
        if (tabRequest != null) {
            val i = tabIds.indexOf(tabRequest)
            if (i >= 0) pager.animateScrollToPage(i)
            onTabRequestHandled()
        }
    }

    val bar: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
            tabIds.forEachIndexed { i, id ->
                val sel = pager.currentPage == i
                Box(
                    Modifier.weight(1f).fillMaxSize().clickable { scope.launch { pager.animateScrollToPage(i) } },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        tabIcon(id), ALL_TABS.first { it.first == id }.second,
                        tint = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Box(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp)
                            .background(if (sel) MaterialTheme.colorScheme.primary else Color.Transparent),
                    )
                }
            }
            if (canSearch) HeaderIcon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search) {
                searching = !searching
                if (!searching) query = ""
            }
            Box {
                HeaderIcon(Icons.Rounded.MoreVert) { menu = true }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; push(Route.Settings) })
                    DropdownMenuItem(text = { Text("Equalizer") }, onClick = { menu = false; push(Route.Equalizer) })
                    DropdownMenuItem(text = { Text("Shuffle all songs") }, onClick = {
                        menu = false
                        if (c.library.isNotEmpty()) c.playTracks(c.library.shuffled(), 0, true)
                    })
                    DropdownMenuItem(text = { Text("Arrange tabs") }, onClick = { menu = false; arrange = true })
                    DropdownMenuItem(text = { Text("Rescan music") }, onClick = { menu = false; actions.rescan() })
                    val opts = SORTS[current]
                    if (opts != null) {
                        val sel = c.store.data.tabSort[current] ?: 0
                        val rev = c.store.data.tabSortRev[current] ?: false
                        Text("Sort by", Modifier.padding(start = 16.dp, top = 8.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        opts.forEachIndexed { i, label ->
                            DropdownMenuItem(
                                text = { Text(label, fontWeight = if (i == sel) FontWeight.Bold else FontWeight.Normal) },
                                onClick = { c.store.update { it.copy(tabSort = it.tabSort + (current to i)) }; menu = false },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("Reverse order", fontWeight = if (rev) FontWeight.Bold else FontWeight.Normal) },
                            onClick = { c.store.update { it.copy(tabSortRev = it.tabSortRev + (current to !rev)) }; menu = false },
                        )
                    }
                    if (current == "albums") {
                        Text("Albums per row", Modifier.padding(start = 16.dp, top = 8.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        listOf(1, 2, 3, 4, 5).forEach { n ->
                            DropdownMenuItem(
                                text = { Text(if (n == 1) "List" else "$n", fontWeight = if (c.store.data.albumCols == n) FontWeight.Bold else FontWeight.Normal) },
                                onClick = { c.store.update { it.copy(albumCols = n) }; menu = false },
                            )
                        }
                    }
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        if (!bottom) bar()
        AnimatedVisibility(searching && canSearch, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            SearchField(
                query, { query = it },
                when (current) {
                    "albums" -> "Search albums, artists, songs…"
                    "artists" -> "Search artists or songs…"
                    "folders" -> "Search folders or songs…"
                    "playlists" -> "Search"
                    else -> "Search songs, artists, albums…"
                },
                autoFocus = true,
            )
        }
        HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth(), beyondViewportPageCount = 0, key = { tabIds.getOrNull(it) ?: it }) { page ->
            when (tabIds.getOrNull(page)) {
                "queues" -> QueueScreen(c, {}, embedded = true)
                "now" -> nowPage(
                    { scope.launch { pager.animateScrollToPage(tabIds.indexOf("playlists").coerceAtLeast(0)) } },
                    { scope.launch { pager.animateScrollToPage(tabIds.indexOf("queues").let { if (it < 0) page else it }) } },
                )
                "tracks" -> TracksTab(c, query)
                "albums" -> AlbumsTab(c, query, push)
                "artists" -> ArtistsTab(c, query, push)
                "genres" -> GenresTab(c, query, push)
                "search" -> SearchTab(c, push)
                "folders" -> FoldersTab(c, query, push)
                "playlists" -> PlaylistsTab(c, push)
                else -> {}
            }
        }
        if (bottom) Box(Modifier.navigationBarsPadding()) { bar() }
    }
    if (arrange) ArrangeTabsDialog(c) { arrange = false }
}

/** Show/hide and reorder the tabs, like Musicolet's "Arrange tabs". Everything below the divider is hidden. */
@Composable
fun ArrangeTabsDialog(c: PlayerController, onDismiss: () -> Unit) {
    val d = c.store.data
    val known = ALL_TABS.map { it.first }
    val order = d.tabOrder.filter { it in known } + known.filter { it !in d.tabOrder }
    val visible = order.filter { it !in d.hiddenTabs }
    val hidden = order.filter { it in d.hiddenTabs }
    fun save(v: List<String>, h: List<String>) {
        if (v.isEmpty()) return // keep at least one tab
        c.store.update { it.copy(tabOrder = v + h, hiddenTabs = h) }
    }

    @Composable
    fun Item(id: String, isHidden: Boolean, up: (() -> Unit)?, down: (() -> Unit)?) {
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(tabIcon(id), null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(end = 14.dp))
            Text(
                ALL_TABS.first { it.first == id }.second, Modifier.weight(1f),
                color = if (isHidden) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface,
                textDecoration = if (isHidden) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
            )
            Box(Modifier.size(38.dp).bounceClick { up?.invoke() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.KeyboardArrowUp, null, tint = if (up != null) MaterialTheme.colorScheme.onSurface else Color.Transparent)
            }
            Box(Modifier.size(38.dp).bounceClick { down?.invoke() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.KeyboardArrowDown, null, tint = if (down != null) MaterialTheme.colorScheme.onSurface else Color.Transparent)
            }
        }
    }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Arrange tabs") },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                visible.forEachIndexed { i, id ->
                    Item(
                        id, false,
                        up = if (i > 0) ({ save(visible.toMutableList().also { l -> l.add(i - 1, l.removeAt(i)) }, hidden) }) else null,
                        down = if (i < visible.lastIndex) ({ save(visible.toMutableList().also { l -> l.add(i + 1, l.removeAt(i)) }, hidden) })
                        else if (visible.size > 1) ({ save(visible - id, listOf(id) + hidden) }) else null,
                    )
                }
                Text(
                    "Tabs below this line are hidden ↓", Modifier.padding(vertical = 10.dp),
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                )
                hidden.forEachIndexed { i, id ->
                    Item(
                        id, true,
                        up = if (i > 0) ({ save(visible, hidden.toMutableList().also { l -> l.add(i - 1, l.removeAt(i)) }) })
                        else ({ save(visible + id, hidden - id) }),
                        down = if (i < hidden.lastIndex) ({ save(visible, hidden.toMutableList().also { l -> l.add(i + 1, l.removeAt(i)) }) }) else null,
                    )
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onDismiss) { Text("Done") } },
    )
}

@Composable
private fun HeaderIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface)
    }
}

private fun matches(t: Track, q: String) = searchMatches(t, q)

@Composable
private fun Empty(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(32.dp))
    }
}

@Composable
fun TrackList(
    c: PlayerController,
    tracks: List<Track>,
    emptyText: String,
    extraMenu: (Track) -> List<Pair<String, () -> Unit>> = { emptyList() },
    sourceName: String? = null,
) {
    if (tracks.isEmpty()) { Empty(emptyText); return }
    val sel = remember(tracks) { androidx.compose.runtime.mutableStateListOf<Int>() }
    androidx.activity.compose.BackHandler(enabled = sel.isNotEmpty()) { sel.clear() }
    fun toggle(i: Int) { if (i in sel) sel.remove(i) else sel.add(i) }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(contentPadding = PaddingValues(bottom = if (sel.isEmpty()) 140.dp else 200.dp, top = 4.dp)) {
            itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
                TrackRow(
                    t, c, Modifier.animateItem(), extraMenu(t),
                    selected = i in sel, onLongClick = { toggle(i) },
                ) {
                    if (sel.isNotEmpty()) toggle(i)
                    else if (!c.store.data.tapPlaysList) c.playTracks(listOf(t))
                    else if (sourceName != null) c.playFromSource(sourceName, tracks, i)
                    else c.playTracks(tracks, i)
                }
            }
        }
        if (sel.isNotEmpty()) {
            SelectionBar(
                c, sel.sorted().mapNotNull { tracks.getOrNull(it) }, inQueue = false, onRemove = {},
                onSelectAll = { sel.clear(); sel.addAll(tracks.indices) },
                onInvert = { val rest = tracks.indices.filter { it !in sel }; sel.clear(); sel.addAll(rest) },
                onCancel = { sel.clear() },
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}

@Composable
private fun TracksTab(c: PlayerController, query: String) {
    val ignore = c.store.data.ignoreWords
    val sort = c.store.data.tabSort["tracks"] ?: 0
    val reverse = c.store.data.tabSortRev["tracks"] ?: false
    val list = remember(c.library, query, sort, ignore, reverse) {
        val f = c.library.filter { matches(it, query) }
        when (sort) {
            1 -> f.sortedWith(compareBy({ it.artist.lowercase() }, { it.album.lowercase() }, { it.trackNo }))
            2 -> f.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo }))
            3 -> f.sortedByDescending { it.dateAdded }
            4 -> f.sortedByDescending { it.durationMs }
            5 -> f.sortedWith(compareByDescending<Track> { it.year }.thenBy { it.title.lowercase() })
            6 -> f.sortedByDescending { it.size }
            7 -> f.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo }))
            else -> f.sortedBy { sortKey(it.title, ignore) }
        }.reversedIf(reverse)
    }
    TrackList(c, list, if (c.library.isEmpty()) "No music found on this device." else "No matches.", sourceName = "All songs")
}

@Composable
private fun AlbumsTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val ignore = c.store.data.ignoreWords
    val sort = c.store.data.tabSort["albums"] ?: 0
    val reverse = c.store.data.tabSortRev["albums"] ?: false
    val cols = c.store.data.albumCols.coerceIn(1, 5)
    val albums = remember(c.library, query, ignore, sort, reverse) {
        val g = c.library.filter { matches(it, query) }
            .groupBy { if (it.albumId > 0) it.albumId.toString() else it.album }
            .values
        when (sort) {
            1 -> g.sortedBy { it.first().artist.lowercase() }
            2 -> g.sortedByDescending { l -> l.maxOf { it.year } }
            3 -> g.sortedByDescending { it.size }
            4 -> g.sortedByDescending { l -> l.maxOf { it.dateAdded } }
            else -> g.sortedBy { sortKey(it.first().album, ignore) }
        }.reversedIf(reverse)
    }
    if (albums.isEmpty()) { Empty("No albums."); return }
    if (cols == 1) {
        LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
            itemsIndexed(albums, key = { _, a -> a.first().albumId.toString() + a.first().album }) { i, tracks ->
                val first = tracks.first()
                GroupRow(i, first.album, "${first.artist} · ${tracks.size} songs", first, null, Modifier.animateItem()) {
                    push(Route.Detail("album", if (first.albumId > 0) first.albumId.toString() else first.album))
                }
            }
        }
        return
    }
    val small = cols >= 3
    LazyVerticalGrid(
        GridCells.Fixed(cols), contentPadding = PaddingValues(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 140.dp),
        horizontalArrangement = Arrangement.spacedBy(if (small) 8.dp else 14.dp), verticalArrangement = Arrangement.spacedBy(if (small) 10.dp else 14.dp),
    ) {
        itemsIndexed(albums, key = { _, a -> a.first().albumId.toString() + a.first().album }) { i, tracks ->
            val first = tracks.first()
            Column(
                Modifier.clip(RoundedCornerShape(if (small) 12.dp else 18.dp))
                    .clickable { push(Route.Detail("album", if (first.albumId > 0) first.albumId.toString() else first.album)) },
            ) {
                AlbumArt(first, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(if (small) 12.dp else 18.dp), if (small) 24.dp else 40.dp)
                Text(
                    first.album, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp),
                    style = if (small) MaterialTheme.typography.labelLarge else MaterialTheme.typography.bodyLarge,
                )
                Text(
                    if (small) first.artist else "${first.artist} · ${tracks.size} songs", maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun GroupRow(
    index: Int, title: String, subtitle: String, art: Track?, icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    modifier: Modifier = Modifier, onClick: () -> Unit,
) {
    Row(
        modifier.staggerIn(index).fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center,
            ) {
                AlbumArt(null, Modifier.fillMaxSize(), RoundedCornerShape(14.dp))
                Icon(icon, null, tint = androidx.compose.ui.graphics.Color.White)
            }
        } else {
            AlbumArt(art, Modifier.size(52.dp), CircleShape, 24.dp)
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ArtistsTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val ignore = c.store.data.ignoreWords
    val split = c.store.data.splitArtists
    val seps = c.store.data.artistSeparators
    val sort = c.store.data.tabSort["artists"] ?: 0
    val reverse = c.store.data.tabSortRev["artists"] ?: false
    var kind by remember { mutableStateOf(0) } // 0 artists, 1 album artists, 2 composers
    val artists = remember(c.library, query, ignore, split, seps, kind, sort, reverse) {
        val m = LinkedHashMap<String, MutableList<Track>>()
        for (t in c.library.filter { matches(it, query) }) {
            val names = when (kind) {
                1 -> listOf(t.albumArtist.ifBlank { t.artist })
                2 -> listOf(t.composer.ifBlank { "Unknown composer" })
                else -> artistsOf(t, split, seps)
            }
            for (a in names) m.getOrPut(a) { ArrayList() }.add(t)
        }
        when (sort) {
            1 -> m.entries.sortedByDescending { it.value.size }
            2 -> m.entries.sortedByDescending { e -> e.value.maxOf { it.dateAdded } }
            else -> m.entries.sortedBy { e -> sortKey(e.key, ignore) }
        }.reversedIf(reverse)
    }
    val kindName = when (kind) { 1 -> "albumartist"; 2 -> "composer"; else -> "artist" }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Artists", "Album-Artists", "Composers").forEachIndexed { i, n ->
                androidx.compose.material3.FilterChip(kind == i, { kind = i }, label = { Text(n) })
            }
        }
        if (artists.isEmpty()) { Empty("Nothing here."); return@Column }
        LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
            itemsIndexed(artists, key = { _, e -> kindName + e.key }) { i, e ->
                GroupRow(i, e.key, "${e.value.size} songs", e.value.first(), null, Modifier.animateItem()) { push(Route.Detail(kindName, e.key)) }
            }
        }
    }
}

@Composable
private fun GenresTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val gSort = c.store.data.tabSort["genres"] ?: 0
    val gRev = c.store.data.tabSortRev["genres"] ?: false
    val genres = remember(c.library, query, gSort, gRev) {
        val g = c.library.filter { matches(it, query) }.groupBy { it.genre.ifBlank { "Unknown genre" } }.entries
        (if (gSort == 1) g.sortedByDescending { it.value.size } else g.sortedBy { it.key.lowercase() }).reversedIf(gRev)
    }
    if (genres.isEmpty()) { Empty("No genres."); return }
    LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
        itemsIndexed(genres, key = { _, e -> e.key }) { i, e ->
            GroupRow(i, e.key, "${e.value.size} songs", e.value.first(), null, Modifier.animateItem()) { push(Route.Detail("genre", e.key)) }
        }
    }
}

@Composable
private fun FoldersTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val tree = c.store.data.foldersTree
    var cur by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renameFor by remember { mutableStateOf<String?>(null) }
    var moveFor by remember { mutableStateOf<String?>(null) }
    val actions = LocalActions.current
    val matched = remember(c.library, query) { c.library.filter { matches(it, query) } }
    val fSort = c.store.data.tabSort["folders"] ?: 0
    val fRev = c.store.data.tabSortRev["folders"] ?: false

    fun under(dir: String) = matched.filter { it.folder == dir || it.folder.startsWith("$dir/") }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (tree && cur.isNotEmpty()) cur else if (tree) "Folder tree" else "All folders",
                Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            androidx.compose.material3.TextButton({ c.store.update { it.copy(foldersTree = !it.foldersTree) }; cur = "" }) { Text(if (tree) "Show as list" else "Show as tree") }
        }
        if (!tree) {
            val folders = remember(matched, fSort, fRev) {
                val g = matched.groupBy { it.folder }.entries
                when (fSort) {
                    1 -> g.sortedByDescending { it.value.size }
                    2 -> g.sortedByDescending { e -> e.value.maxOf { it.dateAdded } }
                    else -> g.sortedBy { it.key.lowercase() }
                }.reversedIf(fRev)
            }
            if (folders.isEmpty()) { Empty("No folders."); return@Column }
            LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
                itemsIndexed(folders, key = { _, e -> e.key }) { i, e ->
                    GroupRow(i, e.key.substringAfterLast('/').ifEmpty { "/" }, "${e.value.size} songs · ${e.key}", null, Icons.Rounded.Folder, Modifier.animateItem()) {
                        push(Route.Detail("folder", e.key))
                    }
                }
            }
        } else {
            // children of the current folder; when there is only one path to follow, skip straight down it
            val inside = if (cur.isEmpty()) matched else under(cur)
            val base = if (cur.isEmpty()) "" else "$cur/"
            val children = inside.filter { it.folder.startsWith(base) && it.folder != cur }
                .groupBy { base + it.folder.removePrefix(base).substringBefore('/') }
                .entries.let { g ->
                    when (fSort) {
                        1 -> g.sortedByDescending { it.value.size }
                        2 -> g.sortedByDescending { e -> e.value.maxOf { it.dateAdded } }
                        else -> g.sortedBy { it.key.lowercase() }
                    }.reversedIf(fRev)
                }
            val direct = inside.filter { it.folder == cur }
            if (cur.isEmpty() && children.size == 1 && direct.isEmpty()) {
                // jump past shared prefixes like /storage/emulated/0
                var d = children.first().key
                while (true) {
                    val sub = matched.filter { it.folder.startsWith("$d/") }.map { d + "/" + it.folder.removePrefix("$d/").substringBefore('/') }.distinct()
                    val here = matched.any { it.folder == d }
                    if (sub.size == 1 && !here) d = sub.first() else break
                }
                cur = d
            }
            BackHandlerIfNested(cur.isNotEmpty()) { cur = cur.substringBeforeLast('/', "") }
            LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
                if (cur.isNotEmpty()) item(key = "up") {
                    GroupRow(0, "..", "Up one level", null, Icons.Rounded.Folder) { cur = if (cur.count { it == '/' } <= 1) "" else cur.substringBeforeLast('/') }
                }
                if (direct.isNotEmpty()) item(key = "here") {
                    GroupRow(1, "Songs in this folder", "${direct.size} songs", direct.first(), null) { push(Route.Detail("folder", cur)) }
                }
                itemsIndexed(children, key = { _, e -> e.key }) { i, e ->
                    val path = e.key
                    val hasSub = matched.any { it.folder.startsWith("$path/") }
                    Box {
                        GroupRow(i + 2, path.substringAfterLast('/'), "${e.value.size} songs" + if (hasSub) " · has sub-folders" else "", null, Icons.Rounded.Folder, Modifier.animateItem()) {
                            if (hasSub) cur = path else push(Route.Detail("folder", path))
                        }
                        Box(Modifier.align(Alignment.CenterEnd)) {
                            Icon(
                                Icons.Rounded.MoreVert, null,
                                Modifier.padding(end = 12.dp).size(36.dp).clip(CircleShape).clickable { menuFor = path }.padding(6.dp),
                            )
                            DropdownMenu(menuFor == path, { menuFor = null }) {
                                DropdownMenuItem(text = { Text("Play all") }, onClick = { menuFor = null; c.playFromSource(path.substringAfterLast('/'), under(path), 0, false) })
                                DropdownMenuItem(text = { Text("Shuffle all") }, onClick = { menuFor = null; c.playFromSource(path.substringAfterLast('/'), under(path).shuffled(), 0, true) })
                                DropdownMenuItem(text = { Text("Add to queue") }, onClick = { menuFor = null; c.addAllToQueue(under(path)) })
                                DropdownMenuItem(text = { Text("Rename folder") }, onClick = { renameFor = path; menuFor = null })
                                DropdownMenuItem(text = { Text("Move songs to another folder") }, onClick = { moveFor = path; menuFor = null })
                                DropdownMenuItem(text = { Text("Pin shortcut to home screen") }, onClick = { menuFor = null; actions.pinShortcut("folder" + path.hashCode(), path.substringAfterLast('/'), "detail|folder|$path") })
                            }
                        }
                    }
                }
            }
        }
    }
    renameFor?.let { path ->
        NameDialog("Rename folder", path.substringAfterLast('/'), "Rename", { renameFor = null }) { n ->
            val clean = n.trim().replace("/", "")
            if (clean.isNotEmpty()) actions.renameFolder(under(path), path, path.substringBeforeLast('/') + "/" + clean)
            renameFor = null; cur = ""
        }
    }
    moveFor?.let { path ->
        NameDialog("Move to (e.g. Music/Rock)", "Music/", "Move", { moveFor = null }) { n ->
            val clean = n.trim().trim('/')
            if (clean.isNotEmpty()) actions.moveTracks(under(path), "$clean/")
            moveFor = null; cur = ""
        }
    }
}

@Composable
private fun BackHandlerIfNested(enabled: Boolean, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler(enabled = enabled, onBack = onBack)
}

@Composable
private fun PlaylistsTab(c: PlayerController, push: (Route) -> Unit) {
    var creating by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    val actions = LocalActions.current
    val pSort = c.store.data.tabSort["playlists"] ?: 0
    val pRev = c.store.data.tabSortRev["playlists"] ?: false
    val pls = c.store.data.playlists.filter { q.isBlank() || it.name.contains(q, true) }
        .let { l -> (if (pSort == 1) l.sortedByDescending { it.trackIds.size } else l.sortedBy { it.name.lowercase() }).reversedIf(pRev) }

    @Composable
    fun Row1(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, count: String? = null, onClick: () -> Unit) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, null, Modifier.size(26.dp))
            Text(title, Modifier.weight(1f).padding(start = 22.dp), style = MaterialTheme.typography.titleMedium)
            if (count != null) Text(count, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 140.dp)) {
            item {
                Column {
                    Row1(Icons.Rounded.MusicNote, "All songs", "${c.library.size}") { push(Route.Detail("smart", "all")) }
                    Row1(Icons.Rounded.Favorite, "Favorites", "${c.store.data.favourites.size}") { push(Route.Detail("smart", "fav")) }
                    Row1(Icons.Rounded.AutoAwesome, "Recently added") { push(Route.Detail("smart", "added")) }
                    Row1(Icons.Rounded.History, "Recently played") { push(Route.Detail("smart", "played")) }
                    Row1(Icons.Rounded.LocalFireDepartment, "Most played") { push(Route.MostPlayed) }
                    Row1(Icons.Rounded.Block, "Not played") { push(Route.Detail("smart", "unplayed")) }
                    Text(
                        "Your playlists", Modifier.padding(start = 16.dp, top = 22.dp, bottom = 6.dp),
                        style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
                    )
                }
            }
            items(pls, key = { it.id }) { p ->
                Row1(Icons.AutoMirrored.Rounded.PlaylistAdd, p.name, "${p.trackIds.size}") { push(Route.Detail("playlist", p.id)) }
            }
            item {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    androidx.compose.material3.OutlinedButton({ creating = true }, shape = RoundedCornerShape(10.dp)) {
                        Icon(Icons.Rounded.Add, null, Modifier.size(20.dp)); Text("  New playlist")
                    }
                    androidx.compose.material3.OutlinedButton({ actions.importPlaylist() }, shape = RoundedCornerShape(10.dp)) {
                        Icon(Icons.Rounded.FileDownload, null, Modifier.size(20.dp)); Text("  External playlists (.m3u)")
                    }
                }
            }
        }
        OutlinedTextField(
            q, { q = it }, singleLine = true, placeholder = { Text("Search a playlist…") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        )
    }
    if (creating) NameDialog("New playlist", confirm = "Create", onDismiss = { creating = false }) {
        c.store.createPlaylist(it); creating = false
    }
}

// -------------------------------------------------------------------------------------------------
// Detail (album / artist / folder / playlist / smart list)
// -------------------------------------------------------------------------------------------------

@Composable
fun DetailScreen(c: PlayerController, kind: String, key: String, back: () -> Unit) {
    val d = c.store.data
    val playlist = if (kind == "playlist") d.playlists.find { it.id == key } else null
    val (title, tracks) = remember(kind, key, c.library, d.playlists, d.playCounts, d.lastPlayed, d.favourites, d.splitArtists, d.artistSeparators) {
        when (kind) {
            "album" -> {
                val l = c.library.filter { (if (it.albumId > 0) it.albumId.toString() else it.album) == key }
                (l.firstOrNull()?.album ?: "Album") to l.sortedBy { it.trackNo }
            }
            "artist" -> key to c.library.filter { key in artistsOf(it, d.splitArtists, d.artistSeparators) }.sortedBy { it.album.lowercase() + "%03d".format(it.trackNo) }
            "albumartist" -> key to c.library.filter { it.albumArtist.ifBlank { it.artist } == key }.sortedBy { it.album.lowercase() + "%03d".format(it.trackNo) }
            "composer" -> key to c.library.filter { it.composer.ifBlank { "Unknown composer" } == key }.sortedBy { it.title.lowercase() }
            "genre" -> key to c.library.filter { it.genre.ifBlank { "Unknown genre" } == key }.sortedBy { it.title.lowercase() }
            "folder" -> key.substringAfterLast('/') to c.library.filter { it.folder == key }.sortedBy { it.title.lowercase() }
            "playlist" -> (playlist?.name ?: "Playlist") to (playlist?.trackIds?.mapNotNull { c.track(it) } ?: emptyList())
            else -> when (key) {
                "all" -> "All songs" to c.library.sortedBy { it.title.lowercase() }
                "fav" -> "Favourites" to d.favourites.mapNotNull { c.track(it) }
                "added" -> "Recently added" to c.library.sortedByDescending { it.dateAdded }.take(100)
                "played" -> "Recently played" to d.lastPlayed.mapNotNull { c.track(it) }
                "unplayed" -> "Not played yet" to c.library.filter { (d.playCounts[it.id] ?: 0) == 0 }.sortedBy { it.title.lowercase() }
                else -> "Most played" to d.playCounts.entries.sortedByDescending { it.value }.take(100).mapNotNull { c.track(it.key) }
            }
        }
    }
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var saveAs by remember { mutableStateOf(false) }
    var moveDlg by remember { mutableStateOf(false) }
    val actions = LocalActions.current

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            HeaderIcon(Icons.AutoMirrored.Rounded.ArrowBack, back)
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Box {
                HeaderIcon(Icons.Rounded.MoreVert) { menu = true }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Add all to queue") }, onClick = { menu = false; c.addAllToQueue(tracks) })
                    DropdownMenuItem(text = { Text("Export as .m3u") }, onClick = { menu = false; actions.exportPlaylist(title, tracks) })
                    if (kind != "smart" || key != "all") DropdownMenuItem(text = { Text("Pin shortcut to home screen") }, onClick = { menu = false; actions.pinShortcut("d" + (kind + key).hashCode(), title, "detail|$kind|$key") })
                    if (kind == "folder") DropdownMenuItem(text = { Text("Move songs to another folder") }, onClick = { menu = false; moveDlg = true })
                    if (playlist != null) {
                        DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; rename = true })
                        DropdownMenuItem(text = { Text("Delete playlist") }, onClick = { menu = false; c.store.deletePlaylist(playlist.id); back() })
                    } else {
                        DropdownMenuItem(text = { Text("Save as playlist") }, onClick = { menu = false; saveAs = true })
                    }
                }
            }
        }
        Row(Modifier.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(tracks.firstOrNull(), Modifier.size(96.dp), RoundedCornerShape(20.dp), 40.dp)
            Column(Modifier.padding(start = 16.dp)) {
                Text("${tracks.size} songs · ${formatTime(tracks.sumOf { it.durationMs })}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Play", Icons.Rounded.PlayArrow, true) { c.playFromSource(title, tracks, 0, false) }
                    PillButton("Shuffle", Icons.Rounded.Shuffle, false) { c.playFromSource(title, tracks.shuffled(), 0, true) }
                }
            }
        }
        TrackList(
            c, tracks, "Nothing here yet.", sourceName = title,
            extraMenu = { t ->
                if (playlist != null) listOf("Remove from playlist" to { c.store.removeFromPlaylist(playlist.id, t.id) }) else emptyList()
            },
        )
    }
    if (rename && playlist != null) NameDialog("Rename playlist", playlist.name, "Rename", { rename = false }) {
        c.store.renamePlaylist(playlist.id, it); rename = false
    }
    if (moveDlg) NameDialog("Move to (e.g. Music/Rock)", "Music/", "Move", { moveDlg = false }) { n ->
        val clean = n.trim().trim('/'); if (clean.isNotEmpty()) actions.moveTracks(tracks, "$clean/"); moveDlg = false
    }
    if (saveAs) NameDialog("Save as playlist", title, "Save", { saveAs = false }) {
        c.store.createPlaylist(it, tracks.map { t -> t.id }); saveAs = false
    }
}

@Composable
fun PillButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, filled: Boolean, onClick: () -> Unit) {
    val bg = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier.clip(RoundedCornerShape(50)).then(Modifier.bounceClick(onClick))
            .background(bg).padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp))
        Spacer(Modifier.size(6.dp))
        Text(label, color = fg, fontWeight = FontWeight.SemiBold)
    }
}
