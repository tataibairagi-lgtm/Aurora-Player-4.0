package com.aurora.player.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.indexAt
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Pick 2 to 4 lines of the lyrics and share them as a quote card tinted with the cover's colour. */
@Composable
fun LyricCardDialog(c: PlayerController, t: Track, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val lines = c.lyrics?.lines.orEmpty().filter { it.text.isNotBlank() }
    val art = rememberArt(t, 700)
    val tint = remember(art) { art?.dominantColor()?.toArgb() ?: 0xFF6C5CE7.toInt() }
    var sel by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var style by remember { mutableIntStateOf(0) }
    val state = rememberLazyListState()
    // start on the line that is playing now, with the next one chosen too
    LaunchedEffect(lines.size) {
        val cur = c.lyrics?.indexAt(c.positionMs) ?: -1
        val at = if (cur >= 0) lines.indexOfFirst { it.timeMs >= (c.lyrics!!.lines[cur].timeMs) }.coerceAtLeast(0) else 0
        sel = setOfNotNull(at.takeIf { it in lines.indices }, (at + 1).takeIf { it in lines.indices })
        state.scrollToItem((at - 1).coerceAtLeast(0))
    }
    val picked = sel.sorted().map { lines[it].text }
    val bmp = remember(art, picked, style) { if (picked.isEmpty()) null else CardPictures.lyric(t, art, picked, style, tint) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Share lyrics") },
        text = {
            Column {
                if (lines.isEmpty()) Text("No lyrics for this song yet. Open the lyrics view and pick a source first.")
                else {
                    Text("Tap 2 to 4 lines (${sel.size} chosen)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 190.dp).padding(vertical = 6.dp), state = state) {
                        itemsIndexed(lines) { i, l ->
                            val on = i in sel
                            Text(
                                l.text,
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                    .background(if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f) else androidx.compose.ui.graphics.Color.Transparent)
                                    .clickable { sel = if (on) sel - i else if (sel.size < 4) sel + i else sel }
                                    .padding(horizontal = 10.dp, vertical = 7.dp),
                                fontWeight = if (on) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal,
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Cover colour", "Dark", "Light").forEachIndexed { i, n -> FilterChip(style == i, { style = i }, label = { Text(n) }) }
                    }
                    if (bmp != null) Image(
                        bmp.asImageBitmap(), null,
                        Modifier.fillMaxWidth().heightIn(max = 260.dp).padding(top = 10.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Fit,
                    )
                }
            }
        },
        confirmButton = {
            TextButton(enabled = bmp != null && sel.size >= 2, onClick = {
                scope.launch {
                    val uri = withContext(Dispatchers.IO) { ShareCard.save(ctx, bmp!!, "Aurora_lyrics_" + t.title.take(24)) }
                    if (uri != null) ShareCard.share(ctx, uri)
                    onDismiss()
                }
            }) { Text("Share") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Close") } },
    )
}
