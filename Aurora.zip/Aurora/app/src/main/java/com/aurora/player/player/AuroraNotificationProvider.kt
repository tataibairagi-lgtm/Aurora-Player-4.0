package com.aurora.player.player

import android.app.Notification
import android.content.Context
import android.os.Bundle
import android.widget.RemoteViews
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import com.aurora.player.R
import com.aurora.player.controller
import com.aurora.player.ui.dominantColor
import androidx.compose.ui.graphics.toArgb
import com.google.common.collect.ImmutableList

/**
 * Media notification in Musicolet's layout: cover on the left, title and artist, one row of buttons
 * (favourite, previous, play/pause, next, close) and the "Upcoming songs" list underneath.
 * Falls back to the standard notification if anything goes wrong.
 */
@UnstableApi
class AuroraNotificationProvider(private val ctx: Context) : MediaNotification.Provider {
    @Volatile private var broken = false
    @Volatile private var validated = false
    private val base = DefaultMediaNotificationProvider.Builder(ctx).build().also { it.setSmallIcon(R.drawable.ic_qs_tile) }

    private var lastSession: MediaSession? = null
    private var lastLayout: ImmutableList<CommandButton>? = null
    private var lastFactory: MediaNotification.ActionFactory? = null
    private var lastCallback: MediaNotification.Provider.Callback? = null

    /** Rebuilds and re-posts the notification, e.g. after a notification setting changed. */
    fun refresh() {
        try {
            val s = lastSession ?: return; val l = lastLayout ?: return
            val f = lastFactory ?: return; val cb = lastCallback ?: return
            cb.onNotificationChanged(createNotification(s, l, f, cb))
        } catch (_: Throwable) {}
    }

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback,
    ): MediaNotification {
        lastSession = mediaSession; lastLayout = customLayout; lastFactory = actionFactory; lastCallback = onNotificationChangedCallback
        val n = base.createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
        return try {
            val c = ctx.controller
            val d = c.store.data
            if (!d.customNotif) return n
            val t = c.current ?: return n
            val playing = mediaSession.player.playWhenReady

            // a small copy of the cover: full-size art inside RemoteViews can blow the binder limit on Android 10
            val artBmp: android.graphics.Bitmap? = try {
                (n.notification.getLargeIcon()?.loadDrawable(ctx) as? android.graphics.drawable.BitmapDrawable)?.bitmap?.let { src ->
                    val k = 256f / maxOf(src.width, src.height)
                    if (k >= 1f) src else android.graphics.Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true)
                }
            } catch (_: Throwable) { null }

            // background = the cover's own background colour, taken from its outer edge (no darkening)
            val bg: Int = try {
                val bmp = artBmp
                // a deep shade of the cover's colour (like Musicolet's dark card) with a bright accent on top
                val base = if (d.notifAdapt && bmp != null) edgeColor(bmp) else 0xFF3A3F55.toInt()
                val hh = FloatArray(3); androidx.core.graphics.ColorUtils.colorToHSL(base, hh)
                androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf(hh[0], hh[1].coerceAtMost(0.45f), 0.10f))
            } catch (_: Throwable) { 0xFF3A3F55.toInt() }
            val light = androidx.core.graphics.ColorUtils.calculateLuminance(bg) > 0.5
            val white = if (light) 0xFF111111.toInt() else android.graphics.Color.WHITE
            val soft = if (light) 0xCC111111.toInt() else 0xCCFFFFFF.toInt()

            // the buttons live inside the layout (like Musicolet): Media3's own action PendingIntents are reused for them
            val acts = n.notification.actions?.toList() ?: emptyList()
            val customTitles = customLayout.map { it.displayName.toString() }
            val custom = acts.filter { a -> a.title?.toString() in customTitles }
            val std = acts.filter { a -> a !in custom }
            val firstCustom = custom.firstOrNull()
            val ordered = ArrayList<Notification.Action>()
            if (std.size >= 3) {
                firstCustom?.let { ordered += it }
                ordered += std[0]; ordered += std[1]; ordered += std[2]
                ordered += custom.drop(if (firstCustom != null) 1 else 0)
            } else { ordered += std; ordered += custom }
            val slots = intArrayOf(R.id.b1, R.id.b2, R.id.b3, R.id.b4, R.id.b5, R.id.b6, R.id.b7)

            // accent colour: the cover's background hue, made light (or dark) enough to read
            val accent: Int = try {
                val hsl = FloatArray(3); androidx.core.graphics.ColorUtils.colorToHSL(bg, hsl)
                hsl[1] = maxOf(hsl[1], 0.55f); hsl[2] = if (light) 0.28f else 0.68f
                androidx.core.graphics.ColorUtils.HSLToColor(hsl)
            } catch (_: Throwable) { white }

            fun build(withUpcoming: Boolean): RemoteViews {
                val rv = RemoteViews(ctx.packageName, if (withUpcoming) R.layout.notif_musicolet else R.layout.notif_musicolet_small)
                rv.setTextColor(R.id.n_title, accent); rv.setTextColor(R.id.n_artist, soft)
                rv.setTextColor(R.id.up_title, accent); rv.setTextColor(R.id.up1, soft); rv.setTextColor(R.id.up2, soft)
                rv.setTextViewText(R.id.n_title, t.title)
                rv.setTextViewText(R.id.n_artist, if (withUpcoming) t.artist else listOf(t.artist, t.album).filter { it.isNotBlank() }.joinToString(" • "))
                if (d.notifArt && artBmp != null) { rv.setImageViewBitmap(R.id.art, artBmp); rv.setViewVisibility(R.id.art, android.view.View.VISIBLE) }
                else rv.setViewVisibility(R.id.art, android.view.View.GONE)

                for ((i, id) in slots.withIndex()) {
                    val a = ordered.getOrNull(i)
                    if (a == null) { rv.setViewVisibility(id, android.view.View.GONE); continue }
                    rv.setViewVisibility(id, android.view.View.VISIBLE)
                    try { a.getIcon()?.let { rv.setImageViewIcon(id, it) } } catch (_: Throwable) {}
                    rv.setInt(id, "setColorFilter", accent)
                    rv.setContentDescription(id, a.title)
                    a.actionIntent?.let { rv.setOnClickPendingIntent(id, it) }
                }

                val upcoming = if (withUpcoming && d.notifUpcoming) c.queue.drop(c.currentIndex + 1).take(2) else emptyList()
                rv.setViewVisibility(R.id.n_div, if (upcoming.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE)
                if (upcoming.isEmpty()) rv.setViewVisibility(R.id.up_box, android.view.View.GONE)
                else {
                    rv.setViewVisibility(R.id.up_box, android.view.View.VISIBLE)
                    rv.setTextViewText(R.id.up1, upcoming.getOrNull(0)?.let { it.title + " - " + it.artist } ?: "")
                    rv.setTextViewText(R.id.up2, upcoming.getOrNull(1)?.let { it.title + " - " + it.artist } ?: "")
                    rv.setViewVisibility(R.id.up2, if (upcoming.size > 1) android.view.View.VISIBLE else android.view.View.GONE)
                }
                return rv
            }

            if (broken) return n
            val small = build(false); val big = build(true)
            // the system inflates these in another process and kills the app if they are invalid, so prove they inflate here first
            if (!validated) {
                small.apply(ctx, android.widget.FrameLayout(ctx)); big.apply(ctx, android.widget.FrameLayout(ctx))
                validated = true
            }
            val b = Notification.Builder.recoverBuilder(ctx, n.notification)
            b.setColor(bg).setColorized(true)
            // the cover is drawn by the layout itself; a large icon would be stretched behind it on some phones
            b.setLargeIcon(null as android.graphics.drawable.Icon?)
            b.setCustomContentView(small)
            b.setCustomBigContentView(big)
            val token = mediaSession.sessionCompatToken.token as android.media.session.MediaSession.Token
            b.setStyle(Notification.DecoratedMediaCustomViewStyle().setMediaSession(token))
            val built = b.build()
            // the buttons are inside the layout now, so drop the system's own action row (no double buttons)
            if (ordered.isNotEmpty()) {
                built.actions = null
                // the standard notification remembered which actions to show when small; with no actions left that crashes the system UI
                try { built.extras.remove("android.compactActions") } catch (_: Throwable) {}
            }
            try { built.extras.remove("android.largeIcon"); built.extras.remove("android.largeIcon.big") } catch (_: Throwable) {}
            MediaNotification(n.notificationId, built)
        } catch (e: Throwable) {
            // never let the custom layout take the app down: remember the failure and use the standard notification from now on
            broken = true
            try { com.aurora.player.CrashLog.write(ctx, "Custom notification disabled", e) } catch (_: Throwable) {}
            n
        }
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        base.handleCustomCommand(session, action, extras)
}

/** Average colour of the outer ring of pixels: that is the cover's background colour. */
private fun edgeColor(src: android.graphics.Bitmap): Int {
    val sm = android.graphics.Bitmap.createScaledBitmap(src, 32, 32, true)
    var r = 0L; var g = 0L; var b = 0L; var cnt = 0
    val last = 31
    for (i in 0..last) for (pos in listOf(i to 0, i to last, 0 to i, last to i)) {
        val px = sm.getPixel(pos.first, pos.second)
        r += android.graphics.Color.red(px); g += android.graphics.Color.green(px); b += android.graphics.Color.blue(px); cnt++
    }
    return android.graphics.Color.rgb((r / cnt).toInt(), (g / cnt).toInt(), (b / cnt).toInt())
}
