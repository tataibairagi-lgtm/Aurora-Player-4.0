package com.aurora.player.data

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.aurora.player.controller
import com.aurora.player.ui.ArtLoader
import java.io.FileNotFoundException

/**
 * Serves covers from memory (nothing is saved) (content://<package>.art/<song id>) so the notification and the media session
 * never ask Android's media service for album art, which keeps its own copies in a folder on the phone.
 */
class ArtProvider : ContentProvider() {
    override fun onCreate() = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val ctx = context?.applicationContext ?: throw FileNotFoundException()
        val id = uri.lastPathSegment?.toLongOrNull() ?: throw FileNotFoundException()
        val t = ctx.controller.track(id) ?: throw FileNotFoundException()
        val bmp = kotlinx.coroutines.runBlocking { ArtLoader.load(ctx, t, 640) } ?: throw FileNotFoundException()
        // handed over through a pipe: no file is written anywhere
        val pipe = ParcelFileDescriptor.createPipe()
        Thread {
            try { ParcelFileDescriptor.AutoCloseOutputStream(pipe[1]).use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) } } catch (_: Throwable) {}
        }.start()
        return pipe[0]
    }

    override fun getType(uri: Uri) = "image/jpeg"
    override fun query(uri: Uri, p: Array<out String>?, s: String?, a: Array<out String>?, o: String?): Cursor? = null
    override fun insert(uri: Uri, v: ContentValues?): Uri? = null
    override fun delete(uri: Uri, s: String?, a: Array<out String>?) = 0
    override fun update(uri: Uri, v: ContentValues?, s: String?, a: Array<out String>?) = 0
}
