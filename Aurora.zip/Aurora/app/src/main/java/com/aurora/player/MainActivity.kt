package com.aurora.player

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.aurora.player.backup.BackupManager
import com.aurora.player.backup.BackupScheduler
import com.aurora.player.backup.LoadedBackup
import com.aurora.player.backup.RestoreOptions
import com.aurora.player.data.MediaScanner
import com.aurora.player.data.PlaylistIo
import com.aurora.player.data.TagData
import com.aurora.player.data.TagIo
import java.io.File
import com.aurora.player.data.Track
import com.aurora.player.lyrics.LyricsOverlayService
import com.aurora.player.player.PlaybackService
import com.aurora.player.ui.Actions
import com.aurora.player.ui.AuroraRoot
import com.aurora.player.ui.AuroraTheme
import com.aurora.player.ui.LocalActions
import com.aurora.player.widget.WidgetUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var pendingEdit: (() -> Unit)? = null
    private var startedOnce = false
    private var pendingRoute by mutableStateOf<String?>(null)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { loadLibrary() }

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                    )
                } catch (_: Exception) {
                }
                controller.store.update { it.copy(backupFolder = uri.toString()) }
                BackupScheduler.apply(this, controller.store.data)
                com.aurora.player.backup.CsvExport.schedule(this, controller.store.data.autoCsv)
                toast("Backups will be saved in that folder")
            }
        }

    private val backupPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { loadBackup(it, "Selected backup") } }

    private val backupSaver =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri -> uri?.let(::saveBackupTo) }

    private val plPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::importPlaylistFile) }

    private var exportTracks: List<Track> = emptyList()
    private val plExport =
        registerForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri -> uri?.let(::writeM3u) }

    private val bgPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                controller.store.update { it.copy(customBgUri = uri.toString(), nowBg = 5) }
            }
        }


    private val lrcPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::readLrc) }

    private val writeRequest =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) pendingEdit?.invoke()
            else if (pendingEdit != null) toast("Android did not get your permission to change the file, so nothing was saved")
            pendingEdit = null
        }

    private val overlayPermissionOnly =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    private val overlayPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) LyricsOverlayService.start(this)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        CrashLog.top = java.lang.ref.WeakReference(this)
        val startErr = (application as AuroraApp).startupError
        if (startErr != null) { super.onCreate(savedInstanceState); setContentView(buildCrashView(this, startErr)); return }
        try {
            onCreateImpl(savedInstanceState)
        } catch (t: Throwable) {
            CrashLog.write(this, "MainActivity start", t)
            try { super.onCreate(savedInstanceState) } catch (_: Throwable) {}
            setContentView(buildCrashView(this, "MainActivity start\n" + android.util.Log.getStackTraceString(t).take(12000)))
        }
    }

    /** Landscape hides the status and navigation bars (swipe from the edge to show them for a moment); portrait shows them. */
    private fun applyImmersive() {
        try {
            val land = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
            val ctl = androidx.core.view.WindowCompat.getInsetsController(window, window.decorView)
            if (land) {
                ctl.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                ctl.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            } else ctl.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
        } catch (_: Throwable) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        applyImmersive()
    }

    private fun onCreateImpl(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // draw into the camera-cutout area too, and hide the system bars in landscape: the app is full screen there
        if (Build.VERSION.SDK_INT >= 28) window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        applyImmersive()
        pendingRoute = intent?.getStringExtra("route")
        // the system refuses to start a service when the app was launched in the background; never let that crash the app
        try { startService(Intent(this, PlaybackService::class.java)) } catch (_: Throwable) {}
        requestPermissions()

        val actions = Actions(
            editTags = ::editTags,
            importLyrics = { lrcPicker.launch(arrayOf("*/*")) },
            importPlaylist = { plPicker.launch(arrayOf("*/*")) },
            exportPlaylist = { name, tracks ->
                exportTracks = tracks
                plExport.launch("$name.m3u")
            },
            toggleOverlay = ::toggleOverlay,
            rescan = ::loadLibrary,
            chooseBackupFolder = { folderPicker.launch(null) },
            backupNow = ::backupNow,
            openRestore = ::openRestore,
            browseBackup = { backupPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
            loadBackup = ::loadBackup,
            applyRestore = ::applyRestore,
            ensureOverlayPermission = ::ensureOverlayPermission,
            pickBackground = { bgPicker.launch(arrayOf("image/*")) },
            saveText = { name, mime, content ->
                pendingText = content
                if (mime.contains("csv")) csvSaver.launch(name) else m3u8Saver.launch(name)
            },
            saveArt = ::saveArtToGallery,
            deleteTracks = ::deleteTracks,
            copyTracks = { list -> pendingCopy = list; copyFolderPicker.launch(null) },
            batchTags = ::batchTags,
            tagsFromNames = ::tagsFromNames,
            embedArt = { list -> pendingArtTracks = list; artPicker.launch("image/*") },
            renameTrack = { t, n -> mediaUpdate(listOf(t), "Renamed") { x -> ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, n.trim().let { s -> if (s.contains('.')) s else s + "." + x.path.substringAfterLast('.', "mp3") }) } } },
            moveTracks = { list, rel -> mediaUpdate(list, "Moved") { _ -> ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, rel) } } },
            renameFolder = ::renameFolder,
            exportHistory = ::exportHistory,
            exportBookmarks = { pendingText = com.aurora.player.data.BookmarkIo.toText(controller.store.data.bookmarks, controller.library); csvSaver.launch("aurora-bookmarks.csv") },
            importBookmarks = { bmPicker.launch(arrayOf("*/*")) },
            pinShortcut = ::pinShortcut,
            saveLyrics = ::saveLyrics,
        )
        pinLocked = controller.store.data.pinHash.isNotEmpty()
        setContent {
            // saved themes can switch by time of day, so the hour is re-read every minute
            var hourNow by androidx.compose.runtime.remember { mutableStateOf(java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)) }
            androidx.compose.runtime.LaunchedEffect(Unit) {
                while (true) {
                    kotlinx.coroutines.delay(60_000)
                    hourNow = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
                }
            }
            val sd = controller.store.data
            val preset = com.aurora.player.data.scheduledTheme(sd, hourNow)
            AuroraTheme(preset?.mode ?: sd.themeMode, preset?.accent ?: sd.accentColor, sd.uiFont) {
                CompositionLocalProvider(LocalActions provides actions) {
                    if (pinLocked && sd.pinHash.isNotEmpty()) com.aurora.player.ui.PinScreen(controller) { pinLocked = false }
                    else com.aurora.player.ui.LoadingGate { AuroraRoot(controller, pendingRoute) { pendingRoute = null } }
                }
            }
        }
    }

    // PIN lock: ask again when the app comes back after being away for longer than the chosen time
    private var pinLocked by mutableStateOf(false)
    private var leftAt = 0L

    override fun onStop() {
        super.onStop()
        com.aurora.player.player.AppVisibility.visible = false
        leftAt = android.os.SystemClock.elapsedRealtime()
    }

    override fun onStart() {
        super.onStart()
        com.aurora.player.player.AppVisibility.visible = true
        if ((application as AuroraApp).startupError != null) return // only the error screen is showing
        val d = controller.store.data
        if (d.pinHash.isNotEmpty() && leftAt > 0 && android.os.SystemClock.elapsedRealtime() - leftAt >= d.pinRelockSec * 1000L) pinLocked = true
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingRoute = intent.getStringExtra("route")
    }

    private fun requestPermissions() {
        val needed = buildList {
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.READ_MEDIA_AUDIO)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) loadLibrary() else permLauncher.launch(missing.toTypedArray())
    }

    private fun hasAudioPermission(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadLibrary() {
        if (!hasAudioPermission()) { com.aurora.player.ui.AppSession.ready = true; return }
        lifecycleScope.launch {
            val d = controller.store.data
            val all = withContext(Dispatchers.IO) { MediaScanner.scan(this@MainActivity, d.minDurationSec) }
            controller.allFolders = (all.map { it.folder } + d.excludedFolders).distinct().sortedBy { it.lowercase() }
            var list = if (d.excludedFolders.isEmpty()) all else all.filter { it.folder !in d.excludedFolders }
            if (d.showFileNames) list = list.map { it.copy(title = it.path.substringAfterLast('/').substringBeforeLast('.')) }
            com.aurora.player.ui.ArtLoader.enabled = d.loadArt
            com.aurora.player.ui.ArtLoader.folderArt = d.folderArt
            controller.attachLibrary(list)
            com.aurora.player.ui.AppSession.ready = true
            if (d.autoPlayOnStart && !startedOnce && list.isNotEmpty()) { startedOnce = true; controller.play() }
            // not needed for the first frame: let the screen finish drawing before the widget/backup work starts
            kotlinx.coroutines.delay(2500)
            WidgetUpdater.update(this@MainActivity)
            maybeAutoBackup()
        }
    }

    // ---- backup / restore ----

    /** Catch-up for when the background job was delayed (battery saver etc.). */
    private fun maybeAutoBackup() {
        val d = controller.store.data
        if (!d.autoBackup || controller.library.isEmpty()) return
        if (System.currentTimeMillis() - d.lastBackupAt < d.autoBackupDays * 86_400_000L) return
        lifecycleScope.launch(Dispatchers.IO) { BackupManager.backupToFolder(this@MainActivity, controller) }
    }

    private fun backupNow() {
        if (controller.library.isEmpty()) { toast("No songs found yet"); return }
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val ok = withContext(Dispatchers.IO) { BackupManager.backupToFolder(this@MainActivity, controller) }
            ui.busy = false
            toast(if (ok) "Backup created successfully" else "Couldn't write the backup. Check the backup folder in Settings.")
        }
    }

    private fun saveBackupTo(uri: Uri) {
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val ok = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openOutputStream(uri)?.use { BackupManager.write(controller, it) }
                    controller.store.update { it.copy(lastBackupAt = System.currentTimeMillis()) }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            ui.busy = false
            toast(if (ok) "Backup created successfully" else "Couldn't write the backup file")
        }
    }

    private fun openRestore() {
        val ui = backupUi
        lifecycleScope.launch {
            ui.files = withContext(Dispatchers.IO) { BackupManager.listBackups(this@MainActivity, controller.store.data.backupFolder) }
            ui.picker = true
        }
    }

    private fun loadBackup(uri: Uri, name: String) {
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val loaded = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.use { BackupManager.read(it) }
                } catch (e: Exception) {
                    null
                }
            }
            ui.busy = false
            if (loaded == null) {
                toast("That isn't an Aurora or Musicolet backup.")
                return@launch
            }
            ui.previewName = name
            ui.preview = loaded
        }
    }

    private fun applyRestore(b: LoadedBackup, opts: RestoreOptions) {
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val r = try {
                BackupManager.restore(controller, b, opts)
            } catch (e: Exception) {
                null
            }
            ui.busy = false
            WidgetUpdater.update(this@MainActivity)
            if (r == null) toast("Restore failed")
            else toast(
                "Restore completed: ${r.favourites} favourites, ${r.playlists} playlists, ${r.lyrics} lyrics" +
                    if (r.skippedSongs > 0) " (${r.skippedSongs} songs not found on this phone)" else ""
            )
        }
    }

    private fun importPlaylistFile(uri: Uri) {
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
            }
            if (text.isNullOrBlank()) { toast("Couldn't read that file"); return@launch }
            val entries = PlaylistIo.parse(text)
            val ids = PlaylistIo.match(entries, controller.library)
            if (ids.isEmpty()) {
                toast("None of the ${entries.size} songs in that playlist were found on this phone")
                return@launch
            }
            var name = "Imported playlist"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0).substringBeforeLast('.').ifBlank { name }
            }
            controller.store.createPlaylist(name, ids)
            toast("Imported ${ids.size} of ${entries.size} songs into “$name”")
        }
    }

    private fun writeM3u(uri: Uri) {
        val text = PlaylistIo.toM3u(exportTracks)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            toast(if (ok) "Playlist exported" else "Couldn't write the file")
        }
    }

    private fun readLrc(uri: Uri) {
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
            }
            if (text.isNullOrBlank()) toast("Couldn't read that file") else controller.importLyrics(text)
        }
    }

    /** Returns true if the overlay permission is already granted; otherwise sends the user to grant it. */
    private fun ensureOverlayPermission(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        toast("Allow “Display over other apps” for Aurora, then turn this on again")
        overlayPermissionOnly.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return false
    }

    private fun toggleOverlay(on: Boolean) {
        if (!on) {
            LyricsOverlayService.stop(this)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow “Display over other apps” for Aurora, then come back")
            overlayPermission.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            LyricsOverlayService.start(this)
        }
    }

    /**
     * Writes the tags into the audio file itself (via a temporary copy, so a failure can't corrupt the song),
     * then updates the Android media library entry so the change shows everywhere.
     */
    private fun editTags(t: Track, d: TagData) {
        val uri = Uri.parse(t.uri)
        val work: () -> Unit = {
            lifecycleScope.launch {
                val tmp = File(cacheDir, "tag_edit." + t.path.substringAfterLast('.', "mp3"))
                val result: Any = withContext(Dispatchers.IO) {
                    try {
                        contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                        try { TagIo.write(tmp, d) } catch (e: Throwable) { return@withContext "unsupported:" + (e.message ?: e.javaClass.simpleName) }
                        if (tmp.length() <= 0L) return@withContext "unsupported:the tag writer produced an empty file"
                        try {
                            contentResolver.openOutputStream(uri, "wt")!!.use { o -> tmp.inputStream().use { i -> i.copyTo(o) } }
                            "file"
                        } catch (e: RecoverableSecurityException) {
                            e
                        } catch (e: Throwable) {
                            // Android refused the media-library route: write the real file instead (works with "All files access")
                            val real = File(t.path)
                            if (t.path.isNotEmpty() && real.canWrite()) {
                                tmp.inputStream().use { i -> real.outputStream().use { o -> i.copyTo(o) } }
                                "file"
                            } else "denied:" + (e.message ?: e.javaClass.simpleName)
                        }
                    } catch (e: RecoverableSecurityException) {
                        e
                    } catch (e: Throwable) {
                        "error:" + (e.message ?: e.javaClass.simpleName)
                    } finally {
                        tmp.delete()
                    }
                }
                if (result is RecoverableSecurityException) {
                    pendingEdit = { editTags(t, d) }
                    writeRequest.launch(IntentSenderRequest.Builder(result.userAction.actionIntent.intentSender).build())
                    return@launch
                }
                if (result is String && result.startsWith("denied")) {
                    // Musicolet-style fix: give Aurora "All files access" so it can write the file itself
                    if (Build.VERSION.SDK_INT >= 30 && !android.os.Environment.isExternalStorageManager()) {
                        toast("Android blocked saving. Allow “All files access” for Aurora, then save the tags again")
                        try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) } catch (_: Throwable) {}
                    } else toast("Android would not let Aurora change this file (${result.substringAfter(':')})")
                    return@launch
                }
                if (result is String && result.startsWith("error")) { toast("Could not save the tags: ${result.substringAfter(':')}"); return@launch }
                // keep the media library in step (title/artist/album/year/track)
                withContext(Dispatchers.IO) {
                    try {
                        val v = ContentValues().apply {
                            put(MediaStore.Audio.Media.TITLE, d.title)
                            put(MediaStore.Audio.Media.ARTIST, d.artist)
                            put(MediaStore.Audio.Media.ALBUM, d.album)
                            d.year.toIntOrNull()?.let { put(MediaStore.Audio.Media.YEAR, it) }
                            d.track.substringBefore('/').toIntOrNull()?.let { put(MediaStore.Audio.Media.TRACK, it) }
                        }
                        contentResolver.update(uri, v, null, null)
                        if (t.path.isNotEmpty()) MediaScannerConnection.scanFile(this@MainActivity, arrayOf(t.path), null, null)
                    } catch (_: Exception) {
                    }
                }
                toast(if (result == "file") "Tags saved in the file" else "Couldn't write tags into this file type (${(result as? String)?.substringAfter(':') ?: "unsupported"}). Saved in the library only.")
                loadLibrary()
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            pendingEdit = work
            val pi = MediaStore.createWriteRequest(contentResolver, listOf(uri))
            writeRequest.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            work()
        }
    }



    /** Song info > Edit lyrics: writes into the song's tag and/or the .lrc file next to it, then reloads the lyrics. */
    private fun saveLyrics(t: Track, text: String, toTag: Boolean, toLrc: Boolean) {
        val c = controller
        fun refresh() { if (c.current?.id == t.id) c.reloadLyrics() }
        lifecycleScope.launch {
            if (toLrc) {
                val ok = withContext(Dispatchers.IO) { c.lyricsRepo.writeSidecar(t, text) }
                if (ok) toast(if (text.isBlank()) ".lrc file removed" else ".lrc file saved next to the song")
                else {
                    // Android won't let apps write plain files into other folders: use a music folder the person picked once
                    val viaTree = withContext(Dispatchers.IO) { com.aurora.player.data.LrcTree.write(this@MainActivity, t, text) }
                    // keep a copy inside Aurora too: without "All files access" Aurora can't read the file back
                    if (viaTree) { if (text.isNotBlank()) c.lyricsRepo.save(t, text) else c.lyricsRepo.delete(t) }
                    if (viaTree) toast(if (text.isBlank()) ".lrc file removed" else ".lrc file saved next to the song")
                    else {
                        if (text.isNotBlank()) c.lyricsRepo.save(t, text) else c.lyricsRepo.delete(t)
                        toast("Saved inside Aurora. To save the .lrc next to the song, choose your Music folder once.")
                        pendingLrc = { saveLyrics(t, text, false, true) }
                        try { lrcTreePicker.launch(null) } catch (_: Throwable) {}
                    }
                }
            }
            if (toTag) writeFiles(listOf(t), "Lyrics saved in the file", { refresh() }) { f -> TagIo.writeLyrics(f, text) }
            else refresh()
        }
    }

    // ---- batch tags, cover art, rename / move ----
    private var pendingArtTracks: List<Track> = emptyList()
    private val artPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@registerForActivityResult
        val mime = contentResolver.getType(uri) ?: "image/jpeg"
        lifecycleScope.launch {
            val bytes = withContext(Dispatchers.IO) { try { contentResolver.openInputStream(uri)?.use { it.readBytes() } } catch (_: Exception) { null } }
            if (bytes == null || bytes.isEmpty()) { toast("Couldn't read that image"); return@launch }
            writeFiles(pendingArtTracks, "Cover art embedded") { f -> TagIo.embedArt(f, bytes, mime) }
        }
    }
    private val bmPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { try { contentResolver.openInputStream(uri)?.bufferedReader()?.readText() } catch (_: Exception) { null } }
            val list = text?.let { com.aurora.player.data.BookmarkIo.fromText(it, controller.library) }.orEmpty()
            if (list.isEmpty()) { toast("No bookmarks found in that file"); return@launch }
            controller.store.update { p -> p.copy(bookmarks = p.bookmarks + list.filter { b -> p.bookmarks.none { it.id == b.id } }) }
            toast("Imported ${list.size} bookmarks")
        }
    }

    /** Copies each song to a temp file, runs [op] on it and writes it back. One permission prompt covers all songs. */
    private fun writeFiles(tracks: List<Track>, doneMsg: String, after: (() -> Unit)? = null, op: (File) -> Unit) {
        if (tracks.isEmpty()) return
        val work: () -> Unit = {
            lifecycleScope.launch {
                var ok = 0; var fail = 0
                var need: RecoverableSecurityException? = null
                var failAt = -1
                withContext(Dispatchers.IO) {
                    for ((idx, t) in tracks.withIndex()) {
                        try {
                            val uri = Uri.parse(t.uri)
                            val tmp = File(cacheDir, "tag_edit." + t.path.substringAfterLast('.', "mp3"))
                            contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                            writingTrack = t
                            op(tmp)
                            if (tmp.length() <= 0L) throw IllegalStateException("empty")
                            try {
                                contentResolver.openOutputStream(uri, "wt")!!.use { o -> tmp.inputStream().use { i -> i.copyTo(o) } }
                            } catch (e: RecoverableSecurityException) { throw e }
                            catch (e: Throwable) {
                                // media-library route refused: write the real file (needs "All files access")
                                val real = File(t.path)
                                if (t.path.isNotEmpty() && real.canWrite()) tmp.inputStream().use { i -> real.outputStream().use { o -> i.copyTo(o) } } else throw e
                            }
                            tmp.delete(); ok++
                        } catch (e: RecoverableSecurityException) {
                            need = e; failAt = idx; break
                        } catch (e: Throwable) {
                            fail++
                        }
                    }
                }
                val ask = need
                if (ask != null) {
                    // Android 10: one permission prompt per file, then carry on from this song
                    val rest = tracks.drop(failAt.coerceAtLeast(0))
                    pendingEdit = { writeFiles(rest, doneMsg, after, op) }
                    writeRequest.launch(IntentSenderRequest.Builder(ask.userAction.actionIntent.intentSender).build())
                    return@launch
                }
                withContext(Dispatchers.IO) {
                    try { MediaScannerConnection.scanFile(this@MainActivity, tracks.map { it.path }.filter { it.isNotEmpty() }.toTypedArray(), null, null) } catch (_: Exception) {}
                }
                toast(if (fail == 0) "$doneMsg ($ok)" else "$doneMsg: $ok done, $fail couldn't be changed")
                after?.invoke()
                loadLibrary()
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            pendingEdit = work
            val pi = MediaStore.createWriteRequest(contentResolver, tracks.map { Uri.parse(it.uri) })
            writeRequest.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else work()
    }

    private var writingTrack: Track? = null

    private var pendingLrc: (() -> Unit)? = null
    private val lrcTreePicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        val retry = pendingLrc; pendingLrc = null
        if (uri == null) return@registerForActivityResult
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Throwable) {}
        com.aurora.player.data.LrcTree.add(this, uri)
        retry?.invoke()
    }

    /** Reads artist, title and so on out of each song's file name and writes them into the tags. */
    private fun tagsFromNames(tracks: List<Track>, pattern: String) {
        val fits = tracks.filter { com.aurora.player.data.NameTags.parse(it.path.ifEmpty { it.title }, pattern) != null }
        if (fits.isEmpty()) { toast("No file name fits that pattern"); return }
        writeFiles(fits, "Tags saved") { f ->
            val t = writingTrack ?: return@writeFiles
            com.aurora.player.data.NameTags.parse(t.path.ifEmpty { t.title }, pattern)?.let { TagIo.write(f, it, onlyFilled = true) }
        }
        lifecycleScope.launch(Dispatchers.IO) {
            for (t in fits) try {
                val d = com.aurora.player.data.NameTags.parse(t.path.ifEmpty { t.title }, pattern) ?: continue
                val v = ContentValues().apply {
                    if (d.title.isNotBlank()) put(MediaStore.Audio.Media.TITLE, d.title)
                    if (d.artist.isNotBlank()) put(MediaStore.Audio.Media.ARTIST, d.artist)
                    if (d.album.isNotBlank()) put(MediaStore.Audio.Media.ALBUM, d.album)
                    d.year.toIntOrNull()?.let { put(MediaStore.Audio.Media.YEAR, it) }
                    d.track.toIntOrNull()?.let { put(MediaStore.Audio.Media.TRACK, it) }
                }
                if (v.size() > 0) contentResolver.update(Uri.parse(t.uri), v, null, null)
            } catch (_: Exception) {}
        }
    }

    private fun batchTags(tracks: List<Track>, d: TagData) {
        writeFiles(tracks, "Tags saved") { f -> TagIo.write(f, d, onlyFilled = true) }
        lifecycleScope.launch(Dispatchers.IO) {
            for (t in tracks) try {
                val v = ContentValues().apply {
                    if (d.title.isNotBlank()) put(MediaStore.Audio.Media.TITLE, d.title)
                    if (d.artist.isNotBlank()) put(MediaStore.Audio.Media.ARTIST, d.artist)
                    if (d.album.isNotBlank()) put(MediaStore.Audio.Media.ALBUM, d.album)
                    d.year.toIntOrNull()?.let { put(MediaStore.Audio.Media.YEAR, it) }
                }
                if (v.size() > 0) contentResolver.update(Uri.parse(t.uri), v, null, null)
            } catch (_: Exception) {}
        }
    }

    /** Applies MediaStore column changes (rename, move) to songs, asking once for write access. */
    private fun mediaUpdate(tracks: List<Track>, doneMsg: String, values: (Track) -> ContentValues) {
        if (tracks.isEmpty()) return
        val work: () -> Unit = {
            lifecycleScope.launch {
                var ok = 0; var fail = 0
                var need: RecoverableSecurityException? = null
                var failAt = -1
                withContext(Dispatchers.IO) {
                    for ((idx, t) in tracks.withIndex()) try {
                        contentResolver.update(Uri.parse(t.uri), values(t), null, null); ok++
                    } catch (e: RecoverableSecurityException) {
                        need = e; failAt = idx; break
                    } catch (e: Throwable) { fail++ }
                }
                val ask = need
                if (ask != null) {
                    val rest = tracks.drop(failAt.coerceAtLeast(0))
                    pendingEdit = { mediaUpdate(rest, doneMsg, values) }
                    writeRequest.launch(IntentSenderRequest.Builder(ask.userAction.actionIntent.intentSender).build())
                    return@launch
                }
                toast(if (fail == 0) "$doneMsg ($ok)" else "$doneMsg: $ok done, $fail failed (only internal storage can be moved)")
                delay(600)
                loadLibrary()
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            pendingEdit = work
            val pi = MediaStore.createWriteRequest(contentResolver, tracks.map { Uri.parse(it.uri) })
            writeRequest.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else work()
    }

    private fun renameFolder(tracks: List<Track>, oldDir: String, newDir: String) {
        val root = "/storage/emulated/0/"
        fun rel(dir: String) = dir.removePrefix(root).trim('/') + "/"
        val o = oldDir.trimEnd('/'); val n = newDir.trimEnd('/')
        mediaUpdate(tracks, "Folder renamed") { t ->
            val parent = t.path.substringBeforeLast('/')
            ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, rel(n + parent.removePrefix(o))) }
        }
    }

    private fun exportHistory() {
        lifecycleScope.launch {
            val csv = withContext(Dispatchers.IO) {
                val byId = controller.library.associateBy { it.id }
                val fmt = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
                fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
                val sb = StringBuilder("Played at,Title,Artist,Album,Duration (s)\n")
                for (e in controller.playLog.events) {
                    val t = byId[e.id] ?: continue
                    sb.append(fmt.format(java.util.Date(e.at))).append(',').append(q(t.title)).append(',').append(q(t.artist)).append(',').append(q(t.album)).append(',').append(t.durationMs / 1000).append('\n')
                }
                sb.toString()
            }
            pendingText = csv
            csvSaver.launch("aurora-listening-history.csv")
        }
    }

    /** Glyph and colours picked from the words in a playlist's name ("Gym" gets a dumbbell, "Night drive" a moon...). */
    private fun nameTheme(label: String): Triple<String, Float, Float> {
        val n = label.lowercase()
        fun has(vararg w: String) = w.any { it in n }
        return when {
            has("gym", "workout", "fitness", "cardio", "pump", "training", "run") -> Triple("dumbbell", 18f, 355f)
            has("sleep", "night", "chill", "calm", "relax", "lofi", "lo-fi", "dream", "late") -> Triple("moon", 245f, 285f)
            has("study", "focus", "work", "read", "exam", "concentr") -> Triple("book", 200f, 170f)
            has("love", "romance", "romantic", "heart", "crush", "fav", "wedding", "valentine") -> Triple("heart", 340f, 5f)
            has("sad", "cry", "break", "rain", "alone", "lonely", "miss", "blue") -> Triple("drop", 215f, 245f)
            has("morning", "sun", "summer", "happy", "beach", "holiday", "good") -> Triple("sun", 38f, 12f)
            has("party", "dance", "club", "edm", "dj", "remix", "house", "bass", "hype", "energy") -> Triple("bolt", 305f, 255f)
            has("rock", "metal", "punk", "grunge", "guitar", "hard") -> Triple("bolt", 0f, 330f)
            has("top", "best", "hit", "gold", "classic", "legend") -> Triple("star", 48f, 25f)
            has("drive", "road", "car", "travel", "trip", "journey", "walk") -> Triple("headphones", 160f, 195f)
            else -> Triple("note", ((label.lowercase().hashCode() and 0x7fffffff) % 360).toFloat(), 0f)
        }
    }

    /**
     * A home-screen icon for a pinned list: the covers of its songs as a mosaic (or a gradient from the name), a dark fade, and a glass
     * badge with a glyph for what it is: a record for an album, a person for an artist, a folder, or for playlists a picture taken from
     * the words in the name.
     */
    private fun shortcutBitmap(label: String, kind: String, covers: List<android.graphics.Bitmap>): android.graphics.Bitmap {
        val size = 432
        val f = size.toFloat()
        val bmp = android.graphics.Bitmap.createBitmap(size, size, android.graphics.Bitmap.Config.ARGB_8888)
        val cv = android.graphics.Canvas(bmp)
        val (glyph, hueA, hueB) = nameTheme(label)
        val hsvA = floatArrayOf(hueA, 0.68f, 0.95f)
        val hsvB = floatArrayOf(if (hueB == 0f) (hueA + 40f) % 360f else hueB, 0.80f, 0.55f)
        val c1 = android.graphics.Color.HSVToColor(hsvA)
        val c2 = android.graphics.Color.HSVToColor(hsvB)
        val fill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
        fill.shader = android.graphics.LinearGradient(0f, 0f, f, f, c1, c2, android.graphics.Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, f, f, fill)
        fill.shader = null
        // soft light blobs behind the glyph
        val blob = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        blob.color = android.graphics.Color.argb(38, 255, 255, 255)
        cv.drawCircle(f * 0.18f, f * 0.16f, f * 0.34f, blob)
        cv.drawCircle(f * 0.9f, f * 0.95f, f * 0.30f, blob)
        fun tile(b: android.graphics.Bitmap, l: Float, t: Float, r: Float, bt: Float) {
            val side = minOf(b.width, b.height)
            val src = android.graphics.Rect((b.width - side) / 2, (b.height - side) / 2, (b.width + side) / 2, (b.height + side) / 2)
            cv.drawBitmap(b, src, android.graphics.RectF(l, t, r, bt), fill)
        }
        if (covers.isNotEmpty()) {
            // a blurred, darkened cover as the backdrop with a fan of cover cards on top: reads as "a playlist of these songs"
            tile(covers[0], -f * 0.1f, -f * 0.1f, f * 1.1f, f * 1.1f)
            val dim = android.graphics.Paint()
            dim.shader = android.graphics.LinearGradient(0f, 0f, 0f, f, android.graphics.Color.argb(150, 0, 0, 0),
                android.graphics.Color.argb(225, android.graphics.Color.red(c2) / 4, android.graphics.Color.green(c2) / 4, android.graphics.Color.blue(c2) / 4), android.graphics.Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, f, f, dim)
            val side = f * 0.52f
            val rad = side * 0.16f
            val n = minOf(covers.size, 3)
            // back to front: left card, right card, then the main one
            val spec = listOf(Triple(-14f, -f * 0.13f, f * 0.03f), Triple(14f, f * 0.13f, f * 0.03f), Triple(0f, 0f, -f * 0.01f))
            val order = if (n >= 3) listOf(0, 1, 2) else if (n == 2) listOf(0, 2) else listOf(2)
            for ((k, si) in order.withIndex()) {
                val (ang, dx, dy) = spec[si]
                val bm = covers[if (n >= 3) k else if (n == 2) k else 0]
                cv.save()
                cv.translate(f / 2 + dx, f / 2 + dy)
                cv.rotate(ang)
                val rect = android.graphics.RectF(-side / 2, -side / 2, side / 2, side / 2)
                val sh = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = android.graphics.Color.BLACK; setShadowLayer(26f, 0f, 10f, android.graphics.Color.argb(150, 0, 0, 0))
                }
                cv.drawRoundRect(rect, rad, rad, sh)
                cv.save()
                cv.clipPath(android.graphics.Path().apply { addRoundRect(rect, rad, rad, android.graphics.Path.Direction.CW) })
                val sd = minOf(bm.width, bm.height)
                cv.drawBitmap(bm, android.graphics.Rect((bm.width - sd) / 2, (bm.height - sd) / 2, (bm.width + sd) / 2, (bm.height + sd) / 2), rect, fill)
                cv.restore()
                val edge = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    style = android.graphics.Paint.Style.STROKE; strokeWidth = 4f; color = android.graphics.Color.argb(220, 255, 255, 255)
                }
                cv.drawRoundRect(rect, rad, rad, edge)
                if (si == 2) {
                    // soft gloss across the top of the main card
                    val gl = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
                    gl.shader = android.graphics.LinearGradient(0f, rect.top, 0f, rect.centerY(), android.graphics.Color.argb(70, 255, 255, 255), android.graphics.Color.TRANSPARENT, android.graphics.Shader.TileMode.CLAMP)
                    cv.save()
                    cv.clipPath(android.graphics.Path().apply { addRoundRect(rect, rad, rad, android.graphics.Path.Direction.CW) })
                    cv.drawRect(rect, gl)
                    cv.restore()
                }
                cv.restore()
            }
            return bmp
        }
        val gap = 6f
        when {
            covers.size == 1 -> tile(covers[0], 0f, 0f, f, f)
            covers.size == 2 -> { tile(covers[0], 0f, 0f, f / 2 - gap / 2, f); tile(covers[1], f / 2 + gap / 2, 0f, f, f) }
            covers.size >= 3 -> {
                tile(covers[0], 0f, 0f, f / 2 - gap / 2, f / 2 - gap / 2); tile(covers[1], f / 2 + gap / 2, 0f, f, f / 2 - gap / 2)
                tile(covers[2], 0f, f / 2 + gap / 2, f / 2 - gap / 2, f); tile(covers[3 % covers.size], f / 2 + gap / 2, f / 2 + gap / 2, f, f)
            }
        }
        if (covers.isNotEmpty()) {
            // tint the covers with the name's colour and darken them so the badge reads
            val scrim = android.graphics.Paint()
            scrim.shader = android.graphics.RadialGradient(f / 2, f / 2, f * 0.66f,
                intArrayOf(android.graphics.Color.argb(120, 0, 0, 0), android.graphics.Color.argb(185, android.graphics.Color.red(c2) / 3, android.graphics.Color.green(c2) / 3, android.graphics.Color.blue(c2) / 3)),
                null, android.graphics.Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, f, f, scrim)
        }
        val cx = f / 2; val cy = f / 2; val r = f * 0.235f
        // glass badge: a frosted disc with a bright rim
        val disc = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        disc.color = android.graphics.Color.argb(if (covers.isEmpty()) 70 else 95, 255, 255, 255)
        disc.setShadowLayer(22f, 0f, 8f, android.graphics.Color.argb(110, 0, 0, 0))
        cv.drawCircle(cx, cy, r, disc); disc.clearShadowLayer()
        val rim = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE; strokeWidth = 5f; color = android.graphics.Color.argb(200, 255, 255, 255)
        }
        cv.drawCircle(cx, cy, r, rim)
        val ink = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE; style = android.graphics.Paint.Style.FILL
            strokeCap = android.graphics.Paint.Cap.ROUND; strokeJoin = android.graphics.Paint.Join.ROUND
            setShadowLayer(8f, 0f, 3f, android.graphics.Color.argb(90, 0, 0, 0))
        }
        val line = android.graphics.Paint(ink).apply { style = android.graphics.Paint.Style.STROKE }
        val u = r / 62f
        fun rr(l: Float, t: Float, rt: Float, b: Float, rad: Float) = cv.drawRoundRect(cx + l * u, cy + t * u, cx + rt * u, cy + b * u, rad * u, rad * u, ink)
        val which = when (kind) { "album" -> "record"; "artist" -> "person"; "folder" -> "folder"; else -> glyph }
        when (which) {
            "record" -> {
                line.strokeWidth = 9f * u; cv.drawCircle(cx, cy, 40f * u, line)
                cv.drawCircle(cx, cy, 15f * u, ink)
            }
            "person" -> {
                cv.drawCircle(cx, cy - 16f * u, 17f * u, ink)
                cv.drawArc(android.graphics.RectF(cx - 32f * u, cy + 6f * u, cx + 32f * u, cy + 62f * u), 180f, 180f, true, ink)
            }
            "folder" -> {
                val pth = android.graphics.Path().apply {
                    moveTo(cx - 38f * u, cy - 26f * u); lineTo(cx - 10f * u, cy - 26f * u); lineTo(cx + 2f * u, cy - 12f * u); lineTo(cx + 38f * u, cy - 12f * u)
                    lineTo(cx + 38f * u, cy + 32f * u); lineTo(cx - 38f * u, cy + 32f * u); close()
                }
                cv.drawPath(pth, ink)
            }
            "heart" -> {
                val pth = android.graphics.Path().apply {
                    moveTo(cx, cy + 36f * u)
                    cubicTo(cx - 52f * u, cy + 2f * u, cx - 44f * u, cy - 38f * u, cx - 18f * u, cy - 32f * u)
                    cubicTo(cx - 8f * u, cy - 30f * u, cx - 2f * u, cy - 23f * u, cx, cy - 17f * u)
                    cubicTo(cx + 2f * u, cy - 23f * u, cx + 8f * u, cy - 30f * u, cx + 18f * u, cy - 32f * u)
                    cubicTo(cx + 44f * u, cy - 38f * u, cx + 52f * u, cy + 2f * u, cx, cy + 36f * u); close()
                }
                cv.drawPath(pth, ink)
            }
            "moon" -> {
                val a = android.graphics.Path().apply { addCircle(cx, cy, 38f * u, android.graphics.Path.Direction.CW) }
                val b = android.graphics.Path().apply { addCircle(cx + 20f * u, cy - 12f * u, 33f * u, android.graphics.Path.Direction.CW) }
                a.op(b, android.graphics.Path.Op.DIFFERENCE)
                cv.drawPath(a, ink)
                cv.drawCircle(cx + 22f * u, cy + 20f * u, 4f * u, ink)
            }
            "sun" -> {
                cv.drawCircle(cx, cy, 19f * u, ink)
                line.strokeWidth = 7f * u
                for (i in 0 until 8) {
                    val ang = Math.toRadians(i * 45.0)
                    cv.drawLine(cx + (28f * u * Math.cos(ang)).toFloat(), cy + (28f * u * Math.sin(ang)).toFloat(), cx + (42f * u * Math.cos(ang)).toFloat(), cy + (42f * u * Math.sin(ang)).toFloat(), line)
                }
            }
            "dumbbell" -> {
                rr(-14f, -5f, 14f, 5f, 3f)
                rr(-46f, -17f, -36f, 17f, 4f); rr(-37f, -27f, -22f, 27f, 5f)
                rr(36f, -17f, 46f, 17f, 4f); rr(22f, -27f, 37f, 27f, 5f)
                rr(-24f, -5f, -14f, 5f, 2f); rr(14f, -5f, 24f, 5f, 2f)
            }
            "bolt" -> {
                val pth = android.graphics.Path().apply {
                    moveTo(cx + 10f * u, cy - 46f * u); lineTo(cx - 24f * u, cy + 6f * u); lineTo(cx - 3f * u, cy + 6f * u)
                    lineTo(cx - 12f * u, cy + 46f * u); lineTo(cx + 26f * u, cy - 10f * u); lineTo(cx + 3f * u, cy - 10f * u); close()
                }
                cv.drawPath(pth, ink)
            }
            "drop" -> {
                val pth = android.graphics.Path().apply {
                    moveTo(cx, cy - 44f * u)
                    cubicTo(cx + 26f * u, cy - 10f * u, cx + 36f * u, cy + 6f * u, cx + 36f * u, cy + 20f * u)
                    cubicTo(cx + 36f * u, cy + 38f * u, cx + 20f * u, cy + 48f * u, cx, cy + 48f * u)
                    cubicTo(cx - 20f * u, cy + 48f * u, cx - 36f * u, cy + 38f * u, cx - 36f * u, cy + 20f * u)
                    cubicTo(cx - 36f * u, cy + 6f * u, cx - 26f * u, cy - 10f * u, cx, cy - 44f * u); close()
                }
                cv.drawPath(pth, ink)
            }
            "book" -> {
                rr(-46f, -30f, -3f, 32f, 7f); rr(3f, -30f, 46f, 32f, 7f)
            }
            "star" -> {
                val pth = android.graphics.Path()
                for (i in 0 until 10) {
                    val rad = if (i % 2 == 0) 46f * u else 20f * u
                    val ang = Math.toRadians(-90.0 + i * 36.0)
                    val x = cx + (rad * Math.cos(ang)).toFloat(); val y = cy + (rad * Math.sin(ang)).toFloat() + 3f * u
                    if (i == 0) pth.moveTo(x, y) else pth.lineTo(x, y)
                }
                pth.close(); cv.drawPath(pth, ink)
            }
            "headphones" -> {
                line.strokeWidth = 9f * u
                cv.drawArc(android.graphics.RectF(cx - 36f * u, cy - 42f * u, cx + 36f * u, cy + 30f * u), 180f, 180f, false, line)
                rr(-46f, -4f, -26f, 34f, 9f); rr(26f, -4f, 46f, 34f, 9f)
            }
            else -> { // a music note
                cv.drawCircle(cx - 14f * u, cy + 28f * u, 15f * u, ink)
                rr(-1f, -40f, 11f, 28f, 3f)
                val flag = android.graphics.Path().apply {
                    moveTo(cx + 9f * u, cy - 40f * u); cubicTo(cx + 30f * u, cy - 36f * u, cx + 38f * u, cy - 22f * u, cx + 34f * u, cy - 6f * u)
                    cubicTo(cx + 30f * u, cy - 16f * u, cx + 22f * u, cy - 20f * u, cx + 9f * u, cy - 18f * u); close()
                }
                cv.drawPath(flag, ink)
            }
        }
        return bmp
    }

    private fun pinShortcut(id: String, label: String, route: String, songs: List<Track>) {
        try {
            if (!androidx.core.content.pm.ShortcutManagerCompat.isRequestPinShortcutSupported(this)) { toast("Your launcher doesn't support pinned shortcuts"); return }
            val kind = route.split("|").getOrNull(1).orEmpty()
            lifecycleScope.launch {
                val covers = ArrayList<android.graphics.Bitmap>()
                try {
                    // up to four different covers
                    for (t in songs.distinctBy { if (it.albumId > 0) it.albumId else -it.id }.take(8)) {
                        if (covers.size >= 4) break
                        com.aurora.player.ui.ArtLoader.load(this@MainActivity, t, 320)?.let { covers += it }
                    }
                } catch (_: Throwable) {}
                try {
                    val intent = Intent(this@MainActivity, MainActivity::class.java).setAction(Intent.ACTION_VIEW).putExtra("route", route)
                    val sc = androidx.core.content.pm.ShortcutInfoCompat.Builder(this@MainActivity, id)
                        .setShortLabel(label.take(20)).setLongLabel(label)
                        .setIcon(androidx.core.graphics.drawable.IconCompat.createWithAdaptiveBitmap(shortcutBitmap(label, kind, covers)))
                        .setIntent(intent).build()
                    androidx.core.content.pm.ShortcutManagerCompat.requestPinShortcut(this@MainActivity, sc, null)
                } catch (_: Throwable) { toast("Couldn't add the shortcut") }
            }
        } catch (_: Throwable) { toast("Couldn't add the shortcut") }
    }

    // ---- save text (queue .csv / .m3u8) ----
    private var pendingText: String? = null
    private val csvSaver = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri -> writeText(uri) }
    private val m3u8Saver = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri -> writeText(uri) }

    private fun writeText(uri: Uri?) {
        val text = pendingText
        pendingText = null
        if (uri == null || text == null) return
        try {
            contentResolver.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            toast("Saved")
        } catch (e: Exception) {
            toast("Couldn't save the file")
        }
    }

    // ---- copy songs to a folder ----
    private var pendingCopy: List<Track> = emptyList()
    private val copyFolderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        val list = pendingCopy
        pendingCopy = emptyList()
        if (uri == null || list.isEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            val n = withContext(Dispatchers.IO) {
                val dir = androidx.documentfile.provider.DocumentFile.fromTreeUri(this@MainActivity, uri) ?: return@withContext 0
                var done = 0
                for (t in list) {
                    try {
                        val src = Uri.parse(t.uri)
                        val mime = contentResolver.getType(src) ?: "audio/mpeg"
                        val base = t.path.substringAfterLast('/').substringBeforeLast('.').ifEmpty { t.title }
                        val out = dir.createFile(mime, base) ?: continue
                        contentResolver.openInputStream(src)!!.use { i ->
                            contentResolver.openOutputStream(out.uri)!!.use { o -> i.copyTo(o) }
                        }
                        done++
                    } catch (_: Exception) {
                    }
                }
                done
            }
            toast("Copied $n of ${list.size} songs")
        }
    }

    // ---- delete songs from the device ----
    private var pendingDelete: List<Uri> = emptyList()
    private val deleteRequest = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (Build.VERSION.SDK_INT >= 30) {
            if (r.resultCode == RESULT_OK) { toast("Deleted"); loadLibrary() }
        } else if (r.resultCode == RESULT_OK) {
            deleteNext()
        }
    }

    private fun deleteTracks(list: List<Track>) {
        val uris = list.map { Uri.parse(it.uri) }
        if (uris.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 30) {
            val pi = MediaStore.createDeleteRequest(contentResolver, uris)
            deleteRequest.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            pendingDelete = uris
            deleteNext()
        }
    }

    /** Android 10: delete one by one; Android asks for permission per file when needed. */
    private fun deleteNext() {
        while (pendingDelete.isNotEmpty()) {
            val u = pendingDelete.first()
            try {
                contentResolver.delete(u, null, null)
                pendingDelete = pendingDelete.drop(1)
            } catch (e: RecoverableSecurityException) {
                deleteRequest.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                return
            } catch (e: Exception) {
                pendingDelete = pendingDelete.drop(1)
            }
        }
        toast("Deleted")
        loadLibrary()
    }

    // ---- save album art to the gallery ----
    private fun saveArtToGallery(t: Track) {
        lifecycleScope.launch {
            val bmp = com.aurora.player.ui.ArtLoader.load(this@MainActivity, t)
            if (bmp == null) { toast("This song has no album art"); return@launch }
            val ok = withContext(Dispatchers.IO) {
                try {
                    val v = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "${t.album.ifBlank { t.title }}.jpg".replace('/', '_'))
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Aurora")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v)!!
                    contentResolver.openOutputStream(uri)!!.use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, it) }
                    v.clear(); v.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, v, null, null)
                    true
                } catch (e: Exception) {
                    false
                }
            }
            toast(if (ok) "Album art saved to Pictures/Aurora" else "Couldn't save the picture")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
