package com.aurora.player

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.aurora.player.player.PlaybackService

/**
 * Aurora's tile for the Quick Settings panel (swipe down, pencil icon, drag "Aurora" in).
 * Tap: play / pause. It lights up while music plays and shows the song's name. If nothing is loaded yet it opens Aurora.
 */
class QuickTileService : TileService() {
    override fun onStartListening() { refresh() }

    override fun onClick() {
        val c = try { application.controller } catch (_: Throwable) { null }
        if (c == null || c.current == null) { openApp(); return }
        try { startService(Intent(this, PlaybackService::class.java)) } catch (_: Throwable) {}
        c.togglePlay()
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        val c = try { application.controller } catch (_: Throwable) { null }
        val playing = c?.isPlaying == true
        t.state = if (playing) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = "Aurora"
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = c?.current?.title ?: "Tap to open"
        t.updateTile()
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }

    companion object {
        /** Asks Android to refresh the tile (called when playback starts or stops). */
        fun update(ctx: android.content.Context) {
            try { requestListeningState(ctx, ComponentName(ctx, QuickTileService::class.java)) } catch (_: Throwable) {}
        }
    }
}
