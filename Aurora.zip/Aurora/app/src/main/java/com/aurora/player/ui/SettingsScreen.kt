package com.aurora.player.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material.icons.rounded.Search
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurora.player.backup.BackupScheduler
import com.aurora.player.lyrics.LyricsOverlayService
import com.aurora.player.player.PlayerController
import com.aurora.player.widget.WidgetUpdater
import kotlin.math.roundToInt

private val PAGES = listOf(
    Triple("theme", "Theme and colours", "Light / dark / black, accent colour"),
    Triple("tabs", "Tabs and layout", "Tab-bar position, arrange or hide tabs, exit"),
    Triple("now", "Now Playing screen", "Background, cover style, seek buttons"),
    Triple("npbuttons", "Now Playing buttons", "Show or hide every button on the player"),
    Triple("playback", "Playback behaviour", "Shuffle, previous button, tap to play, skip times"),
    Triple("positions", "Play counts and positions", "Remember positions, what counts as a play"),
    Triple("audio", "Audio and fades", "Fades, crossfade, audio focus, volume, equalizer"),
    Triple("headset", "Headset, Bluetooth and speaker", "Pause and resume when devices connect"),
    Triple("exit", "Closing and exit", "Idle close, recents, confirm before exit"),
    Triple("motion", "Motion and animations", "Speed, transitions, list and button motion"),
    Triple("albums", "Albums", "List or grid, extra info under each album"),
    Triple("library", "Song library and tags", "Excluded folders, short files, scan"),
    Triple("queues", "Queues and sorting", "Merging queues, sort rules"),
    Triple("lyrics", "Lyrics", "Source: embedded, .lrc file or online"),
    Triple("desktop", "Desktop lyrics", "Floating lyrics window"),
    Triple("notification", "Notification", "Style, buttons, upcoming songs"),
    Triple("lock", "Lock screen and widgets", "Lock-screen player, queue widget theme"),
    Triple("tile", "Quick Settings tile", "Play / pause tile in the swipe-down panel"),
    Triple("backup", "Backup and restore", "Zip backups, automatic backup"),
    Triple("compat", "Compatibility and performance", "Switch off heavy features on slower phones"),
    Triple("about", "About", ""),
)

/** The home screen shows the pages in these groups, so similar settings sit together. */
private val GROUPS = listOf(
    "Appearance" to listOf("theme", "motion", "tabs", "now", "npbuttons"),
    "Playback" to listOf("playback", "positions", "audio", "headset", "exit"),
    "Library" to listOf("library", "albums", "queues"),
    "Lyrics" to listOf("lyrics", "desktop"),
    "Notification, lock screen and widgets" to listOf("notification", "lock", "tile"),
    "Data" to listOf("backup"),
    "System" to listOf("compat", "about"),
)

/** (setting name, page id, extra keywords) for the settings search. */
private val SETTING_INDEX = listOf(
    Triple("Upcoming songs", "notification", "notification queue next"), Triple("Notification buttons", "notification", "arrangement heart close repeat shuffle"),
    Triple("Animation speed", "motion", "animations off fast slow smooth"), Triple("Screen transition", "motion", "slide fade zoom navigation"),
    Triple("List animation", "motion", "entrance stagger items"), Triple("Button press bounce", "motion", "tap spring"),
    Triple("Theme", "theme", "dark light black amoled colour"), Triple("Accent colour", "theme", "color"),
    Triple("Tab-bar position", "tabs", "top bottom tabs"), Triple("Arrange tabs", "tabs", "hide genres"),
    Triple("Spinning vinyl album art", "now", "disc"), Triple("Now playing background", "now", "blur image"),
    Triple("Hide a Now Playing button", "npbuttons", "icon remove heart info lyrics"),
    Triple("Equalizer", "audio", "bass virtualizer loudness"), Triple("Audio focus", "audio", "calls duck pause"),
    Triple("Crossfade", "audio", "overlap fade songs"), Triple("ReplayGain", "audio", "loudness normalize volume"),
    Triple("Remember speed per song", "audio", "playback speed"), Triple("Skip silence", "audio", "gaps"),
    Triple("Headset and Bluetooth", "headset", "unplug resume wired"), Triple("Excluded folders", "library", "hide"),
    Triple("Split multiple artists", "library", "separator"), Triple("Minimum duration", "library", "short files"),
    Triple("Sleep timer", "exit", "stop"), Triple("Queues", "queues", "merge"),
    Triple("Shuffle behaviour", "playback", "random below"), Triple("Previous button", "playback", "restart percentage"),
    Triple("Remember positions", "positions", "resume ask"), Triple("Play count", "positions", "minimum percentage"),
    Triple("Confirm before exit", "exit", "back"),
    Triple("Back button in main screen", "exit", "back history now playing"),
    Triple("Album view mode", "albums", "grid list columns"), Triple("Show extra info in the list of albums", "albums", "songs duration year artist composer"),
    Triple("Lyrics source", "lyrics", "embedded lrc file"), Triple("Desktop lyrics overlay", "desktop", "floating"),
    Triple("Backup and restore", "backup", "zip automatic"), Triple("Export listening history", "backup", "csv plays"),
    Triple("Lock screen player", "lock", "swipe widget"), Triple("Widget theme and transparency", "lock", "widget queue simple advanced album art"),
    Triple("Quick Settings tile", "tile", "panel play pause"),
    Triple("Safe mode", "compat", "crash slow lag android 10 notification equalizer widget"),
)

@Composable
fun SettingsScreen(c: PlayerController, back: () -> Unit, openEq: () -> Unit) {
    var page by remember { mutableStateOf<String?>(null) }
    var q by remember { mutableStateOf("") }
    BackHandler(enabled = page != null) { page = null }
    val title = PAGES.firstOrNull { it.first == page }?.second ?: "Settings"

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).bounceClick { if (page != null) page = null else back() }, contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, null)
            }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            when (page) {
                null -> {
                    androidx.compose.material3.OutlinedTextField(
                        q, { q = it }, singleLine = true, placeholder = { Text("Search settings…") },
                        leadingIcon = { Icon(androidx.compose.material.icons.Icons.Rounded.Search, null) },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    )
                    if (q.isBlank()) GROUPS.forEach { (group, ids) ->
                        Section(group)
                        ids.forEach { id -> PAGES.first { it.first == id }.let { (_, name, sub) -> ActionRow(name, sub) { page = id } } }
                    }
                    else {
                        val hits = SETTING_INDEX.filter { it.first.contains(q, true) || it.third.contains(q, true) }
                        if (hits.isEmpty()) Text("No settings match.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        hits.forEach { (name, pg, kw) -> ActionRow(name, PAGES.first { it.first == pg }.second) { page = pg; q = "" } }
                    }
                }
                "theme", "tabs", "now", "npbuttons", "tile" -> InterfacePage(c, page!!)
                "audio" -> AudioPage(c, openEq)
                "headset" -> HeadsetPage(c)
                "library" -> LibraryPage(c)
                "playback", "positions", "exit", "queues" -> AdvancedPage(c, page!!)
                "compat" -> CompatPage(c)
                "albums" -> AlbumsPage(c)
                "motion" -> MotionPage(c)
                "lyrics" -> LyricsPage(c)
                "desktop" -> DesktopPage(c)
                "backup" -> BackupPage(c)
                "notification" -> NotificationPage(c)
                "lock" -> LockPage(c)
                else -> AboutPage()
            }
            Box(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun InterfacePage(c: PlayerController, part: String) {
    val d = c.store.data
    val actions = LocalActions.current
    var arrange by remember { mutableStateOf(false) }
    if (arrange) ArrangeTabsDialog(c) { arrange = false }

    if (part == "theme") {
    ChipRow("Theme") {
        listOf("System", "Light", "Dark", "Black").forEachIndexed { i, n ->
            FilterChip(d.themeMode == i, { c.store.update { it.copy(themeMode = i) } }, label = { Text(n) })
        }
    }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text("Accent colour")
        Text(
            "Default uses your phone's colours (Android 12+) or Aurora purple.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(Modifier.padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(0L, 0xFF007CC3, 0xFF0078D7, 0xFFE8E4DA, 0xFF894E62, 0xFF7F56FF, 0xFFCC00CC, 0xFFE8003C, 0xFFB35F00, 0xFF737A00, 0xFF2A8A00, 0xFF008A80, 0xFF5B63FF, 0xFF2EA8FF, 0xFFFFB300).forEach { col ->
                val sel = d.accentColor == col
                Box(
                    Modifier.size(34.dp)
                        .background(if (col == 0L) MaterialTheme.colorScheme.surfaceVariant else Color(col), CircleShape)
                        .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.onSurface else Color.Gray, CircleShape)
                        .bounceClick { c.store.update { it.copy(accentColor = col) } },
                    contentAlignment = Alignment.Center,
                ) { if (col == 0L) Text("A", style = MaterialTheme.typography.labelLarge) }
            }
        }
    }
    }
    if (part == "tabs") {
    ChipRow("Tab-bar position") {
        listOf(false to "Top", true to "Bottom").forEach { (b, n) ->
            FilterChip(d.tabsBottom == b, { c.store.update { it.copy(tabsBottom = b) } }, label = { Text(n) })
        }
    }
    ActionRow("Arrange tabs", "Arrange tabs, or enable/disable them") { arrange = true }
    }
    if (part == "now") {
    SwitchRow("Spinning vinyl album art", "Off = a breathing square cover", d.discArt) { v -> c.store.update { it.copy(discArt = v) } }
    SwitchRow("Fast-forward / rewind buttons", "Show the skip-forward and skip-back buttons under the seek bar on Now playing", d.showSeekButtons) { v -> c.store.update { it.copy(showSeekButtons = v) } }

    Section("Now playing")
    ChipRow("Background") {
        listOf("Album colour", "Blurred art", "Aurora", "Plain", "Black", "My image").forEachIndexed { i, n ->
            FilterChip(d.nowBg == i, {
                if (i == 5 && d.customBgUri.isEmpty()) actions.pickBackground() else c.store.update { it.copy(nowBg = i) }
            }, label = { Text(n) })
        }
    }
    if (d.nowBg == 5) ActionRow("Choose image", "Pick the picture shown behind the player") { actions.pickBackground() }
    if (d.nowBg == 1 || d.nowBg == 5) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            Row {
                Text("Darken background", Modifier.weight(1f))
                Text("${d.nowBgDim}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Slider(d.nowBgDim.toFloat(), { v -> c.store.update { it.copy(nowBgDim = v.roundToInt()) } }, valueRange = 0f..80f)
        }
    }
    Text(
        "Tip: tap the palette icon on the Now Playing screen to cycle through backgrounds.",
        Modifier.padding(horizontal = 20.dp, vertical = 2.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    SwitchRow("Keep screen on", "While the Now Playing screen is open", d.keepScreenOn) { v -> c.store.update { it.copy(keepScreenOn = v) } }

    }
    if (part == "tile") {
        Text("Adds a tile to the swipe-down panel that shows the song and plays / pauses it. Tap the tile to open Aurora.", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    run {
        val qctx = androidx.compose.ui.platform.LocalContext.current
        ActionRow("Quick Settings tile", "Add Aurora's play / pause tile to the swipe-down panel") {
            try {
                if (android.os.Build.VERSION.SDK_INT >= 33) {
                    val sm = qctx.getSystemService(android.app.StatusBarManager::class.java)
                    sm.requestAddTileService(
                        android.content.ComponentName(qctx, com.aurora.player.QuickTileService::class.java), "Aurora",
                        android.graphics.drawable.Icon.createWithResource(qctx, com.aurora.player.R.drawable.ic_qs_tile), { r -> r.run() }, { },
                    )
                } else {
                    android.widget.Toast.makeText(qctx, "Swipe down twice, tap the pencil (edit) and drag the Aurora tile into the panel.", android.widget.Toast.LENGTH_LONG).show()
                }
            } catch (_: Throwable) {
                android.widget.Toast.makeText(qctx, "Swipe down twice, tap the pencil (edit) and drag the Aurora tile into the panel.", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    }
    if (part == "npbuttons") {
    Text(
        "Switch off any button you never use. It disappears from the Now Playing screen.",
        Modifier.padding(horizontal = 20.dp, vertical = 2.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    listOf(
        "palette" to "Background (palette) button", "queue" to "Queue button",
        "fav" to "Favourite (heart)", "info" to "Song info", "lyrics" to "Lyrics", "overlay" to "Desktop lyrics", "addpl" to "Add to playlist",
        "sleep" to "Sleep timer", "more" to "More (…) menu", "ab" to "A–B repeat", "mode" to "Repeat / play mode",
        "shuffle" to "Shuffle", "vol" to "Volume", "eq" to "Equalizer",
    ).forEach { (key, name) ->
        SwitchRow(name, "", key !in d.hideNp) { on ->
            c.store.update { it.copy(hideNp = if (on) it.hideNp - key else (it.hideNp + key).distinct()) }
        }
    }
    }
}

@Composable
private fun AudioPage(c: PlayerController, openEq: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val d = c.store.data
    ActionRow("Equalizer", "Per-output equalizer, bass boost, virtualizer, loudness, speed and pitch") { openEq() }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
        Row {
            Text("Audio focus", Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text("Level ${d.focusLevel}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(
            d.focusLevel.toFloat(), { v -> c.store.update { it.copy(focusLevel = v.roundToInt().coerceIn(1, 5)) }; c.applyPlaybackPrefs() },
            valueRange = 1f..5f, steps = 3,
        )
        val lvl = d.focusLevel
        fun line(on: Boolean, text: String) = (if (on) "✓ " else "✗ ") + text
        Text(
            listOf(
                line(lvl >= 2, "Pause music during phone calls"),
                line(lvl >= 3, "Pause music when another app plays audio for a long time (music, video)"),
                line(lvl == 4, "Lower the volume for short sounds: navigation prompts, notification sounds"),
                line(lvl >= 5, "Pause (instead of lowering the volume) for short sounds too"),
                if (lvl == 1) "Level 1: Aurora ignores calls and other apps completely." else "",
            ).filter { it.isNotEmpty() }.joinToString("\n"),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
    SwitchRow("Resume after call ends", "Resume after a call or a short interruption ends", d.resumeAfterCall) { v ->
        c.store.update { it.copy(resumeAfterCall = v) }
    }
    ChipRow("Crossfade (overlap songs)") {
        listOf(0, 2, 4, 6, 8, 12).forEach { sec ->
            FilterChip(d.crossfadeSec == sec, { c.store.update { it.copy(crossfadeSec = sec) } }, label = { Text(if (sec == 0) "Off" else "${sec}s") })
        }
    }
    SwitchRow("ReplayGain", "Evens out loudness using the ReplayGain tags in your files (only lowers loud songs)", d.replayGain) { v ->
        c.store.update { it.copy(replayGain = v) }
    }
    SwitchRow(
        "Aurora sound engine", "31-band equalizer, mono and balance. Turn off if songs don't play; it switches itself off after a playback error",
        d.soundEngine,
    ) { v -> c.store.update { it.copy(soundEngine = v) }; if (v) android.widget.Toast.makeText(ctx, "Restart Aurora to apply", android.widget.Toast.LENGTH_SHORT).show() }
    SwitchRow("Skip silence", "Skips silent gaps within songs", d.skipSilence) { v ->
        c.store.update { it.copy(skipSilence = v) }; c.applyPlaybackPrefs()
    }
    SliderSetting("Fade between songs", d.fadeSec.toFloat(), 0f..12f, 11, if (d.fadeSec == 0) "Off" else "${d.fadeSec} s") { v ->
        c.store.update { it.copy(fadeSec = v.roundToInt()) }
    }
    SliderSetting("Fade-in volume when play", d.fadeInMs.toFloat(), 0f..2000f, 19, "${d.fadeInMs} ms") { v ->
        c.store.update { it.copy(fadeInMs = (v / 100).roundToInt() * 100) }
    }
    SliderSetting("Fade-out volume when pause", d.fadeOutMs.toFloat(), 0f..2000f, 19, "${d.fadeOutMs} ms") { v ->
        c.store.update { it.copy(fadeOutMs = (v / 100).roundToInt() * 100) }
    }
    Section("Volume")
    SwitchRow("Do not allow playback if audio volume is 0", "Shows a message instead of playing silently", d.blockPlayMuted) { v ->
        c.store.update { it.copy(blockPlayMuted = v) }
    }
    SwitchRow("Pause when audio is muted", "Pauses when the media volume reaches 0", d.pauseOnMute) { v -> c.store.update { it.copy(pauseOnMute = v) } }
    SwitchRow("Resume when audio is un-muted", "Only if playback was paused because it was muted", d.resumeOnUnmute) { v ->
        c.store.update { it.copy(resumeOnUnmute = v) }
    }
    Text(
        "Gapless playback is always on.", Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun HeadsetPage(c: PlayerController) {
    val d = c.store.data
    Section("Pause when disconnect")
    SwitchRow("Pause when disconnect", "Pause music when headset, speaker or Bluetooth is disconnected", d.pauseOnUnplug) { v ->
        c.store.update { it.copy(pauseOnUnplug = v) }; c.applyPlaybackPrefs()
    }
    Section("Resume when connect")
    SwitchRow("Resume only if paused by disconnection before", "", d.resumeOnlyIfPaused) { v -> c.store.update { it.copy(resumeOnlyIfPaused = v) } }
    SwitchRow("Resume on Bluetooth connect", "", d.resumeOnBt) { v -> c.store.update { it.copy(resumeOnBt = v) } }
    SwitchRow("Resume on wired headset / speaker connect", "", d.resumeOnWired) { v -> c.store.update { it.copy(resumeOnWired = v) } }
    Section("Earphone's mic button")
    Text(
        "Single press: play / pause. Double press: next song. Triple press: previous song. " +
            "Some phones don't send earphone button presses to music apps.",
        Modifier.padding(horizontal = 20.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun LibraryPage(c: PlayerController) {
    val d = c.store.data
    val actions = LocalActions.current
    var foldersDialog by remember { mutableStateOf(false) }
    if (foldersDialog) ExcludedFoldersDialog(c, { foldersDialog = false }) { actions.rescan() }

    Section("Song library")
    SwitchRow("Split multiple artists", "“A & B; C” shows as separate artists (separators: ${d.artistSeparators})", d.splitArtists) { v ->
        c.store.update { it.copy(splitArtists = v) }
    }
    ActionRow(
        "Excluded folders",
        if (d.excludedFolders.isEmpty()) "None. Hide folders (voice notes, ringtones…) from Aurora" else "${d.excludedFolders.size} hidden",
    ) { foldersDialog = true }
    ChipRow("Exclude small duration files") {
        listOf(0, 15, 30, 60, 120).forEach { sec ->
            FilterChip(d.minDurationSec == sec, {
                c.store.update { it.copy(minDurationSec = sec) }; actions.rescan()
            }, label = { Text(if (sec == 0) "None" else if (sec < 60) "$sec s" else "${sec / 60} min") })
        }
    }
    Section("Scan")
    ActionRow("Scan", "${c.library.size} songs found. Aurora also scans every time it starts") { actions.rescan() }
    Section("Tags, album art, lyrics")
    SwitchRow("Load album arts", "If disabled, album art is not loaded anywhere in the app", d.loadArt) { v ->
        c.store.update { it.copy(loadArt = v) }; ArtLoader.enabled = v
    }
    SwitchRow("Show file names instead of titles", "Shows each song's file name everywhere", d.showFileNames) { v ->
        c.store.update { it.copy(showFileNames = v) }; actions.rescan()
    }
    Text(
        "Edit tags: open a song's ⋮ menu and choose “Edit tags”. Title, artist, album, album artist, genre, year, track and " +
            "embedded lyrics are written into the audio file.",
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun AdvancedPage(c: PlayerController, part: String) {
    val d = c.store.data
    var shuffleDlg by remember { mutableStateOf<String?>(null) }
    fun belowText(b: Boolean) = if (b) "Only shuffle songs below the currently playing song" else "Shuffle all songs in that queue"
    var backDlg by remember { mutableStateOf(false) }
    if (part == "exit") {
    ActionRow("When I press the back button in main screen…", if (d.backMode == 1) "If not in 'Now playing' tab then go there, otherwise exit the app" else "Remember history of tab switching and always go to previous tabs") { backDlg = true }
    }
    if (backDlg) androidx.compose.material3.AlertDialog(
        onDismissRequest = { backDlg = false },
        title = { Text("When I press the back button in main screen…") },
        text = {
            Column {
                listOf(0 to "Remember history of tab switching and always go to previous tabs", 1 to "If not in 'Now playing' tab then go there, otherwise exit the app").forEach { (m, label) ->
                    Row(Modifier.fillMaxWidth().clickable { c.store.update { it.copy(backMode = m) }; backDlg = false }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(d.backMode == m, { c.store.update { it.copy(backMode = m) }; backDlg = false })
                        Text(label, Modifier.padding(start = 12.dp))
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ backDlg = false }) { Text("Cancel") } },
    )
    if (part == "playback") {
    ActionRow("When I turn on the 'Shuffle mode'…", belowText(d.shuffleBelowOnly)) { shuffleDlg = "mode" }
    ActionRow("When I select 'Randomize' sort-option for a queue…", belowText(d.randomizeBelowOnly)) { shuffleDlg = "sort" }
    shuffleDlg?.let { which ->
        val cur = if (which == "mode") d.shuffleBelowOnly else d.randomizeBelowOnly
        fun pick(below: Boolean) {
            c.store.update { if (which == "mode") it.copy(shuffleBelowOnly = below) else it.copy(randomizeBelowOnly = below) }
            shuffleDlg = null
        }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { shuffleDlg = null },
            title = { Text(if (which == "mode") "When I turn on the 'Shuffle mode'…" else "When I select 'Randomize' sort-option for a queue…") },
            text = {
                Column {
                    listOf(false to "Shuffle all songs in that queue", true to "Only shuffle songs below the currently playing song").forEach { (below, label) ->
                        Row(Modifier.fillMaxWidth().clickable { pick(below) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.RadioButton(cur == below, { pick(below) })
                            Text(label, Modifier.padding(start = 12.dp))
                        }
                    }
                }
            },
            confirmButton = { androidx.compose.material3.TextButton({ shuffleDlg = null }) { Text("Cancel") } },
        )
    }
    }
    if (part == "exit") {
    ChipRow("Close the app when no music has played for") {
        listOf(0, 5, 10, 15, 30, 60).forEach { m ->
            FilterChip(d.idleStopMin == m, { c.store.update { it.copy(idleStopMin = m) } }, label = { Text(if (m == 0) "Never" else "$m min") })
        }
    }
    }
    if (part == "exit") {
    SwitchRow("Stop playing and close the app when removed from recents", "", d.stopOnTaskRemoved) { v -> c.store.update { it.copy(stopOnTaskRemoved = v) } }
    }
    if (part == "playback") {
    SwitchRow("Start playback when app is started", "Resumes your last queue automatically", d.autoPlayOnStart) { v -> c.store.update { it.copy(autoPlayOnStart = v) } }
    }
    var posDialog by remember { mutableStateOf(false) }
    if (part == "positions") {
    ActionRow(
        "Remember last positions of all tracks",
        if (d.rememberPositions) "On · songs of ${d.rememberMinMin}+ min · ${if (d.askToResume) "ask to resume" else "resume without asking"}" else "Off",
    ) { posDialog = true }
    if (posDialog) androidx.compose.ui.window.Dialog(onDismissRequest = { posDialog = false }) {
        androidx.compose.material3.Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, tonalElevation = 6.dp) {
            Column(Modifier.padding(24.dp).verticalScroll(rememberScrollState())) {
                Text("Remember last positions", style = MaterialTheme.typography.headlineSmall)
                Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Remember positions", Modifier.weight(1f))
                    androidx.compose.material3.Switch(d.rememberPositions, { v -> c.store.update { it.copy(rememberPositions = v) } })
                }
                Text(
                    "Only tracks at least this long (in minutes) are remembered:",
                    Modifier.padding(top = 14.dp, bottom = 6.dp), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                listOf(listOf(1, 2, 3, 5), listOf(10, 15, 20, 30)).forEach { rowMins ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowMins.forEach { m ->
                            FilterChip(
                                d.rememberMinMin == m, { c.store.update { it.copy(rememberMinMin = m) } },
                                label = { Text("$m min", maxLines = 1) }, modifier = Modifier.weight(1f),
                                enabled = d.rememberPositions,
                            )
                        }
                    }
                }
                listOf(true to "Ask to resume", false to "Resume without asking").forEach { (ask, label) ->
                    Row(
                        Modifier.fillMaxWidth().padding(top = 6.dp).clickable { c.store.update { it.copy(askToResume = ask) } },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        androidx.compose.material3.RadioButton(d.askToResume == ask, { c.store.update { it.copy(askToResume = ask) } })
                        Text(label, Modifier.padding(start = 4.dp))
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.End) {
                    androidx.compose.material3.TextButton({ posDialog = false }) { Text("Close") }
                }
            }
        }
    }
    ChipRow("Minimum duration for considering a playback") {
        listOf(5, 10, 15, 30, 60).forEach { sec ->
            FilterChip(d.playCountPct == 0 && d.minPlaySec == sec, { c.store.update { it.copy(minPlaySec = sec, playCountPct = 0) } }, label = { Text("$sec s") })
        }
    }
    ChipRow("…or a percentage of the song played") {
        listOf(10, 25, 50, 75, 90).forEach { pc ->
            FilterChip(d.playCountPct == pc, { c.store.update { it.copy(playCountPct = if (d.playCountPct == pc) 0 else pc) } }, label = { Text("$pc%") })
        }
    }
    }
    if (part == "playback") {
    SwitchRow("Previous button restarts the song", "After the first 3 seconds, tapping previous goes back to the start", d.prevRestarts) { v ->
        c.store.update { it.copy(prevRestarts = v) }
    }
    if (d.prevRestarts) ChipRow("Restart the song once this much has played") {
        FilterChip(d.prevRestartPct == 0, { c.store.update { it.copy(prevRestartPct = 0) } }, label = { Text("3 s") })
        listOf(5, 10, 25, 50, 75).forEach { pc ->
            FilterChip(d.prevRestartPct == pc, { c.store.update { it.copy(prevRestartPct = pc) } }, label = { Text("$pc%") })
        }
    }
    SwitchRow("Tapping a song plays the whole list", "Off = plays only that song", d.tapPlaysList) { v -> c.store.update { it.copy(tapPlaysList = v) } }
    ChipRow("Fast-forward duration") {
        listOf(5, 10, 15, 30).forEach { sec ->
            FilterChip(d.ffSec == sec, { c.store.update { it.copy(ffSec = sec) } }, label = { Text("$sec s") })
        }
    }
    ChipRow("Rewind duration") {
        listOf(5, 10, 15, 30).forEach { sec ->
            FilterChip(d.rewindSec == sec, { c.store.update { it.copy(rewindSec = sec) } }, label = { Text("$sec s") })
        }
    }
    }
    if (part == "exit") {
        SwitchRow("Confirm before exit", "Ask when pressing back on the first tab", d.confirmExit) { v -> c.store.update { it.copy(confirmExit = v) } }
    }
    if (part == "queues") {
    Section("Queues")
    SwitchRow(
        "Open a queue named after the source",
        "Playing an album, playlist, folder… uses (or creates) a queue with that name. You can keep up to 20 queues.", d.sourceQueues,
    ) { v -> c.store.update { it.copy(sourceQueues = v) } }
    ChipRow("If a queue with that name already exists") {
        listOf(false to "Replace it", true to "Merge into it").forEach { (m, n) ->
            FilterChip(d.queueMerge == m, { c.store.update { it.copy(queueMerge = m) } }, label = { Text(n) })
        }
    }
    Section("Sort")
    SwitchRow("Ignore certain words at beginning while sorting", "Ignores “A”, “An”, “The” when sorting songs, albums and artists", d.ignoreWords) { v ->
        c.store.update { it.copy(ignoreWords = v) }
    }
    }
}

@Composable
private fun LyricsPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    ChipRow("Preferred source of lyrics") {
        listOf("embedded" to "Embedded in song", "file" to "Lyrics file (.lrc)", "saved" to "Saved / imported").forEach { (id, n) ->
            FilterChip(d.lyricsPreferred == id, { c.store.update { it.copy(lyricsPreferred = id) } }, label = { Text(n) })
        }
    }
    Text(
        "When several sources have lyrics, the preferred one is used first. To choose a source for one song, tap the album art on the Now Playing screen " +
            "to open the lyrics, then tap “Source”. Aurora has no internet access, so lyrics come only from the song's tags, a .lrc file or ones you import.",
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text("Lyrics appearance", Modifier.padding(start = 20.dp, top = 12.dp), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
    ChipRow("Text size") {
        listOf("Small", "Medium", "Large").forEachIndexed { i, n ->
            FilterChip(d.lyricScale == listOf(80, 100, 125)[i], { c.store.update { it.copy(lyricScale = listOf(80, 100, 125)[i]) } }, label = { Text(n) })
        }
    }
    ChipRow("Alignment") {
        listOf("Left", "Center", "Right").forEachIndexed { i, n ->
            FilterChip(d.lyricAlignC == i, { c.store.update { it.copy(lyricAlignC = i) } }, label = { Text(n) })
        }
    }
    ChipRow("Font") {
        listOf(false to "Sans", true to "Serif").forEach { (serif, n) ->
            FilterChip(d.lyricSerif == serif, { c.store.update { it.copy(lyricSerif = serif) } }, label = { Text(n) })
        }
    }
    ActionRow("Read .lrc files next to songs", "Grants all-files access so “song.mp3” can use “song.lrc” in the same folder (Android 11+).") {
        if (Build.VERSION.SDK_INT >= 30) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}

@Composable
private fun DesktopPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current
        SwitchRow("Show floating lyrics", "Draws over other apps. Needs “display over other apps” permission.", c.overlayActive) {
            actions.toggleOverlay(it)
        }
        ChipRow("Lyric line motion") {
        com.aurora.player.ui.LYRIC_MOTIONS.forEachIndexed { i, name ->
            FilterChip(
                d.lyricMotion == i, { c.store.update { it.copy(lyricMotion = i) } }, label = { Text(name) },
                colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer, selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer),
            )
        }
    }
        SwitchRow("Lock position", "Stops the window from being dragged. Its buttons keep working.", d.overlayLocked) {
            LyricsOverlayService.setLocked(ctx, it)
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Row {
                Text("Text size", Modifier.weight(1f))
                Text("${d.overlayTextSp} sp", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Slider(d.overlayTextSp.toFloat(), { v -> c.store.update { it.copy(overlayTextSp = v.roundToInt()) } }, valueRange = 12f..48f)
            Text("Colour")
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(0xFFFFFFFF, 0xFFFFE066, 0xFF7FE3D0, 0xFFFF8FB1, 0xFF9CFF8A, 0xFFB4A8FF).forEach { col ->
                    val sel = d.overlayColor == col
                    Box(
                        Modifier.size(34.dp).background(Color(col), CircleShape)
                            .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                            .bounceClick { c.store.update { it.copy(overlayColor = col) } },
                    )
                }
            }
        }

}

@Composable
private fun BackupPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current
        val folderLabel = if (d.backupFolder.isEmpty()) "Default: Documents/Aurora/Backups/Automatic backups. Tap to choose another folder"
        else (Uri.parse(d.backupFolder).lastPathSegment ?: "Chosen folder").replace(':', '/')
        ActionRow("Export listening history", "Every counted play with date and time, as a .csv file") { actions.exportHistory() }
        ActionRow("Backup folder", folderLabel) { actions.chooseBackupFolder() }
        ActionRow("Backup now", "Last backup: ${formatDateTime(ctx, d.lastBackupAt)}") { actions.backupNow() }
        SwitchRow(
            "Automatic backup", "Saves a new zip in the background and keeps only the latest ones",
            d.autoBackup,
        ) { on ->
            c.store.update { it.copy(autoBackup = on) }
            BackupScheduler.apply(ctx, c.store.data)
        }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Every", Modifier.padding(end = 4.dp))
            listOf(1 to "Day", 7 to "Week", 30 to "Month").forEach { (days, name) ->
                FilterChip(d.autoBackupDays == days, {
                    c.store.update { it.copy(autoBackupDays = days) }
                    BackupScheduler.apply(ctx, c.store.data)
                }, label = { Text(name) })
            }
        }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Keep last", Modifier.padding(end = 4.dp))
            listOf(3, 5, 10).forEach { n ->
                FilterChip(d.autoBackupKeep == n, { c.store.update { it.copy(autoBackupKeep = n) } }, label = { Text("$n") })
            }
        }
        ActionRow("Restore from backup", "Choose what to restore: settings, favourites, playlists, play counts, queues, lyrics") { actions.openRestore() }

}

@Composable
private fun LockPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current
        Section("Lock screen")
        SwitchRow(
            "Lock-screen player",
            "Shows a full player over the lock screen when music is playing and the screen turns off. Needs “display over other apps”.",
            d.lockScreenPlayer,
        ) { on ->
            if (on && !actions.ensureOverlayPermission()) return@SwitchRow
            c.store.update { it.copy(lockScreenPlayer = on) }
        }
        SwitchRow("Always show", "Show the lock-screen player whenever the screen turns off, even if music is paused", d.lockAlways) { v ->
            c.store.update { it.copy(lockAlways = v) }
        }
        SwitchRow("Adapt from album art", "Blurred cover and cover colours as the lock-screen background", d.lockAdapt) { v ->
            c.store.update { it.copy(lockAdapt = v) }
        }
        SwitchRow("Show lyrics on lock screen", "Current line under the cover", d.lockShowLyrics) { v ->
            c.store.update { it.copy(lockShowLyrics = v) }
        }
    ChipRow("Lyric line motion") {
        com.aurora.player.ui.LYRIC_MOTIONS.forEachIndexed { i, name ->
            FilterChip(
                d.lyricMotion == i, { c.store.update { it.copy(lyricMotion = i) } }, label = { Text(name) },
                colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer, selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer),
            )
        }
    }

        WidgetSettings(c)

}

@Composable
private fun NotificationPage(c: PlayerController) {
    val d = c.store.data
    fun save(f: (com.aurora.player.data.Persisted) -> com.aurora.player.data.Persisted) { c.store.update(f); c.onNotifSettingsChanged?.invoke() }
    Section("Buttons next to play / previous / next")
    val all = listOf("fav" to "Favourite", "repeat" to "Repeat", "shuffle" to "Shuffle", "overlay" to "Desktop lyrics", "close" to "Close")
    Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text("Arrangement of buttons")
        Text(
            "Tap to add or remove a button. They appear in the order you tap them.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            all.forEach { (k, n) ->
                val on = k in d.notifButtons
                FilterChip(on, {
                    save { it.copy(notifButtons = if (on) it.notifButtons - k else it.notifButtons + k) }
                }, label = { Text(n + if (on) "  ${d.notifButtons.indexOf(k) + 1}" else "") })
            }
        }
    }
    SwitchRow("Adapt from album art", "Colours the notification with the cover's dominant colour", d.notifAdapt) { v -> save { it.copy(notifAdapt = v) } }
    Section("Expanded notification")
    SwitchRow("Upcoming songs", "Shows the next two songs when the notification is expanded", d.notifUpcoming) { v -> save { it.copy(notifUpcoming = v) } }
    SwitchRow("Album art", "Shows the cover in the notification", d.notifArt) { v -> save { it.copy(notifArt = v) } }
    Text(
        "The notification's colours follow the album art and your phone's theme (set by Android).",
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun MotionPage(c: PlayerController) {
    val d = c.store.data
    var replay by remember { mutableStateOf(0) }
    Section("Speed")
    ChipRow("Animation speed") {
        Motion.SPEEDS.forEachIndexed { i, n -> FilterChip(d.motionSpeed == i, { c.store.update { it.copy(motionSpeed = i) }; replay++ }, label = { Text(n) }) }
    }
    Text(
        "Off turns every animation off (best for slow phones). Relaxed is slower and floatier, Snappy is quicker.",
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Section("Screens")
    ChipRow("Transition between screens") {
        Motion.NAV.forEachIndexed { i, n -> FilterChip(d.navStyle == i, { c.store.update { it.copy(navStyle = i) } }, label = { Text(n) }) }
    }
    SwitchRow("Fade between covers", "Album art cross-fades when the song changes", d.artFade) { v -> c.store.update { it.copy(artFade = v) } }
    Section("Lists")
    ChipRow("How songs and albums appear") {
        Motion.LIST.forEachIndexed { i, n -> FilterChip(d.listAnim == i, { c.store.update { it.copy(listAnim = i) }; replay++ }, label = { Text(n) }) }
    }
    SwitchRow("One after another", "Items appear with a small delay between them", d.listStagger) { v -> c.store.update { it.copy(listStagger = v) }; replay++ }
    Section("Buttons")
    ChipRow("Press bounce") {
        Motion.PRESS.forEachIndexed { i, n -> FilterChip(d.pressMode == i, { c.store.update { it.copy(pressMode = i) } }, label = { Text(n) }) }
    }
    Section("Preview")
    Column(Modifier.padding(horizontal = 12.dp)) {
        androidx.compose.runtime.key(replay) {
            listOf("First song", "Second song", "Third song", "Fourth song").forEachIndexed { i, n ->
                Row(
                    Modifier.fillMaxWidth().staggerIn(i).padding(horizontal = 8.dp, vertical = 3.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) { Text(n) }
            }
        }
        Row(Modifier.padding(top = 10.dp, start = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).background(MaterialTheme.colorScheme.primary, CircleShape).bounceClick { replay++ },
                contentAlignment = Alignment.Center,
            ) { Icon(androidx.compose.material.icons.Icons.Rounded.PlayArrow, null, tint = MaterialTheme.colorScheme.onPrimary) }
            Text("  Tap to test the button bounce and replay the list", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AlbumsPage(c: PlayerController) {
    val d = c.store.data
    var viewDlg by remember { mutableStateOf(false) }
    var infoDlg by remember { mutableStateOf(false) }
    ActionRow("Album view mode", if (d.albumCols == 1) "List view" else "Grid view, ${d.albumCols} columns") { viewDlg = true }
    ActionRow("Show extra info in the list of albums", ALBUM_INFO_OPTIONS.getOrElse(d.albumInfo) { ALBUM_INFO_OPTIONS[0] }) { infoDlg = true }
    if (viewDlg) androidx.compose.material3.AlertDialog(
        onDismissRequest = { viewDlg = false },
        title = { Text("Album view mode") },
        text = {
            Column {
                (1..5).forEach { n ->
                    Row(Modifier.fillMaxWidth().clickable { c.store.update { it.copy(albumCols = n) }; viewDlg = false }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(d.albumCols == n, { c.store.update { it.copy(albumCols = n) }; viewDlg = false })
                        Text(if (n == 1) "List view" else "Grid view, $n columns", Modifier.padding(start = 12.dp))
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ viewDlg = false }) { Text("Cancel") } },
    )
    if (infoDlg) androidx.compose.material3.AlertDialog(
        onDismissRequest = { infoDlg = false },
        title = { Text("Show extra info in the list of albums") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                ALBUM_INFO_OPTIONS.forEachIndexed { i, label ->
                    Row(Modifier.fillMaxWidth().clickable { c.store.update { it.copy(albumInfo = i) }; infoDlg = false }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(d.albumInfo == i, { c.store.update { it.copy(albumInfo = i) }; infoDlg = false })
                        Text(label, Modifier.padding(start = 12.dp))
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ infoDlg = false }) { Text("Cancel") } },
    )
}

@Composable
private fun CompatPage(c: PlayerController) {
    val d = c.store.data
    Text(
        "If Aurora is slow, or stops while playing on an older phone, switch features off here. Each one is independent, so you can find out which one causes trouble.",
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (d.safeNote) {
        androidx.compose.material3.Card(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Aurora switched some features off", fontWeight = FontWeight.Bold)
                Text("The app stopped during playback last time, so the custom notification and the sound engine were turned off automatically (and more, if it happened again). Turn them back on one at a time to find the cause.", style = MaterialTheme.typography.bodySmall)
                androidx.compose.material3.TextButton({ c.store.update { it.copy(safeNote = false) } }) { Text("Dismiss") }
            }
        }
    }
    Section("Playback")
    SwitchRow("Aurora sound engine", "Equalizer, mono and balance. Restart Aurora after changing it.", d.soundEngine) { v -> c.store.update { it.copy(soundEngine = v) } }
    SwitchRow("Fast lyric updates", "Off = lyrics refresh 8 times a second instead of 25 (lighter on slow phones)", d.fastLyrics) { v -> c.store.update { it.copy(fastLyrics = v) } }
    Section("Notification, widgets and tile")
    SwitchRow("Custom notification", "Aurora's own layout. Off = Android's standard media notification", d.customNotif) { v -> c.store.update { it.copy(customNotif = v) } }
    SwitchRow("Update widgets while playing", "Off = widgets refresh only when playback pauses", d.widgetsLive) { v -> c.store.update { it.copy(widgetsLive = v) } }
    SwitchRow("Update Quick Settings tile while playing", "", d.qsTileLive) { v -> c.store.update { it.copy(qsTileLive = v) } }
    Section("Reset")
    ActionRow("Turn everything on", "Restores all of the switches above") {
        c.store.update { it.copy(soundEngine = true, customNotif = true, widgetsLive = true, qsTileLive = true, fastLyrics = true, safeNote = false) }
    }
    ActionRow("Turn everything off (safe mode)", "The lightest setup, for the slowest phones") {
        c.store.update { it.copy(soundEngine = false, customNotif = false, widgetsLive = false, qsTileLive = false, fastLyrics = false) }
    }
}

@Composable
private fun AboutPage() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(com.aurora.player.R.drawable.ic_logo), null,
            Modifier.size(96.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(24.dp)),
        )
        Text("Aurora", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Version 2.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    var err by remember { mutableStateOf(com.aurora.player.CrashLog.read(ctx)) }
    if (err.isNotBlank()) {
        Section("Last error")
        Text(err, Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            androidx.compose.material3.TextButton({
                (ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("Aurora error", err))
            }) { Text("Copy") }
            androidx.compose.material3.TextButton({ com.aurora.player.CrashLog.clear(ctx); err = "" }) { Text("Clear") }
        }
    }
    Text(
        "Aurora keeps playing in the background with lock-screen controls, gapless playback, two switchable queues, " +
            "playlists, favourites, equalizer, bass boost, speed/pitch, sleep timer, A–B repeat and floating lyrics.",
        Modifier.padding(horizontal = 20.dp, vertical = 12.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun SliderSetting(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, text: String, onChange: (Float) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        Row {
            Text(label, Modifier.weight(1f))
            Text(text, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(value, onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun ChipRow(label: String, content: @Composable () -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        Text(label)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
private fun ExcludedFoldersDialog(c: PlayerController, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val d = c.store.data
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { onDismiss(); onChanged() },
        title = { Text("Excluded folders") },
        text = {
            androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                if (c.allFolders.isEmpty()) item { Text("No music folders found yet.") }
                items(c.allFolders.size) { i ->
                    val f = c.allFolders[i]
                    val hidden = f in d.excludedFolders
                    Row(Modifier.fillMaxWidth().clickable {
                        c.store.update { it.copy(excludedFolders = if (hidden) it.excludedFolders - f else it.excludedFolders + f) }
                    }, verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Checkbox(hidden, null)
                        Column(Modifier.padding(start = 8.dp, top = 6.dp, bottom = 6.dp)) {
                            Text(f.substringAfterLast('/').ifEmpty { "/" }, fontWeight = FontWeight.Medium)
                            Text(f, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ onDismiss(); onChanged() }) { Text("Done") } },
    )
}

@Composable
private fun Section(title: String) {
    Text(
        title, Modifier.padding(start = 20.dp, top = 22.dp, bottom = 6.dp),
        style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun ActionRow(title: String, sub: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp)) {
        Text(title, fontWeight = FontWeight.Medium)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


@Composable
private fun WidgetSettings(c: PlayerController) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val d = c.store.data
    var tab by remember { mutableStateOf(2) }
    fun save(f: (com.aurora.player.data.Persisted) -> com.aurora.player.data.Persisted) { c.store.update(f); WidgetUpdater.update(ctx) }
    Section("Widget theme:")
    listOf("Light theme" to 1, "Dark theme" to 2, "Match with system" to 0, "Adapt from album art" to 3).forEach { (n, v) ->
        Row(
            Modifier.fillMaxWidth().clickable { save { it.copy(queueTheme = v) } }.padding(horizontal = 20.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            androidx.compose.material3.RadioButton(d.queueTheme == v, { save { it.copy(queueTheme = v) } })
            Text(n, Modifier.padding(start = 8.dp))
        }
    }
    Text(
        "“Match with system” follows your wallpaper colours (Material You on Android 12+) and dark mode.",
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Section("Transparency")
    SliderSetting("Transparency", d.wAlpha.toFloat(), 0f..100f, 19, "${d.wAlpha}%") { v -> save { it.copy(wAlpha = v.toInt()) } }

    androidx.compose.material3.TabRow(tab, Modifier.padding(top = 12.dp)) {
        listOf("SIMPLE", "ADVANCED", "CURRENT QUEUE").forEachIndexed { i, n ->
            androidx.compose.material3.Tab(tab == i, { tab = i }, text = { Text(n, maxLines = 1, style = MaterialTheme.typography.labelMedium) })
        }
    }
    @Composable
    fun Check(label: String, on: Boolean, set: (Boolean) -> Unit) {
        Row(Modifier.fillMaxWidth().clickable { set(!on) }.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(on, { set(it) })
            Text(label, Modifier.padding(start = 8.dp))
        }
    }
    when (tab) {
        0 -> {
            Text("Standard widget", Modifier.padding(start = 20.dp, top = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Check("Album art", d.wsArt) { v -> save { it.copy(wsArt = v) } }
            Check("Add/Remove favorite", d.wsFav) { v -> save { it.copy(wsFav = v) } }
            Check("Progress bar", d.wsProg) { v -> save { it.copy(wsProg = v) } }
        }
        1 -> {
            Text("Large widget", Modifier.padding(start = 20.dp, top = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Check("Album art", d.waArt) { v -> save { it.copy(waArt = v) } }
            Check("Add/Remove favorite", d.waFav) { v -> save { it.copy(waFav = v) } }
            Check("Progress bar", d.waProg) { v -> save { it.copy(waProg = v) } }
            Check("Shuffle and repeat buttons", d.waModes) { v -> save { it.copy(waModes = v) } }
            Check("Upcoming songs", d.waNext) { v -> save { it.copy(waNext = v) } }
        }
        else -> {
            Text("Current queue widget", Modifier.padding(start = 20.dp, top = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Check("Album art", d.wqArt) { v -> save { it.copy(wqArt = v) } }
            Check("Desktop lyrics button", d.wqOverlay) { v -> save { it.copy(wqOverlay = v) } }
            Check("Add/Remove favorite", d.wqFav) { v -> save { it.copy(wqFav = v) } }
            Check("Fast-forward and rewind buttons", d.wqFfRew) { v -> save { it.copy(wqFfRew = v) } }
        }
    }
}
