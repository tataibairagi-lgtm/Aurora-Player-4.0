package com.aurora.player

import android.app.Application
import android.app.WallpaperManager
import android.content.ComponentCallbacks
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.aurora.player.backup.BackupUiState
import com.aurora.player.data.LyricsRepo
import com.aurora.player.data.Store
import com.aurora.player.player.PlayerController
import com.aurora.player.widget.WidgetUpdater

class AuroraApp : Application() {
    lateinit var controller: PlayerController
        private set
    val backupUi = BackupUiState()

    /** Set when starting the player failed; MainActivity then shows the error instead of closing. */
    @Volatile var startupError: String? = null

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        CrashLog.install(this) // as early as possible, so even a crash while starting up is reported
    }

    override fun onCreate() {
        super.onCreate()
        // the crash screen runs in its own process: do not start the player there, or a startup crash would crash it too
        if (Application.getProcessName().endsWith(":crash")) return
        // the last run crashed and nobody has seen the error yet: do not start the player, just show the error (MainActivity)
        val exitReport = CrashLog.lastExitReport(this)
        if (exitReport != null) {
            startupError = "The last time Aurora ran, Android recorded this:\n\n$exitReport"
            return
        }
        if (CrashLog.pending(this)) {
            startupError = "The last time Aurora ran it stopped with this error:\n\n" + CrashLog.read(this)
            return
        }
        try { boot() } catch (t: Throwable) {
            startupError = "Startup failed\n" + android.util.Log.getStackTraceString(t).take(12000)
            CrashLog.write(this, "Startup failed", t)
        }
    }

    private fun boot() {
        Thread { CrashLog.recordLastExit(this) }.start()
        val store = Store(this)
        Thread { try { com.aurora.player.automation.Automation.schedule(this, store.data.alarms) } catch (_: Throwable) {} }.start()
        Thread { try { Thread.sleep(4000) } catch (_: Throwable) {}; com.aurora.player.ui.ArtLoader.cleanOldFiles(this) }.apply { priority = Thread.MIN_PRIORITY }.start()
        // If the last run ended during the first seconds of playback (crash, or killed after "not responding"),
        // switch the heavy features off so the app can play again; they can be turned back on in Settings.
        try {
            val health = getSharedPreferences("aurora_health", MODE_PRIVATE)
            if (!health.getBoolean("play_ok", true)) {
                val fails = health.getInt("fails", 0) + 1
                health.edit().putInt("fails", fails).putBoolean("play_ok", true).commit()
                store.update {
                    var n = it.copy(soundEngine = false, customNotif = false, safeNote = true)
                    if (fails >= 2) n = n.copy(widgetsLive = false, qsTileLive = false, fastLyrics = false)
                    n
                }
            }
        } catch (_: Throwable) {
        }
        controller = PlayerController(this, store, LyricsRepo(this))

        // The queue widget takes its colours from the wallpaper, so redraw it when either the wallpaper
        // or the light/dark mode changes (while Aurora's process is alive, e.g. during playback).
        if (Build.VERSION.SDK_INT >= 27) {
            try {
                WallpaperManager.getInstance(this).addOnColorsChangedListener(
                    WallpaperManager.OnColorsChangedListener { _, _ -> com.aurora.player.widget.WidgetTheme.invalidate(); WidgetUpdater.update(this) },
                    Handler(Looper.getMainLooper()),
                )
            } catch (_: Exception) {
            }
        }
        registerComponentCallbacks(object : ComponentCallbacks {
            override fun onConfigurationChanged(newConfig: Configuration) { WidgetUpdater.update(this@AuroraApp) }
            override fun onLowMemory() {}
        })
    }
}

val Context.controller: PlayerController
    get() = (applicationContext as AuroraApp).controller

val Context.backupUi: BackupUiState
    get() = (applicationContext as AuroraApp).backupUi
