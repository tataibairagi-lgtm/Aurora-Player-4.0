package com.aurora.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** One "Removed … · Undo" message at a time, shown for a few seconds. */
object UndoBus {
    var showing by mutableStateOf(false)
    var text by mutableStateOf("")
    private var stamp by mutableIntStateOf(0)
    var action: (() -> Unit)? = null

    fun offer(message: String, undo: () -> Unit) {
        action = undo; text = message; showing = true; stamp++
    }

    fun stampNow() = stamp
}

@Composable
fun UndoHost(modifier: Modifier = Modifier) {
    LaunchedEffect(UndoBus.stampNow()) {
        if (UndoBus.showing) { delay(5500); UndoBus.showing = false; UndoBus.action = null }
    }
    AnimatedVisibility(UndoBus.showing, modifier, enter = fadeIn() + slideInVertically { it / 2 }, exit = fadeOut() + slideOutVertically { it / 2 }) {
        Surface(shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.inverseSurface, shadowElevation = 6.dp, modifier = Modifier.padding(horizontal = 16.dp)) {
            Row(Modifier.padding(start = 18.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(UndoBus.text, Modifier.padding(vertical = 12.dp).weight(1f, fill = false), color = MaterialTheme.colorScheme.inverseOnSurface, maxLines = 2)
                TextButton({ UndoBus.action?.invoke(); UndoBus.action = null; UndoBus.showing = false }) { Text("Undo", color = MaterialTheme.colorScheme.inversePrimary) }
            }
        }
    }
}
