package com.aurora.player.data

import kotlinx.serialization.Serializable

/** A saved look: light / dark / black plus the accent colour. */
@Serializable
data class ThemePreset(val name: String, val mode: Int = 0, val accent: Long = 0L)

/** A playlist alarm. [days] is a bit mask (bit 0 = Monday ... bit 6 = Sunday); 0 means every day. [playlistId] "" = all songs, "fav" = favourites. */
@Serializable
data class AlarmItem(
    val id: String,
    val hour: Int = 7,
    val minute: Int = 0,
    val playlistId: String = "",
    val days: Int = 0,
    val shuffle: Boolean = true,
    val enabled: Boolean = true,
)

/** When the Bluetooth device named [device] connects, play [playlistId] ("" = all songs, "fav" = favourites). */
@Serializable
data class BtRule(val device: String, val playlistId: String = "", val shuffle: Boolean = true)

/** Which saved theme applies at [hour] (0..23), or null to use the normal theme settings. */
fun scheduledTheme(d: Persisted, hour: Int): ThemePreset? {
    if (!d.themeSchedule) return null
    val day = if (d.dayStartHour < d.nightStartHour) hour in d.dayStartHour until d.nightStartHour
    else hour >= d.dayStartHour || hour < d.nightStartHour
    val name = if (day) d.dayTheme else d.nightTheme
    return d.themePresets.firstOrNull { it.name == name }
}

/** Switch the equalizer to [preset] when [kind] is "device" (the connected output's name contains [match]) or "genre" (the song's genre contains [match]). */
@Serializable
data class AutoEqRule(val kind: String, val match: String, val preset: String)
