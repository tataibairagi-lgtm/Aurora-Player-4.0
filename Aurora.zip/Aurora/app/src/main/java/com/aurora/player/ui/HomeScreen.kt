@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class, androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.aurora.player.ui

import androidx.compose.foundation.background
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.getValue
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Star
import com.aurora.player.data.albumKey
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController

/** Everything on Home that takes a moment to work out. Kept for as long as the app lives, so coming back to Home is instant. */
private class HomeData(
    val artists: List<Triple<String, Int, Track>>, val albums: List<Track>, val mixes: List<Mix>,
    val most: List<Track>, val added: List<Track>, val genres: List<Pair<String, Int>>, val forgotten: List<Track>,
    val weekPlays: Int, val weekHours: Float, val todayPlays: Int, val weekArtist: String,
)

private object HomeCache { var key: String = ""; var data: HomeData? = null }

private fun computeHome(c: PlayerController, seed: Int): HomeData {
    val lim = 12
    val d = c.store.data
    val lib = c.library
    val counts = d.playCounts
    val most = lib.filter { (counts[it.id] ?: 0) > 0 }.sortedByDescending { counts[it.id] ?: 0 }.take(lim)
    val added = lib.sortedByDescending { it.dateAdded }.take(lim)
    val artists = lib.groupBy { it.artist }.filter { it.key.isNotBlank() }
        .map { (n, l) -> Triple(n, l.sumOf { counts[it.id] ?: 0 }, l.first()) }
        .filter { it.second > 0 }.sortedByDescending { it.second }.take(lim)
    val albums = lib.sortedByDescending { it.dateAdded }.distinctBy { it.albumKey() }.take(lim)
    val genres = lib.groupBy { it.genre }.filter { it.key.isNotBlank() && !it.key.equals("unknown", true) }
        .map { it.key to it.value.size }.sortedByDescending { it.second }.take(lim)
    val mixes = try { buildMixes(c, seed).take(lim) } catch (_: Throwable) { emptyList() }
    val now = System.currentTimeMillis()
    // "this week" is the calendar week starting Monday, the same as Most played → This week (not just the last 7 days)
    val weekAgo = java.util.Calendar.getInstance().apply {
        firstDayOfWeek = java.util.Calendar.MONDAY
        set(java.util.Calendar.DAY_OF_WEEK, java.util.Calendar.MONDAY)
        set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        if (timeInMillis > now) add(java.util.Calendar.WEEK_OF_YEAR, -1)
    }.timeInMillis
    val cal = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0) }
    val dayStart = cal.timeInMillis
    val byId = lib.associateBy { it.id }
    var wp = 0; var ms = 0L; var tp = 0
    val artistWeek = HashMap<String, Int>()
    val lastAt = HashMap<Long, Long>()
    for (e in c.playLog.events) {
        if (e.at > (lastAt[e.id] ?: 0L)) lastAt[e.id] = e.at
        if (e.at >= weekAgo) { val t = byId[e.id] ?: continue; wp++; ms += t.durationMs; artistWeek[t.artist] = (artistWeek[t.artist] ?: 0) + 1; if (e.at >= dayStart) tp++ }
    }
    val monthAgo = now - 30L * 86_400_000L
    val forgotten = lib.filter { (counts[it.id] ?: 0) >= 5 && (lastAt[it.id] ?: 0L) < monthAgo }.sortedByDescending { counts[it.id] ?: 0 }.take(lim)
    return HomeData(artists, albums, mixes, most, added, genres, forgotten, wp, ms / 3_600_000f, tp, artistWeek.maxByOrNull { it.value }?.key ?: "")
}

/** A cover collage: four covers when there are enough, otherwise one. */
@Composable
private fun Mosaic(tracks: List<Track>, size: androidx.compose.ui.unit.Dp, radius: androidx.compose.ui.unit.Dp = 18.dp) {
    val shape = RoundedCornerShape(radius)
    if (tracks.size >= 4) {
        Column(Modifier.size(size).clip(shape)) {
            Row(Modifier.weight(1f)) { AlbumArt(tracks[0], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp), 14.dp, 128); AlbumArt(tracks[1], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp), 14.dp, 128) }
            Row(Modifier.weight(1f)) { AlbumArt(tracks[2], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp), 14.dp, 128); AlbumArt(tracks[3], Modifier.weight(1f).fillMaxHeight(), RoundedCornerShape(0.dp), 14.dp, 128) }
        }
    } else AlbumArt(tracks.firstOrNull(), Modifier.size(size), shape, 30.dp, 256)
}

/** The Home tab: a full-screen start page with what is playing and shelves of queues, mixes, playlists, artists and songs. */
@Composable
fun HomeScreen(c: PlayerController, push: (Route) -> Unit, goTab: (String) -> Unit, openNow: () -> Unit) {
    val d = c.store.data
    val cs = MaterialTheme.colorScheme
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val hello = when { hour < 5 -> "Good night"; hour < 12 -> "Good morning"; hour < 17 -> "Good afternoon"; hour < 22 -> "Good evening"; else -> "Good night" }
    val byId = remember(c.library) { c.library.associateBy { it.id } }

    // cheap, always live: what you played last, favourites, more from the artist playing now
    val recent = remember(d.lastPlayed, byId) { d.lastPlayed.mapNotNull { byId[it] }.distinctBy { it.id }.take(12) }
    val favs = remember(d.favourites, byId) { d.favourites.mapNotNull { byId[it] }.take(12) }
    val cur = c.current
    val more = remember(cur?.id, c.library) {
        if (cur == null) emptyList() else c.library.filter { it.artist == cur.artist && it.id != cur.id }.shuffled().take(12)
    }

    // the heavy part is worked out in the background and kept: Home opens at once the next time and only refreshes behind the scenes
    var refreshN by remember { mutableIntStateOf(0) }
    var spin by remember { mutableStateOf(false) }
    val key = "$refreshN|${c.library.size}|${d.playCounts.size}|${d.playlists.size}|${c.playLog.events.size}|${System.currentTimeMillis() / 10_800_000L}"
    val data by androidx.compose.runtime.produceState(if (HomeCache.key.isNotEmpty()) HomeCache.data else null, key) {
        if (c.library.isEmpty()) return@produceState
        if (HomeCache.key != key || HomeCache.data == null) {
            val fresh = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { computeHome(c, (System.currentTimeMillis() / 10_800_000L).toInt() + refreshN * 7919) }
            HomeCache.key = key; HomeCache.data = fresh
            value = fresh
        } else value = HomeCache.data
        spin = false
    }

    @Composable
    fun Shelf(title: String, sub: String? = null, action: String? = null, onAction: () -> Unit = {}) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 26.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (sub != null) Text(sub, fontSize = 12.sp, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (action != null) Text(action, Modifier.clip(RoundedCornerShape(50)).background(cs.primary.copy(alpha = 0.12f)).bounceClick(onAction).padding(horizontal = 12.dp, vertical = 5.dp), color = cs.primary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
    }
    @Composable
    fun SongCard(t: Track, list: List<Track>, queueName: String) {
        Column(Modifier.width(128.dp).bounceClick { c.playInQueue(queueName, list, list.indexOf(t)) }) {
            Box {
                AlbumArt(t, Modifier.size(128.dp), RoundedCornerShape(20.dp), 32.dp, 256)
                Box(Modifier.align(Alignment.BottomEnd).padding(7.dp).size(28.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp), tint = Color.White)
                }
            }
            Text(t.title, Modifier.padding(top = 7.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
    }
    fun hue(name: String, light: Float = 0.42f, index: Int = -1): Brush {
        // names are mixed well before use (short names hash to nearly the same hue); a genre row also gets its own step round the colour wheel
        val mixed = (name.hashCode() * -1640531535) ushr 7
        val h = if (index >= 0) (index * 137.5f + (mixed % 40)) % 360f else (mixed % 360).toFloat()
        val a = Color(androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf(h, 0.58f, light)))
        val b = Color(androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf((h + 40f) % 360f, 0.62f, (light - 0.12f).coerceAtLeast(0.15f))))
        return Brush.linearGradient(listOf(a, b))
    }
    /** A square card: a cover collage with the name on a dark fade. Tap plays; hold opens. */
    @Composable
    fun CollageCard(title: String, sub: String, tracks: List<Track>, tint: Brush, onHold: (() -> Unit)? = null, onClick: () -> Unit) {
        val size = 150
        Box(
            Modifier.size(size.dp).clip(RoundedCornerShape(22.dp)).background(tint)
                .combinedClickable(onLongClick = onHold, onClick = onClick),
        ) {
            if (tracks.isNotEmpty()) Mosaic(tracks, size.dp, 22.dp)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.30f to Color.Transparent, 0.62f to Color.Black.copy(alpha = 0.72f), 1f to Color.Black.copy(alpha = 0.92f))))
            Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
                Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White, lineHeight = 17.sp, style = androidx.compose.ui.text.TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Color.Black, androidx.compose.ui.geometry.Offset(0f, 2f), 6f)))
                Text(sub, maxLines = 1, fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
            }
            Box(Modifier.align(Alignment.TopEnd).padding(8.dp).size(30.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.4f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.PlayArrow, null, Modifier.size(18.dp), tint = Color.White)
            }
        }
    }
    @Composable
    fun Skeleton() {
        val a by androidx.compose.animation.core.rememberInfiniteTransition(label = "sk").animateFloat(0.35f, 0.8f, androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(800), androidx.compose.animation.core.RepeatMode.Reverse), label = "ska")
        Column {
            repeat(2) {
                Box(Modifier.padding(start = 20.dp, top = 26.dp, bottom = 12.dp).width(140.dp).height(18.dp).clip(RoundedCornerShape(9.dp)).background(cs.onSurface.copy(alpha = a * 0.12f)))
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    repeat(3) { Box(Modifier.size(128.dp).clip(RoundedCornerShape(20.dp)).background(cs.onSurface.copy(alpha = a * 0.12f))) }
                }
            }
        }
    }

    val contin = remember(recent, d.positions) {
        d.lastPlayed.mapNotNull { byId[it] }.distinctBy { it.id }.filter { val p = d.positions[it.id] ?: 0L; p > 15_000L && p < it.durationMs - 15_000L }.take(10)
    }
    // pull down to get fresh mixes
    androidx.compose.material3.pulltorefresh.PullToRefreshBox(isRefreshing = spin, onRefresh = { spin = true; refreshN++ }, modifier = Modifier.fillMaxSize()) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 150.dp)) {
        // header: runs under the status bar
        item {
            Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(cs.primary.copy(alpha = 0.28f), Color.Transparent))).statusBarsPadding().padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 10.dp)) {
                Column {
                    Text(hello, fontSize = 32.sp, fontWeight = FontWeight.Black)
                    Text("${c.library.size} songs  ·  ${d.playlists.size} playlists  ·  ${d.queues.size} queues", color = cs.onSurfaceVariant, fontSize = 13.sp)
                }
            }
        }
        // now playing
        item {
            if (cur != null) Row(
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth().clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(cs.primaryContainer, cs.secondaryContainer))).bounceClick(openNow).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                AlbumArt(cur, Modifier.size(76.dp), RoundedCornerShape(20.dp), 28.dp, 256)
                Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                    Text(if (c.isPlaying) "NOW PLAYING" else "PAUSED", fontSize = 10.sp, letterSpacing = 1.2.sp, color = cs.onPrimaryContainer.copy(alpha = 0.7f), fontWeight = FontWeight.Bold)
                    Text(cur.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = cs.onPrimaryContainer)
                    Text(cur.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = cs.onPrimaryContainer.copy(alpha = 0.75f))
                    // progress through the song, and what comes next
                    val prog = if (c.durationMs > 0) (c.positionMs.toFloat() / c.durationMs).coerceIn(0f, 1f) else 0f
                    androidx.compose.material3.LinearProgressIndicator({ prog }, Modifier.padding(top = 8.dp).fillMaxWidth().height(3.dp).clip(RoundedCornerShape(50)), color = cs.primary, trackColor = cs.onPrimaryContainer.copy(alpha = 0.15f))
                    c.queue.getOrNull(c.currentIndex + 1)?.let { nx -> Text("Next: ${nx.title}", Modifier.padding(top = 5.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp, color = cs.onPrimaryContainer.copy(alpha = 0.65f)) }
                }
                Box(Modifier.size(50.dp).clip(CircleShape).background(cs.primary).bounceClick { c.togglePlay() }, contentAlignment = Alignment.Center) {
                    Icon(if (c.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, Modifier.size(28.dp), tint = cs.onPrimary)
                }
                Box(Modifier.padding(start = 6.dp).size(40.dp).clip(CircleShape).background(cs.onPrimaryContainer.copy(alpha = 0.1f)).bounceClick { c.next() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SkipNext, null, tint = cs.onPrimaryContainer)
                }
            }
        }
        // quick actions
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                @Composable
                fun Chip(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, filled: Boolean = false, onClick: () -> Unit) = Row(
                    Modifier.clip(RoundedCornerShape(50)).background(if (filled) cs.primary else cs.surfaceVariant.copy(alpha = 0.6f)).bounceClick(onClick).padding(vertical = 10.dp, horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(icon, null, Modifier.size(18.dp), tint = if (filled) cs.onPrimary else cs.primary)
                    Text("  $text", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, color = if (filled) cs.onPrimary else cs.onSurface)
                }
                Chip(Icons.Rounded.Shuffle, "Shuffle all", true) { if (c.library.isNotEmpty()) c.playInQueue("Shuffle all", c.library.shuffled(), 0, true) }
                Chip(Icons.Rounded.Favorite, "Favorites") { push(Route.Detail("smart", "fav")) }
                Chip(Icons.Rounded.LocalFireDepartment, "Most played") { push(Route.MostPlayed) }
                Chip(Icons.Rounded.AutoAwesome, "Smart mixes") { push(Route.Mixes) }
                Chip(Icons.Rounded.Star, "Year in review") { push(Route.YearReview) }
            }
        }
        // this week
        val dd = data
        if (dd != null && dd.weekPlays > 0) item {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp).fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(cs.surfaceVariant.copy(alpha = 0.5f)).padding(vertical = 14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                @Composable
                fun Stat(v: String, l: String) = Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(v, fontSize = 20.sp, fontWeight = FontWeight.Black, color = cs.primary)
                    Text(l, fontSize = 11.sp, color = cs.onSurfaceVariant)
                }
                Stat("${dd.todayPlays}", "plays today")
                Stat("${dd.weekPlays}", "this week")
                Stat("%.1f h".format(dd.weekHours), "listened")
            }
            if (dd.weekArtist.isNotBlank()) Text("Your artist this week: ${dd.weekArtist}", Modifier.padding(horizontal = 24.dp), fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
        // quick picks
        val picks = recent.take(6).ifEmpty { dd?.added?.take(6).orEmpty() }
        if (picks.isNotEmpty()) {
            item { Shelf("Quick picks") }
            item {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    picks.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { t ->
                                Row(
                                    Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(cs.surfaceVariant.copy(alpha = 0.5f))
                                        .bounceClick { c.playInQueue(if (recent.isNotEmpty()) "Recently played" else "Recently added", picks, picks.indexOf(t)) },
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    AlbumArt(t, Modifier.size(52.dp), RoundedCornerShape(16.dp), 20.dp, 128)
                                    Text(t.title, Modifier.padding(horizontal = 10.dp), maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 12.sp, lineHeight = 15.sp)
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        // queues: tap plays the queue where it stopped; hold opens the Queues tab
        val qs = d.queues
        if (qs.any { it.trackIds.isNotEmpty() }) {
            item { Shelf("Your queues", "Tap to play  ·  hold to open", "Open", { goTab("queues") }) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(qs.indices.filter { qs[it].trackIds.isNotEmpty() }) { i ->
                        val q = qs[i]
                        val ts = remember(q.trackIds, byId) { q.trackIds.take(4).mapNotNull { byId[it] } }
                        CollageCard(q.name, "${q.trackIds.size} songs" + if (i == c.activeQueue) " · playing" else "", ts, hue(q.name + i), { c.switchQueue(i); goTab("queues") }) {
                            if (i == c.activeQueue) { if (!c.isPlaying) c.play() }
                            else { c.switchQueue(i); if (c.queue.isNotEmpty()) c.play() }
                        }
                    }
                }
            }
        }
        // mixes
        if (contin.isNotEmpty()) {
            item { Shelf("Continue listening", "Songs you stopped part-way through") }
            item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(contin) { SongCard(it, contin, "Continue listening") } } }
        }
        if (dd == null && c.library.isNotEmpty()) item { Skeleton() }
        if (dd != null && dd.mixes.isNotEmpty()) {
            item { Shelf("Made for you", "Refreshes through the day", "All mixes", { push(Route.Mixes) }) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(dd.mixes) { m -> CollageCard(m.name, "${m.tracks.size} songs", m.tracks.take(4), hue(m.name, 0.40f)) { c.playInQueue(m.name, m.tracks, 0, false) } }
                }
            }
        }
        if (recent.size > 6) {
            item { Shelf("Jump back in", null, "All", { push(Route.Detail("smart", "played")) }) }
            item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(recent) { SongCard(it, recent, "Recently played") } } }
        }
        if (cur != null && more.isNotEmpty()) {
            item { Shelf("More from ${cur.artist}", "Because you are listening to ${cur.title}") }
            item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(more) { SongCard(it, more, "More from ${cur.artist}") } } }
        }
        // playlists
        if (d.playlists.isNotEmpty()) {
            item { Shelf("Playlists", "Tap to play  ·  hold to open", "All", { goTab("playlists") }) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(d.playlists.take(14)) { p ->
                        val ts = remember(p.trackIds, byId) { p.trackIds.mapNotNull { byId[it] } }
                        CollageCard(p.name, "${p.trackIds.size} songs", ts.take(4), hue(p.name), { push(Route.Detail("playlist", p.id)) }) { if (ts.isNotEmpty()) c.playInQueue(p.name, ts) }
                    }
                }
            }
        }
        // genres
        if (dd != null && dd.genres.isNotEmpty()) {
            item { Shelf("Browse by genre", null, "All", { goTab("genres") }) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    itemsIndexed(dd.genres) { gi, (g, n) ->
                        Column(Modifier.clip(RoundedCornerShape(18.dp)).background(hue(g, 0.38f, gi)).bounceClick { push(Route.Detail("genre", g)) }.padding(horizontal = 18.dp, vertical = 14.dp)) {
                            Text(g, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Text("$n songs", fontSize = 11.sp, color = Color.White.copy(alpha = 0.8f))
                        }
                    }
                }
            }
        }
        // top artists
        if (dd != null && dd.artists.isNotEmpty()) {
            item { Shelf("Your top artists", null, "All", { goTab("artists") }) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(dd.artists) { (n, _, t) ->
                        Column(Modifier.width(96.dp).bounceClick { push(Route.Detail("artist", n)) }, horizontalAlignment = Alignment.CenterHorizontally) {
                            AlbumArt(t, Modifier.size(96.dp), CircleShape, 32.dp, 256)
                            Text(n, Modifier.padding(top = 7.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
        if (dd != null && dd.most.isNotEmpty()) {
            item { Shelf("Most played", null, "More", { push(Route.MostPlayed) }) }
            item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(dd.most) { SongCard(it, dd.most, "Most played") } } }
        }
        if (dd != null && dd.forgotten.isNotEmpty()) {
            item { Shelf("Forgotten favourites", "Played a lot, not heard for a month") }
            item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(dd.forgotten) { SongCard(it, dd.forgotten, "Forgotten favourites") } } }
        }
        if (dd != null && dd.albums.isNotEmpty()) {
            item { Shelf("New albums", null, "All", { goTab("albums") }) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(dd.albums) { t ->
                        Column(Modifier.width(128.dp).bounceClick { push(Route.Detail("album", t.albumKey())) }) {
                            AlbumArt(t, Modifier.size(128.dp), RoundedCornerShape(14.dp), 32.dp, 256)
                            Text(t.album, Modifier.padding(top = 7.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = cs.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        if (dd != null && dd.added.isNotEmpty()) {
            item { Shelf("Recently added", null, "All", { push(Route.Detail("smart", "added")) }) }
            item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(dd.added) { SongCard(it, dd.added, "Recently added") } } }
        }
        if (favs.isNotEmpty()) {
            item { Shelf("Favourites", null, "All", { push(Route.Detail("smart", "fav")) }) }
            item { LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) { items(favs) { SongCard(it, favs, "Favourites") } } }
        }
    }
    }
}
