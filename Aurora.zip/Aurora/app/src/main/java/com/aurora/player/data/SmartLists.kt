package com.aurora.player.data

import kotlinx.serialization.Serializable

/** One condition of a smart playlist. [field] is one of [SMART_FIELDS]; [value] is text or a number. */
@Serializable
data class SmartRule(val field: String = "artist", val value: String = "")

@Serializable
data class SmartList(
    val id: String,
    val name: String,
    val rules: List<SmartRule> = emptyList(),
    val matchAll: Boolean = true,
    val limit: Int = 0, // 0 = no limit
)

/** Field id to its label in the editor. */
val SMART_FIELDS = listOf(
    "artist" to "Artist contains",
    "album" to "Album contains",
    "title" to "Title contains",
    "genre" to "Genre contains",
    "folder" to "Folder contains",
    "yearFrom" to "Year from",
    "yearTo" to "Year up to",
    "ratingMin" to "Rating at least (stars)",
    "playsMin" to "Played at least (times)",
    "playsMax" to "Played at most (times)",
    "addedDays" to "Added in the last (days)",
    "favourite" to "Is a favourite",
    "unplayed" to "Never played",
)

/** Rules that need no typed value. */
fun smartNeedsValue(field: String) = field != "favourite" && field != "unplayed"

fun smartFieldLabel(field: String) = SMART_FIELDS.firstOrNull { it.first == field }?.second ?: field

/** The songs a smart playlist currently holds. Rules with an empty or invalid value are ignored. */
fun smartTracks(lib: List<Track>, sl: SmartList, d: Persisted): List<Track> {
    val rules = sl.rules.filter { !smartNeedsValue(it.field) || it.value.isNotBlank() }
    if (rules.isEmpty()) return emptyList()
    val nowSec = System.currentTimeMillis() / 1000
    fun ok(t: Track, r: SmartRule): Boolean {
        val v = r.value.trim()
        val n = v.toIntOrNull()
        return when (r.field) {
            "artist" -> t.artist.contains(v, true)
            "album" -> t.album.contains(v, true)
            "title" -> t.title.contains(v, true)
            "genre" -> t.genre.contains(v, true)
            "folder" -> t.path.contains(v, true)
            "yearFrom" -> n == null || t.year >= n
            "yearTo" -> n == null || (t.year in 1..n)
            "ratingMin" -> n == null || (d.ratings[t.id] ?: 0) >= n
            "playsMin" -> n == null || (d.playCounts[t.id] ?: 0) >= n
            "playsMax" -> n == null || (d.playCounts[t.id] ?: 0) <= n
            "addedDays" -> n == null || t.dateAdded >= nowSec - n * 86_400L
            "favourite" -> t.id in d.favourites
            "unplayed" -> (d.playCounts[t.id] ?: 0) == 0
            else -> true
        }
    }
    val out = lib.filter { t -> if (sl.matchAll) rules.all { ok(t, it) } else rules.any { ok(t, it) } }
        .sortedBy { it.title.lowercase() }
    return if (sl.limit > 0) out.take(sl.limit) else out
}
