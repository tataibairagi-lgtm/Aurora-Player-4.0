package com.aurora.player.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

const val SPECTRUM_BANDS = 24

/** The 31 ISO third-octave centre frequencies, 20 Hz to 20 kHz. */
val EQ_FREQS = doubleArrayOf(
    20.0, 25.0, 31.5, 40.0, 50.0, 63.0, 80.0, 100.0, 125.0, 160.0, 200.0, 250.0, 315.0, 400.0, 500.0, 630.0,
    800.0, 1000.0, 1250.0, 1600.0, 2000.0, 2500.0, 3150.0, 4000.0, 5000.0, 6300.0, 8000.0, 10000.0, 12500.0, 16000.0, 20000.0,
)

/**
 * Aurora's own DSP: a 31-band graphic equalizer (peaking biquads, one per third-octave band),
 * mono mix-down and left/right balance. Works on 16-bit, 24-bit, 32-bit and float PCM, mono or stereo; other formats pass through untouched.
 */
@UnstableApi
class AuroraAudioProcessor : BaseAudioProcessor() {
    @Volatile var mono = false
    @Volatile var balance = 0 // -100 (left only) .. +100 (right only)
    /** Set when the DSP failed once: audio then passes through untouched so playback never stops because of the equalizer. */
    @Volatile var bypass = false

    /** Preamp in dB (-6..+9), applied to the sound itself so it works on every phone. */
    @Volatile var preampDb = 0.0

    /** Night sound: a gentle compressor that lowers loud parts and lifts quiet ones, so you can listen low without missing detail. */
    @Volatile var night = false
    private var env = 0.0
    private fun nightGain(level: Double): Double {
        val x = level / 32768.0
        env = if (x > env) env + (x - env) * 0.01 else env + (x - env) * 0.0004   // fast attack, slow release
        val th = 0.18
        val g = if (env > th) (th + (env - th) / 3.5) / env else 1.0
        return g * 1.5                                                           // make-up gain for the quiet parts
    }

    /** Live spectrum for the visualizer: [SPECTRUM_BANDS] values 0..1. Only computed while [visualizerOn]. */
    @Volatile var visualizerOn = false
    val spectrum = FloatArray(SPECTRUM_BANDS)
    private val fre = DoubleArray(512)
    private val fim = DoubleArray(512)

    @Volatile private var eqOn = false
    @Volatile private var gainsDb = DoubleArray(EQ_FREQS.size)
    @Volatile private var dirty = true
    private var sampleRate = 44100
    private var channels = 2
    private var enc = C.ENCODING_PCM_16BIT
    private var bytes = 2

    // active filters: coefficients and per-channel state
    private var n = 0
    private var b0 = DoubleArray(0); private var b1 = DoubleArray(0); private var b2 = DoubleArray(0)
    private var a1 = DoubleArray(0); private var a2 = DoubleArray(0)
    private var x1 = DoubleArray(0); private var x2 = DoubleArray(0); private var y1 = DoubleArray(0); private var y2 = DoubleArray(0)

    /** [levelsMb]: 31 gains in millibels (100 = 1 dB). */
    fun setEq(on: Boolean, levelsMb: List<Int>) {
        gainsDb = DoubleArray(EQ_FREQS.size) { (levelsMb.getOrElse(it) { 0 } / 100.0).coerceIn(-12.0, 12.0) }
        eqOn = on
        dirty = true
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        // after a failure the processor drops out of the audio chain completely
        if (bypass) return AudioProcessor.AudioFormat.NOT_SET
        val e = inputAudioFormat.encoding
        val supported = e == C.ENCODING_PCM_16BIT || e == C.ENCODING_PCM_24BIT || e == C.ENCODING_PCM_32BIT || e == C.ENCODING_PCM_FLOAT
        return if (supported && inputAudioFormat.channelCount in 1..2) {
            enc = e
            bytes = when (e) { C.ENCODING_PCM_16BIT -> 2; C.ENCODING_PCM_24BIT -> 3; else -> 4 }
            sampleRate = inputAudioFormat.sampleRate
            channels = inputAudioFormat.channelCount
            dirty = true
            inputAudioFormat
        } else AudioProcessor.AudioFormat.NOT_SET
    }

    override fun onFlush() { dirty = true }

    private fun rebuild() {
        dirty = false
        val g = gainsDb
        val idx = if (eqOn) EQ_FREQS.indices.filter { Math.abs(g[it]) >= 0.05 && EQ_FREQS[it] < sampleRate * 0.45 } else emptyList()
        n = idx.size
        b0 = DoubleArray(n); b1 = DoubleArray(n); b2 = DoubleArray(n); a1 = DoubleArray(n); a2 = DoubleArray(n)
        x1 = DoubleArray(n * 2); x2 = DoubleArray(n * 2); y1 = DoubleArray(n * 2); y2 = DoubleArray(n * 2)
        val q = 4.318 // one third of an octave
        idx.forEachIndexed { k, i ->
            val a = 10.0.pow(g[i] / 40.0)
            val w0 = 2.0 * PI * EQ_FREQS[i] / sampleRate
            val al = sin(w0) / (2.0 * q)
            val c = cos(w0)
            val a0 = 1.0 + al / a
            b0[k] = (1.0 + al * a) / a0; b1[k] = -2.0 * c / a0; b2[k] = (1.0 - al * a) / a0
            a1[k] = -2.0 * c / a0; a2[k] = (1.0 - al / a) / a0
        }
    }

    private var scratch: ByteBuffer = ByteBuffer.allocate(0)

    override fun queueInput(inputBuffer: ByteBuffer) {
        val count = inputBuffer.remaining()
        if (count == 0) return
        // The player can hand us the very buffer we write into (our previous output), and replaceOutputBuffer reuses it:
        // read the input into a private copy first, so input and output are never the same buffer.
        if (scratch.capacity() < count) scratch = ByteBuffer.allocate(count).order(java.nio.ByteOrder.nativeOrder())
        scratch.clear()
        scratch.put(inputBuffer)
        scratch.flip()
        if (visualizerOn) try { analyse(scratch) } catch (_: Throwable) { visualizerOn = false }
        val out = replaceOutputBuffer(count)
        if (!bypass) {
            try {
                process(scratch, out)
                out.flip()
                return
            } catch (_: Throwable) {
                bypass = true
                scratch.position(0)
                out.clear()
            }
        }
        out.put(scratch); out.flip()
    }

    /** Looks at the last 512 frames of this chunk (without consuming it) and updates [spectrum]. */
    private fun analyse(buf: ByteBuffer) {
        val frameBytes = bytes * channels
        if (frameBytes <= 0) return
        val frames = buf.remaining() / frameBytes
        if (frames < 64) return
        val take = minOf(512, frames)
        val d = buf.duplicate().order(java.nio.ByteOrder.nativeOrder())
        d.position(buf.position() + (frames - take) * frameBytes)
        for (i in 0 until 512) {
            if (i < take) {
                var s = 0.0
                for (ch in 0 until channels) s += read(d)
                val w = 0.5 - 0.5 * cos(2.0 * PI * i / (take - 1).coerceAtLeast(1))
                fre[i] = s / channels / 32768.0 * w
            } else fre[i] = 0.0
            fim[i] = 0.0
        }
        fft(fre, fim)
        // log-spaced bands between about 40 Hz and 16 kHz
        val binHz = sampleRate / 512.0
        val lo = 40.0; val hi = minOf(16000.0, sampleRate * 0.45)
        for (b in 0 until SPECTRUM_BANDS) {
            val f0 = lo * Math.pow(hi / lo, b.toDouble() / SPECTRUM_BANDS)
            val f1 = lo * Math.pow(hi / lo, (b + 1).toDouble() / SPECTRUM_BANDS)
            val i0 = (f0 / binHz).toInt().coerceIn(1, 255)
            val i1 = maxOf(i0 + 1, (f1 / binHz).toInt()).coerceAtMost(256)
            var m = 0.0
            for (i in i0 until i1) m = maxOf(m, Math.hypot(fre[i], fim[i]))
            // magnitude to a 0..1 level on a decibel scale
            val db = 20.0 * Math.log10(m * 4.0 + 1e-9)
            val v = ((db + 55.0) / 55.0).coerceIn(0.0, 1.0).toFloat()
            spectrum[b] = maxOf(v, spectrum[b] * 0.8f)
        }
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val t = re[i]; re[i] = re[j]; re[j] = t; val u = im[i]; im[i] = im[j]; im[j] = u }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wr = cos(ang); val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0; var ci = 0.0
                for (k in 0 until len / 2) {
                    val ur = re[i + k]; val ui = im[i + k]
                    val vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci
                    val vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr
                    re[i + k] = ur + vr; im[i + k] = ui + vi
                    re[i + k + len / 2] = ur - vr; im[i + k + len / 2] = ui - vi
                    val nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr
                }
                i += len
            }
            len = len shl 1
        }
    }

    private fun process(inputBuffer: ByteBuffer, out: ByteBuffer) {
        if (dirty) rebuild()
        val m = mono && channels == 2
        val b = if (channels == 2) balance else 0
        val pre = if (Math.abs(preampDb) < 0.05) 1.0 else 10.0.pow(preampDb / 20.0)
        val nt = night
        if (n == 0 && !m && b == 0 && pre == 1.0 && !nt) { out.put(inputBuffer); return }
        val gl = if (b > 0) (100 - b) / 100f else 1f
        val gr = if (b < 0) (100 + b) / 100f else 1f
        if (channels == 2) {
            while (inputBuffer.remaining() >= bytes * 2) {
                var l = read(inputBuffer)
                var r = read(inputBuffer)
                if (m) { val x = (l + r) / 2; l = x; r = x }
                for (k in 0 until n) { l = biquad(k, 0, l); r = biquad(k, 1, r) }
                val ng = if (nt) nightGain(maxOf(Math.abs(l), Math.abs(r))) else 1.0
                write(out, l * gl * pre * ng); write(out, r * gr * pre * ng)
            }
        } else {
            while (inputBuffer.remaining() >= bytes) {
                var s = read(inputBuffer)
                for (k in 0 until n) s = biquad(k, 0, s)
                write(out, s * pre * (if (nt) nightGain(Math.abs(s)) else 1.0))
            }
        }
        // a stray partial sample would otherwise never be consumed
        if (inputBuffer.hasRemaining()) out.put(inputBuffer)
    }

    /** One sample as a number on the 16-bit scale (-32768..32767), whatever the stream's bit depth. */
    private fun read(b: ByteBuffer): Double = when (enc) {
        C.ENCODING_PCM_24BIT -> {
            val v = (b.get().toInt() and 0xFF) or ((b.get().toInt() and 0xFF) shl 8) or (b.get().toInt() shl 16)
            v / 256.0
        }
        C.ENCODING_PCM_32BIT -> b.int / 65536.0
        C.ENCODING_PCM_FLOAT -> b.float * 32768.0
        else -> b.short.toDouble()
    }

    private fun write(b: ByteBuffer, v: Double) {
        when (enc) {
            C.ENCODING_PCM_24BIT -> {
                val x = (v * 256.0).coerceIn(-8388608.0, 8388607.0).toInt()
                b.put(x.toByte()); b.put((x shr 8).toByte()); b.put((x shr 16).toByte())
            }
            C.ENCODING_PCM_32BIT -> b.putInt((v * 65536.0).coerceIn(-2147483648.0, 2147483647.0).toInt())
            C.ENCODING_PCM_FLOAT -> b.putFloat((v / 32768.0).coerceIn(-1.0, 1.0).toFloat())
            else -> b.putShort(clip(v))
        }
    }

    private fun biquad(k: Int, ch: Int, x: Double): Double {
        val s = k * 2 + ch
        val y = b0[k] * x + b1[k] * x1[s] + b2[k] * x2[s] - a1[k] * y1[s] - a2[k] * y2[s]
        x2[s] = x1[s]; x1[s] = x; y2[s] = y1[s]; y1[s] = y
        return y
    }

    private fun clip(v: Double): Short = v.coerceIn(-32768.0, 32767.0).toInt().toShort()
}
