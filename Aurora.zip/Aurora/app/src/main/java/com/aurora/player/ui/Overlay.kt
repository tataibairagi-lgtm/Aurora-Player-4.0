package com.aurora.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.TextDecrease
import androidx.compose.material.icons.rounded.TextIncrease
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.player.data.indexAt
import com.aurora.player.player.PlayerController

/** Current line gets a left-to-right "karaoke" sweep that follows the playback position. */
@Composable
fun KaraokeText(text: String, progress: Float, sizeSp: Int, color: Color, modifier: Modifier = Modifier) {
    val p by animateFloatAsState(progress, tween(120, easing = LinearEasing), label = "karaoke")
    Box(modifier) {
        Text(
            text, color = color.copy(alpha = 0.38f), fontSize = sizeSp.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), lineHeight = (sizeSp * 1.25f).sp,
        )
        Text(
            text, color = color, fontSize = sizeSp.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, lineHeight = (sizeSp * 1.25f).sp,
            modifier = Modifier
                .fillMaxWidth()
                .drawWithContent {
                    clipRect(left = 0f, top = 0f, right = size.width * p, bottom = size.height) {
                        this@drawWithContent.drawContent()
                    }
                },
        )
    }
}

@Composable
fun OverlayContent(
    c: PlayerController,
    onDrag: (Float, Float) -> Unit,
    onDragEnd: () -> Unit,
    onClose: () -> Unit,
    onLock: () -> Unit,
) {
    val d = c.store.data
    val color = Color(d.overlayColor)
    val lyr = c.lyrics
    val pos = c.positionMs
    val idx = lyr?.indexAt(pos + d.lyricOffsetMs) ?: -1
    val t = c.current

    Column(
        Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(Color(0xB30D0D17))
            .pointerInput(Unit) {
                detectDragGestures(onDragEnd = onDragEnd) { change, drag ->
                    change.consume()
                    onDrag(drag.x, drag.y)
                }
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
        // control strip
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                t?.let { "${it.title} · ${it.artist}" } ?: "Aurora",
                color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
            )
            OverlayBtn(Icons.Rounded.SkipPrevious) { c.previous() }
            OverlayBtn(if (c.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow) { c.togglePlay() }
            OverlayBtn(Icons.Rounded.SkipNext) { c.next() }
            OverlayBtn(Icons.Rounded.TextDecrease) {
                c.store.update { it.copy(overlayTextSp = (it.overlayTextSp - 2).coerceAtLeast(12)) }
            }
            OverlayBtn(Icons.Rounded.TextIncrease) {
                c.store.update { it.copy(overlayTextSp = (it.overlayTextSp + 2).coerceAtMost(48)) }
            }
            OverlayBtn(Icons.Rounded.Lock, onClick = onLock)
            OverlayBtn(Icons.Rounded.Close, onClick = onClose)
        }

        val syncedLines = lyr?.takeIf { it.synced }?.lines
        if (syncedLines == null) {
            Text(
                when {
                    c.lyricsLoading -> "Looking for lyrics…"
                    lyr != null -> lyr.lines.firstOrNull()?.text ?: ""
                    else -> "No lyrics for this song"
                },
                color = color.copy(alpha = 0.8f), fontSize = d.overlayTextSp.sp, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            )
            return@Column
        }

        AnimatedContent(
            targetState = idx,
            transitionSpec = {
                (slideInVertically(tween(320)) { it / 2 } + fadeIn(tween(320))) togetherWith
                    (slideOutVertically(tween(260)) { -it / 2 } + fadeOut(tween(200)))
            },
            label = "overlayLine",
        ) { i ->
            Column(
                Modifier.fillMaxWidth().padding(top = 6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                val prev = syncedLines.getOrNull(i - 1)?.text.orEmpty()
                val cur = syncedLines.getOrNull(i)
                val next = syncedLines.getOrNull(i + 1)?.text.orEmpty()
                Text(
                    prev, color = color.copy(alpha = 0.4f), fontSize = (d.overlayTextSp * 0.65f).sp,
                    textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                val curText = cur?.text?.ifBlank { "♪" } ?: "♪"
                val start = cur?.timeMs ?: 0L
                val end = syncedLines.getOrNull(i + 1)?.timeMs ?: (start + 4000)
                val prog = if (cur == null || end <= start) 0f
                else ((pos - start).toFloat() / (end - start)).coerceIn(0f, 1f)
                KaraokeText(curText, prog, d.overlayTextSp, color)
                Text(
                    next, color = color.copy(alpha = 0.4f), fontSize = (d.overlayTextSp * 0.65f).sp,
                    textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun OverlayBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(
        Modifier.size(30.dp).bounceClick(onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(18.dp))
    }
}
