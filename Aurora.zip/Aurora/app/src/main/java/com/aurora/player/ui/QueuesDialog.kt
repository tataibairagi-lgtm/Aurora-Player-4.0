package com.aurora.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.player.PlayerController

/** Musicolet-style "Queues" dialog: pick the queue to view, drag to reorder, rename, delete. */
@Composable
fun QueuesDialog(c: PlayerController, onDismiss: () -> Unit) {
    val d = c.store.data
    var renameIdx by remember { mutableStateOf<Int?>(null) }
    var deleteIdx by remember { mutableStateOf<Int?>(null) }
    var removeOthers by remember { mutableStateOf(false) }
    val rowH = 52.dp
    val vq = c.viewQueue

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = null,
        title = { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.AutoMirrored.Rounded.QueueMusic, null); Text("  Queues") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                d.queues.forEachIndexed { i, q ->
                    var dy by remember(i) { mutableStateOf(0f) }
                    val density = androidx.compose.ui.platform.LocalDensity.current
                    val step = with(density) { rowH.toPx() }
                    Row(Modifier.fillMaxWidth().height(rowH), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.DragHandle, null,
                            Modifier.size(32.dp).pointerInput(d.queues.size) {
                                detectDragGestures(onDragEnd = { dy = 0f }, onDragCancel = { dy = 0f }) { change, amount ->
                                    change.consume()
                                    dy += amount.y
                                    // dragging past one row height swaps with the neighbour; the row index is read fresh each time
                                    val idx = c.store.data.queues.indexOfFirst { it === q }.let { if (it < 0) i else it }
                                    if (dy > step * 0.6f && idx < c.store.data.queues.lastIndex) { c.moveQueue(idx, idx + 1); dy = 0f }
                                    else if (dy < -step * 0.6f && idx > 0) { c.moveQueue(idx, idx - 1); dy = 0f }
                                }
                            },
                        )
                        RadioButton(selected = i == vq, onClick = { c.viewQueue = i })
                        Text("${i + 1}", Modifier.width(18.dp), style = MaterialTheme.typography.bodySmall)
                        Box(Modifier.size(20.dp), contentAlignment = Alignment.Center) {
                            if (i == c.activeQueue) Icon(Icons.Rounded.PlayArrow, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Text(
                            q.name, Modifier.weight(1f).clickable { c.viewQueue = i; onDismiss() },
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Icon(Icons.Rounded.Edit, null, Modifier.size(36.dp).clickable { renameIdx = i }.padding(8.dp))
                        Icon(Icons.Rounded.Close, null, Modifier.size(36.dp).clickable { deleteIdx = i }.padding(8.dp))
                    }
                }
                if (d.queues.size > 1) TextButton({ removeOthers = true }, Modifier.padding(top = 8.dp)) { Text("REMOVE ALL OTHER QUEUES") }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } },
    )

    renameIdx?.let { i ->
        NameDialog("Rename queue", d.queues.getOrNull(i)?.name ?: "", "Rename", { renameIdx = null }) { c.renameQueue(i, it); renameIdx = null }
    }
    deleteIdx?.let { i ->
        AlertDialog(
            onDismissRequest = { deleteIdx = null },
            title = { Text("Delete queue?") },
            text = { Text("“${d.queues.getOrNull(i)?.name ?: ""}” will be removed.") },
            confirmButton = { TextButton({ c.deleteQueue(i); deleteIdx = null }) { Text("Delete") } },
            dismissButton = { TextButton({ deleteIdx = null }) { Text("Cancel") } },
        )
    }
    if (removeOthers) AlertDialog(
        onDismissRequest = { removeOthers = false },
        title = { Text("Remove all other queues?") },
        text = { Text("Only the selected queue will be kept; playback moves to it.") },
        confirmButton = { TextButton({ c.removeOtherQueues(vq); removeOthers = false }) { Text("Remove") } },
        dismissButton = { TextButton({ removeOthers = false }) { Text("Cancel") } },
    )
}
