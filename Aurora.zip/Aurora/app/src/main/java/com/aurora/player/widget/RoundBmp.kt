package com.aurora.player.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF

/** Centre-crops to a square of at most [px] and rounds the corners (RemoteViews can't clip an ImageView reliably). */
fun roundedSquare(src: Bitmap, px: Int, radiusFrac: Float = 0.16f): Bitmap {
    val side = minOf(src.width, src.height)
    val out = minOf(px, side).coerceAtLeast(1)
    val res = Bitmap.createBitmap(out, out, Bitmap.Config.ARGB_8888)
    val c = Canvas(res)
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val r = out * radiusFrac
    c.drawRoundRect(RectF(0f, 0f, out.toFloat(), out.toFloat()), r, r, p)
    p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
    val sx = (src.width - side) / 2; val sy = (src.height - side) / 2
    c.drawBitmap(src, android.graphics.Rect(sx, sy, sx + side, sy + side), RectF(0f, 0f, out.toFloat(), out.toFloat()), p)
    return res
}
