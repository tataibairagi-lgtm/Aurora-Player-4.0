package com.aurora.player.data

import kotlinx.serialization.Serializable

data class Track(
    val id: Long,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val path: String,
    val dateAdded: Long,
    val trackNo: Int,
    val genre: String = "",
    val year: Int = 0,
    val size: Long = 0,
    val albumArtist: String = "",
    val composer: String = "",
) {
    val folder: String get() = path.substringBeforeLast('/', "")
    val folderName: String get() = folder.substringAfterLast('/')
}

@Serializable
data class Bookmark(val id: String, val trackId: Long, val posMs: Long, val note: String = "", val created: Long = 0)

@Serializable
data class Playlist(val id: String, val name: String, val trackIds: List<Long> = emptyList())

@Serializable
data class QueueData(
    val name: String,
    val trackIds: List<Long> = emptyList(),
    val index: Int = 0,
    val positionMs: Long = 0,
)

data class LyricWord(val timeMs: Long, val text: String)

data class LyricLine(val timeMs: Long, val text: String, val words: List<LyricWord>? = null)

/** Splits a line into words with estimated times (used when the .lrc has no word timing), weighted by word length. */
fun estimateWords(line: LyricLine, endMs: Long): List<LyricWord> {
    val parts = Regex("""\S+\s*""").findAll(line.text).map { it.value }.toList()
    if (parts.size < 2) return parts.map { LyricWord(line.timeMs, it) }
    val span = (if (endMs > line.timeMs) endMs - line.timeMs else 4000L).coerceIn(600L, 9000L) * 9 / 10
    val total = parts.sumOf { it.trim().length + 1 }.toFloat()
    var acc = 0f
    return parts.map { w ->
        val t = line.timeMs + (span * acc / total).toLong()
        acc += w.trim().length + 1
        LyricWord(t, w)
    }
}

class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

/** Index of the line that should be highlighted at [posMs], or -1 before the first line. */
fun Lyrics.indexAt(posMs: Long): Int {
    if (!synced) return -1
    var lo = 0
    var hi = lines.lastIndex
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].timeMs <= posMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
    }
    return ans
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

/** One equalizer setup. Musicolet keeps a separate one per audio output (speaker, headphones, Bluetooth...). */
@Serializable
data class EqProfile(
    val enabled: Boolean = false,
    val levels: List<Int> = emptyList(),
    val bass: Int = 0,        // 0..1000
    val virtualizer: Int = 0, // 0..1000
    val loudness: Int = 0,    // millibels of extra gain, 0..1500
    val preset: String = "Custom",
)

@Serializable
data class EqPreset(val name: String, val levels: List<Int>)


/**
 * Identifies the album a song belongs to. MediaStore's own album id splits one album in several when the songs have
 * different (featured) artists, so albums are matched by name plus album artist, or by name plus folder when the album
 * artist isn't tagged.
 */
fun Track.albumKey(): String = AlbumIndex.keyOf(this)

/**
 * Groups songs into albums by album NAME. If the same name belongs to different album artists (two different
 * "Greatest Hits"), those are kept apart; songs with no album artist join the group of their own artist, or the biggest group.
 */
object AlbumIndex {
    @Volatile private var keys: Map<Long, String> = emptyMap()
    /** "Album merge strategy": true = songs with the same album name are always one album, whoever the artist is. */
    @Volatile var mergeByName = false

    private fun related(a: String, b: String) = a.length > 1 && b.length > 1 && (a == b || a.startsWith("$b ") || b.startsWith("$a ") || " $a ".contains(" $b ") || " $b ".contains(" $a "))

    fun norm(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    fun keyOf(t: Track): String = keys[t.id] ?: (norm(t.album) + "::")

    fun rebuild(tracks: List<Track>) {
        val out = HashMap<Long, String>(tracks.size * 2)
        val byName = tracks.groupBy { norm(it.album) }
        for ((name, list) in byName) {
            val generic = name.isEmpty() || name == "unknown album" || name == "unknown" || name == "<unknown>"
            if (generic) {
                for (t in list) out[t.id] = "$name::" + norm(t.artist.ifBlank { t.albumArtist })
                continue
            }
            if (mergeByName) { for (t in list) out[t.id] = "$name::"; continue }
            val owners = list.map { norm(it.albumArtist) }.filter { it.isNotEmpty() }.groupingBy { it }.eachCount()
            if (owners.size <= 1) {
                for (t in list) out[t.id] = "$name::"
                continue
            }
            // album artists that share a name ("Alan Walker" and "Alan Walker, Au/Ra") are the same owner; only unrelated artists split an album name
            val names = owners.keys.toList()
            val parent = IntArray(names.size) { it }
            fun find(x: Int): Int { var r = x; while (parent[r] != r) r = parent[r]; return r }
            val toks = names.map { n -> n.split(' ').filter { it.length > 1 }.toSet() }
            for (i in names.indices) for (j in i + 1 until names.size) {
                if (related(names[i], names[j]) && toks[i].isNotEmpty() && toks[j].isNotEmpty()) parent[find(i)] = find(j)
            }
            val groupOf = names.indices.associate { names[it] to find(it) }
            val groups = names.indices.groupBy { find(it) }
            val label = groups.mapValues { (_, idx) -> idx.maxByOrNull { owners[names[it]] ?: 0 }!!.let { names[it] } }
            if (groups.size <= 1) {
                for (t in list) out[t.id] = "$name::"
                continue
            }
            val biggest = groups.keys.maxByOrNull { g -> groups[g]!!.sumOf { owners[names[it]] ?: 0 } }!!
            for (t in list) {
                val o = norm(t.albumArtist)
                val g = when {
                    o.isNotEmpty() -> groupOf[o]!!
                    else -> names.indices.firstOrNull { i -> related(norm(t.artist), names[i]) }?.let { find(it) } ?: biggest
                }
                out[t.id] = "$name::" + label[g]
            }
        }
        keys = out
    }
}
