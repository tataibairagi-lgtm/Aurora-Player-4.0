package com.aurora.player.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/** The 31 ISO third-octave centre frequencies, 20 Hz to 20 kHz. */
val EQ_FREQS = doubleArrayOf(
    20.0, 25.0, 31.5, 40.0, 50.0, 63.0, 80.0, 100.0, 125.0, 160.0, 200.0, 250.0, 315.0, 400.0, 500.0, 630.0,
    800.0, 1000.0, 1250.0, 1600.0, 2000.0, 2500.0, 3150.0, 4000.0, 5000.0, 6300.0, 8000.0, 10000.0, 12500.0, 16000.0, 20000.0,
)

/**
 * Aurora's own DSP: a 31-band graphic equalizer (peaking biquads, one per third-octave band),
 * mono mix-down and left/right balance. Works on 16-bit, 24-bit, 32-bit and float PCM, mono or stereo; other formats pass through untouched.
 */
@UnstableApi
class AuroraAudioProcessor : BaseAudioProcessor() {
    @Volatile var mono = false
    @Volatile var balance = 0 // -100 (left only) .. +100 (right only)
    /** Set when the DSP failed once: audio then passes through untouched so playback never stops because of the equalizer. */
    @Volatile var bypass = false

    @Volatile private var eqOn = false
    @Volatile private var gainsDb = DoubleArray(EQ_FREQS.size)
    @Volatile private var dirty = true
    private var sampleRate = 44100
    private var channels = 2
    private var enc = C.ENCODING_PCM_16BIT
    private var bytes = 2

    // active filters: coefficients and per-channel state
    private var n = 0
    private var b0 = DoubleArray(0); private var b1 = DoubleArray(0); private var b2 = DoubleArray(0)
    private var a1 = DoubleArray(0); private var a2 = DoubleArray(0)
    private var x1 = DoubleArray(0); private var x2 = DoubleArray(0); private var y1 = DoubleArray(0); private var y2 = DoubleArray(0)

    /** [levelsMb]: 31 gains in millibels (100 = 1 dB). */
    fun setEq(on: Boolean, levelsMb: List<Int>) {
        gainsDb = DoubleArray(EQ_FREQS.size) { (levelsMb.getOrElse(it) { 0 } / 100.0).coerceIn(-12.0, 12.0) }
        eqOn = on
        dirty = true
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        // after a failure the processor drops out of the audio chain completely
        if (bypass) return AudioProcessor.AudioFormat.NOT_SET
        val e = inputAudioFormat.encoding
        val supported = e == C.ENCODING_PCM_16BIT || e == C.ENCODING_PCM_24BIT || e == C.ENCODING_PCM_32BIT || e == C.ENCODING_PCM_FLOAT
        return if (supported && inputAudioFormat.channelCount in 1..2) {
            enc = e
            bytes = when (e) { C.ENCODING_PCM_16BIT -> 2; C.ENCODING_PCM_24BIT -> 3; else -> 4 }
            sampleRate = inputAudioFormat.sampleRate
            channels = inputAudioFormat.channelCount
            dirty = true
            inputAudioFormat
        } else AudioProcessor.AudioFormat.NOT_SET
    }

    override fun onFlush() { dirty = true }

    private fun rebuild() {
        dirty = false
        val g = gainsDb
        val idx = if (eqOn) EQ_FREQS.indices.filter { Math.abs(g[it]) >= 0.05 && EQ_FREQS[it] < sampleRate * 0.45 } else emptyList()
        n = idx.size
        b0 = DoubleArray(n); b1 = DoubleArray(n); b2 = DoubleArray(n); a1 = DoubleArray(n); a2 = DoubleArray(n)
        x1 = DoubleArray(n * 2); x2 = DoubleArray(n * 2); y1 = DoubleArray(n * 2); y2 = DoubleArray(n * 2)
        val q = 4.318 // one third of an octave
        idx.forEachIndexed { k, i ->
            val a = 10.0.pow(g[i] / 40.0)
            val w0 = 2.0 * PI * EQ_FREQS[i] / sampleRate
            val al = sin(w0) / (2.0 * q)
            val c = cos(w0)
            val a0 = 1.0 + al / a
            b0[k] = (1.0 + al * a) / a0; b1[k] = -2.0 * c / a0; b2[k] = (1.0 - al * a) / a0
            a1[k] = -2.0 * c / a0; a2[k] = (1.0 - al / a) / a0
        }
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val start = inputBuffer.position()
        val out = replaceOutputBuffer(inputBuffer.remaining())
        if (!bypass) {
            try {
                process(inputBuffer, out)
                out.flip()
                return
            } catch (_: Throwable) {
                bypass = true
                inputBuffer.position(start)
                out.clear()
            }
        }
        out.put(inputBuffer); out.flip()
    }

    private fun process(inputBuffer: ByteBuffer, out: ByteBuffer) {
        if (dirty) rebuild()
        val m = mono && channels == 2
        val b = if (channels == 2) balance else 0
        if (n == 0 && !m && b == 0) { out.put(inputBuffer); return }
        val gl = if (b > 0) (100 - b) / 100f else 1f
        val gr = if (b < 0) (100 + b) / 100f else 1f
        if (channels == 2) {
            while (inputBuffer.remaining() >= bytes * 2) {
                var l = read(inputBuffer)
                var r = read(inputBuffer)
                if (m) { val x = (l + r) / 2; l = x; r = x }
                for (k in 0 until n) { l = biquad(k, 0, l); r = biquad(k, 1, r) }
                write(out, l * gl); write(out, r * gr)
            }
        } else {
            while (inputBuffer.remaining() >= bytes) {
                var s = read(inputBuffer)
                for (k in 0 until n) s = biquad(k, 0, s)
                write(out, s)
            }
        }
        // a stray partial sample would otherwise never be consumed
        if (inputBuffer.hasRemaining()) out.put(inputBuffer)
    }

    /** One sample as a number on the 16-bit scale (-32768..32767), whatever the stream's bit depth. */
    private fun read(b: ByteBuffer): Double = when (enc) {
        C.ENCODING_PCM_24BIT -> {
            val v = (b.get().toInt() and 0xFF) or ((b.get().toInt() and 0xFF) shl 8) or (b.get().toInt() shl 16)
            v / 256.0
        }
        C.ENCODING_PCM_32BIT -> b.int / 65536.0
        C.ENCODING_PCM_FLOAT -> b.float * 32768.0
        else -> b.short.toDouble()
    }

    private fun write(b: ByteBuffer, v: Double) {
        when (enc) {
            C.ENCODING_PCM_24BIT -> {
                val x = (v * 256.0).coerceIn(-8388608.0, 8388607.0).toInt()
                b.put(x.toByte()); b.put((x shr 8).toByte()); b.put((x shr 16).toByte())
            }
            C.ENCODING_PCM_32BIT -> b.putInt((v * 65536.0).coerceIn(-2147483648.0, 2147483647.0).toInt())
            C.ENCODING_PCM_FLOAT -> b.putFloat((v / 32768.0).coerceIn(-1.0, 1.0).toFloat())
            else -> b.putShort(clip(v))
        }
    }

    private fun biquad(k: Int, ch: Int, x: Double): Double {
        val s = k * 2 + ch
        val y = b0[k] * x + b1[k] * x1[s] + b2[k] * x2[s] - a1[k] * y1[s] - a2[k] * y2[s]
        x2[s] = x1[s]; x1[s] = x; y2[s] = y1[s]; y1[s] = y
        return y
    }

    private fun clip(v: Double): Short = v.coerceIn(-32768.0, 32767.0).toInt().toShort()
}
