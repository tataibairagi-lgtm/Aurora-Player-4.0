package com.aurora.player.backup

import android.content.Context
import android.net.Uri
import android.provider.MediaStore.MediaColumns as M
import androidx.documentfile.provider.DocumentFile
import com.aurora.player.data.LyricsRepo
import com.aurora.player.data.PlayEvent
import com.aurora.player.data.Persisted
import com.aurora.player.data.Playlist
import com.aurora.player.data.QueueData
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Songs are identified by path/title/artist/duration, not by MediaStore id: ids change when you
 * reinstall, rescan or move to a new phone, so a backup must not depend on them.
 */
@Serializable
data class TrackRef(val path: String, val title: String, val artist: String, val album: String, val durationMs: Long)

@Serializable
data class BPlaylist(val name: String, val tracks: List<TrackRef>)

@Serializable
data class BCount(val ref: TrackRef, val count: Int)

@Serializable
data class BQueue(val name: String, val tracks: List<TrackRef>, val index: Int, val positionMs: Long)

@Serializable
data class BPlay(val ref: TrackRef, val at: Long)

@Serializable
data class BLyric(val ref: TrackRef, val file: String)

@Serializable
data class BackupData(
    val format: Int = 1,
    val app: String = "Aurora",
    val createdAt: Long = 0,
    val settings: Persisted = Persisted(),
    val favourites: List<TrackRef> = emptyList(),
    val playlists: List<BPlaylist> = emptyList(),
    val playCounts: List<BCount> = emptyList(),
    val lastPlayed: List<TrackRef> = emptyList(),
    val queues: List<BQueue> = emptyList(),
    val activeQueue: Int = 0,
    val playLog: List<BPlay> = emptyList(),
    val lyrics: List<BLyric> = emptyList(),
)

class LoadedBackup(val data: BackupData, val lyricFiles: Map<String, ByteArray>)

enum class ConflictMode(val label: String, val help: String) {
    Skip("Skip", "Keep your current playlist, ignore the one in the backup"),
    Replace("Replace", "Your current playlist is replaced by the one in the backup"),
    Merge("Merge", "Songs only the backup has are added to your current playlist"),
    KeepBoth("Keep both", "Your playlist stays; the backup's is added under a new name"),
}

class RestoreOptions(
    val settings: Boolean,
    val favourites: Boolean,
    val playlistNames: Set<String>,
    val mode: ConflictMode,
    val playCountsAndQueues: Boolean,
    val lyrics: Boolean,
)

class RestoreResult(
    val favourites: Int, val playlists: Int, val skippedSongs: Int, val lyrics: Int,
)

class BackupFile(val name: String, val uri: Uri, val modified: Long, val size: Long)

object BackupManager {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    const val PREFIX = "Aurora_backup_"
    private const val DATA_ENTRY = "backup.json"

    fun ref(t: Track) = TrackRef(t.path, t.title, t.artist, t.album, t.durationMs)

    fun newFileName(): String =
        PREFIX + SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date()) + ".zip"

    // ------------------------------------------------------------------------------------------
    // Create
    // ------------------------------------------------------------------------------------------

    fun write(c: PlayerController, out: OutputStream) {
        val store = c.store
        val d = store.data
        val byId = c.library.associateBy { it.id }
        fun refs(ids: Collection<Long>) = ids.mapNotNull { byId[it]?.let(::ref) }

        val lyricFiles = LinkedHashMap<String, ByteArray>()
        val lyricIndex = ArrayList<BLyric>()
        val dir = c.lyricsRepo.dir
        for (t in c.library) {
            val f = File(dir, "${t.id}.lrc")
            if (f.exists()) {
                val name = "lyrics/${lyricIndex.size}.lrc"
                lyricFiles[name] = f.readBytes()
                lyricIndex += BLyric(ref(t), name)
            }
        }

        val data = BackupData(
            createdAt = System.currentTimeMillis(),
            // personal lists live in their own fields; strip them (and the device-specific backup settings) here
            settings = d.copy(
                favourites = emptyList(), playlists = emptyList(), queues = emptyList(),
                playCounts = emptyMap(), lastPlayed = emptyList(),
                backupFolder = "", autoBackup = false, lastBackupAt = 0,
            ),
            favourites = refs(d.favourites),
            playlists = d.playlists.map { BPlaylist(it.name, refs(it.trackIds)) },
            playCounts = d.playCounts.mapNotNull { (id, n) -> byId[id]?.let { BCount(ref(it), n) } },
            lastPlayed = refs(d.lastPlayed),
            queues = d.queues.map { BQueue(it.name, refs(it.trackIds), it.index, it.positionMs) },
            activeQueue = d.activeQueue,
            playLog = c.playLog.events.mapNotNull { e -> byId[e.id]?.let { BPlay(ref(it), e.at) } },
            lyrics = lyricIndex,
        )

        ZipOutputStream(out.buffered()).use { zip ->
            zip.putNextEntry(ZipEntry(DATA_ENTRY))
            zip.write(json.encodeToString(data).toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            for ((name, bytes) in lyricFiles) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(bytes)
                zip.closeEntry()
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    // Read
    // ------------------------------------------------------------------------------------------

    /** Returns null if the stream isn't an Aurora backup (e.g. a Musicolet backup, which is encrypted). */
    fun read(input: InputStream): LoadedBackup? {
        val buf = input.readBytes()
        MusicoletImport.read(buf.inputStream())?.let { return it }
        return readAurora(buf.inputStream())
    }

    private fun readAurora(input: InputStream): LoadedBackup? {
        var data: BackupData? = null
        val lyrics = HashMap<String, ByteArray>()
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (e.isDirectory) continue
                val bytes = ByteArrayOutputStream().also { zip.copyTo(it) }.toByteArray()
                when {
                    e.name == DATA_ENTRY -> data = try {
                        json.decodeFromString<BackupData>(bytes.toString(Charsets.UTF_8))
                    } catch (_: Exception) {
                        null
                    }
                    e.name.startsWith("lyrics/") -> lyrics[e.name] = bytes
                }
            }
        }
        val d = data ?: return null
        return if (d.app == "Aurora") LoadedBackup(d, lyrics) else null
    }

    // ------------------------------------------------------------------------------------------
    // Restore
    // ------------------------------------------------------------------------------------------

    private class Matcher(library: List<Track>) {
        private val byPath = library.filter { it.path.isNotEmpty() }.associateBy { it.path }
        private val byKey = library.groupBy { key(it.title, it.artist) }
        fun find(r: TrackRef): Track? {
            byPath[r.path]?.let { return it }
            if (r.title.isBlank()) return null
            val c = byKey[key(r.title, r.artist)] ?: return null
            return c.minByOrNull { Math.abs(it.durationMs - r.durationMs) }
                ?.takeIf { Math.abs(it.durationMs - r.durationMs) <= 3000 }
        }

        private fun key(t: String, a: String) = t.trim().lowercase() + "\u0001" + a.trim().lowercase()
    }

    fun restore(c: PlayerController, b: LoadedBackup, o: RestoreOptions): RestoreResult {
        val m = Matcher(c.library)
        val store = c.store
        var skipped = 0
        fun ids(refs: List<TrackRef>): List<Long> {
            val out = ArrayList<Long>()
            for (r in refs) {
                val t = m.find(r)
                if (t == null) skipped++ else if (t.id !in out) out += t.id
            }
            return out
        }

        var favCount = 0
        if (o.favourites) {
            val ids = ids(b.data.favourites)
            store.update { it.copy(favourites = it.favourites + ids.filter { id -> id !in it.favourites }) }
            favCount = ids.size
        }

        var plCount = 0
        for (bp in b.data.playlists.filter { it.name in o.playlistNames }) {
            val songs = ids(bp.tracks)
            val existing = store.data.playlists.find { it.name.equals(bp.name, ignoreCase = true) }
            when {
                existing == null -> { store.createPlaylist(bp.name, songs); plCount++ }
                o.mode == ConflictMode.Skip -> {}
                o.mode == ConflictMode.Replace -> {
                    store.update { p -> p.copy(playlists = p.playlists.map { if (it.id == existing.id) it.copy(trackIds = songs) else it }) }
                    plCount++
                }
                o.mode == ConflictMode.Merge -> { store.addToPlaylist(existing.id, songs); plCount++ }
                o.mode == ConflictMode.KeepBoth -> {
                    var n = 2
                    var name = "${bp.name} ($n)"
                    while (store.data.playlists.any { it.name == name }) name = "${bp.name} (${++n})"
                    store.createPlaylist(name, songs); plCount++
                }
            }
        }

        if (o.playCountsAndQueues) {
            val counts = HashMap<Long, Int>()
            for (pc in b.data.playCounts) m.find(pc.ref)?.let { counts[it.id] = pc.count }
            val last = ids(b.data.lastPlayed)
            if (b.data.playLog.isNotEmpty()) {
                c.playLog.replaceAll(b.data.playLog.mapNotNull { p -> m.find(p.ref)?.let { PlayEvent(p.at, it.id) } })
            }
            val queues = b.data.queues.map { q ->
                val tracks = ids(q.tracks)
                QueueData(q.name, tracks, q.index.coerceIn(0, (tracks.size - 1).coerceAtLeast(0)), q.positionMs)
            }
            store.update {
                it.copy(
                    playCounts = counts, lastPlayed = last,
                    queues = if (queues.isNotEmpty()) queues else it.queues,
                    activeQueue = b.data.activeQueue.coerceIn(0, (queues.size - 1).coerceAtLeast(0)),
                )
            }
            c.reloadQueueFromStore()
        }

        if (o.settings) {
            val s = b.data.settings
            // every setting in the backup is restored; only the things that belong to this phone or to other restore options stay as they are
            store.update {
                s.copy(
                    favourites = it.favourites, playlists = it.playlists, queues = it.queues, activeQueue = it.activeQueue,
                    playCounts = it.playCounts, lastPlayed = it.lastPlayed,
                    backupFolder = it.backupFolder, autoBackup = it.autoBackup, lastBackupAt = it.lastBackupAt,
                    // the compatibility switches describe how well this particular phone copes, so they are not copied over
                    soundEngine = it.soundEngine, customNotif = it.customNotif, widgetsLive = it.widgetsLive,
                    qsTileLive = it.qsTileLive, fastLyrics = it.fastLyrics, safeNote = it.safeNote,
                )
            }
            com.aurora.player.ui.ArtLoader.enabled = s.loadArt
            c.setSpeedPitch(s.speed, s.pitch)
            c.reapplyEffects()
            // put every restored setting to work right away, not only after the next start
            runCatching { c.applyPlaybackPrefs() }
            runCatching { c.updateShake() }
            runCatching { com.aurora.player.data.AlbumIndex.rebuild(c.library) }
            runCatching { c.refreshWidgets() }
        }

        var lyr = 0
        if (o.lyrics) {
            for (l in b.data.lyrics) {
                val t = m.find(l.ref) ?: continue
                val bytes = b.lyricFiles[l.file] ?: continue
                c.lyricsRepo.save(t, bytes.toString(Charsets.UTF_8))
                lyr++
            }
        }
        return RestoreResult(favCount, plCount, skipped, lyr)
    }

    // ------------------------------------------------------------------------------------------
    // Backup folder (Storage Access Framework tree chosen by the user)
    // ------------------------------------------------------------------------------------------

    /** Where automatic backups go when no folder was chosen: Documents/Aurora/Backups/Automatic backups. */
    private const val DEFAULT_DIR = "Documents/Aurora/Backups/Automatic backups/"

    private fun defaultCollection() = android.provider.MediaStore.Files.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)

    private fun listDefault(ctx: Context): List<BackupFile> {
        val out = ArrayList<BackupFile>()
        try {
            ctx.contentResolver.query(
                defaultCollection(), arrayOf(M._ID, M.DISPLAY_NAME, M.DATE_MODIFIED, M.SIZE),
                "${M.RELATIVE_PATH} = ? AND ${M.DISPLAY_NAME} LIKE ?", arrayOf(DEFAULT_DIR, "%.zip"), "${M.DATE_MODIFIED} DESC",
            )?.use { q ->
                while (q.moveToNext()) {
                    out.add(BackupFile(q.getString(1), android.content.ContentUris.withAppendedId(defaultCollection(), q.getLong(0)), q.getLong(2) * 1000, q.getLong(3)))
                }
            }
        } catch (_: Exception) {}
        return out
    }

    private fun backupToDefault(ctx: Context, c: PlayerController): Boolean {
        return try {
            val v = android.content.ContentValues().apply {
                put(M.DISPLAY_NAME, newFileName())
                put(M.MIME_TYPE, "application/zip")
                put(M.RELATIVE_PATH, DEFAULT_DIR)
                put(M.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(defaultCollection(), v) ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { write(c, it) } ?: return false
            v.clear(); v.put(M.IS_PENDING, 0)
            ctx.contentResolver.update(uri, v, null, null)
            c.store.update { it.copy(lastBackupAt = System.currentTimeMillis()) }
            val keep = c.store.data.autoBackupKeep.coerceAtLeast(1)
            listDefault(ctx).filter { it.name.startsWith(PREFIX) }.drop(keep).forEach { runCatching { ctx.contentResolver.delete(it.uri, null, null) } }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun listBackups(ctx: Context, folder: String): List<BackupFile> {
        if (folder.isEmpty()) return listDefault(ctx)
        val dir = DocumentFile.fromTreeUri(ctx, Uri.parse(folder)) ?: return emptyList()
        return try {
            dir.listFiles()
                .filter { it.isFile && (it.name ?: "").let { n -> n.endsWith(".zip") } }
                .map { BackupFile(it.name ?: "backup.zip", it.uri, it.lastModified(), it.length()) }
                .sortedByDescending { it.modified }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /** Writes a new backup into the chosen folder and prunes old Aurora backups. Returns false on failure. */
    fun backupToFolder(ctx: Context, c: PlayerController): Boolean {
        val folder = c.store.data.backupFolder
        if (folder.isEmpty()) return backupToDefault(ctx, c)
        return try {
            val dir = DocumentFile.fromTreeUri(ctx, Uri.parse(folder)) ?: return false
            if (!dir.canWrite()) return false
            val file = dir.createFile("application/zip", newFileName()) ?: return false
            ctx.contentResolver.openOutputStream(file.uri)?.use { write(c, it) } ?: return false
            c.store.update { it.copy(lastBackupAt = System.currentTimeMillis()) }
            val keep = c.store.data.autoBackupKeep.coerceAtLeast(1)
            dir.listFiles()
                .filter { (it.name ?: "").startsWith(PREFIX) }
                .sortedByDescending { it.lastModified() }
                .drop(keep)
                .forEach { runCatching { it.delete() } }
            true
        } catch (_: Exception) {
            false
        }
    }
}
