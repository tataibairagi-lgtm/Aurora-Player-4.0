package com.aurora.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.positionChange
import kotlin.math.roundToInt
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest
import androidx.compose.animation.animateContentSize
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

private fun csvCell(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

fun queueCsv(tracks: List<Track>): String = buildString {
    append("Position,Title,Artist,Album,Duration (s),Path\n")
    tracks.forEachIndexed { i, t ->
        append("${i + 1},${csvCell(t.title)},${csvCell(t.artist)},${csvCell(t.album)},${t.durationMs / 1000},${csvCell(t.path)}\n")
    }
}

fun queueM3u8(tracks: List<Track>): String = buildString {
    append("#EXTM3U\n")
    tracks.forEach { t -> append("#EXTINF:${t.durationMs / 1000},${t.artist} - ${t.title}\n${t.path}\n") }
}

/** Musicolet-style queues page: up to 20 queues, drag to reorder, multi-select with options, search, export. */
@Composable
fun QueueScreen(c: PlayerController, back: () -> Unit, embedded: Boolean = false) {
    val actions = LocalActions.current
    val state = rememberLazyListState()
    var query by remember { mutableStateOf("") }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var saveDialog by remember { mutableStateOf(false) }
    var newDialog by remember { mutableStateOf(false) }
    var renameDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    // --- drag & drop: while a finger is down nothing in the player changes, the rows only slide out of the way;
    // the move is committed once, when the finger lifts (so the playing song is never interrupted mid-drag)
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragDy by remember { mutableFloatStateOf(0f) }
    // top edge of the dragged row in screen terms: follows the finger no matter how the rows above it fold or the list scrolls
    var dragTop by remember { mutableFloatStateOf(0f) }
    var dragFrom by remember { mutableIntStateOf(-1) }
    var dragTo by remember { mutableIntStateOf(-1) }
    var dragH by remember { mutableFloatStateOf(0f) }
    var blockDrag by remember { mutableStateOf(false) }
    var settleKey by remember { mutableStateOf<String?>(null) }
    var settleY by remember { mutableFloatStateOf(0f) }
    var noAnim by remember { mutableStateOf(false) }
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val d = c.store.data
    val vq = c.viewQueue.coerceIn(0, (d.queues.size - 1).coerceAtLeast(0))
    val isLive = vq == c.activeQueue
    val vt = c.viewTracks(vq)
    val sel = IdSel(c, vt)
    val vIndex = c.viewIndex(vq)
    var queuesDialog by remember { mutableStateOf(false) }
    val qName = d.queues.getOrNull(vq)?.name ?: "Queue"

    BackHandler(enabled = sel.isNotEmpty()) { sel.clear() }
    LaunchedEffect(vq, c.activeQueue) { c.pruneEmptyQueues() }
    // opens on the playing song (also when the widget's queue button asks for it), with a couple of rows above for context
    LaunchedEffect(vq, c.queueScrollTick, vt.isNotEmpty()) {
        if (vIndex > 0 && vt.isNotEmpty()) runCatching { state.scrollToItem((vIndex - 2).coerceAtLeast(0)) }
    }

    // stable keys so a row keeps its identity while it is dragged to a new position
    val keys = remember(vt) {
        val seen = HashMap<Long, Int>()
        vt.map { t -> val n = (seen[t.id] ?: 0) + 1; seen[t.id] = n; if (n == 1) "${t.id}" else "${t.id}#$n" }
    }
    val shown = remember(vt, query) {
        vt.withIndex().filter { (_, t) ->
            searchMatches(t, query)
        }.map { it.index }
    }
    fun toggle(i: Int) { if (i in sel) sel.remove(i) else sel.add(i) }
    val selNow = rememberUpdatedState(sel)
    val vqNow = rememberUpdatedState(vq)

    /** Which row slot the dragged row's centre is over right now. */
    fun computeTarget() {
        val infos = state.layoutInfo.visibleItemsInfo.filter { it.size > 0 }
        if (infos.isEmpty()) return
        if (dragKey == null) return
        val centre = dragTop + dragH / 2f
        val t = infos.firstOrNull { centre >= it.offset && centre < it.offset + it.size }
            ?: if (centre < infos.first().offset) infos.first() else infos.last()
        dragTo = t.index
    }
    LaunchedEffect(settleKey) {
        if (settleKey != null) {
            androidx.compose.animation.core.animate(settleY, 0f, animationSpec = androidx.compose.animation.core.tween(170)) { v, _ -> settleY = v }
            settleKey = null
        }
    }
    // scroll the list when the dragged row is held near the top or bottom edge
    LaunchedEffect(dragKey) {
        if (dragKey == null) return@LaunchedEffect
        while (true) {
            androidx.compose.runtime.withFrameNanos { }
            val info = state.layoutInfo
            val centre = dragTop + dragH / 2f
            val h = info.viewportSize.height.toFloat()
            val edge = h * 0.18f
            val v = when {
                centre < edge -> -(edge - centre) / edge * 26f
                centre > h - edge -> (centre - (h - edge)) / edge * 26f
                else -> 0f
            }
            if (v != 0f) { state.scrollBy(v); computeTarget() }
        }
    }

    Column(Modifier.fillMaxSize().then(if (embedded) Modifier else Modifier.statusBarsPadding())) {
        // ---- queue picker ----
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!embedded) Box(Modifier.size(44.dp).bounceClick(back), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Box(Modifier.weight(1f)) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .clickable { queuesDialog = true }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${vq + 1}. $qName", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Icon(Icons.Rounded.KeyboardArrowDown, null)
                }
            }
            Box(Modifier.size(44.dp).bounceClick { deleteDialog = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Close, null) }
        }

        // ---- controls ----
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).bounceClick { if (isLive) c.togglePlay() else c.playViewed(vq, null) }, contentAlignment = Alignment.Center) {
                Icon(if (isLive && c.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
            }
            Box {
                Box(Modifier.size(48.dp).bounceClick { sortMenu = true }, contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.Sort, null) }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf<Pair<String, (List<Track>) -> List<Track>>>(
                        "Sort by title" to { l -> l.sortedBy { it.title.lowercase() } },
                        "Sort by artist" to { l -> l.sortedBy { it.artist.lowercase() } },
                        "Sort by album" to { l -> l.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo })) },
                        "Sort by duration" to { l -> l.sortedBy { it.durationMs } },
                        "Sort by date added" to { l -> l.sortedByDescending { it.dateAdded } },
                        "Reverse order" to { l -> l.reversed() },
                        "Randomize" to { l -> l },
                    ).forEach { (label, f) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { sortMenu = false; if (label == "Randomize") { if (isLive) c.randomizeQueue() else c.viewReorder(vq, vt.shuffled()) } else c.viewReorder(vq, f(vt)) })
                    }
                }
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "${if (vIndex >= 0 && vt.isNotEmpty()) vIndex + 1 else 0} / ${vt.size}",
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Timer, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        " " + formatTime(vt.sumOf { it.durationMs }),
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Box(Modifier.size(48.dp).bounceClick { if (vt.isNotEmpty()) saveDialog = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Save, null)
            }
            Box {
                Box(Modifier.size(48.dp).bounceClick { moreMenu = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MoreHoriz, null) }
                DropdownMenu(moreMenu, { moreMenu = false }) {
                    DropdownMenuItem(text = { Text("Export as .csv") }, onClick = {
                        moreMenu = false
                        actions.saveText("$qName.csv", "text/csv", queueCsv(vt))
                    })
                    DropdownMenuItem(text = { Text("Export as .m3u8") }, onClick = {
                        moreMenu = false
                        actions.saveText("$qName.m3u8", "audio/x-mpegurl", queueM3u8(vt))
                    })
                    DropdownMenuItem(text = { Text("Select all") }, onClick = { moreMenu = false; sel.clear(); sel.addAll(vt.indices) })
                    DropdownMenuItem(text = { Text("New queue…") }, enabled = d.queues.size < c.maxQueues, onClick = { moreMenu = false; newDialog = true })
                    DropdownMenuItem(text = { Text("Clear this queue") }, onClick = { moreMenu = false; c.viewReorder(vq, emptyList()) })
                }
            }
        }

        // ---- list ----
        val handleW = with(androidx.compose.ui.platform.LocalDensity.current) { 64.dp.toPx() }
        val queryNow = rememberUpdatedState(query)
        val vtNow = rememberUpdatedState(vt)
        val keysNow = rememberUpdatedState(keys)
        fun finishDrag(commit: Boolean) {
            val from = dragFrom
            computeTarget()
            val to = dragTo
            val infos = state.layoutInfo.visibleItemsInfo
            val tgt = infos.firstOrNull { it.index == to }
            val block = blockDrag
            val sels = selNow.value.toList()
            val q = vqNow.value
            scope.launch {
                if (commit && tgt != null && to >= 0 && from >= 0) {
                    // glide the floating row into its slot, then change the order once
                    androidx.compose.animation.core.animate(dragTop, tgt.offset.toFloat(), animationSpec = androidx.compose.animation.core.tween(110)) { v, _ -> dragTop = v }
                    noAnim = true
                    if (block) c.viewMoveBlockAt(q, sels, to, to > from)
                    else if (from != to) c.viewMove(q, from, to)
                } else if (commit && to >= 0 && from >= 0) {
                    noAnim = true
                    if (block) c.viewMoveBlockAt(q, sels, to, to > from) else if (from != to) c.viewMove(q, from, to)
                }
                dragKey = null; dragDy = 0f; dragFrom = -1; dragTo = -1; blockDrag = false
                kotlinx.coroutines.delay(90); noAnim = false
            }
        }
        Box(
            Modifier.weight(1f).fillMaxWidth().pointerInput(Unit) {
                // the drag lives here, not in a row: rows get recycled when the list auto-scrolls, a gesture on the container never is
                while (true) awaitPointerEventScope {
                    val down = awaitFirstDown(requireUnconsumed = false, pass = androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                    if (dragKey != null || queryNow.value.isNotBlank() || down.position.x > handleW) return@awaitPointerEventScope
                    val row = state.layoutInfo.visibleItemsInfo.firstOrNull { down.position.y.toInt() >= it.offset && down.position.y.toInt() < it.offset + it.size }
                        ?: return@awaitPointerEventScope
                    var started = false
                    while (true) {
                        val ev = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                        val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                        if (!ch.pressed) { if (started) finishDrag(true); return@awaitPointerEventScope }
                        if (!started) {
                            val dx = ch.position.x - down.position.x; val dy = ch.position.y - down.position.y
                            if (kotlin.math.abs(dy) > viewConfiguration.touchSlop && kotlin.math.abs(dy) > kotlin.math.abs(dx)) {
                                started = true
                                try { haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress) } catch (_: Throwable) {}
                                dragKey = row.key as? String
                                dragDy = 0f; dragTop = row.offset.toFloat() + dy
                                dragFrom = row.index; dragTo = row.index; dragH = row.size.toFloat()
                                blockDrag = row.index in selNow.value && selNow.value.size > 1
                                ch.consume()
                                computeTarget()
                            }
                        } else {
                            ch.consume()
                            dragTop += ch.position.y - ch.previousPosition.y
                            computeTarget()
                        }
                    }
                    if (started) finishDrag(false)
                }
            },
        ) {
            if (vt.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("This queue is empty.\nPlay a song or use “Add to queue”.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            } else {
                val lineColor = MaterialTheme.colorScheme.primary
                LazyColumn(state = state, contentPadding = PaddingValues(bottom = 24.dp)) {
                    itemsIndexed(shown, key = { _, idx -> keys.getOrElse(idx) { "x$idx" } }, contentType = { _, _ -> "row" }) { _, idx ->
                        val t = vt.getOrNull(idx) ?: return@itemsIndexed
                        val key = keys.getOrElse(idx) { "x$idx" }
                        val dragging = dragKey == key
                        val idxState = rememberUpdatedState(idx)
                        // the other rows glide out of the way (one short animation per row, no recomposition while it runs)
                        val slide = remember { androidx.compose.animation.core.Animatable(0f) }
                        LaunchedEffect(Unit) {
                            androidx.compose.runtime.snapshotFlow {
                                val i = idxState.value
                                when {
                                    dragKey == null -> 0f
                                    dragFrom < dragTo && i in (dragFrom + 1)..dragTo -> -dragH
                                    dragFrom > dragTo && i in dragTo until dragFrom -> dragH
                                    else -> 0f
                                }
                            }.collectLatest { target ->
                                if (dragKey == null) slide.snapTo(0f) else slide.animateTo(target, androidx.compose.animation.core.tween(130))
                            }
                        }
                        // while a group is being dragged its other songs fold away, leaving ONE row that stands for all of them
                        val folded = blockDrag && dragKey != null && !dragging && idx in sel
                        val swipe = remember { androidx.compose.animation.core.Animatable(0f) }
                        var rowW by remember { mutableFloatStateOf(1f) }
                        val swipeOn = d.swipeRemove && sel.isEmpty() && dragKey == null
                        Box(
                            Modifier
                                .then(if (dragKey != null || noAnim) Modifier else Modifier.animateItem())
                                .zIndex(if (dragging || key == settleKey) 1f else 0f)
                                .onSizeChanged { rowW = it.width.toFloat().coerceAtLeast(1f) }
                                .pointerInput(swipeOn) {
                                    if (swipeOn) while (true) {
                                        awaitPointerEventScope {
                                            val down = awaitFirstDown(requireUnconsumed = false)
                                            var dx = 0f
                                            var dy = 0f
                                            var locked = false
                                            var vertical = false
                                            while (!vertical) {
                                                val ev = awaitPointerEvent()
                                                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                                                if (!ch.pressed) break
                                                val dp = ch.positionChange()
                                                if (!locked) {
                                                    dx += dp.x
                                                    dy += dp.y
                                                    if (kotlin.math.abs(dx) > viewConfiguration.touchSlop && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.5f) locked = true
                                                    else if (kotlin.math.abs(dy) > viewConfiguration.touchSlop) vertical = true
                                                } else {
                                                    ch.consume()
                                                    val amount: Float = dp.x
                                                    scope.launch { swipe.snapTo(swipe.value + amount) }
                                                }
                                            }
                                            if (locked) scope.launch {
                                                if (kotlin.math.abs(swipe.value) > rowW * 0.38f) {
                                                    swipe.animateTo(if (swipe.value > 0) rowW else -rowW, androidx.compose.animation.core.tween(160))
                                                    c.viewRemove(vq, listOf(idxState.value))
                                                } else swipe.animateTo(0f, androidx.compose.animation.core.spring())
                                            }
                                        }
                                    }
                                }
                                .graphicsLayer {
                                    translationX = swipe.value
                                    translationY = when {
                                        dragging -> 0f
                                        dragKey == null -> 0f
                                        else -> slide.value
                                    }
                                    alpha = if (dragging) 0f else (1f - kotlin.math.abs(swipe.value) / rowW).coerceIn(0f, 1f)
                                }
                                .background(MaterialTheme.colorScheme.background),
                        ) {
                            Box(Modifier.animateContentSize(androidx.compose.animation.core.tween(150))) {
                            if (!folded) TrackRow(
                                t, c,
                                selected = idx in sel,
                                onLongClick = { toggle(idx) },
                                leading = {
                                    if (query.isBlank()) Box(
                                        Modifier.size(40.dp),
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Icon(Icons.Rounded.DragHandle, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                extraMenu = buildList {
                                    add("Remove from queue" to { c.viewRemove(vq, listOf(idxState.value)) })
                                    add((if (c.sleepStopAtId == t.id) "Cancel stop after this song" else "Stop after this song") to {
                                        if (c.sleepStopAtId == t.id) c.cancelSleep() else c.setSleepAfterSong(t.id)
                                    })
                                    add("Move to top" to { c.viewMove(vq, idxState.value, 0) })
                                    add("Move to end" to { c.viewMove(vq, idxState.value, vt.lastIndex) })
                                },
                            ) { if (sel.isNotEmpty()) toggle(idx) else c.playViewed(vq, idx) }
                            }
                        }
                    }
                }
            }
            val dt = vt.getOrNull(dragFrom)
            if (dragKey != null && dt != null) {
                Box(
                    Modifier.offset { androidx.compose.ui.unit.IntOffset(0, dragTop.roundToInt()) }
                        .fillMaxWidth().height(with(androidx.compose.ui.platform.LocalDensity.current) { dragH.toDp() })
                        .graphicsLayer { shadowElevation = 14f; scaleX = 1.02f; scaleY = 1.02f }
                        .background(MaterialTheme.colorScheme.background, RoundedCornerShape(14.dp)),
                ) {
                    if (blockDrag) Box(
                        Modifier.matchParentSize().padding(horizontal = 8.dp, vertical = 2.dp)
                            .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(14.dp)).padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterStart,
                    ) {
                        Column {
                            Text("${selNow.value.size} songs", fontWeight = FontWeight.Bold)
                            Text("Drop to move them together", style = MaterialTheme.typography.bodySmall)
                        }
                    } else TrackRow(
                        dt, c,
                        leading = { Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.DragHandle, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant) } },
                    ) {}
                }
            }
        }

        if (sel.isNotEmpty()) {
            SelectionBar(
                c, c.selection.toList(), inQueue = true,
                onRemove = { c.viewRemove(vq, sel.toList()); sel.clear() },
                onSelectAll = { sel.clear(); sel.addAll(vt.indices) },
                onDeselectAll = { sel.clear() },
                onBetween = { val lo = sel.min(); val hi = sel.max(); sel.clear(); sel.addAll(lo..hi) },
                onInvert = { val all = vt.indices.filter { it !in sel }; sel.clear(); sel.addAll(all) },
                onCancel = { sel.clear() },
            )
        }
        SearchField(query, { query = it }, "Search in this queue…")
    }

    if (queuesDialog) QueuesDialog(c) { queuesDialog = false }
    if (saveDialog) NameDialog("Save queue as playlist", qName, "Save", { saveDialog = false }) {
        c.store.createPlaylist(it, vt.map { t -> t.id }); saveDialog = false
    }
    if (newDialog) NameDialog("New queue", "Queue ${d.queues.size + 1}", "Create", { newDialog = false }) { c.newQueue(it); newDialog = false }
    if (renameDialog) NameDialog("Rename queue", qName, "Rename", { renameDialog = false }) { c.renameQueue(vq, it); renameDialog = false }
    if (deleteDialog) AlertDialog(
        onDismissRequest = { deleteDialog = false },
        title = { Text(if (d.queues.size > 1) "Delete this queue?" else "Clear this queue?") },
        text = { Text("“$qName” with ${vt.size} songs.") },
        confirmButton = { TextButton({ c.deleteQueue(vq); deleteDialog = false }) { Text(if (d.queues.size > 1) "Delete" else "Clear") } },
        dismissButton = { TextButton({ deleteDialog = false }) { Text("Cancel") } },
    )
}
