package com.aurora.player.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Backup
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Headset
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material.icons.rounded.Search
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.backup.BackupScheduler
import com.aurora.player.lyrics.LyricsOverlayService
import com.aurora.player.player.PlayerController
import com.aurora.player.widget.WidgetUpdater
import kotlin.math.roundToInt

private val PAGES = listOf(
    Triple("theme", "Theme and colours", "Light / dark / black, accent colour"),
    Triple("tabs", "Tabs and layout", "Tab-bar position, arrange or hide tabs, exit"),
    Triple("now", "Now Playing screen", "Background, cover style, seek bar, and every player button"),
    Triple("playback", "Playback behaviour", "Shuffle, previous button, tap to play, skip times"),
    Triple("positions", "Play counts and positions", "Remember positions, what counts as a play"),
    Triple("audio", "Audio and fades", "Fades, crossfade, audio focus, volume, equalizer"),
    Triple("headset", "Headset, Bluetooth and speaker", "Pause and resume when devices connect"),
    Triple("exit", "Closing and exit", "Idle close, recents, confirm before exit"),
    Triple("motion", "Motion and animations", "Speed, transitions, list and button motion"),
    Triple("albums", "Albums", "List or grid, extra info under each album"),
    Triple("library", "Song library and tags", "Excluded folders, short files, scan"),
    Triple("queues", "Queues and sorting", "Merging queues, sort rules"),
    Triple("lyrics", "Lyrics", "Source: embedded, .lrc file or online"),
    Triple("desktop", "Desktop lyrics", "Floating lyrics window"),
    Triple("notification", "Notification", "Style, buttons, upcoming songs"),
    Triple("lock", "Lock screen and widgets", "Lock-screen player, queue widget theme"),
    Triple("tile", "Quick Settings tile", "Play / pause tile in the swipe-down panel"),
    Triple("backup", "Backup and restore", "Zip backups, automatic backup"),
    Triple("compat", "Compatibility and performance", "Switch off heavy features on slower phones"),
    Triple("themes", "Saved themes and schedule", "Save looks, switch automatically by time of day"),
    Triple("privacy", "PIN lock", "Ask for a PIN when the app opens"),
    Triple("alarms", "Alarms and Bluetooth auto-play", "Start a playlist at a set time or when a device connects"),
    Triple("about", "About", ""),
    Triple("h_interface", "Interface", "Theme, tabs, Now Playing, per-tab options, menus"),
    Triple("h_audio", "Audio and devices", "Fades, equalizer, headset, Bluetooth"),
    Triple("h_notif", "Notifications", "Notification style and Quick Settings tile"),
    Triple("h_lyrics", "Lyrics", "Lyrics source and floating desktop lyrics"),
    Triple("h_adv", "Advanced", "Playback behaviour, play counts, closing, performance"),
    Triple("t_folders", "Folders tab", "Tree or list, extra info"),
    Triple("t_artists", "Artists tab", "Extra info, split artists"),
    Triple("t_genres", "Genres tab", "Extra info"),
    Triple("t_playlists", "Playlists tab", "Choose which smart lists are shown"),
    Triple("m_song", "Song menu", "Items in a song's three-dot menu"),
    Triple("m_main", "Main menu", "Items in the top-right menu"),
    Triple("m_list", "Album, artist, genre and playlist menu", "Items in the menu of a list of songs"),
)

/** Settings pages that are only a list of other pages: section title (or null) to child page ids. */
private val HUBS: Map<String, List<Pair<String?, List<String>>>> = mapOf(
    "h_interface" to listOf(
        "Look" to listOf("theme", "themes", "tabs", "motion"),
        "Player" to listOf("now"),
        "Library tabs" to listOf("queues", "t_folders", "albums", "t_artists", "t_genres", "t_playlists"),
        "Menus" to listOf("m_main", "m_song", "m_list"),
    ),
    "h_audio" to listOf(null to listOf("audio", "headset", "alarms")),
    "h_notif" to listOf(null to listOf("notification", "tile")),
    "h_lyrics" to listOf(null to listOf("lyrics", "desktop")),
    "h_adv" to listOf(
        "Playback" to listOf("playback", "positions", "exit"),
        "System" to listOf("privacy", "compat", "about"),
    ),
)

/** Where the back button goes from a page (null = the Settings home). */
private fun parentOf(id: String?): String? = when (id) {
    "theme", "themes", "tabs", "motion", "now", "queues", "albums", "t_folders", "t_artists", "t_genres", "t_playlists", "m_song", "m_main", "m_list" -> "h_interface"
    "audio", "headset", "alarms" -> "h_audio"
    "lyrics", "desktop" -> "h_lyrics"
    "notification", "tile" -> "h_notif"
    "playback", "positions", "exit", "privacy", "compat", "about" -> "h_adv"
    else -> null
}

/** Musicolet-style home list: icon, title, subtitle, page id. */
private val TOP = listOf(
    listOf(Icons.Rounded.Palette, "Interface", "Theme, tabs, Now Playing, per-tab options, menus", "h_interface"),
    listOf(Icons.Rounded.GraphicEq, "Audio and devices", "Fades, equalizer, headset, Bluetooth", "h_audio"),
    listOf(Icons.Rounded.LibraryMusic, "Song library and tags", "Folders to scan, exclusions, scan", "library"),
    listOf(Icons.Rounded.Notifications, "Notifications", "Style, buttons, Quick Settings tile", "h_notif"),
    listOf(Icons.Rounded.Lock, "Lock screen and widgets", "Lock-screen player, widget theme", "lock"),
    listOf(Icons.Rounded.Lyrics, "Lyrics", "Source and desktop lyrics", "h_lyrics"),
    listOf(Icons.Rounded.Tune, "Advanced", "Playback, play counts, exit, performance", "h_adv"),
    listOf(Icons.Rounded.Backup, "Backup and restore", "Zip backups, automatic backup", "backup"),
)

/** (setting name, page id, extra keywords) for the settings search. */
private val SETTING_INDEX = listOf(
    Triple("Upcoming songs", "notification", "notification queue next"), Triple("Notification buttons", "notification", "arrangement heart close repeat shuffle"),
    Triple("Animation speed", "motion", "animations off fast slow smooth"), Triple("Screen transition", "motion", "slide fade zoom navigation"),
    Triple("List animation", "motion", "entrance stagger items"), Triple("Button press bounce", "motion", "tap spring"),
    Triple("Theme", "theme", "dark light black amoled colour"), Triple("Accent colour", "theme", "color"),
    Triple("Tab-bar position", "tabs", "top bottom tabs"), Triple("Arrange tabs", "tabs", "hide genres"),
    Triple("Spinning vinyl album art", "now", "disc"), Triple("Now playing background", "now", "blur image"),
    Triple("Hide a Now Playing button", "now", "icon remove heart info lyrics"),
    Triple("Equalizer", "audio", "bass virtualizer loudness"), Triple("Audio focus", "audio", "calls duck pause"),
    Triple("Crossfade", "audio", "overlap fade songs"), Triple("ReplayGain", "audio", "loudness normalize volume"),
    Triple("Remember speed per song", "audio", "playback speed"), Triple("Skip silence", "audio", "gaps"),
    Triple("Headset and Bluetooth", "headset", "unplug resume wired"), Triple("Excluded folders", "library", "hide"),
    Triple("Split multiple artists", "library", "separator"), Triple("Minimum duration", "library", "short files"),
    Triple("Sleep timer", "exit", "stop"), Triple("Queues", "queues", "merge"),
    Triple("Shuffle behaviour", "playback", "random below"), Triple("Previous button", "playback", "restart percentage"),
    Triple("Remember positions", "positions", "resume ask"), Triple("Play count", "positions", "minimum percentage"),
    Triple("Confirm before exit", "exit", "back"),
    Triple("Back button in main screen", "exit", "back history now playing"),
    Triple("Album view mode", "albums", "grid list columns"), Triple("Show extra info in the list of albums", "albums", "songs duration year artist composer"),
    Triple("Lyrics source", "lyrics", "embedded lrc file"), Triple("Desktop lyrics overlay", "desktop", "floating"),
    Triple("Backup and restore", "backup", "zip automatic"), Triple("Export listening history", "backup", "csv plays"),
    Triple("Lock screen player", "lock", "swipe widget"), Triple("Widget theme and transparency", "lock", "widget queue simple advanced album art"),
    Triple("Quick Settings tile", "tile", "panel play pause"),
    Triple("Folder tab's structure", "t_folders", "tree hierarchical flat list"), Triple("Show folder path", "t_folders", "extra info"),
    Triple("Artists extra info", "t_artists", "albums songs duration"), Triple("Genres extra info", "t_genres", "duration"),
    Triple("Swipe right to remove from queue", "queues", "swipe"), Triple("Shake to skip", "playback", "shake"),
    Triple("Find duplicate songs", "library", "duplicates"),
    Triple("Prevent unwanted autoplay", "headset", "bluetooth connect play"), Triple("Advanced shuffle", "playback", "artist spread"),
    Triple("Advanced external control", "playback", "android auto bluetooth"), Triple("Alphanumeric sorting", "queues", "natural numbers sort"),
    Triple("Song menu items", "m_song", "hide options menus"), Triple("Playlists tab", "t_playlists", "smart lists hide"),
    Triple("Earphone button actions", "headset", "double triple press next previous"),
    Triple("Prevent accidental touch on seek bar", "now", "knob thumb seekbar"),
    Triple("Lock-screen lyrics style", "lock", "size alignment darkness bold full screen lyrics tune"), Triple("Lock-screen colour style", "lock", "swatch blurred adapt"),
    Triple("Smart mixes: exclude folders and playlists", "t_playlists", "mix exclude smart tune"), Triple("Preamp", "audio", "gain boost headroom volume"),
    Triple("Notification colour from cover", "notification", "adapt swatch musicolet"), Triple("Now Playing cover swatch background", "now", "palette"),
    Triple("PIN lock", "privacy", "password security app lock"), Triple("Saved themes", "themes", "day night schedule dark light switch"),
    Triple("Playlist alarm", "alarms", "wake up clock start playlist time"), Triple("Bluetooth auto-play", "alarms", "device connect headphones soundbar start playlist"),
    Triple("Split genre names", "t_genres", "separator pop dance mix"),
    Triple("Sleep timer fade-out", "audio", "fade stop volume seconds"), Triple("Swipe cover up or down", "now", "next previous gesture"),
    Triple("Export most played now", "backup", "csv songs artists"), Triple("Export most played automatically", "backup", "csv weekly monthly yearly"),
    Triple("Hide website names from tags", "library", "junk clean title artist"),
    Triple("Reverb", "audio", "room hall plate effect"), Triple("Smart playlists", "t_playlists", "rules auto"),
    Triple("Rate songs", "m_song", "stars rating"), Triple("Trim start and end", "m_song", "cut skip intro"),
    Triple("Lyrics presets", "lyrics", "font size style big bold serif"), Triple("Sync lyrics by tapping", "lyrics", "edit lrc timing"),
    Triple("Sleep at a clock time", "exit", "timer stop"), Triple("Skip lock screen when paused", "lock", "paused for a while"),
    Triple("Artist and genre mixes count", "t_playlists", "mix artists limit"), Triple("Keep screen on", "now", "awake"),
    Triple("Safe mode", "compat", "crash slow lag android 10 notification equalizer widget"),
)

@Composable
fun SettingsScreen(c: PlayerController, back: () -> Unit, openEq: () -> Unit) {
    var page by remember { mutableStateOf<String?>(null) }
    var q by remember { mutableStateOf("") }
    BackHandler(enabled = page != null) { page = parentOf(page) }
    val title = PAGES.firstOrNull { it.first == page }?.second ?: "Settings"

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).bounceClick { if (page != null) page = parentOf(page) else back() }, contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, null)
            }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            when (page) {
                null -> {
                    androidx.compose.material3.OutlinedTextField(
                        q, { q = it }, singleLine = true, placeholder = { Text("Search settings…") },
                        leadingIcon = { Icon(androidx.compose.material.icons.Icons.Rounded.Search, null) },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    )
                    if (q.isBlank()) run {
                        val lctx = LocalContext.current
                        TopRow(Icons.Rounded.Language, "Language", "Opens your phone's app-language screen. Aurora's text is English only for now") {
                            try {
                                lctx.startActivity(
                                    (if (Build.VERSION.SDK_INT >= 33) Intent(Settings.ACTION_APP_LOCALE_SETTINGS, Uri.parse("package:" + lctx.packageName)) else Intent(Settings.ACTION_LOCALE_SETTINGS))
                                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                )
                            } catch (_: Throwable) {
                                try { lctx.startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
                            }
                        }
                    }
                    if (q.isBlank()) TOP.forEach { r ->
                        @Suppress("UNCHECKED_CAST")
                        TopRow(r[0] as androidx.compose.ui.graphics.vector.ImageVector, r[1] as String, r[2] as String) { page = r[3] as String }
                    }
                    else {
                        val words = q.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                        val hits = SETTING_INDEX.filter { e -> words.all { w -> e.first.contains(w, true) || e.third.contains(w, true) || PAGES.first { it.first == e.second }.second.contains(w, true) } }
                        if (hits.isEmpty()) Text("No settings match.", Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        hits.forEach { (name, pg, _) -> ActionRow(name, "In: " + pathOf(pg)) { page = pg; q = "" } }
                    }
                }
                "h_interface", "h_audio", "h_notif", "h_lyrics", "h_adv" -> HubPage(page!!) { page = it }
                "t_folders", "t_artists", "t_genres", "t_playlists" -> TabPage(c, page!!)
                "m_song", "m_main", "m_list" -> MenuPage(c, page!!)
                "theme", "tabs", "now", "tile" -> InterfacePage(c, page!!)
                "audio" -> AudioPage(c, openEq)
                "headset" -> HeadsetPage(c)
                "library" -> LibraryPage(c)
                "playback", "positions", "exit", "queues" -> AdvancedPage(c, page!!)
                "compat" -> CompatPage(c)
                "themes" -> ThemesPage(c)
                "privacy" -> PrivacyPage(c)
                "alarms" -> AlarmsPage(c)
                "albums" -> AlbumsPage(c)
                "motion" -> MotionPage(c)
                "lyrics" -> LyricsPage(c)
                "desktop" -> DesktopPage(c)
                "backup" -> BackupPage(c)
                "notification" -> NotificationPage(c)
                "lock" -> LockPage(c)
                else -> AboutPage()
            }
            Box(Modifier.height(32.dp))
        }
    }
}

/** "Interface > Theme and colours" style location shown under each search result. */
private fun pathOf(id: String): String {
    val names = ArrayList<String>()
    var cur: String? = id
    while (cur != null) {
        names.add(0, PAGES.first { it.first == cur }.second)
        cur = parentOf(cur)
    }
    return names.joinToString(" › ")
}

@Composable
private fun TopRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp)
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            .bounceClick(onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        }
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun HubPage(id: String, open: (String) -> Unit) {
    HUBS[id].orEmpty().forEach { (section, ids) ->
        if (section != null) Section(section)
        ids.forEach { cid -> PAGES.first { it.first == cid }.let { (_, name, sub) -> ActionRow(name, sub) { open(cid) } } }
    }
}

@Composable
private fun TabPage(c: PlayerController, id: String) {
    val d = c.store.data
    when (id) {
        "t_folders" -> {
            SwitchRow("Folder tab's structure: tree", "On = hierarchical tree of folders. Off = one flat list of every folder", d.foldersTree) { v -> c.store.update { it.copy(foldersTree = v) } }
            SwitchRow("Show folder path", "Show the full path under each folder in the flat list", d.folderPath) { v -> c.store.update { it.copy(folderPath = v) } }
        }
        "t_artists" -> {
            SwitchRow("Show extra info in the list of artists", "Number of albums and total duration under each artist", d.artistExtra) { v -> c.store.update { it.copy(artistExtra = v) } }
            SwitchRow("Split multiple artists", "Treat \"A, B\" as two artists (also splits album artists)", d.splitArtists) { v -> c.store.update { it.copy(splitArtists = v) } }
        }
        "t_playlists" -> {
            Section("Show in the Playlists tab")
            listOf(
                "all" to "All songs", "fav" to "Favorites", "added" to "Recently added", "played" to "Recently played",
                "most" to "Most played", "mixes" to "Smart mixes", "unplayed" to "Not played",
            ).forEach { (k, n) ->
                SwitchRow(n, "", k !in d.hiddenSmart) { on -> c.store.update { it.copy(hiddenSmart = if (on) it.hiddenSmart - k else (it.hiddenSmart + k).distinct()) } }
            }
            var mixDlg by remember { mutableStateOf(false) }
            ActionRow("Smart mixes", "Exclude folders and playlists, and choose how many songs a mix has") { mixDlg = true }
            if (mixDlg) MixFilterDialog(c) { mixDlg = false }
            SwitchRow("Show number of songs", "Song count at the end of each playlist row", d.playlistCounts) { v -> c.store.update { it.copy(playlistCounts = v) } }
        }
        else -> {
            SwitchRow("Split genre names", "\"Pop; Dance\" shows under both Pop and Dance, and the genre mixes use the split genres", d.splitGenres) { v -> c.store.update { it.copy(splitGenres = v) } }
            if (d.splitGenres) androidx.compose.material3.OutlinedTextField(
                d.genreSeparators, { v -> c.store.update { it.copy(genreSeparators = v.filter { ch -> !ch.isLetterOrDigit() && ch != ' ' }.take(8)) } },
                label = { Text("Characters that separate genres") }, singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            )
            SwitchRow("Show extra info in the list of genres", "Total duration under each genre", d.genreExtra) { v -> c.store.update { it.copy(genreExtra = v) } }
        }
    }
}

@Composable
private fun MenuPage(c: PlayerController, id: String) {
    val d = c.store.data
    val items = when (id) {
        "m_main" -> listOf("m_eq" to "Equalizer", "m_shuffle" to "Shuffle all songs", "m_arrange" to "Arrange tabs", "m_rescan" to "Rescan music")
        "m_song" -> listOf(
            "info" to "Song info", "playnext" to "Play after current song", "queue" to "Add to a queue", "playlist" to "Add to playlists",
            "preview" to "Preview", "tags" to "Edit tags", "rename" to "Rename file", "move" to "Move to a folder",
            "ringtone" to "Set as ringtone", "speed" to "Play speed and Pitch", "delete" to "Delete permanently",
        )
        else -> listOf("d_play" to "Play all", "d_queue" to "Add all to queue", "d_export" to "Export as .m3u", "d_save" to "Save as playlist")
    }
    Text(
        "Switch off the items you never use. They disappear from the menu." + if (id == "m_main") " “Settings” always stays so you can never lock yourself out." else "",
        Modifier.padding(horizontal = 20.dp, vertical = 6.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    items.forEach { (k, n) ->
        SwitchRow(n, "", k !in d.hiddenMenu) { on -> c.store.update { it.copy(hiddenMenu = if (on) it.hiddenMenu - k else (it.hiddenMenu + k).distinct()) } }
    }
}

@Composable
private fun InterfacePage(c: PlayerController, part: String) {
    val d = c.store.data
    val actions = LocalActions.current
    var arrange by remember { mutableStateOf(false) }
    if (arrange) ArrangeTabsDialog(c) { arrange = false }

    if (part == "theme") {
    Section("Colours")
    ChipRow("Theme") {
        listOf("System", "Light", "Dark", "Black").forEachIndexed { i, n ->
            FilterChip(d.themeMode == i, { c.store.update { it.copy(themeMode = i) } }, label = { Text(n) })
        }
    }
    Column(Modifier.cardRow().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text("Accent colour", fontWeight = FontWeight.Medium)
        Text(
            "Default uses your phone's colours (Android 12+) or Aurora blue.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(Modifier.padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(0L, 0xFF007CC3, 0xFF0078D7, 0xFFE8E4DA, 0xFF894E62, 0xFF7F56FF, 0xFFCC00CC, 0xFFE8003C, 0xFFB35F00, 0xFF737A00, 0xFF2A8A00, 0xFF008A80, 0xFF5B63FF, 0xFF2EA8FF, 0xFFFFB300).forEach { col ->
                val sel = d.accentColor == col
                Box(
                    Modifier.size(34.dp)
                        .background(if (col == 0L) MaterialTheme.colorScheme.surfaceVariant else Color(col), CircleShape)
                        .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.onSurface else Color.Gray, CircleShape)
                        .bounceClick { c.store.update { it.copy(accentColor = col) } },
                    contentAlignment = Alignment.Center,
                ) { if (col == 0L) Text("A", style = MaterialTheme.typography.labelLarge) }
            }
        }
    }
    }
    if (part == "tabs") {
    Section("Tab bar")
    ChipRow("Tab-bar position") {
        listOf(false to "Top", true to "Bottom").forEach { (b, n) ->
            FilterChip(d.tabsBottom == b, { c.store.update { it.copy(tabsBottom = b) } }, label = { Text(n) })
        }
    }
    ActionRow("Arrange tabs", "Arrange tabs, or enable/disable them") { arrange = true }
    }
    if (part == "now") {
    Section("Cover and buttons")
    SwitchRow("Spinning vinyl album art", "Off = a breathing square cover", d.discArt) { v -> c.store.update { it.copy(discArt = v) } }
    SwitchRow("Fast-forward / rewind buttons", "Show the skip-forward and skip-back buttons under the seek bar on Now playing", d.showSeekButtons) { v -> c.store.update { it.copy(showSeekButtons = v) } }

    Section("Expressive looks (all off by default)")
    SwitchRow("Wavy seek bar", "The played part ripples while music plays and goes flat when paused", d.uiSquiggly) { v -> c.store.update { it.copy(uiSquiggly = v) } }
    SwitchRow("Morphing play button", "Softer square while playing, circle when paused, with a bounce and a tap buzz", d.uiMorphPlay) { v -> c.store.update { it.copy(uiMorphPlay = v) } }
    SwitchRow("Audio format pill", "Shows format, sample rate and bitrate above the seek bar; tap for song info", d.uiSpecPill) { v -> c.store.update { it.copy(uiSpecPill = v) } }
    SwitchRow("Scrolling long titles", "Title and artist slide sideways when they do not fit", d.uiMarquee) { v -> c.store.update { it.copy(uiMarquee = v) } }
    SwitchRow("Pure black for Fluid mesh", "Use true black behind the Fluid mesh background (saves power on AMOLED)", d.uiAmoled) { v -> c.store.update { it.copy(uiAmoled = v) } }

    Section("Background")
    ChipRow("Background") {
        listOf("Album colour", "Blurred art", "Aurora", "Plain", "Black", "My image", "Cover swatch", "Fluid mesh").forEachIndexed { i, n ->
            FilterChip(d.nowBg == i, {
                if (i == 5 && d.customBgUri.isEmpty()) actions.pickBackground() else c.store.update { it.copy(nowBg = i) }
            }, label = { Text(n) })
        }
    }
    if (d.nowBg == 5) ActionRow("Choose image", "Pick the picture shown behind the player") { actions.pickBackground() }
    if (d.nowBg == 1 || d.nowBg == 5) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            Row {
                Text("Darken background", Modifier.weight(1f))
                Text("${d.nowBgDim}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Slider(d.nowBgDim.toFloat(), { v -> c.store.update { it.copy(nowBgDim = v.roundToInt()) } }, valueRange = 0f..80f)
        }
    }
    Text(
        "Tip: tap the palette icon on the Now Playing screen to cycle through backgrounds.",
        Modifier.padding(horizontal = 20.dp, vertical = 2.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Section("Gestures and screen")
    SwitchRow("Prevent accidental touch on seek bar", "Only the knob (thumb) of the seek bar can be dragged. Touching elsewhere on the bar does nothing", d.seekKnobOnly) { v -> c.store.update { it.copy(seekKnobOnly = v) } }
    SwitchRow("Swipe cover up / down", "Swipe up on the cover for the next song and down for the previous one", d.swipeArtVertical) { v -> c.store.update { it.copy(swipeArtVertical = v) } }
    SwitchRow("Keep screen on", "While the Now Playing screen is open", d.keepScreenOn) { v -> c.store.update { it.copy(keepScreenOn = v, keepOnNp = v) } }

    }
    if (part == "tile") {
        Text("Adds a tile to the swipe-down panel that shows the song and plays / pauses it. Tap the tile to open Aurora.", Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    run {
        val qctx = androidx.compose.ui.platform.LocalContext.current
        ActionRow("Quick Settings tile", "Add Aurora's play / pause tile to the swipe-down panel") {
            try {
                if (android.os.Build.VERSION.SDK_INT >= 33) {
                    val sm = qctx.getSystemService(android.app.StatusBarManager::class.java)
                    sm.requestAddTileService(
                        android.content.ComponentName(qctx, com.aurora.player.QuickTileService::class.java), "Aurora",
                        android.graphics.drawable.Icon.createWithResource(qctx, com.aurora.player.R.drawable.ic_qs_tile), { r -> r.run() }, { },
                    )
                } else {
                    android.widget.Toast.makeText(qctx, "Swipe down twice, tap the pencil (edit) and drag the Aurora tile into the panel.", android.widget.Toast.LENGTH_LONG).show()
                }
            } catch (_: Throwable) {
                android.widget.Toast.makeText(qctx, "Swipe down twice, tap the pencil (edit) and drag the Aurora tile into the panel.", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    }
    if (part == "now") {
    Section("Show or hide Now Playing buttons")
    Text(
        "Switch off any button you never use. It disappears from the Now Playing screen.",
        Modifier.padding(horizontal = 20.dp, vertical = 2.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    listOf(
        "palette" to "Background (palette) button", "queue" to "Queue button",
        "fav" to "Favourite (heart)", "info" to "Song info", "lyrics" to "Lyrics", "overlay" to "Desktop lyrics", "addpl" to "Add to playlist",
        "sleep" to "Sleep timer", "more" to "More (…) menu", "ab" to "A–B repeat", "mode" to "Repeat / play mode",
        "shuffle" to "Shuffle", "vol" to "Volume", "eq" to "Equalizer",
    ).forEach { (key, name) ->
        SwitchRow(name, "", key !in d.hideNp) { on ->
            c.store.update { it.copy(hideNp = if (on) it.hideNp - key else (it.hideNp + key).distinct()) }
        }
    }
    }
}

@Composable
private fun AudioPage(c: PlayerController, openEq: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val d = c.store.data
    Section("Sound")
    ActionRow("Equalizer", "Per-output equalizer, bass boost, virtualizer, loudness, speed and pitch") { openEq() }
    SwitchRow("Use the same equalizer for all outputs", "One equalizer for speaker, headphones and Bluetooth. Off = each output keeps its own", d.eqSameForAll) { v ->
        c.store.update { it.copy(eqSameForAll = v) }; c.applyActiveProfile()
    }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
        Row {
            Text("Audio focus", Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text("Level ${d.focusLevel}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(
            d.focusLevel.toFloat(), { v -> c.store.update { it.copy(focusLevel = v.roundToInt().coerceIn(1, 5)) }; c.applyPlaybackPrefs() },
            valueRange = 1f..5f, steps = 3,
        )
        val lvl = d.focusLevel
        fun line(on: Boolean, text: String) = (if (on) "✓ " else "✗ ") + text
        Text(
            listOf(
                line(lvl >= 2, "Pause music during phone calls"),
                line(lvl >= 3, "Pause music when another app plays audio for a long time (music, video)"),
                line(lvl == 4, "Lower the volume for short sounds: navigation prompts, notification sounds"),
                line(lvl >= 5, "Pause (instead of lowering the volume) for short sounds too"),
                if (lvl == 1) "Level 1: Aurora ignores calls and other apps completely." else "",
            ).filter { it.isNotEmpty() }.joinToString("\n"),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
    SwitchRow("Resume after call ends", "Resume after a call or a short interruption ends", d.resumeAfterCall) { v ->
        c.store.update { it.copy(resumeAfterCall = v) }
    }
    Section("Fades and gain")
    ChipRow("Crossfade (overlap songs)") {
        listOf(0, 2, 4, 6, 8, 12).forEach { sec ->
            FilterChip(d.crossfadeSec == sec, { c.store.update { it.copy(crossfadeSec = sec) } }, label = { Text(if (sec == 0) "Off" else "${sec}s") })
        }
    }
    SwitchRow("ReplayGain", "Evens out loudness using the ReplayGain tags in your files (only lowers loud songs)", d.replayGain) { v ->
        c.store.update { it.copy(replayGain = v) }
    }
    SwitchRow(
        "Aurora sound engine", "31-band equalizer, mono and balance. Turn off if songs don't play; it switches itself off after a playback error",
        d.soundEngine,
    ) { v -> c.store.update { it.copy(soundEngine = v) }; if (v) android.widget.Toast.makeText(ctx, "Restart Aurora to apply", android.widget.Toast.LENGTH_SHORT).show() }
    SwitchRow("Skip silence", "Skips silent gaps within songs", d.skipSilence) { v ->
        c.store.update { it.copy(skipSilence = v) }; c.applyPlaybackPrefs()
    }
    SliderSetting("Fade between songs", d.fadeSec.toFloat(), 0f..12f, 11, if (d.fadeSec == 0) "Off" else "${d.fadeSec} s") { v ->
        c.store.update { it.copy(fadeSec = v.roundToInt()) }
    }
    SliderSetting("Fade-in volume when play", d.fadeInMs.toFloat(), 0f..2000f, 19, "${d.fadeInMs} ms") { v ->
        c.store.update { it.copy(fadeInMs = (v / 100).roundToInt() * 100) }
    }
    SliderSetting("Sleep timer fade-out", d.sleepFadeSec.toFloat(), 1f..60f, 58, "${d.sleepFadeSec} s") { v ->
        c.store.update { it.copy(sleepFadeSec = v.roundToInt().coerceIn(1, 60)) }
    }
    SliderSetting("Fade-out volume when pause", d.fadeOutMs.toFloat(), 0f..2000f, 19, "${d.fadeOutMs} ms") { v ->
        c.store.update { it.copy(fadeOutMs = (v / 100).roundToInt() * 100) }
    }
    Section("Volume")
    SwitchRow("Do not allow playback if audio volume is 0", "Shows a message instead of playing silently", d.blockPlayMuted) { v ->
        c.store.update { it.copy(blockPlayMuted = v) }
    }
    SwitchRow("Pause when audio is muted", "Pauses when the media volume reaches 0", d.pauseOnMute) { v -> c.store.update { it.copy(pauseOnMute = v) } }
    SwitchRow("Resume when audio is un-muted", "Only if playback was paused because it was muted", d.resumeOnUnmute) { v ->
        c.store.update { it.copy(resumeOnUnmute = v) }
    }
    Text(
        "Gapless playback is always on.", Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun HeadsetPage(c: PlayerController) {
    val d = c.store.data
    Section("Pause when disconnect")
    SwitchRow("Pause when disconnect", "Pause music when headset, speaker or Bluetooth is disconnected", d.pauseOnUnplug) { v ->
        c.store.update { it.copy(pauseOnUnplug = v) }; c.applyPlaybackPrefs()
    }
    Section("Resume when connect")
    SwitchRow("Resume only if paused by disconnection before", "", d.resumeOnlyIfPaused) { v -> c.store.update { it.copy(resumeOnlyIfPaused = v) } }
    SwitchRow("Resume on Bluetooth connect", "", d.resumeOnBt) { v -> c.store.update { it.copy(resumeOnBt = v) } }
    SwitchRow("Resume on wired headset / speaker connect", "", d.resumeOnWired) { v -> c.store.update { it.copy(resumeOnWired = v) } }
    Section("Prevent unwanted autoplay")
    SwitchRow("Prevent unwanted autoplay", "Some Bluetooth devices send a play command the moment they connect. Ignore it", d.preventAutoplay) { v -> c.store.update { it.copy(preventAutoplay = v) } }
    Section("Earphone's mic button")
    var earDlg by remember { mutableStateOf<String?>(null) }
    ActionRow("Earphone button's Double-press action", EAR_ACTIONS[d.earDouble.coerceIn(0, EAR_ACTIONS.lastIndex)]) { earDlg = "double" }
    ActionRow("Earphone button's Triple-press action", EAR_ACTIONS[d.earTriple.coerceIn(0, EAR_ACTIONS.lastIndex)]) { earDlg = "triple" }
    Text(
        "Single press: play / pause. On each earphone button press of 4 or more, you can do Fast-forward. " +
            "Note: earphone button actions may not work on some phones, because they don't send the button presses to music apps.",
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    earDlg?.let { which ->
        val cur = if (which == "double") d.earDouble else d.earTriple
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { earDlg = null },
            title = { Text(if (which == "double") "Double-press action" else "Triple-press action") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    EAR_ACTIONS.forEachIndexed { i, label ->
                        val pick = { c.store.update { if (which == "double") it.copy(earDouble = i) else it.copy(earTriple = i) }; earDlg = null }
                        Row(Modifier.fillMaxWidth().clickable { pick() }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.RadioButton(cur == i, { pick() })
                            Text(label, Modifier.padding(start = 12.dp))
                        }
                    }
                }
            },
            confirmButton = { androidx.compose.material3.TextButton({ earDlg = null }) { Text("Cancel") } },
        )
    }
}

private val EAR_ACTIONS = listOf("Next song", "Previous song", "Play / pause", "Fast-forward", "Rewind", "Toggle shuffle", "Toggle favourite", "Do nothing")

@Composable
private fun LibraryPage(c: PlayerController) {
    val d = c.store.data
    val actions = LocalActions.current
    var foldersDialog by remember { mutableStateOf(false) }
    if (foldersDialog) ExcludedFoldersDialog(c, { foldersDialog = false }) { actions.rescan() }
    SwitchRow("Use folder pictures", "Use folder.jpg, cover.jpg or AlbumArt.jpg from the song's folder when the song has no picture of its own", d.folderArt) { v ->
        com.aurora.player.ui.ArtLoader.folderArt = v; c.store.update { it.copy(folderArt = v) }
    }

    var dupDialog by remember { mutableStateOf(false) }
    if (dupDialog) DuplicatesDialog(c) { dupDialog = false }
    Section("Song library")
    SwitchRow("Split multiple artists", "“A & B; C” shows as separate artists and album artists (separators: ${d.artistSeparators})", d.splitArtists) { v ->
        c.store.update { it.copy(splitArtists = v) }
    }
    ActionRow("Find duplicate songs", "Same title, artist and length stored more than once") { dupDialog = true }
    ActionRow(
        "Excluded folders",
        if (d.excludedFolders.isEmpty()) "None. Hide folders (voice notes, ringtones…) from Aurora" else "${d.excludedFolders.size} hidden",
    ) { foldersDialog = true }
    ChipRow("Exclude small duration files") {
        listOf(0, 15, 30, 60, 120).forEach { sec ->
            FilterChip(d.minDurationSec == sec, {
                c.store.update { it.copy(minDurationSec = sec) }; actions.rescan()
            }, label = { Text(if (sec == 0) "None" else if (sec < 60) "$sec s" else "${sec / 60} min") })
        }
    }
    Section("Scan")
    ActionRow("Scan", "${c.library.size} songs found. Aurora also scans every time it starts") { actions.rescan() }
    Section("Tags, album art, lyrics")
    SwitchRow("Load album arts", "If disabled, album art is not loaded anywhere in the app", d.loadArt) { v ->
        c.store.update { it.copy(loadArt = v) }; ArtLoader.enabled = v
    }
    SwitchRow("Hide website names from tags", "Removes things like [www.site.com] or \"Downloaded from site.net\" from titles, artists and albums everywhere", d.hideWebInfo) { v ->
        c.store.update { it.copy(hideWebInfo = v) }; actions.rescan()
    }
    SwitchRow("Show file names instead of titles", "Shows each song's file name everywhere", d.showFileNames) { v ->
        c.store.update { it.copy(showFileNames = v) }; actions.rescan()
    }
    Text(
        "Edit tags: open a song's ⋮ menu and choose “Edit tags”. Title, artist, album, album artist, genre, year, track and " +
            "embedded lyrics are written into the audio file.",
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun AdvancedPage(c: PlayerController, part: String) {
    val d = c.store.data
    var shuffleDlg by remember { mutableStateOf<String?>(null) }
    fun belowText(b: Boolean) = if (b) "Only shuffle songs below the currently playing song" else "Shuffle all songs in that queue"
    var backDlg by remember { mutableStateOf(false) }
    if (part == "exit") {
    ActionRow("When I press the back button in main screen…", if (d.backMode == 1) "If not in 'Now playing' tab then go there, otherwise exit the app" else "Remember history of tab switching and always go to previous tabs") { backDlg = true }
    }
    if (backDlg) androidx.compose.material3.AlertDialog(
        onDismissRequest = { backDlg = false },
        title = { Text("When I press the back button in main screen…") },
        text = {
            Column {
                listOf(0 to "Remember history of tab switching and always go to previous tabs", 1 to "If not in 'Now playing' tab then go there, otherwise exit the app").forEach { (m, label) ->
                    Row(Modifier.fillMaxWidth().clickable { c.store.update { it.copy(backMode = m) }; backDlg = false }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(d.backMode == m, { c.store.update { it.copy(backMode = m) }; backDlg = false })
                        Text(label, Modifier.padding(start = 12.dp))
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ backDlg = false }) { Text("Cancel") } },
    )
    if (part == "playback") {
    Section("Shuffle")
    ActionRow("When I turn on the 'Shuffle mode'…", belowText(d.shuffleBelowOnly)) { shuffleDlg = "mode" }
    ActionRow("When I select 'Randomize' sort-option for a queue…", belowText(d.randomizeBelowOnly)) { shuffleDlg = "sort" }
    shuffleDlg?.let { which ->
        val cur = if (which == "mode") d.shuffleBelowOnly else d.randomizeBelowOnly
        fun pick(below: Boolean) {
            c.store.update { if (which == "mode") it.copy(shuffleBelowOnly = below) else it.copy(randomizeBelowOnly = below) }
            shuffleDlg = null
        }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { shuffleDlg = null },
            title = { Text(if (which == "mode") "When I turn on the 'Shuffle mode'…" else "When I select 'Randomize' sort-option for a queue…") },
            text = {
                Column {
                    listOf(false to "Shuffle all songs in that queue", true to "Only shuffle songs below the currently playing song").forEach { (below, label) ->
                        Row(Modifier.fillMaxWidth().clickable { pick(below) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            androidx.compose.material3.RadioButton(cur == below, { pick(below) })
                            Text(label, Modifier.padding(start = 12.dp))
                        }
                    }
                }
            },
            confirmButton = { androidx.compose.material3.TextButton({ shuffleDlg = null }) { Text("Cancel") } },
        )
    }
    }
    if (part == "exit") {
    ChipRow("Close the app when no music has played for") {
        listOf(0, 5, 10, 15, 30, 60).forEach { m ->
            FilterChip(d.idleStopMin == m, { c.store.update { it.copy(idleStopMin = m) } }, label = { Text(if (m == 0) "Never" else "$m min") })
        }
    }
    }
    if (part == "exit") {
    SwitchRow("Stop playing and close the app when removed from recents", "", d.stopOnTaskRemoved) { v -> c.store.update { it.copy(stopOnTaskRemoved = v) } }
    }
    if (part == "playback") {
    Section("Shake")
    ChipRow("When I shake the phone") {
        listOf("Do nothing", "Next song", "Previous song", "Play / pause").forEachIndexed { i, n ->
            FilterChip(d.shakeAction == i, { c.store.update { it.copy(shakeAction = i) }; c.updateShake() }, label = { Text(n) })
        }
    }
    if (d.shakeAction != 0) ChipRow("Shake strength needed") {
        listOf("Light", "Normal", "Hard").forEachIndexed { i, n ->
            FilterChip(d.shakeStrength == i, { c.store.update { it.copy(shakeStrength = i) }; c.updateShake() }, label = { Text(n) })
        }
    }
    Section("Start")
    SwitchRow("Start playback when app is started", "Resumes your last queue automatically", d.autoPlayOnStart) { v -> c.store.update { it.copy(autoPlayOnStart = v) } }
    }
    var posDialog by remember { mutableStateOf(false) }
    if (part == "positions") {
    ActionRow(
        "Remember last positions of all tracks",
        if (d.rememberPositions) "On · songs of ${d.rememberMinMin}+ min · ${if (d.askToResume) "ask to resume" else "resume without asking"}" else "Off",
    ) { posDialog = true }
    if (posDialog) androidx.compose.ui.window.Dialog(onDismissRequest = { posDialog = false }) {
        androidx.compose.material3.Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, tonalElevation = 6.dp) {
            Column(Modifier.padding(24.dp).verticalScroll(rememberScrollState())) {
                Text("Remember last positions", style = MaterialTheme.typography.headlineSmall)
                Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Remember positions", Modifier.weight(1f))
                    androidx.compose.material3.Switch(d.rememberPositions, { v -> c.store.update { it.copy(rememberPositions = v) } })
                }
                Text(
                    "Only tracks at least this long (in minutes) are remembered:",
                    Modifier.padding(top = 14.dp, bottom = 6.dp), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                listOf(listOf(1, 2, 3, 5), listOf(10, 15, 20, 30)).forEach { rowMins ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowMins.forEach { m ->
                            FilterChip(
                                d.rememberMinMin == m, { c.store.update { it.copy(rememberMinMin = m) } },
                                label = { Text("$m min", maxLines = 1) }, modifier = Modifier.weight(1f),
                                enabled = d.rememberPositions,
                            )
                        }
                    }
                }
                listOf(true to "Ask to resume", false to "Resume without asking").forEach { (ask, label) ->
                    Row(
                        Modifier.fillMaxWidth().padding(top = 6.dp).clickable { c.store.update { it.copy(askToResume = ask) } },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        androidx.compose.material3.RadioButton(d.askToResume == ask, { c.store.update { it.copy(askToResume = ask) } })
                        Text(label, Modifier.padding(start = 4.dp))
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.End) {
                    androidx.compose.material3.TextButton({ posDialog = false }) { Text("Close") }
                }
            }
        }
    }
    ChipRow("Minimum duration for considering a playback") {
        listOf(5, 10, 15, 30, 60).forEach { sec ->
            FilterChip(d.playCountPct == 0 && d.minPlaySec == sec, { c.store.update { it.copy(minPlaySec = sec, playCountPct = 0) } }, label = { Text("$sec s") })
        }
    }
    ChipRow("…or a percentage of the song played") {
        listOf(10, 25, 50, 75, 90).forEach { pc ->
            FilterChip(d.playCountPct == pc, { c.store.update { it.copy(playCountPct = if (d.playCountPct == pc) 0 else pc) } }, label = { Text("$pc%") })
        }
    }
    }
    if (part == "playback") {
    Section("Previous, tap and skip")
    SwitchRow("Previous button restarts the song", "After the first 3 seconds, tapping previous goes back to the start", d.prevRestarts) { v ->
        c.store.update { it.copy(prevRestarts = v) }
    }
    if (d.prevRestarts) ChipRow("Restart the song once this much has played") {
        FilterChip(d.prevRestartPct == 0, { c.store.update { it.copy(prevRestartPct = 0) } }, label = { Text("3 s") })
        listOf(5, 10, 25, 50, 75).forEach { pc ->
            FilterChip(d.prevRestartPct == pc, { c.store.update { it.copy(prevRestartPct = pc) } }, label = { Text("$pc%") })
        }
    }
    SwitchRow("Tapping a song plays the whole list", "Off = plays only that song", d.tapPlaysList) { v -> c.store.update { it.copy(tapPlaysList = v) } }
    ChipRow("Fast-forward duration") {
        listOf(5, 10, 15, 30).forEach { sec ->
            FilterChip(d.ffSec == sec, { c.store.update { it.copy(ffSec = sec) } }, label = { Text("$sec s") })
        }
    }
    ChipRow("Rewind duration") {
        listOf(5, 10, 15, 30).forEach { sec ->
            FilterChip(d.rewindSec == sec, { c.store.update { it.copy(rewindSec = sec) } }, label = { Text("$sec s") })
        }
    }
    }
    if (part == "exit") {
        val bctx = LocalContext.current
        ActionRow("Allow background playback", "Stops Android from closing Aurora while it plays with the screen off or while you use other apps. Opens the battery list: set Aurora to “Not optimised”.") {
            try { bctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (_: Throwable) { try { bctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {} }
        }
    }
    if (part == "playback") {
        Section("Advanced")
        SwitchRow("Advanced shuffle", "Spread songs by the same artist apart when shuffling", d.smartShuffle) { v -> c.store.update { it.copy(smartShuffle = v) } }
        SwitchRow("Advanced external control", "Allow other apps and devices (Bluetooth, Android Auto, watches) to change repeat and shuffle. Takes effect when they reconnect", d.externalControl) { v -> c.store.update { it.copy(externalControl = v) } }
        SwitchRow("Make 'Next' / 'Previous' work like 'Fast-forward' / 'Rewind'", "For the Next / Previous keys on headphones and remote controls. Uses your fast-forward and rewind durations.", d.nextPrevSeek) { v -> c.store.update { it.copy(nextPrevSeek = v) } }
    }
    if (part == "exit") {
        SwitchRow("Confirm before exit", "Ask when pressing back on the first tab", d.confirmExit) { v -> c.store.update { it.copy(confirmExit = v) } }
    }
    if (part == "queues") {
    Section("Queues")
    SwitchRow("Swipe a song to remove it", "Slide a song left or right in the queue to take it out", d.swipeRemove) { v -> c.store.update { it.copy(swipeRemove = v) } }
    SwitchRow(
        "Open a queue named after the source",
        "Playing an album, playlist, folder… uses (or creates) a queue with that name. You can keep up to 20 queues.", d.sourceQueues,
    ) { v -> c.store.update { it.copy(sourceQueues = v) } }
    ChipRow("If a queue with that name already exists") {
        listOf(false to "Replace it", true to "Merge into it").forEach { (m, n) ->
            FilterChip(d.queueMerge == m, { c.store.update { it.copy(queueMerge = m) } }, label = { Text(n) })
        }
    }
    Section("Sort")
    SwitchRow("Ignore certain words at beginning while sorting", "Ignores “A”, “An”, “The” when sorting songs, albums and artists", d.ignoreWords) { v ->
        c.store.update { it.copy(ignoreWords = v) }
    }
    SwitchRow("Alphanumeric sorting", "Sort numbers by value: “Track 2” comes before “Track 10”", d.alphaNum) { v -> c.store.update { it.copy(alphaNum = v) } }
    }
}

@Composable
private fun LyricsPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    ChipRow("Preferred source of lyrics") {
        listOf("embedded" to "Embedded in song", "file" to "Lyrics file (.lrc)", "saved" to "Saved / imported").forEach { (id, n) ->
            FilterChip(d.lyricsPreferred == id, { c.store.update { it.copy(lyricsPreferred = id) } }, label = { Text(n) })
        }
    }
    Text(
        "When several sources have lyrics, the preferred one is used first. To choose a source for one song, tap the album art on the Now Playing screen " +
            "to open the lyrics, then tap “Source”. Aurora has no internet access, so lyrics come only from the song's tags, a .lrc file or ones you import.",
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Text("Lyrics appearance", Modifier.padding(start = 20.dp, top = 12.dp), style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
    ChipRow("Text size") {
        listOf("Small", "Medium", "Large").forEachIndexed { i, n ->
            FilterChip(d.lyricScale == listOf(80, 100, 125)[i], { c.store.update { it.copy(lyricScale = listOf(80, 100, 125)[i]) } }, label = { Text(n) })
        }
    }
    ChipRow("Alignment") {
        listOf("Left", "Center", "Right").forEachIndexed { i, n ->
            FilterChip(d.lyricAlignC == i, { c.store.update { it.copy(lyricAlignC = i) } }, label = { Text(n) })
        }
    }
    ChipRow("Font") {
        listOf(false to "Sans", true to "Serif").forEach { (serif, n) ->
            FilterChip(d.lyricSerif == serif, { c.store.update { it.copy(lyricSerif = serif) } }, label = { Text(n) })
        }
    }
    ActionRow("Read .lrc files next to songs", "Grants all-files access so “song.mp3” can use “song.lrc” in the same folder (Android 11+).") {
        if (Build.VERSION.SDK_INT >= 30) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}

@Composable
private fun DesktopPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current
        SwitchRow("Show floating lyrics", "Draws over other apps. Needs “display over other apps” permission.", c.overlayActive) {
            actions.toggleOverlay(it)
        }
        ChipRow("Lyric line motion") {
        com.aurora.player.ui.LYRIC_MOTIONS.forEachIndexed { i, name ->
            FilterChip(
                d.lyricMotion == i, { c.store.update { it.copy(lyricMotion = i) } }, label = { Text(name) },
                colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer, selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer),
            )
        }
    }
        SwitchRow("Lock position", "Stops the window from being dragged. Its buttons keep working.", d.overlayLocked) {
            LyricsOverlayService.setLocked(ctx, it)
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Row {
                Text("Text size", Modifier.weight(1f))
                Text("${d.overlayTextSp} sp", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Slider(d.overlayTextSp.toFloat(), { v -> c.store.update { it.copy(overlayTextSp = v.roundToInt()) } }, valueRange = 12f..48f)
            Text("Colour")
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(0xFFFFFFFF, 0xFFFFE066, 0xFF7FE3D0, 0xFFFF8FB1, 0xFF9CFF8A, 0xFFB4A8FF).forEach { col ->
                    val sel = d.overlayColor == col
                    Box(
                        Modifier.size(34.dp).background(Color(col), CircleShape)
                            .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                            .bounceClick { c.store.update { it.copy(overlayColor = col) } },
                    )
                }
            }
        }

}

@Composable
private fun BackupPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current
        val folderLabel = if (d.backupFolder.isEmpty()) "Default: Documents/Aurora/Backups/Automatic backups. Tap to choose another folder"
        else (Uri.parse(d.backupFolder).lastPathSegment ?: "Chosen folder").replace(':', '/')
        ActionRow("Export listening history", "Every counted play with date and time, as a .csv file") { actions.exportHistory() }
        ActionRow("Backup folder", folderLabel) { actions.chooseBackupFolder() }
        ActionRow("Backup now", "Last backup: ${formatDateTime(ctx, d.lastBackupAt)}") { actions.backupNow() }
        SwitchRow(
            "Automatic backup", "Saves a new zip in the background and keeps only the latest ones",
            d.autoBackup,
        ) { on ->
            c.store.update { it.copy(autoBackup = on) }
            BackupScheduler.apply(ctx, c.store.data)
        }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Every", Modifier.padding(end = 4.dp))
            listOf(1 to "Day", 7 to "Week", 30 to "Month").forEach { (days, name) ->
                FilterChip(d.autoBackupDays == days, {
                    c.store.update { it.copy(autoBackupDays = days) }
                    BackupScheduler.apply(ctx, c.store.data)
                }, label = { Text(name) })
            }
        }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Keep last", Modifier.padding(end = 4.dp))
            listOf(3, 5, 10).forEach { n ->
                FilterChip(d.autoBackupKeep == n, { c.store.update { it.copy(autoBackupKeep = n) } }, label = { Text("$n") })
            }
        }
        SwitchRow(
            "Export most played automatically", "At the end of each week, month and year, saves your most played songs and artists as .csv files in the backup folder",
            d.autoCsv,
        ) { on ->
            c.store.update { it.copy(autoCsv = on) }
            com.aurora.player.backup.CsvExport.schedule(ctx, on)
        }
        ActionRow("Export most played now", "Saves your all-time and this-month most played songs and artists as .csv files right away") {
            val app = ctx.applicationContext
            Thread {
                val n = try { com.aurora.player.backup.CsvExport.runNow(app, c) } catch (_: Throwable) { -1 }
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    android.widget.Toast.makeText(app, if (n > 0) "Exported to the backup folder" else if (n == 0) "No plays to export yet" else "Could not save the files", android.widget.Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
        ActionRow("Restore from backup", "Choose what to restore: settings, favourites, playlists, play counts, queues, lyrics") { actions.openRestore() }

}

@Composable
private fun LockPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current
        Section("Lock screen")
        SwitchRow(
            "Lock-screen player",
            "Shows a full player over the lock screen when music is playing and the screen turns off. Needs “display over other apps”.",
            d.lockScreenPlayer,
        ) { on ->
            if (on && !actions.ensureOverlayPermission()) return@SwitchRow
            c.store.update { it.copy(lockScreenPlayer = on) }
        }
        SwitchRow("Skip when paused for a while", "Don't show the lock-screen player if music has been paused for more than a minute", d.lockSkipPaused) { v ->
            c.store.update { it.copy(lockSkipPaused = v) }
        }
        SwitchRow("Always show", "Show the lock-screen player whenever the screen turns off, even if music is paused", d.lockAlways) { v ->
            c.store.update { it.copy(lockAlways = v) }
        }
        SwitchRow("Adapt from album art", "Blurred cover and cover colours as the lock-screen background", d.lockAdapt) { v ->
            c.store.update { it.copy(lockAdapt = v) }
        }
        if (d.lockAdapt) ChipRow("Adapt style") {
            listOf("Blurred cover", "Cover swatch").forEachIndexed { i, n ->
                FilterChip(d.lockAdaptStyle == i, { c.store.update { it.copy(lockAdaptStyle = i) } }, label = { Text(n) })
            }
        }
        SwitchRow("Bold current lyric line", "Full-screen lyrics (tap the lyrics, then the tune icon for size, alignment and darkness)", d.lockLyricBold) { v ->
            c.store.update { it.copy(lockLyricBold = v) }
        }
        SwitchRow("Show lyrics on lock screen", "Current line under the cover", d.lockShowLyrics) { v ->
            c.store.update { it.copy(lockShowLyrics = v) }
        }
    ChipRow("Lyric line motion") {
        com.aurora.player.ui.LYRIC_MOTIONS.forEachIndexed { i, name ->
            FilterChip(
                d.lyricMotion == i, { c.store.update { it.copy(lyricMotion = i) } }, label = { Text(name) },
                colors = androidx.compose.material3.FilterChipDefaults.filterChipColors(selectedContainerColor = MaterialTheme.colorScheme.primaryContainer, selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer),
            )
        }
    }

        WidgetSettings(c)

}

@Composable
private fun NotificationPage(c: PlayerController) {
    val d = c.store.data
    fun save(f: (com.aurora.player.data.Persisted) -> com.aurora.player.data.Persisted) { c.store.update(f); c.onNotifSettingsChanged?.invoke() }
    Section("Buttons next to play / previous / next")
    val all = listOf("fav" to "Favourite", "repeat" to "Repeat", "shuffle" to "Shuffle", "overlay" to "Desktop lyrics", "addpl" to "Add to playlist (cross when paused)", "close" to "Close")
    Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text("Arrangement of buttons")
        Text(
            "Tap to add or remove a button. They appear in the order you tap them.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            all.forEach { (k, n) ->
                val on = k in d.notifButtons
                FilterChip(on, {
                    save { it.copy(notifButtons = if (on) it.notifButtons - k else it.notifButtons + k) }
                }, label = { Text(n + if (on) "  ${d.notifButtons.indexOf(k) + 1}" else "") })
            }
        }
    }
    SwitchRow("Adapt from album art", "Colours the notification with the cover's dominant colour", d.notifAdapt) { v -> save { it.copy(notifAdapt = v) } }
    if (d.notifAdapt) ChipRow("Adapt style") {
        listOf("Cover edge", "Cover swatch").forEachIndexed { i, n ->
            FilterChip(d.notifAdaptStyle == i, { save { it.copy(notifAdaptStyle = i) } }, label = { Text(n) })
        }
    }
    Section("Expanded notification")
    SwitchRow("Upcoming songs", "Shows the next two songs when the notification is expanded", d.notifUpcoming) { v -> save { it.copy(notifUpcoming = v) } }
    SwitchRow("Album art", "Shows the cover in the notification", d.notifArt) { v -> save { it.copy(notifArt = v) } }
    Text(
        "The notification's colours follow the album art and your phone's theme (set by Android).",
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun MotionPage(c: PlayerController) {
    val d = c.store.data
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var replay by remember { mutableStateOf(0) }
    Section("Speed")
    ChipRow("Animation speed") {
        Motion.SPEEDS.forEachIndexed { i, n -> FilterChip(d.motionSpeed == i, { c.store.update { it.copy(motionSpeed = i) }; replay++ }, label = { Text(n) }) }
    }
    Text(
        "Off turns every animation off (best for slow phones). Relaxed is slower and floatier, Snappy is quicker.",
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Section("Screens")
    ChipRow("Transition between screens") {
        Motion.NAV.forEachIndexed { i, n -> FilterChip(d.navStyle == i, { c.store.update { it.copy(navStyle = i) } }, label = { Text(n) }) }
    }
    SwitchRow("Fade between covers", "Album art cross-fades when the song changes", d.artFade) { v -> c.store.update { it.copy(artFade = v) } }
    Section("Lists")
    ChipRow("How songs and albums appear") {
        Motion.LIST.forEachIndexed { i, n -> FilterChip(d.listAnim == i, { c.store.update { it.copy(listAnim = i) }; replay++ }, label = { Text(n) }) }
    }
    SwitchRow("One after another", "Items appear with a small delay between them", d.listStagger) { v -> c.store.update { it.copy(listStagger = v) }; replay++ }
    Section("Buttons")
    ChipRow("Press bounce") {
        Motion.PRESS.forEachIndexed { i, n -> FilterChip(d.pressMode == i, { c.store.update { it.copy(pressMode = i) } }, label = { Text(n) }) }
    }
    Section("Preview")
    Column(Modifier.padding(horizontal = 12.dp)) {
        androidx.compose.runtime.key(replay) {
            listOf("First song", "Second song", "Third song", "Fourth song").forEachIndexed { i, n ->
                Row(
                    Modifier.fillMaxWidth().staggerIn(i).padding(horizontal = 8.dp, vertical = 3.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) { Text(n) }
            }
        }
        Row(Modifier.padding(top = 10.dp, start = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).background(MaterialTheme.colorScheme.primary, CircleShape).bounceClick {
                    replay++
                    if (d.motionSpeed == 0) android.widget.Toast.makeText(ctx, "Animation speed is Off - choose Relaxed, Normal or Snappy to see motion", android.widget.Toast.LENGTH_SHORT).show()
                    else if (d.listAnim == 0 && d.pressMode == 0) android.widget.Toast.makeText(ctx, "List animation and press bounce are both off", android.widget.Toast.LENGTH_SHORT).show()
                },
                contentAlignment = Alignment.Center,
            ) { Icon(androidx.compose.material.icons.Icons.Rounded.PlayArrow, null, tint = MaterialTheme.colorScheme.onPrimary) }
            Column(Modifier.padding(start = 12.dp)) {
                Text("Tap to test the button bounce and replay the list", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (d.motionSpeed == 0) Text("Animations are off. Pick Relaxed, Normal or Snappy under Speed.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                else if (d.pressMode == 0) Text("Press bounce is off.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun AlbumsPage(c: PlayerController) {
    val d = c.store.data
    var viewDlg by remember { mutableStateOf(false) }
    var infoDlg by remember { mutableStateOf(false) }
    SwitchRow("Merge albums with the same name", "Always treat songs with the same album name as one album, even when the album artists differ", d.albumMergeByName) { v ->
        c.store.update { it.copy(albumMergeByName = v) }; com.aurora.player.data.AlbumIndex.rebuild(c.library)
    }
    ActionRow("Album view mode", if (d.albumCols == 1) "List view" else "Grid view, ${d.albumCols} columns") { viewDlg = true }
    ActionRow("Show extra info in the list of albums", ALBUM_INFO_OPTIONS.getOrElse(d.albumInfo) { ALBUM_INFO_OPTIONS[0] }) { infoDlg = true }
    if (viewDlg) androidx.compose.material3.AlertDialog(
        onDismissRequest = { viewDlg = false },
        title = { Text("Album view mode") },
        text = {
            Column {
                (1..5).forEach { n ->
                    Row(Modifier.fillMaxWidth().clickable { c.store.update { it.copy(albumCols = n) }; viewDlg = false }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(d.albumCols == n, { c.store.update { it.copy(albumCols = n) }; viewDlg = false })
                        Text(if (n == 1) "List view" else "Grid view, $n columns", Modifier.padding(start = 12.dp))
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ viewDlg = false }) { Text("Cancel") } },
    )
    if (infoDlg) androidx.compose.material3.AlertDialog(
        onDismissRequest = { infoDlg = false },
        title = { Text("Show extra info in the list of albums") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                ALBUM_INFO_OPTIONS.forEachIndexed { i, label ->
                    Row(Modifier.fillMaxWidth().clickable { c.store.update { it.copy(albumInfo = i) }; infoDlg = false }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.RadioButton(d.albumInfo == i, { c.store.update { it.copy(albumInfo = i) }; infoDlg = false })
                        Text(label, Modifier.padding(start = 12.dp))
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ infoDlg = false }) { Text("Cancel") } },
    )
}

@Composable
private fun CompatPage(c: PlayerController) {
    val d = c.store.data
    Text(
        "If Aurora is slow, or stops while playing on an older phone, switch features off here. Each one is independent, so you can find out which one causes trouble.",
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (d.safeNote) {
        androidx.compose.material3.Card(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Aurora switched some features off", fontWeight = FontWeight.Bold)
                Text("The app stopped during playback last time, so the custom notification and the sound engine were turned off automatically (and more, if it happened again). Turn them back on one at a time to find the cause.", style = MaterialTheme.typography.bodySmall)
                androidx.compose.material3.TextButton({ c.store.update { it.copy(safeNote = false) } }) { Text("Dismiss") }
            }
        }
    }
    Section("Playback")
    SwitchRow("Aurora sound engine", "Equalizer, mono and balance. Restart Aurora after changing it.", d.soundEngine) { v -> c.store.update { it.copy(soundEngine = v) } }
    SwitchRow("Fast lyric updates", "Off = lyrics refresh 8 times a second instead of 25 (lighter on slow phones)", d.fastLyrics) { v -> c.store.update { it.copy(fastLyrics = v) } }
    Section("Notification, widgets and tile")
    SwitchRow("Custom notification", "Aurora's own layout. Off = Android's standard media notification", d.customNotif) { v -> c.store.update { it.copy(customNotif = v) } }
    SwitchRow("Update widgets while playing", "Off = widgets refresh only when playback pauses", d.widgetsLive) { v -> c.store.update { it.copy(widgetsLive = v) } }
    SwitchRow("Update Quick Settings tile while playing", "", d.qsTileLive) { v -> c.store.update { it.copy(qsTileLive = v) } }
    Section("Reset")
    ActionRow("Turn everything on", "Restores all of the switches above") {
        c.store.update { it.copy(soundEngine = true, customNotif = true, widgetsLive = true, qsTileLive = true, fastLyrics = true, safeNote = false) }
    }
    ActionRow("Turn everything off (safe mode)", "The lightest setup, for the slowest phones") {
        c.store.update { it.copy(soundEngine = false, customNotif = false, widgetsLive = false, qsTileLive = false, fastLyrics = false) }
    }
}

@Composable
private fun AboutPage() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        androidx.compose.foundation.Image(
            androidx.compose.ui.res.painterResource(com.aurora.player.R.drawable.ic_logo), null,
            Modifier.size(96.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(24.dp)),
        )
        Text("Aurora", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text("Version 2.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    var err by remember { mutableStateOf(com.aurora.player.CrashLog.read(ctx)) }
    if (err.isNotBlank()) {
        Section("Last error")
        Text(err, Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            androidx.compose.material3.TextButton({
                (ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                    .setPrimaryClip(android.content.ClipData.newPlainText("Aurora error", err))
            }) { Text("Copy") }
            androidx.compose.material3.TextButton({ com.aurora.player.CrashLog.clear(ctx); err = "" }) { Text("Clear") }
        }
    }
    Text(
        "Aurora keeps playing in the background with lock-screen controls, gapless playback, two switchable queues, " +
            "playlists, favourites, equalizer, bass boost, speed/pitch, sleep timer, A–B repeat and floating lyrics.",
        Modifier.padding(horizontal = 20.dp, vertical = 12.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
internal fun SliderSetting(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, text: String, onChange: (Float) -> Unit) {
    Column(Modifier.cardRow().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row {
            Text(label, Modifier.weight(1f))
            Text(text, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(value, onChange, valueRange = range, steps = steps)
    }
}

@Composable
internal fun ChipRow(label: String, content: @Composable () -> Unit) {
    Column(Modifier.cardRow().padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(label, fontWeight = FontWeight.Medium)
        Row(Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
private fun ExcludedFoldersDialog(c: PlayerController, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val d = c.store.data
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { onDismiss(); onChanged() },
        title = { Text("Excluded folders") },
        text = {
            androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                if (c.allFolders.isEmpty()) item { Text("No music folders found yet.") }
                items(c.allFolders.size) { i ->
                    val f = c.allFolders[i]
                    val hidden = f in d.excludedFolders
                    Row(Modifier.fillMaxWidth().clickable {
                        c.store.update { it.copy(excludedFolders = if (hidden) it.excludedFolders - f else it.excludedFolders + f) }
                    }, verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Checkbox(hidden, null)
                        Column(Modifier.padding(start = 8.dp, top = 6.dp, bottom = 6.dp)) {
                            Text(f.substringAfterLast('/').ifEmpty { "/" }, fontWeight = FontWeight.Medium)
                            Text(f, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ onDismiss(); onChanged() }) { Text("Done") } },
    )
}

@Composable
internal fun Section(title: String) {
    Row(Modifier.padding(start = 24.dp, end = 16.dp, top = 24.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(width = 4.dp, height = 16.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
        Text(
            title, Modifier.padding(start = 10.dp),
            style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
        )
    }
}

/** Every setting row sits on its own rounded card, so the lists read as tidy blocks. */
@Composable
internal fun Modifier.cardRow(): Modifier = this.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp)
    .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.38f))

@Composable
internal fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.cardRow().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Medium)
            if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
internal fun ActionRow(title: String, sub: String, onClick: () -> Unit) {
    Column(Modifier.cardRow().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text(title, fontWeight = FontWeight.Medium)
        if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


@Composable
private fun WidgetSettings(c: PlayerController) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val d = c.store.data
    var tab by remember { mutableStateOf(2) }
    fun save(f: (com.aurora.player.data.Persisted) -> com.aurora.player.data.Persisted) { c.store.update(f); WidgetUpdater.update(ctx) }
    Section("Widget theme:")
    listOf("Black and red widget" to 4, "Light theme" to 1, "Dark theme" to 2, "Match with system" to 0, "Adapt from album art" to 3).forEach { (n, v) ->
        Row(
            Modifier.fillMaxWidth().clickable { save { it.copy(queueTheme = v) } }.padding(horizontal = 20.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            androidx.compose.material3.RadioButton(d.queueTheme == v, { save { it.copy(queueTheme = v) } })
            Text(n, Modifier.padding(start = 8.dp))
        }
    }
    Text(
        "“Match with system” follows your wallpaper colours (Material You on Android 12+) and dark mode.",
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Section("Transparency")
    SliderSetting("Transparency", d.wAlpha.toFloat(), 0f..100f, 19, "${d.wAlpha}%") { v -> save { it.copy(wAlpha = v.toInt()) } }

    androidx.compose.material3.TabRow(tab, Modifier.padding(top = 12.dp)) {
        listOf("SIMPLE", "ADVANCED", "CURRENT QUEUE").forEachIndexed { i, n ->
            androidx.compose.material3.Tab(tab == i, { tab = i }, text = { Text(n, maxLines = 1, style = MaterialTheme.typography.labelMedium) })
        }
    }
    @Composable
    fun Check(label: String, on: Boolean, set: (Boolean) -> Unit) {
        Row(Modifier.fillMaxWidth().clickable { set(!on) }.padding(horizontal = 20.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.Checkbox(on, { set(it) })
            Text(label, Modifier.padding(start = 8.dp))
        }
    }
    when (tab) {
        0 -> {
            Text("Standard widget", Modifier.padding(start = 20.dp, top = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Check("Album art", d.wsArt) { v -> save { it.copy(wsArt = v) } }
            Check("Add/Remove favorite", d.wsFav) { v -> save { it.copy(wsFav = v) } }
            Check("Progress bar", d.wsProg) { v -> save { it.copy(wsProg = v) } }
        }
        1 -> {
            Text("Large widget", Modifier.padding(start = 20.dp, top = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Check("Album art", d.waArt) { v -> save { it.copy(waArt = v) } }
            Check("Add/Remove favorite", d.waFav) { v -> save { it.copy(waFav = v) } }
            Check("Progress bar", d.waProg) { v -> save { it.copy(waProg = v) } }
            Check("Shuffle and repeat buttons", d.waModes) { v -> save { it.copy(waModes = v) } }
            Check("Upcoming songs", d.waNext) { v -> save { it.copy(waNext = v) } }
        }
        else -> {
            Text("Current queue widget", Modifier.padding(start = 20.dp, top = 12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            Check("Album art", d.wqArt) { v -> save { it.copy(wqArt = v) } }
            Check("Desktop lyrics button", d.wqOverlay) { v -> save { it.copy(wqOverlay = v) } }
            Check("Add/Remove favorite", d.wqFav) { v -> save { it.copy(wqFav = v) } }
            Check("Fast-forward and rewind buttons", d.wqFfRew) { v -> save { it.copy(wqFfRew = v) } }
        }
    }
}


@Composable
private fun DuplicatesDialog(c: PlayerController, onDismiss: () -> Unit) {
    val groups = remember(c.library) {
        c.library.groupBy { Triple(it.title.trim().lowercase(), it.artist.trim().lowercase(), it.durationMs / 3000) }
            .values.filter { it.size > 1 }.sortedBy { it.first().title.lowercase() }
    }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (groups.isEmpty()) "No duplicates" else "${groups.size} duplicated songs") },
        text = {
            if (groups.isEmpty()) Text("Every song in your library is unique.")
            else Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                groups.forEach { g ->
                    Column(Modifier.padding(vertical = 6.dp)) {
                        Text(g.first().title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(g.first().artist, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        g.forEach { t -> Text(t.path, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onDismiss) { Text("Close") } },
    )
}
