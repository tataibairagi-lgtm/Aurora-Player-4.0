package com.aurora.player.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/** One topic of the guide: a heading, a short plain-language intro and the things you can do there. */
class GuideTopic(val title: String, val intro: String, val points: List<Pair<String, String>>)

/** Everything Aurora can do, written for someone who has never used it. Shown on first start and in Settings, About. */
val GUIDE_TOPICS: List<GuideTopic> = listOf(
    GuideTopic(
        "Welcome to Aurora",
        "Aurora is a music player that works completely offline. It plays the songs already on your phone, and it has no internet permission at all, so nothing you play or save ever leaves your phone.",
        listOf(
            "Your music" to "On the first start Aurora asks to read your audio files. Allow it and your songs appear in the tabs at the top.",
            "Tabs" to "Swipe left and right, or tap the icons: Queue, Now playing, Albums, Artists, Songs, Search, Folders, Playlists and more. You can hide or rearrange them in Settings, Tabs and layout.",
            "Everything is optional" to "Aurora looks good as it is. Every extra feature in this guide is a switch you can turn on later, so there is nothing you have to set up now.",
        ),
    ),
    GuideTopic(
        "Playing music",
        "Tap any song to play it. The song you tap and the songs after it become the queue, which is the list of what plays next.",
        listOf(
            "Now playing" to "The big screen with the cover, seek bar and buttons. Drag the seek bar, tap the heart to favourite, swipe the cover to skip.",
            "The three-dot menu" to "Almost everything has a three-dot menu: play next, add to a queue or playlist, edit tags, share, set as ringtone, delete.",
            "Long-press" to "Press and hold a song to select it, then pick more songs to act on several at once.",
            "Search" to "The magnifier tab finds songs, albums, artists and folders as you type.",
        ),
    ),
    GuideTopic(
        "Queues",
        "A queue is the list of songs that will play. Aurora can keep several queues at once, so you can switch between, for example, a workout list and a bedtime list without losing your place in either.",
        listOf(
            "Add to queue" to "Use \"Play next\" or \"Add to queue\" from any song menu.",
            "Several queues" to "Open the Queue tab and use the queue switcher. Each queue remembers its song and position.",
            "Reorder and clean up" to "Drag songs to reorder, swipe to remove, and sort the queue from its menu.",
            "When the queue ends" to "Settings, Playback behaviour lets you stop, repeat, or go on to the next queue.",
        ),
    ),
    GuideTopic(
        "Playlists, favourites and mixes",
        "Playlists are lists you build yourself. Mixes are lists Aurora builds for you from what you listen to.",
        listOf(
            "Playlists" to "Playlists tab, then New playlist. Add songs from any song menu. Import and export .m3u files from the playlist menu.",
            "Favourites" to "Tap the heart on Now playing. Favourites collect in one list.",
            "Mixes" to "Most played, never played, forgotten songs, top rated, by genre, by artist, by time of day. Pull the refresh button for a fresh pick.",
            "Ratings" to "Give a song 1 to 5 stars from its menu, and Aurora builds a Top rated mix.",
        ),
    ),
    GuideTopic(
        "Lyrics",
        "Aurora shows lyrics stored inside the song file or in a .lrc file next to it. Synced lyrics light up line by line as the song plays.",
        listOf(
            "Show lyrics" to "Tap the lyrics button on Now playing, or the cover, depending on your gesture settings.",
            "Edit and sync" to "Edit lyrics inside the file or as a .lrc file, and tap along to time unsynced lyrics yourself.",
            "Desktop lyrics" to "A small floating lyrics window that stays on top of other apps.",
            "Style" to "Size, colour, alignment, blur and animation can all be changed from the lyrics style dialog.",
        ),
    ),
    GuideTopic(
        "Sound",
        "Aurora has its own sound engine, with no extra app needed.",
        listOf(
            "Equalizer" to "A 31-band equalizer with presets, bass boost, virtualizer and loudness. It remembers separate settings for the speaker, wired headphones and Bluetooth.",
            "Speed and pitch" to "Slow a song down to learn it, or speed up a podcast.",
            "A-B repeat" to "Mark a start and an end and loop just that part.",
            "Fades and crossfade" to "Smooth fades when you pause or resume, and crossfade between songs.",
            "Sleep timer" to "Stop after a number of minutes, after this song, or after a number of songs, fading out gently.",
            "Per-song trim" to "Play only part of a song, every time, without changing the file.",
        ),
    ),
    GuideTopic(
        "Around your phone",
        "Aurora keeps working when you leave the app.",
        listOf(
            "Notification" to "Controls in the notification, with a compact or full style and your choice of buttons.",
            "Lock screen player" to "A full player shown when the screen turns off while music plays.",
            "Widgets" to "Home-screen widgets for the player and the queue, in several sizes.",
            "Quick Settings tile" to "Play and pause from the swipe-down panel.",
            "Alarms and Bluetooth" to "Start a playlist at a set time, or when your headphones or car connect.",
            "Shake to skip, headset buttons" to "Switch these on in Settings if you like them.",
        ),
    ),
    GuideTopic(
        "Your library",
        "Keep your files tidy and your music organised.",
        listOf(
            "Tag editor" to "Fix the title, artist, album, genre and cover art inside the files.",
            "Folders" to "Browse the way your files are stored, and hide folders you don't want, like voice notes.",
            "Artists and genres" to "Songs by \"A feat. B\" can be split so they appear under both artists.",
            "Duplicates" to "Find duplicate songs and clean them up.",
            "Statistics" to "Play counts, a year in review you can share as a picture, and a share card for any song.",
        ),
    ),
    GuideTopic(
        "Make it yours",
        "Aurora is very customisable, and none of it is needed to enjoy the app.",
        listOf(
            "Theme" to "Light, dark or pure black, with your choice of accent colour. Save looks and let Aurora switch between them by time of day.",
            "Now playing" to "Pick the background, the cover style (square, round, spinning vinyl) and which buttons to show.",
            "Expressive looks" to "Settings, Interface, Expressive looks has optional extras: wavy seek bar, floating tabs, collapsing headers, fonts and more. They are all off until you switch them on.",
            "Settings search" to "Lost? Type what you want, like \"crossfade\", at the top of Settings.",
            "PIN lock" to "Protect the app with a PIN.",
        ),
    ),
    GuideTopic(
        "Keep it safe",
        "Your playlists, play counts and settings live only on your phone, so back them up.",
        listOf(
            "Backup" to "Settings, Backup and restore makes a zip you can keep anywhere. Turn on automatic backup to do it for you.",
            "Restore" to "Restore from that zip on a new phone and everything comes back, including your queues.",
            "If something goes wrong" to "Settings, About shows the last error and why the app last stopped, which helps when asking for help.",
        ),
    ),
)

/** The first-start walkthrough: one page per topic, swipe or tap Next. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WelcomeGuide(onDone: () -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = {},
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = false, dismissOnClickOutside = false, decorFitsSystemWindows = true),
    ) {
        val pager = rememberPagerState { GUIDE_TOPICS.size }
        val scope = rememberCoroutineScope()
        val last = pager.currentPage == GUIDE_TOPICS.lastIndex
        Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${pager.currentPage + 1} of ${GUIDE_TOPICS.size}", Modifier.padding(start = 12.dp).weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                TextButton(onDone) { Text("Skip") }
            }
            HorizontalPager(pager, Modifier.weight(1f)) { i ->
                val t = GUIDE_TOPICS[i]
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 8.dp)) {
                    Text(t.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(t.intro, Modifier.padding(top = 10.dp, bottom = 14.dp), style = MaterialTheme.typography.bodyLarge)
                    t.points.forEach { (h, body) ->
                        Column(
                            Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(18.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)).padding(14.dp),
                        ) {
                            Text(h, fontWeight = FontWeight.SemiBold)
                            Text(body, Modifier.padding(top = 3.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.size(12.dp))
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    GUIDE_TOPICS.indices.forEach { i ->
                        Box(Modifier.size(if (i == pager.currentPage) 10.dp else 7.dp).clip(CircleShape)
                            .background(if (i == pager.currentPage) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)))
                    }
                }
                Button({ if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } }) { Text(if (last) "Get started" else "Next") }
            }
        }
    }
}
