package com.aurora.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object LrcParser {
    private val tag = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")

    private val wordTag = Regex("""<(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?>""")

    private fun toMs(min: String, sec: String, frac: String): Long =
        min.toLong() * 60_000 + sec.toLong() * 1000 + (if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong())

    /** Enhanced LRC: "<00:12.40>word <00:12.90>word" gives per-word times. */
    private fun splitWords(body: String): Pair<String, List<LyricWord>?> {
        val ms = wordTag.findAll(body).toList()
        if (ms.isEmpty()) return body to null
        val words = ArrayList<LyricWord>()
        val pre = body.substring(0, ms[0].range.first)
        for ((k, m) in ms.withIndex()) {
            val end = if (k + 1 < ms.size) ms[k + 1].range.first else body.length
            var txt = body.substring(m.range.last + 1, end)
            if (k == 0) txt = pre + txt
            if (txt.isEmpty()) continue
            words += LyricWord(toMs(m.groupValues[1], m.groupValues[2], m.groupValues[3]), txt)
        }
        val text = words.joinToString("") { it.text }.trim()
        return text to words.takeIf { it.isNotEmpty() }
    }

    fun parse(text: String): Lyrics? {
        val synced = ArrayList<LyricLine>()
        val plain = ArrayList<String>()
        for (raw in text.lines()) {
            val matches = tag.findAll(raw).toList()
            if (matches.isEmpty()) {
                val t = raw.trim()
                if (t.isNotEmpty() && !t.startsWith("[")) plain += t
                continue
            }
            val rawBody = raw.substring(matches.last().range.last + 1)
            val (body, words) = splitWords(rawBody.trim())
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                synced += LyricLine(min * 60_000 + sec * 1000 + ms, body, words)
            }
        }
        if (synced.isNotEmpty()) return Lyrics(synced.sortedBy { it.timeMs }, true)
        if (plain.isNotEmpty()) return Lyrics(plain.map { LyricLine(-1, it) }, false)
        return null
    }
}

class LyricsRepo(ctx: Context) {
    private val appCtx: Context = ctx.applicationContext
    val dir: File = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    private fun lrc(t: Track) = File(dir, "${t.id}.lrc")

    fun hasLocal(t: Track) = lrc(t).exists()

    fun save(t: Track, text: String) {
        lrc(t).writeText(text)
    }

    fun delete(t: Track) {
        lrc(t).delete()
    }

    private fun sidecar(t: Track) = File(t.path.substringBeforeLast('.') + ".lrc")

    /** Text of the .lrc file next to the song, or null. */
    fun readSidecar(t: Track): String? = try { sidecar(t).takeIf { it.exists() && it.canRead() }?.readText() } catch (_: Exception) { null }

    /** Text saved/imported inside Aurora, or null. */
    fun readSaved(t: Track): String? = try { lrc(t).takeIf { it.exists() }?.readText() } catch (_: Exception) { null }

    /** Writes the .lrc file next to the song. Returns false if the system doesn't let Aurora write there. */
    fun writeSidecar(t: Track, text: String): Boolean = try {
        val f = sidecar(t)
        if (text.isBlank()) { if (f.exists()) f.delete() else true } else { f.writeText(text); true }
    } catch (_: Throwable) {
        false
    }

    /** Which sources have lyrics for this song right now (online is always "maybe"). */
    suspend fun available(t: Track): Map<String, Boolean> = withContext(Dispatchers.IO) {
        mapOf(
            "saved" to lrc(t).exists(),
            "file" to try { sidecar(t).let { it.exists() && it.canRead() } } catch (_: Exception) { false },
            "embedded" to (TagIo.embeddedLyrics(appCtx, t) != null),
        )
    }

    private fun fromSource(t: Track, src: String, force: Boolean): Lyrics? = try {
        when (src) {
            "saved" -> lrc(t).takeIf { it.exists() }?.let { LrcParser.parse(it.readText()) }
            "file" -> sidecar(t).takeIf { it.exists() && it.canRead() }?.let { LrcParser.parse(it.readText()) }
            "embedded" -> TagIo.embeddedLyrics(appCtx, t)?.let { LrcParser.parse(it) }
            else -> null
        }
    } catch (_: Exception) {
        null
    }

    /** Tries the sources in [order] ("saved", "file", "embedded"); the first that has lyrics wins. */
    suspend fun load(t: Track, order: List<String>, allowOnline: Boolean, force: Boolean = false): Lyrics? =
        withContext(Dispatchers.IO) {
            for (src in order) {
                fromSource(t, src, force)?.let { return@withContext it }
            }
            null
        }

}
