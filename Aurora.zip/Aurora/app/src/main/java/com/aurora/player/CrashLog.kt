package com.aurora.player

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps the last crash / playback error in a small file so it can be read in Settings > About (no computer needed). */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_error.txt")

    /** The screen that is open, so a crash can be shown on top of it instead of closing the app. */
    @Volatile var top: java.lang.ref.WeakReference<android.app.Activity>? = null

    fun install(ctx: Context) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            write(ctx, "Crash in thread ${t.name}", e)
            val trace = "Crash in thread ${t.name}\n" + android.util.Log.getStackTraceString(e).take(12000)
            val a = top?.get()
            if (a != null && !a.isFinishing) {
                // show the error on the open screen and keep the app alive long enough to copy it
                try {
                    if (android.os.Looper.myLooper() === android.os.Looper.getMainLooper()) {
                        a.setContentView(buildCrashView(a, trace))
                        while (true) { try { android.os.Looper.loop() } catch (_: Throwable) {} }
                    } else {
                        a.runOnUiThread { try { a.setContentView(buildCrashView(a, trace)) } catch (_: Throwable) {} }
                        return@setDefaultUncaughtExceptionHandler
                    }
                } catch (_: Throwable) {}
            }
            try { ctx.getSharedPreferences("aurora_crash", Context.MODE_PRIVATE).edit().putBoolean("pending", true).commit() } catch (_: Throwable) {}
            try {
                ctx.startActivity(
                    android.content.Intent(ctx, CrashActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
                        .putExtra("trace", trace),
                )
                Thread.sleep(1500)
            } catch (_: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    /**
     * Android remembers why an app's last process ended. A sudden stop with no error message is usually the system
     * killing the app (low memory, battery saver) or an app-not-responding; this notes that so it shows in Settings > About.
     */
    fun recordLastExit(ctx: Context) {
        if (android.os.Build.VERSION.SDK_INT < 30) return
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val r = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 1).firstOrNull() ?: return
            val why = when (r.reason) {
                android.app.ApplicationExitInfo.REASON_ANR -> "The app stopped responding (ANR)"
                android.app.ApplicationExitInfo.REASON_CRASH -> "A crash in the app"
                android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "A native (low-level) crash"
                android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> "Android closed the app because the phone ran low on memory"
                android.app.ApplicationExitInfo.REASON_SIGNALED -> "Android ended the app process"
                android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "Android closed the app for using too many resources"
                android.app.ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "A system service the app needs stopped"
                android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "The app failed to start"
                else -> return // closed by the user or by the app itself: nothing to report
            }
            val f = file(ctx)
            if (f.exists() && f.lastModified() >= r.timestamp) return // a crash was already written for this one
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(r.timestamp))
            f.writeText("$time\nLast time Aurora stopped: $why\n${r.description.orEmpty()}")
        } catch (_: Throwable) {}
    }

    fun write(ctx: Context, what: String, e: Throwable) {
        try {
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val text = "$time\n$what\n${android.util.Log.getStackTraceString(e).take(8000)}"
            file(ctx).writeText(text)
            if (what.startsWith("Crash") || what.startsWith("Startup") || what.startsWith("MainActivity")) copyToDownloads(ctx, text)
        } catch (_: Throwable) {}
    }

    /** Also leaves the report in Downloads as Aurora_crash_<time>.txt, so it can be opened from the Files app even when Aurora will not start. */
    private fun copyToDownloads(ctx: Context, text: String) {
        // a new file name each time: after a reinstall Android will not let the new app replace a file the old install made
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        try {
            val r = ctx.contentResolver
            val v = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "Aurora_crash_$stamp.txt")
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = r.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return
            r.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
        } catch (_: Throwable) {}
    }

    /**
     * What Android recorded about how the previous run ended (crash, native crash, killed...), with the native
     * stack when there is one. Returns null for a normal end or one already shown. Needs Android 11.
     */
    fun lastExitReport(ctx: Context): String? {
        if (android.os.Build.VERSION.SDK_INT < 30) return null
        return try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val r = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 6)
                .firstOrNull { it.processName == ctx.packageName && it.reason in setOf(android.app.ApplicationExitInfo.REASON_CRASH, android.app.ApplicationExitInfo.REASON_CRASH_NATIVE, android.app.ApplicationExitInfo.REASON_ANR, android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE) } ?: return null
            val prefs = ctx.getSharedPreferences("aurora_crash", Context.MODE_PRIVATE)
            if (r.timestamp <= prefs.getLong("ack_ts", 0L)) return null
            val bad = setOf(
                android.app.ApplicationExitInfo.REASON_CRASH, android.app.ApplicationExitInfo.REASON_CRASH_NATIVE, android.app.ApplicationExitInfo.REASON_ANR,
                android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE, android.app.ApplicationExitInfo.REASON_SIGNALED, android.app.ApplicationExitInfo.REASON_DEPENDENCY_DIED,
            )
            if (r.reason !in bad) return null
            val trace = try { r.traceInputStream?.bufferedReader()?.readText()?.take(9000).orEmpty() } catch (_: Throwable) { "" }
            "Android says the last run ended with reason ${r.reason} (status ${r.status}) at ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(r.timestamp))}\n" +
                "${r.description.orEmpty()}\n\n$trace\n\n--- Aurora's own record ---\n${read(ctx)}\n[exit-ts:${r.timestamp}]"
        } catch (_: Throwable) { null }
    }

    /** Everything known about recent stops: Aurora's own record plus Android's last few exit records (with native stacks). For the "Aurora log" viewer. */
    fun fullReport(ctx: Context): String {
        val sb = StringBuilder()
        val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (_: Throwable) { "?" }
        sb.append("Aurora ").append(ver).append("  (Android ").append(android.os.Build.VERSION.RELEASE).append(", ").append(android.os.Build.MODEL).append(")\n\n")
        val own = read(ctx)
        sb.append("=== Aurora's own record ===\n").append(if (own.isBlank()) "(none)" else own).append("\n\n")
        if (android.os.Build.VERSION.SDK_INT >= 30) try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val list = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 6)
            sb.append("=== Android's record of recent stops ===\n")
            if (list.isEmpty()) sb.append("(none)\n")
            for (r in list) {
                sb.append("\n[").append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(r.timestamp))).append("] process ").append(r.processName)
                    .append(", reason ").append(r.reason).append(", status ").append(r.status).append("\n").append(r.description.orEmpty()).append("\n")
                val tr = try { r.traceInputStream?.bufferedReader()?.readText()?.take(7000).orEmpty() } catch (_: Throwable) { "" }
                if (tr.isNotBlank()) sb.append(tr).append("\n")
            }
        } catch (t: Throwable) { sb.append("(could not read Android's record: ").append(t).append(")\n") }
        return sb.toString()
    }

    /** True when the last run ended in a crash that has not been looked at yet. */
    fun pending(ctx: Context): Boolean = try { ctx.getSharedPreferences("aurora_crash", Context.MODE_PRIVATE).getBoolean("pending", false) } catch (_: Throwable) { false }
    fun acknowledge(ctx: Context, report: String = "") {
        try {
            val e = ctx.getSharedPreferences("aurora_crash", Context.MODE_PRIVATE).edit().putBoolean("pending", false)
            Regex("\\[exit-ts:(\\d+)]").find(report)?.groupValues?.get(1)?.toLongOrNull()?.let { e.putLong("ack_ts", it) }
            e.commit()
        } catch (_: Throwable) {}
    }

    fun read(ctx: Context): String = try { file(ctx).takeIf { it.exists() }?.readText().orEmpty() } catch (_: Throwable) { "" }
    fun clear(ctx: Context) { try { file(ctx).delete() } catch (_: Throwable) {} }
}
