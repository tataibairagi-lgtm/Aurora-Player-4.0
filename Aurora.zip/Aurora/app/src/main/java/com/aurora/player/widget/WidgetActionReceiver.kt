package com.aurora.player.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.media3.common.Player
import com.aurora.player.controller
import com.aurora.player.data.MediaScanner
import com.aurora.player.player.PlaybackService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Handles the buttons on the home-screen widgets, even when the app itself is closed. */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val c = app.controller
                if (c.library.isEmpty()) {
                    val list = withContext(Dispatchers.IO) { runCatching { MediaScanner.scan(app) }.getOrDefault(emptyList()) }
                    if (list.isNotEmpty()) c.attachLibrary(list)
                }
                when (intent.action) {
                    ACTION_PLAY_PAUSE -> {
                        runCatching { app.startService(Intent(app, PlaybackService::class.java)) }
                        c.togglePlay()
                    }
                    ACTION_NEXT -> c.next()
                    ACTION_PREV -> c.previous()
                    ACTION_REWIND -> c.rewind()
                    ACTION_FF -> c.fastForward()
                    ACTION_SHUFFLE -> c.toggleShuffle()
                    ACTION_REPEAT -> c.cycleRepeat()
                    ACTION_FAVOURITE -> c.toggleFavouriteCurrent()
                    ACTION_JUMP -> {
                        runCatching { app.startService(Intent(app, PlaybackService::class.java)) }
                        c.jumpTo(intent.getIntExtra(EXTRA_INDEX, -1))
                    }
                }
                WidgetUpdater.update(app)
            } finally {
                pending.finish()
            }
        }
    }
}
