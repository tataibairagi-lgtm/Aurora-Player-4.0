package com.aurora.player

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps the last crash / playback error in a small file so it can be read in Settings > About (no computer needed). */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_error.txt")

    fun install(ctx: Context) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            write(ctx, "Crash in thread ${t.name}", e)
            old?.uncaughtException(t, e)
        }
    }

    /**
     * Android remembers why an app's last process ended. A sudden stop with no error message is usually the system
     * killing the app (low memory, battery saver) or an app-not-responding; this notes that so it shows in Settings > About.
     */
    fun recordLastExit(ctx: Context) {
        if (android.os.Build.VERSION.SDK_INT < 30) return
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
            val r = am.getHistoricalProcessExitReasons(ctx.packageName, 0, 1).firstOrNull() ?: return
            val why = when (r.reason) {
                android.app.ApplicationExitInfo.REASON_ANR -> "The app stopped responding (ANR)"
                android.app.ApplicationExitInfo.REASON_CRASH -> "A crash in the app"
                android.app.ApplicationExitInfo.REASON_CRASH_NATIVE -> "A native (low-level) crash"
                android.app.ApplicationExitInfo.REASON_LOW_MEMORY -> "Android closed the app because the phone ran low on memory"
                android.app.ApplicationExitInfo.REASON_SIGNALED -> "Android ended the app process"
                android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "Android closed the app for using too many resources"
                android.app.ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "A system service the app needs stopped"
                android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "The app failed to start"
                else -> return // closed by the user or by the app itself: nothing to report
            }
            val f = file(ctx)
            if (f.exists() && f.lastModified() >= r.timestamp) return // a crash was already written for this one
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(r.timestamp))
            f.writeText("$time\nLast time Aurora stopped: $why\n${r.description.orEmpty()}")
        } catch (_: Throwable) {}
    }

    fun write(ctx: Context, what: String, e: Throwable) {
        try {
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            file(ctx).writeText("$time\n$what\n${android.util.Log.getStackTraceString(e).take(6000)}")
        } catch (_: Throwable) {}
    }

    fun read(ctx: Context): String = try { file(ctx).takeIf { it.exists() }?.readText().orEmpty() } catch (_: Throwable) { "" }
    fun clear(ctx: Context) { try { file(ctx).delete() } catch (_: Throwable) {} }
}
