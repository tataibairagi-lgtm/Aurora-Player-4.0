package com.aurora.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.aurora.player.player.PlayerController

/** What happens when a song ends and when the queue ends (simple and advanced views). */
@Composable
fun PlayModeDialog(c: PlayerController, onDismiss: () -> Unit) {
    val d = c.store.data
    var advanced by remember { mutableStateOf(!(d.songEnd == 2 && d.queueEnd == 0) && !(d.songEnd == 2 && d.queueEnd == 2) && !(d.songEnd == 3)) }

    @Composable
    fun Opt(selected: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected, onClick)
            Icon(icon, null, Modifier.padding(start = 6.dp).size(24.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(label, Modifier.padding(start = 14.dp))
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (!advanced) {
                    Text("Playback mode", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Opt(d.songEnd != 3 && d.queueEnd != 2, Icons.Rounded.PlayArrow, "Play the queue once") { c.setEndModes(2, 0) }
                    Opt(d.songEnd != 3 && d.queueEnd == 2, Icons.Rounded.Repeat, "Repeat the queue") { c.setEndModes(2, 2) }
                    Opt(d.songEnd == 3, Icons.Rounded.RepeatOne, "Repeat the same song") { c.setEndModes(3, d.queueEnd) }
                } else {
                    Text("When a song ends…", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                    Opt(d.songEnd == 0, Icons.Rounded.Stop, "Just stop there") { c.setEndModes(0, d.queueEnd) }
                    Opt(d.songEnd == 1, Icons.Rounded.Pause, "Load next song and pause") { c.setEndModes(1, d.queueEnd) }
                    Opt(d.songEnd == 2, Icons.Rounded.SkipNext, "Play next song") { c.setEndModes(2, d.queueEnd) }
                    Opt(d.songEnd == 3, Icons.Rounded.RepeatOne, "Repeat the same song") { c.setEndModes(3, d.queueEnd) }
                    Text(
                        "When current queue ends…", Modifier.padding(top = 16.dp),
                        style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
                    )
                    Row(
                        Modifier.fillMaxWidth().clickable { c.setEndModes(d.songEnd, d.queueEnd, !d.reshuffleOnEnd) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(d.reshuffleOnEnd, null, Modifier.padding(start = 12.dp, end = 8.dp))
                        Text("Re-shuffle the queue (if shuffle mode is on)")
                    }
                    Text("And then…", Modifier.padding(start = 4.dp, top = 6.dp))
                    Opt(d.queueEnd == 0, Icons.Rounded.Stop, "Just stop there") { c.setEndModes(d.songEnd, 0) }
                    Opt(d.queueEnd == 1, Icons.Rounded.QueueMusic, "Jump to next queue") { c.setEndModes(d.songEnd, 1) }
                    Opt(d.queueEnd == 2, Icons.Rounded.Repeat, "Repeat the same queue") { c.setEndModes(d.songEnd, 2) }
                }
            }
        },
        confirmButton = {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!advanced, { advanced = false }, label = { Text("Simple") })
                FilterChip(advanced, { advanced = true }, label = { Text("Advanced") })
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton({ c.setEndModes(2, 0, true) }, shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                        Icon(Icons.Rounded.RestartAlt, "Reset")
                    }
                    OutlinedButton(onDismiss, Modifier.padding(start = 8.dp), shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)) {
                        Icon(Icons.Rounded.Check, "OK")
                    }
                }
            }
        },
    )
}
