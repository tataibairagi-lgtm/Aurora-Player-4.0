package com.aurora.player.ui

import android.media.MediaExtractor
import android.media.MediaFormat
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class AudioFacts(val format: String, val sampleRate: String, val bits: String, val encoding: String, val channels: String)

private fun readFacts(path: String, uri: String, ctx: android.content.Context): AudioFacts? = try {
    val ex = MediaExtractor()
    try {
        if (path.isNotEmpty() && File(path).canRead()) ex.setDataSource(path) else ex.setDataSource(ctx, android.net.Uri.parse(uri), null)
        val f = (0 until ex.trackCount).map { ex.getTrackFormat(it) }.firstOrNull { it.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
        if (f == null) null else {
            val mime = f.getString(MediaFormat.KEY_MIME).orEmpty()
            val name = mime.removePrefix("audio/").substringAfter("x-").replaceFirstChar { it.uppercase() }
            val bitsN = if (f.containsKey("bits-per-sample")) f.getInteger("bits-per-sample")
            else if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) when (f.getInteger(MediaFormat.KEY_PCM_ENCODING)) { 2 -> 16; 21 -> 24; 22 -> 32; 4 -> 32; else -> 0 } else 0
            AudioFacts(
                format = name,
                sampleRate = if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) "${f.getInteger(MediaFormat.KEY_SAMPLE_RATE)} Hz" else "[unknown]",
                bits = if (bitsN > 0) "$bitsN" else "[unknown]",
                encoding = if (bitsN > 0 && name.equals("Flac", true)) "FLAC $bitsN bits" else name,
                channels = if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) "${f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)}" else "[unknown]",
            )
        }
    } finally { ex.release() }
} catch (_: Throwable) { null }

private class LyrInfo(val embedded: String?, val lrc: String?)

private fun describeLyrics(text: String): String {
    val lines = text.lines().count { it.isNotBlank() }
    val kind = when {
        Regex("""<\d{1,3}:\d{1,2}""").containsMatchIn(text) -> "word-synced"
        Regex("""\[\d{1,3}:\d{1,2}""").containsMatchIn(text) -> "synced"
        else -> "plain text"
    }
    return "Found · $lines lines · $kind"
}

/** Edit the lyrics text and write it into the song's tag and/or the .lrc file, like Musicolet. */
@Composable
fun LyricsEditDialog(c: PlayerController, t: Track, onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val actions = LocalActions.current
    var text by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<String?>(null) }
    var toTag by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }
    var toLrc by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(true) }
    val sources by produceState<Map<String, String>?>(null, t.id) {
        value = withContext(Dispatchers.IO) {
            buildMap {
                com.aurora.player.data.TagIo.embeddedLyrics(ctx, t)?.let { put("Embedded", it) }
                c.lyricsRepo.readSidecar(t)?.let { put(".lrc file", it) }
                c.lyricsRepo.readSaved(t)?.let { put("Saved copy", it) }
            }
        }
    }
    androidx.compose.runtime.LaunchedEffect(sources) {
        val s = sources ?: return@LaunchedEffect
        if (text == null) text = (s[".lrc file"] ?: s["Embedded"] ?: s["Saved copy"]).orEmpty()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit lyrics") },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                val src = sources
                if (src != null && src.isNotEmpty()) {
                    Text("Load from", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                        src.forEach { (name, body) ->
                            androidx.compose.material3.AssistChip({ text = body }, label = { Text(name) })
                        }
                    }
                }
                androidx.compose.material3.OutlinedTextField(
                    value = text.orEmpty(), onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 220.dp),
                    placeholder = { Text("[00:12.50] First line\n[00:16.00] Second line") },
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                )
                Text(
                    "Synced lines start with [mm:ss.xx]. For word-by-word sync put <mm:ss.xx> before each word.",
                    Modifier.padding(top = 6.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Checkbox(toTag, { toTag = it }); Text("Save in the song's tag")
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.Checkbox(toLrc, { toLrc = it }); Text("Save in the .lrc file")
                }
            }
        },
        confirmButton = {
            TextButton(
                { actions.saveLyrics(t, text.orEmpty(), toTag, toLrc); onDismiss() },
                enabled = text != null && (toTag || toLrc),
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

/** Musicolet-style "Song info" window with the tags and the technical details of one song. */
@Composable
fun SongInfoDialog(c: PlayerController, t: Track, onEditTags: () -> Unit, onDismiss: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val facts by produceState<AudioFacts?>(null, t.id) { value = withContext(Dispatchers.IO) { readFacts(t.path, t.uri, ctx) } }
    val fmt = remember2 { SimpleDateFormat("MMMM d, yyyy HH:mm", Locale.getDefault()) }
    val unknown = "[unknown]"
    fun s(v: String) = v.ifBlank { unknown }
    val added = if (t.dateAdded > 0) fmt.format(Date(t.dateAdded * 1000)) else unknown
    val modified = try { File(t.path).lastModified().takeIf { it > 0 }?.let { fmt.format(Date(it)) } ?: unknown } catch (_: Throwable) { unknown }
    val last = c.playLog.events.lastOrNull { it.id == t.id }?.let { fmt.format(Date(it.at)) } ?: "Never"
    val plays = c.store.data.playCounts[t.id] ?: 0
    val kbps = if (t.durationMs > 0 && t.size > 0) "~${(t.size * 8 / t.durationMs)} kbps" else unknown
    val loc = t.folder.replace("/storage/emulated/0", "Internal Storage").replace("/sdcard", "Internal Storage").split('/').filter { it.isNotEmpty() }.joinToString(" › ")

    var editLyrics by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val lyrInfo by produceState<LyrInfo?>(null, t.id, c.lyrics, editLyrics) {
        value = withContext(Dispatchers.IO) { LyrInfo(com.aurora.player.data.TagIo.embeddedLyrics(ctx, t), c.lyricsRepo.readSidecar(t)) }
    }
    if (editLyrics) LyricsEditDialog(c, t) { editLyrics = false }

    @Composable
    fun Field(label: String, value: String) {
        Column(Modifier.padding(vertical = 5.dp)) {
            Text(label, fontWeight = FontWeight.Bold)
            Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Info, null); Text("  Song info") } },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AlbumArt(t, Modifier.padding(end = 12.dp).size(64.dp), androidx.compose.foundation.shape.RoundedCornerShape(8.dp), 24.dp)
                    Field("File name", t.path.substringAfterLast('/'))
                }
                Field("Location", loc)
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Field("Title", s(t.title)); Field("Album", s(t.album)); Field("Artist", s(t.artist))
                Field("Album-Artist", s(t.albumArtist.ifBlank { t.artist })); Field("Composer", s(t.composer)); Field("Genre", s(t.genre))
                Field("Track number", "${t.trackNo}"); Field("Year", "${t.year}")
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Field("Duration", formatTime(t.durationMs)); Field("Bitrate", kbps)
                Field("Sample rate", facts?.sampleRate ?: unknown); Field("Bits per sample", facts?.bits ?: unknown)
                Field("Format", facts?.format ?: t.path.substringAfterLast('.', unknown).replaceFirstChar { it.uppercase() })
                Field("Encoding", facts?.encoding ?: unknown); Field("Channels", facts?.channels ?: unknown)
                Field("Size", "%.2f MB".format(t.size / 1048576.0))
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Field("Embedded lyrics", lyrInfo?.embedded?.let { describeLyrics(it) } ?: if (lyrInfo == null) "Checking…" else "None")
                Field(".lrc file", lyrInfo?.lrc?.let { describeLyrics(it) + "\n" + t.path.substringBeforeLast('.').substringAfterLast('/') + ".lrc" }
                    ?: if (lyrInfo == null) "Checking…" else "None next to the song")
                TextButton({ editLyrics = true }, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) {
                    Icon(Icons.Rounded.Edit, null, Modifier.size(18.dp)); Text("  Edit lyrics (embedded / .lrc)")
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Field("Date added to library", added); Field("Date modified", modified)
                Field("Date last played", last); Field("Played", "$plays times before")
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Done") } },
        dismissButton = { TextButton({ onDismiss(); onEditTags() }) { Text("Edit tags") } },
    )
}

@Composable
private fun <T> remember2(f: () -> T): T = androidx.compose.runtime.remember { f() }
