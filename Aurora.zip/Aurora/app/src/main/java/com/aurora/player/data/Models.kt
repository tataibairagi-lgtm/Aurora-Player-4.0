package com.aurora.player.data

import kotlinx.serialization.Serializable

data class Track(
    val id: Long,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val path: String,
    val dateAdded: Long,
    val trackNo: Int,
    val genre: String = "",
    val year: Int = 0,
    val size: Long = 0,
    val albumArtist: String = "",
    val composer: String = "",
) {
    val folder: String get() = path.substringBeforeLast('/', "")
    val folderName: String get() = folder.substringAfterLast('/')
}

@Serializable
data class Bookmark(val id: String, val trackId: Long, val posMs: Long, val note: String = "", val created: Long = 0)

@Serializable
data class Playlist(val id: String, val name: String, val trackIds: List<Long> = emptyList())

@Serializable
data class QueueData(
    val name: String,
    val trackIds: List<Long> = emptyList(),
    val index: Int = 0,
    val positionMs: Long = 0,
)

data class LyricWord(val timeMs: Long, val text: String)

data class LyricLine(val timeMs: Long, val text: String, val words: List<LyricWord>? = null)

/** Splits a line into words with estimated times (used when the .lrc has no word timing), weighted by word length. */
fun estimateWords(line: LyricLine, endMs: Long): List<LyricWord> {
    val parts = Regex("""\S+\s*""").findAll(line.text).map { it.value }.toList()
    if (parts.size < 2) return parts.map { LyricWord(line.timeMs, it) }
    val span = (if (endMs > line.timeMs) endMs - line.timeMs else 4000L).coerceIn(600L, 9000L) * 9 / 10
    val total = parts.sumOf { it.trim().length + 1 }.toFloat()
    var acc = 0f
    return parts.map { w ->
        val t = line.timeMs + (span * acc / total).toLong()
        acc += w.trim().length + 1
        LyricWord(t, w)
    }
}

class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

/** Index of the line that should be highlighted at [posMs], or -1 before the first line. */
fun Lyrics.indexAt(posMs: Long): Int {
    if (!synced) return -1
    var lo = 0
    var hi = lines.lastIndex
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].timeMs <= posMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
    }
    return ans
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

/** One equalizer setup. Musicolet keeps a separate one per audio output (speaker, headphones, Bluetooth...). */
@Serializable
data class EqProfile(
    val enabled: Boolean = false,
    val levels: List<Int> = emptyList(),
    val bass: Int = 0,        // 0..1000
    val virtualizer: Int = 0, // 0..1000
    val loudness: Int = 0,    // millibels of extra gain, 0..1500
    val preset: String = "Custom",
)

@Serializable
data class EqPreset(val name: String, val levels: List<Int>)


/**
 * Identifies the album a song belongs to. MediaStore's own album id splits one album in several when the songs have
 * different (featured) artists, so albums are matched by name plus album artist, or by name plus folder when the album
 * artist isn't tagged.
 */
fun Track.albumKey(): String {
    val name = album.trim().lowercase().replace(Regex("\\s+"), " ")
    val owner = albumArtist.trim().lowercase().ifBlank { folder }
    return "$name::$owner"
}
