package com.aurora.player.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext

private val AuroraDark = darkColorScheme(
    primary = Color(0xFFB4A8FF),
    onPrimary = Color(0xFF1E1550),
    secondary = Color(0xFF7FE3D0),
    background = Color(0xFF0F0D1A),
    surface = Color(0xFF151222),
    surfaceVariant = Color(0xFF241F38),
    onSurface = Color(0xFFEAE6FF),
    onSurfaceVariant = Color(0xFFB9B3D6),
)

private val AuroraLight = lightColorScheme(
    primary = Color(0xFF5B49D6),
    secondary = Color(0xFF00796B),
    background = Color(0xFFFBF9FF),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFEAE6F7),
)

@Composable
fun AuroraTheme(mode: Int, accent: Long = 0, content: @Composable () -> Unit) {
    // 0 system, 1 light, 2 dark, 3 black (AMOLED)
    val dark = when (mode) {
        1 -> false
        2, 3 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    var scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> AuroraDark
        else -> AuroraLight
    }
    if (accent != 0L) {
        val a = Color(accent)
        val base = if (dark) Color(0xFF14141A) else Color.White
        scheme = scheme.copy(
            primary = a, onPrimary = if (a.luminance() > 0.5f) Color.Black else Color.White,
            primaryContainer = androidx.compose.ui.graphics.lerp(base, a, if (dark) 0.38f else 0.2f),
            onPrimaryContainer = if (dark) Color.White else androidx.compose.ui.graphics.lerp(a, Color.Black, 0.45f),
            secondaryContainer = androidx.compose.ui.graphics.lerp(base, a, if (dark) 0.28f else 0.14f),
            onSecondaryContainer = if (dark) Color.White else androidx.compose.ui.graphics.lerp(a, Color.Black, 0.5f),
            surfaceTint = a,
        )
    }
    if (mode == 3) {
        scheme = scheme.copy(
            background = Color.Black, surface = Color(0xFF0B0B0B),
            surfaceVariant = Color(0xFF1B1B1F), surfaceContainer = Color(0xFF111114),
        )
    }
    MaterialTheme(colorScheme = scheme) {
        // Without a Surface, text falls back to black, which is unreadable in dark mode.
        androidx.compose.material3.Surface(
            Modifier.fillMaxSize(), color = scheme.background, contentColor = scheme.onBackground,
        ) { content() }
    }
}
