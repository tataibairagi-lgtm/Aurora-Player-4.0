package com.aurora.player

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** The error screen: plain views on purpose, so it works even when Compose or the player is what failed. */
fun buildCrashView(act: Activity, trace: String): android.view.View {
    val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(32, 100, 32, 32) }
    root.addView(TextView(act).apply { text = "Aurora hit a problem"; textSize = 22f; setTextColor(Color.BLACK) })
    root.addView(TextView(act).apply { text = "Tap Copy and paste the text to the developer."; setTextColor(Color.DKGRAY); setPadding(0, 8, 0, 16) })
    val row = LinearLayout(act).apply { gravity = Gravity.START }
    row.addView(Button(act).apply {
        text = "Copy"
        setOnClickListener {
            (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Aurora crash", trace))
            Toast.makeText(act, "Copied. Tap Close, then open Aurora again to retry", Toast.LENGTH_LONG).show()
        }
    })
    row.addView(Button(act).apply { text = "Close and retry"; setOnClickListener { CrashLog.acknowledge(act); act.finishAndRemoveTask(); android.os.Process.killProcess(android.os.Process.myPid()) } })
    root.addView(row)
    root.addView(ScrollView(act).apply {
        addView(TextView(act).apply { text = trace; textSize = 11f; setTextColor(Color.BLACK); setTextIsSelectable(true) })
    })
    return root
}

class CrashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(buildCrashView(this, intent.getStringExtra("trace").orEmpty()))
    }
}
