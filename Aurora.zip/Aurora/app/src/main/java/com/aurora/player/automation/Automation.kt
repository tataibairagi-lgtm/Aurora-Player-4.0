package com.aurora.player.automation

import android.app.AlarmManager
import android.app.PendingIntent
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.aurora.player.MainActivity
import com.aurora.player.controller
import com.aurora.player.data.AlarmItem
import com.aurora.player.data.MediaScanner
import com.aurora.player.player.PlaybackService
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

/** Playlist alarms and Bluetooth auto-play. */
object Automation {
    const val ACTION_ALARM = "com.aurora.player.ALARM"
    const val EXTRA_ID = "alarm_id"
    const val ALARM_NOTIF = 7002

    const val ACTION_CANCEL_SNOOZE = "com.aurora.player.ALARM_CANCEL_SNOOZE"
    const val SNOOZE_NOTIF = 7003

    private fun snoozePending(ctx: Context, alarmId: String): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, ("snooze" + alarmId).hashCode(),
            Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_ALARM).putExtra(EXTRA_ID, alarmId).putExtra("snoozed", true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun setSnoozeAt(ctx: Context, alarmId: String, at: Long) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), snoozePending(ctx, alarmId))
    }

    /** Rings the alarm again in [minutes] (the alarm itself keeps its normal schedule). The time is remembered so the alarm list can show it. */
    fun snooze(ctx: Context, c: PlayerController, alarmId: String, minutes: Int) {
        val at = System.currentTimeMillis() + minutes * 60_000L
        try { setSnoozeAt(ctx, alarmId, at) } catch (_: Throwable) {}
        c.store.update { it.copy(alarmSnoozeUntil = it.alarmSnoozeUntil + (alarmId to at)) }
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(android.app.NotificationChannel("aurora_alarm_info", "Alarm snooze", android.app.NotificationManager.IMPORTANCE_DEFAULT).apply { setSound(null, null) })
            val whenText = java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(at))
            val stop = PendingIntent.getBroadcast(ctx, 9, Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_CANCEL_SNOOZE).putExtra(EXTRA_ID, alarmId), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = androidx.core.app.NotificationCompat.Builder(ctx, "aurora_alarm_info")
                .setSmallIcon(com.aurora.player.R.drawable.ic_stat_tile)
                .setContentTitle("Alarm snoozed")
                .setContentText("Rings again in $minutes min, at $whenText")
                .setCategory(androidx.core.app.NotificationCompat.CATEGORY_ALARM)
                .setWhen(at).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true)
                .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true)
                .addAction(0, "Cancel alarm", stop)
                .build()
            nm.notify(SNOOZE_NOTIF, n)
        } catch (_: Throwable) {}
    }

    /** Forgets a snooze: the pending ring, the note on the alarm and the notification. */
    fun cancelSnooze(ctx: Context, c: PlayerController, alarmId: String) {
        try { (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(snoozePending(ctx, alarmId)) } catch (_: Throwable) {}
        try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(SNOOZE_NOTIF) } catch (_: Throwable) {}
        if (alarmId in c.store.data.alarmSnoozeUntil) c.store.update { it.copy(alarmSnoozeUntil = it.alarmSnoozeUntil - alarmId) }
    }

    /** Shows the alarm screen over the lock screen (a full-screen notification is the way Android allows it from the background). */
    fun showRing(ctx: Context, alarmId: String) {
        val launch = Intent(ctx, com.aurora.player.lock.AlarmRingActivity::class.java)
            .putExtra(EXTRA_ID, alarmId).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(android.app.NotificationChannel("aurora_alarm", "Alarms", android.app.NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) })
            val pi = PendingIntent.getActivity(ctx, 8, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = androidx.core.app.NotificationCompat.Builder(ctx, "aurora_alarm")
                .setSmallIcon(com.aurora.player.R.drawable.ic_stat_tile)
                .setContentTitle("Alarm").setContentText("Tap to open")
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_MAX)
                .setCategory(androidx.core.app.NotificationCompat.CATEGORY_ALARM)
                .setContentIntent(pi).setFullScreenIntent(pi, true).setOngoing(true)
                .build()
            nm.notify(ALARM_NOTIF, n)
        } catch (_: Throwable) {}
        try { ctx.startActivity(launch) } catch (_: Throwable) {}
    }

    fun stopRing(ctx: Context) {
        try { (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(ALARM_NOTIF) } catch (_: Throwable) {}
    }

    /** The next time [a] should ring, in epoch millis. */
    /** Tomorrow at the alarm's time. */
    fun tomorrowAt(a: AlarmItem, now: Long = System.currentTimeMillis()): Long =
        Calendar.getInstance().apply {
            timeInMillis = now
            add(Calendar.DAY_OF_YEAR, 1)
            set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

    /** "7 h 12 min", "35 min", "less than a minute", "1 day 2 h" */
    fun ringsIn(ms: Long): String {
        val mins = ((ms + 59_999L) / 60_000L).coerceAtLeast(0)
        if (mins < 1) return "less than a minute"
        val d = mins / 1440; val h = (mins % 1440) / 60; val m = mins % 60
        return when {
            d > 0 -> "$d day${if (d > 1) "s" else ""}" + if (h > 0) " $h h" else ""
            h > 0 -> "$h h" + if (m > 0) " $m min" else ""
            else -> "$m min"
        }
    }

    fun nextTrigger(a: AlarmItem, now: Long = System.currentTimeMillis()): Long {
        if (a.once) return if (a.onceAt > now) a.onceAt else tomorrowAt(a, now)
        for (dayOff in 0..7) {
            val cal = Calendar.getInstance().apply {
                timeInMillis = now
                add(Calendar.DAY_OF_YEAR, dayOff)
                set(Calendar.HOUR_OF_DAY, a.hour); set(Calendar.MINUTE, a.minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (cal.timeInMillis <= now) continue
            val monday0 = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Mon = 0 ... Sun = 6
            if (a.days == 0 || ((a.days shr monday0) and 1) == 1) return cal.timeInMillis
        }
        return now + 24 * 3_600_000L
    }

    private fun pending(ctx: Context, a: AlarmItem): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, a.id.hashCode(),
            Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_ALARM).putExtra(EXTRA_ID, a.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    /** (Re)sets the system alarm of every enabled alarm and cancels the others. */
    fun schedule(ctx: Context, alarms: List<AlarmItem>) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (a in alarms) {
            try {
                if (!a.enabled || (a.once && a.onceAt <= System.currentTimeMillis())) { am.cancel(pending(ctx, a)); continue }
                val show = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                // an "alarm clock" alarm is exact and needs no special permission
                am.setAlarmClock(AlarmManager.AlarmClockInfo(nextTrigger(a), show), pending(ctx, a))
            } catch (_: Throwable) {}
        }
    }

    /** Sets the system alarm of snoozes still waiting (after a restart). */
    fun restoreSnoozes(ctx: Context, c: PlayerController) {
        val now = System.currentTimeMillis()
        c.store.data.alarmSnoozeUntil.forEach { (id, at) -> if (at > now) try { setSnoozeAt(ctx, id, at) } catch (_: Throwable) {} }
    }

    fun cancel(ctx: Context, a: AlarmItem) {
        try { (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx, a)) } catch (_: Throwable) {}
    }

    /** Starts a playlist ("" = all songs, "fav" = favourites). */
    fun startPlaylist(ctx: Context, c: PlayerController, playlistId: String, shuffle: Boolean, alarm: Boolean = false) {
        val d = c.store.data
        if (playlistId.startsWith("q:")) {
            // a saved queue: continue it where it was left
            val i = playlistId.removePrefix("q:").toIntOrNull() ?: return
            if (i !in d.queues.indices) return
            runCatching { ctx.startService(Intent(ctx, PlaybackService::class.java)) }
            c.switchQueue(i)
            if (alarm) c.setAlarmAudio(true)
            if (c.queue.isNotEmpty()) c.play()
            return
        }
        val tracks = when (playlistId) {
            "" -> c.library
            "fav" -> c.library.filter { it.id in d.favourites }
            else -> d.playlists.find { it.id == playlistId }?.trackIds?.mapNotNull { c.track(it) }.orEmpty()
        }
        if (tracks.isEmpty()) return
        runCatching { ctx.startService(Intent(ctx, PlaybackService::class.java)) }
        // started by itself: it gets a queue of its own, so the queue you were using is never overwritten or renamed
        val qName = when (playlistId) { "" -> "All songs"; "fav" -> "Favourites"; else -> d.playlists.find { it.id == playlistId }?.name ?: "Playlist" }
        if (alarm) c.alarmNext()
        c.playFromSource(qName, if (shuffle) tracks.shuffled() else tracks, 0, null, true)
    }

    /** Names of the Bluetooth audio devices connected right now (no permission needed). */
    fun connectedBluetooth(ctx: Context): List<String> {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || (Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET) }
            .map { it.productName.toString() }.filter { it.isNotBlank() }.distinct()
    }

    suspend fun ensureLibrary(ctx: Context, c: PlayerController) {
        if (c.library.isEmpty()) {
            val list = withContext(Dispatchers.IO) { runCatching { MediaScanner.scan(ctx) }.getOrDefault(emptyList()) }
            if (list.isNotEmpty()) c.attachLibrary(list)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val c = app.controller
                if (intent.action == Automation.ACTION_CANCEL_SNOOZE) {
                    Automation.cancelSnooze(app, c, intent.getStringExtra(Automation.EXTRA_ID).orEmpty())
                    return@launch
                }
                Automation.ensureLibrary(app, c)
                val a = c.store.data.alarms.firstOrNull { it.id == intent.getStringExtra(Automation.EXTRA_ID) }
                if (a != null) Automation.cancelSnooze(app, c, a.id)   // the snooze is over: it is ringing now
                if (a != null && (a.enabled || intent.getBooleanExtra("snoozed", false))) {
                    Automation.startPlaylist(app, c, a.playlistId, a.shuffle, alarm = true)
                    Automation.showRing(app, a.id)
                }
                // a "Tomorrow" alarm rings once and switches itself off
                if (a != null && a.once) c.store.update { st -> st.copy(alarms = st.alarms.map { if (it.id == a.id) it.copy(enabled = false, onceAt = 0L) else it }) }
                Automation.schedule(app, c.store.data.alarms) // set the next ring
            } finally { pending.finish() }
        }
    }
}

/** Sets the alarms again after the phone restarts. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = context.applicationContext
        try { Automation.schedule(app, app.controller.store.data.alarms); Automation.restoreSnoozes(app, app.controller) } catch (_: Throwable) {}
    }
}

class BtReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != BluetoothDevice.ACTION_ACL_CONNECTED) return
        val app = context.applicationContext
        val named = try {
            @Suppress("DEPRECATION")
            (intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE))?.name
        } catch (_: Throwable) { null }
        val pending = goAsync()
        // the audio route needs a moment to appear after the link comes up
        Handler(Looper.getMainLooper()).postDelayed({
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    val c = app.controller
                    val rules = c.store.data.btRules
                    if (rules.isNotEmpty()) {
                        val names = (listOfNotNull(named) + Automation.connectedBluetooth(app)).map { it.lowercase() }
                        val rule = rules.firstOrNull { r -> r.device.isNotBlank() && names.any { it == r.device.trim().lowercase() } }
                        if (rule != null) {
                            Automation.ensureLibrary(app, c)
                            Automation.startPlaylist(app, c, rule.playlistId, rule.shuffle)
                        } else if (c.store.data.resumeOnBt) {
                            // "Resume on Bluetooth connect" also works when Aurora was closed: this receiver wakes it up
                            Automation.ensureLibrary(app, c)
                            runCatching { app.startService(Intent(app, PlaybackService::class.java)) }
                            if (!c.player.isPlaying && c.queue.isNotEmpty()) c.play()
                        }
                    } else if (c.store.data.resumeOnBt) {
                        Automation.ensureLibrary(app, c)
                        runCatching { app.startService(Intent(app, PlaybackService::class.java)) }
                        if (!c.player.isPlaying && c.queue.isNotEmpty()) c.play()
                    }
                } finally { pending.finish() }
            }
        }, 3500)
    }
}
