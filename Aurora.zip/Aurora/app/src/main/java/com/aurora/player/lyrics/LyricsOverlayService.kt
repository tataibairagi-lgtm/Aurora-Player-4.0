package com.aurora.player.lyrics

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.aurora.player.controller
import com.aurora.player.data.indexAt

/**
 * Floating "desktop lyrics": a small draggable window over every app.
 * Built from plain Android views (no Compose) so it is light, never leaks and can't crash the host.
 */
class LyricsOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var title: TextView
    private lateinit var prev: TextView
    private lateinit var cur: TextView
    private lateinit var next: TextView
    private lateinit var playBtn: android.widget.ImageView
    private lateinit var lockBtn: TextView

    private var lastKey = ""
    private var lastSp = -1
    private var lastColor = 0

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(v: Float) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

    private fun button(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
        gravity = Gravity.CENTER
        val p = dp(9f).toInt()
        setPadding(p, p / 2, p, p / 2)
        setOnClickListener { onClick() }
    }

    /** White vector icon button (the ⏸ ▶ ⏮ ⏭ characters turn into orange emoji on many phones, so icons are drawn instead). */
    private fun iconButton(res: Int, onClick: () -> Unit): android.widget.ImageView = android.widget.ImageView(this).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE)
        val p = dp(7f).toInt()
        setPadding(p, p / 2, p, p / 2)
        layoutParams = LinearLayout.LayoutParams(dp(36f).toInt(), dp(32f).toInt())
        setOnClickListener { onClick() }
    }

    /** Thin outline padlock; faded when the window is free to move, solid when pinned. */
    private fun setLockIcon(locked: Boolean) {
        val d = androidx.core.content.ContextCompat.getDrawable(this, if (locked) com.aurora.player.R.drawable.ic_lock else com.aurora.player.R.drawable.ic_lock_open)?.mutate()
        val size = dp(18f).toInt()
        d?.setBounds(0, 0, size, size)
        lockBtn.setCompoundDrawables(d, null, null, null)
        lockBtn.alpha = if (locked) 1f else 0.55f
    }

    private fun lineView(): TextView = TextView(this).apply {
        gravity = Gravity.CENTER
        maxLines = 2
        ellipsize = TextUtils.TruncateAt.END
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val c = controller
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val bg = GradientDrawable().apply { cornerRadius = dp(20f); setColor(0xCC0D0D17.toInt()) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            val p = dp(12f).toInt()
            setPadding(p, p / 2, p, p)
        }

        title = TextView(this).apply {
            setTextColor(0x99FFFFFF.toInt()); setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        playBtn = iconButton(com.aurora.player.R.drawable.ic_w_play) { c.togglePlay() }
        val strip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(title)
            addView(iconButton(com.aurora.player.R.drawable.ic_w_prev) { c.previous() })
            addView(playBtn)
            addView(iconButton(com.aurora.player.R.drawable.ic_w_next) { c.next() })
            addView(button("A−") { c.store.update { it.copy(overlayTextSp = (it.overlayTextSp - 2).coerceAtLeast(12)) } })
            addView(button("A+") { c.store.update { it.copy(overlayTextSp = (it.overlayTextSp + 2).coerceAtMost(48)) } })
            lockBtn = button("") {
                val now = !c.store.data.overlayLocked
                c.store.update { it.copy(overlayLocked = now) }
                setLockIcon(now)
            }
            setLockIcon(c.store.data.overlayLocked)
            addView(lockBtn)
            addView(button("✕") { stopSelf() })
        }
        prev = lineView(); cur = lineView(); next = lineView()
        cur.setTypeface(Typeface.DEFAULT_BOLD)
        box.addView(strip)
        box.addView(prev); box.addView(cur); box.addView(next)

        // dragging: touch anywhere on the card that isn't a button
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> if (c.store.data.overlayLocked) false else { downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; true }
                MotionEvent.ACTION_MOVE -> if (c.store.data.overlayLocked) false else {
                    lp.x = startX + (e.rawX - downX).toInt()
                    lp.y = startY + (e.rawY - downY).toInt()
                    try { wm.updateViewLayout(box, lp) } catch (_: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> { c.store.update { it.copy(overlayX = lp.x, overlayY = lp.y) }; true }
                else -> false
            }
        }

        val width = (resources.displayMetrics.widthPixels * 0.94f).toInt()
        lp = WindowManager.LayoutParams(
            width, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = c.store.data.overlayX.coerceAtLeast(0)
            y = c.store.data.overlayY
        }
        root = box
        try { wm.addView(box, lp) } catch (_: Exception) { stopSelf(); return }
        c.overlayActive = true
        handler.post(tick)
    }

    /** Redraws only what changed, a few times a second. */
    private val tick = object : Runnable {
        override fun run() {
            try { refresh() } catch (_: Exception) {}
            handler.postDelayed(this, 250)
        }
    }

    private fun refresh() {
        val c = controller
        val d = c.store.data
        if (d.overlayTextSp != lastSp || d.overlayColor.toInt() != lastColor) {
            lastSp = d.overlayTextSp; lastColor = d.overlayColor.toInt()
            val col = d.overlayColor.toInt()
            cur.setTextColor(col); prev.setTextColor((col and 0x00FFFFFF) or 0x66000000); next.setTextColor((col and 0x00FFFFFF) or 0x66000000)
            cur.setTextSize(TypedValue.COMPLEX_UNIT_SP, d.overlayTextSp.toFloat())
            prev.setTextSize(TypedValue.COMPLEX_UNIT_SP, d.overlayTextSp * 0.62f)
            next.setTextSize(TypedValue.COMPLEX_UNIT_SP, d.overlayTextSp * 0.62f)
        }
        playBtn.setImageResource(if (c.isPlaying) com.aurora.player.R.drawable.ic_w_pause else com.aurora.player.R.drawable.ic_w_play)
        val t = c.current
        title.text = t?.let { it.title + " · " + it.artist } ?: "Aurora"

        val lyr = c.lyrics
        val p: String; val n: String; val m: String
        if (lyr == null || lyr.lines.isEmpty()) {
            p = ""; n = ""
            m = if (c.lyricsLoading) "Looking for lyrics…" else "No lyrics for this song"
        } else if (!lyr.synced) {
            p = ""; n = ""; m = lyr.lines.first().text
        } else {
            val i = lyr.indexAt(c.lyricPosMs)
            p = lyr.lines.getOrNull(i - 1)?.text.orEmpty()
            m = if (i < 0) "♪" else lyr.lines[i].text.ifBlank { "♪" }
            n = lyr.lines.getOrNull(i + 1)?.text.orEmpty()
        }
        val key = "$p\u0000$m\u0000$n"
        if (key != lastKey) {
            lastKey = key
            prev.text = p; cur.text = m; next.text = n
            // the chosen motion (Settings → Desktop lyrics): each style brings the new lines in differently
            val mode = controller.store.data.lyricMotion
            animateIn(cur, mode, 320); animateIn(prev, mode, 280); animateIn(next, mode, 420)
            prev.visibility = if (p.isEmpty()) View.GONE else View.VISIBLE
            next.visibility = if (n.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun animateIn(v: View, mode: Int, ms: Long) {
        v.animate().cancel()
        v.alpha = 1f; v.translationX = 0f; v.translationY = 0f; v.scaleX = 1f; v.scaleY = 1f
        if (mode == 5) return
        when (mode) {
            1 -> v.alpha = 0f
            2 -> { v.alpha = 0f; v.scaleX = 0.6f; v.scaleY = 0.6f }
            3 -> { v.alpha = 0f; v.translationX = dp(46f) }
            4 -> { v.alpha = 0f; v.translationY = -dp(16f) }
            else -> { v.alpha = 0f; v.translationY = dp(12f) }
        }
        v.animate().alpha(1f).translationX(0f).translationY(0f).scaleX(1f).scaleY(1f)
            .setDuration(if (mode == 1) ms + 130 else ms)
            .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != null && ::lockBtn.isInitialized) {
            setLockIcon(controller.store.data.overlayLocked)
        }
        return START_NOT_STICKY
    }

    /** Turning the phone: refit the floating lyrics to the new screen width and keep them on screen. */
    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        val r = root ?: return
        try {
            val m = resources.displayMetrics
            lp.width = (m.widthPixels * 0.94f).toInt()
            lp.x = lp.x.coerceIn(0, (m.widthPixels - lp.width).coerceAtLeast(0))
            lp.y = lp.y.coerceIn(0, (m.heightPixels - dp(120f).toInt()).coerceAtLeast(0))
            wm.updateViewLayout(r, lp)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        controller.overlayActive = false
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_LOCK = "aurora.overlay.LOCK"
        const val ACTION_UNLOCK = "aurora.overlay.UNLOCK"

        fun start(ctx: Context) { ctx.startService(Intent(ctx, LyricsOverlayService::class.java)) }
        /** Shows or hides the floating lyrics from anywhere (notification, widget); asks for the permission the first time. */
        fun toggle(ctx: Context) {
            val c = ctx.applicationContext.controller
            if (c.overlayActive) { stop(ctx); return }
            if (android.provider.Settings.canDrawOverlays(ctx)) start(ctx)
            else {
                android.widget.Toast.makeText(ctx, "Allow “Display over other apps” for Aurora, then try again", android.widget.Toast.LENGTH_LONG).show()
                try {
                    ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {}
            }
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, LyricsOverlayService::class.java)) }

        fun setLocked(ctx: Context, locked: Boolean) {
            ctx.controller.store.update { it.copy(overlayLocked = locked) }
            ctx.startService(Intent(ctx, LyricsOverlayService::class.java).setAction(if (locked) ACTION_LOCK else ACTION_UNLOCK))
        }
    }
}
