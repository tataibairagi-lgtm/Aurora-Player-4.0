package com.aurora.player.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import com.aurora.player.data.Track

/** Pictures for sharing: one song, and the year in review. Plain Canvas, so it works on every Android version. */
object CardPictures {
    private const val W = 1080

    private fun tp(size: Float, color: Int, bold: Boolean = false) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = size; this.color = color; typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun fit(s: String, p: TextPaint, maxW: Float) = TextUtils.ellipsize(s, p, maxW, TextUtils.TruncateAt.END).toString()

    /** The cover with its title, artist and album under it. */
    fun song(t: Track, art: Bitmap?, pal: SharePal): Bitmap {
        val h = 1500
        val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(pal.bg)
        val pad = 90f
        val side = W - 2 * pad
        val rect = RectF(pad, 150f, pad + side, 150f + side)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = pal.fg; alpha = 40 }
        cv.drawRoundRect(rect, 56f, 56f, fill)
        if (art != null) {
            val clip = android.graphics.Path().apply { addRoundRect(rect, 56f, 56f, android.graphics.Path.Direction.CW) }
            cv.save(); cv.clipPath(clip)
            // fill the square, cropping the longer side
            val s = minOf(art.width, art.height)
            val src = android.graphics.Rect((art.width - s) / 2, (art.height - s) / 2, (art.width + s) / 2, (art.height + s) / 2)
            cv.drawBitmap(art, src, rect, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
            cv.restore()
        }
        var y = rect.bottom + 120f
        val title = tp(64f, pal.fg, true)
        cv.drawText(fit(t.title, title, side), pad, y, title)
        y += 70f
        val artist = tp(44f, pal.fg).apply { alpha = 220 }
        cv.drawText(fit(t.artist, artist, side), pad, y, artist)
        if (t.album.isNotBlank()) {
            y += 62f
            val album = tp(36f, pal.fg).apply { alpha = 150 }
            cv.drawText(fit(t.album, album, side), pad, y, album)
        }
        val foot = tp(34f, pal.fg, true)
        cv.drawText("Aurora", pad, h - 80f, foot)
        val tag = tp(30f, pal.fg).apply { alpha = 140; textAlign = Paint.Align.RIGHT }
        cv.drawText("Now playing", W - pad, h - 80f, tag)
        return bmp
    }

    class Review(
        val year: Int, val plays: Int, val songs: Int, val artists: Int, val hours: Double,
        val topSongs: List<Pair<String, Int>>, val topArtists: List<Pair<String, Int>>,
        val topGenre: String, val busiestMonth: String, val busiestDay: String, val peakHour: Int,
    )

    fun year(r: Review, pal: SharePal): Bitmap {
        val h = 1700
        val bmp = Bitmap.createBitmap(W, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(pal.bg)
        val pad = 80f
        val inner = W - 2 * pad
        var y = 150f
        cv.drawText("Aurora", pad, y, tp(40f, pal.fg, true))
        y += 120f
        cv.drawText("Your ${r.year}", pad, y, tp(110f, pal.fg, true))
        y += 120f
        val big = tp(88f, pal.fg, true)
        val small = tp(34f, pal.fg).apply { alpha = 170 }
        cv.drawText("${r.plays}", pad, y, big)
        cv.drawText("plays", pad, y + 46f, small)
        cv.drawText("%.0f".format(r.hours), pad + 400f, y, big)
        cv.drawText("hours listened", pad + 400f, y + 46f, small)
        y += 150f
        fun block(title: String, rows: List<Pair<String, Int>>) {
            cv.drawText(title, pad, y, tp(40f, pal.fg, true))
            y += 26f
            val name = tp(38f, pal.fg)
            val count = tp(34f, pal.fg).apply { alpha = 170; textAlign = Paint.Align.RIGHT }
            rows.take(5).forEachIndexed { i, (n, c) ->
                y += 58f
                cv.drawText("${i + 1}", pad, y, tp(34f, pal.fg).apply { alpha = 140 })
                cv.drawText(fit(n, name, inner - 190f), pad + 56f, y, name)
                cv.drawText("$c", W - pad, y, count)
            }
            y += 80f
        }
        block("Top songs", r.topSongs)
        block("Top artists", r.topArtists)
        val line = tp(38f, pal.fg)
        cv.drawText("Top genre: ${r.topGenre}", pad, y, line); y += 58f
        cv.drawText("Busiest month: ${r.busiestMonth}", pad, y, line); y += 58f
        cv.drawText("Favourite day: ${r.busiestDay}", pad, y, line); y += 58f
        cv.drawText("Peak hour: %02d:00".format(r.peakHour), pad, y, line)
        return bmp
    }
}
