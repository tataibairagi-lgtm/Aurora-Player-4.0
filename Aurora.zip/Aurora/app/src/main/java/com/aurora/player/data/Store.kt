package com.aurora.player.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

@Serializable
data class Persisted(
    val favourites: List<Long> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val queues: List<QueueData> = listOf(QueueData("Queue 1"), QueueData("Queue 2")),
    val activeQueue: Int = 0,
    val playCounts: Map<Long, Int> = emptyMap(),
    val lastPlayed: List<Long> = emptyList(),
    // audio
    val eqProfiles: Map<String, EqProfile> = emptyMap(),
    val customPresets: List<EqPreset> = emptyList(),
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val fadeSec: Int = 0,
    // ui
    val themeMode: Int = 0, // 0 system, 1 light, 2 dark
    val discArt: Boolean = true,
    val onlineLyrics: Boolean = true,
    // desktop lyrics
    val overlayTextSp: Int = 22,
    val overlayColor: Long = 0xFFFFFFFF,
    val lyricSize: Int = 1,
    val notifAdapt: Boolean = true,
    val notifAdaptStyle: Int = 1,  // 0 cover edge colour, 1 cover swatch colour (Musicolet-like)
    val lockAdapt: Boolean = true,
    val folderArt: Boolean = true,   // use folder.jpg / cover.jpg when a song has no embedded picture
    val keepOnNp: Boolean = false,   // keep the screen on while Now Playing is shown
    val lockAdaptStyle: Int = 0,   // 0 blurred cover, 1 cover swatch colour (Musicolet-like)
    val lyricsDim: Int = 40,       // darkening of the full-screen lock-screen lyrics
    val lockLyricSize: Int = 26,
    val lockLyricAlign: Int = 1,   // 0 left, 1 centre, 2 right
    val lockLyricBold: Boolean = true,
    val lockAlways: Boolean = true,
    val lockSkipPaused: Boolean = false, // do not show the lock-screen player when music has been paused for over a minute
    val notifUpcoming: Boolean = true,
    val notifArt: Boolean = true,
    val notifButtons: List<String> = listOf("fav", "overlay", "close"),
    val lyricAlign: Int = 0, // old setting, no longer used
    val lyricAlignC: Int = 1, // 0 left, 1 centre, 2 right
    val lyricColor: Long = 0, // 0 = default / theme colour for the current line and sung words
    val lyricDim: Int = 40, // opacity of the other lines, percent
    val lyricInactiveScale: Int = 84, // size of the other lines relative to the current one, percent
    val lyricAnchor: Int = 50, // where the current line sits in the lyrics area, percent from the top
    val lyricScrollMs: Int = 300, // scroll animation length
    val lyricEstimate: Boolean = false, // guess word times for lines that have none
    val lyricWordDim: Int = 38, // opacity of words not yet sung, percent
    val lyricShowSong: Boolean = true, // song title row above the lyrics
    val lyricSerif: Boolean = false,
    val lyricScale: Int = 100, // percent
    val lyricBold: Boolean = true,
    val lyricBlur: Boolean = true,
    val lyricSmooth: Boolean = true, // animations; off = lighter on slow phones
    val lyricWordSync: Boolean = true,
    val lyricAccent: Boolean = false,
    val lyricOffsetMs: Int = 200, // lyrics appear this much early
    val lyricSpacing: Int = 100, // percent
    val overlayX: Int = 0,
    val overlayY: Int = 160,
    val overlayLocked: Boolean = false,
    val lyricMotion: Int = 0,
    val swipeRemove: Boolean = true,
    val shakeAction: Int = 0, // 0 off, 1 next song, 2 previous song, 3 play / pause
    val shakeStrength: Int = 1, // 0 light, 1 normal, 2 hard
    // motion
    val motionSpeed: Int = 2, // 0 off, 1 relaxed, 2 normal, 3 snappy
    val navStyle: Int = 0,
    val listAnim: Int = 1,
    val listStagger: Boolean = true,
    val pressMode: Int = 2,
    val artFade: Boolean = true,
    // lock screen player
    val lockScreenPlayer: Boolean = false,
    val lockShowLyrics: Boolean = true,
    // queue widget colours: 0 follow wallpaper, 1 light, 2 dark
    val queueTheme: Int = 4, // 4 = Musicolet style, 3 = adapt from album art
    val shareSongs: Int = 10, val shareArtists: Int = 3, val sharePal: Int = 0, // Most played share picture
    val addedDays: Int = 30, // "Recently added" period in days (0 = all time)
    val playedDays: Int = 7, // "Recently played" period in days (0 = all time)
    val customDays: Int = 0, // the user's own extra period chip
    val customNotif: Boolean = true, // Musicolet-style notification layout (off = Android's standard media notification)
    val widgetsLive: Boolean = true, // redraw home-screen widgets while music plays
    val qsTileLive: Boolean = true, // keep the Quick Settings tile in sync while music plays
    val fastLyrics: Boolean = true, // update synced lyrics about 25 times a second (off = 8 times, lighter)
    val safeNote: Boolean = false, // Aurora switched heavy features off after the app stopped while playing
    val soundEngine: Boolean = true, // Aurora's own equalizer / mono / balance engine in the audio chain
    val wAlpha: Int = 30, // widget transparency, percent
    val wqArt: Boolean = true, val wqFav: Boolean = true, val wqFfRew: Boolean = false, val wqOverlay: Boolean = true,
    val wsArt: Boolean = true, val wsFav: Boolean = true, val wsProg: Boolean = true,
    val waArt: Boolean = true, val waFav: Boolean = true, val waProg: Boolean = true, val waModes: Boolean = true, val waNext: Boolean = true,
    // backup (device specific: never restored from a backup)
    val backupFolder: String = "",
    val autoBackup: Boolean = false,
    val autoBackupDays: Int = 1,
    val autoCsv: Boolean = false,           // export most played songs/artists to .csv at the end of each week, month and year
    val csvDone: List<String> = emptyList(), // periods already exported
    val autoBackupKeep: Int = 5,
    val lastBackupAt: Long = 0,
    // library tabs (ids in display order; hidden ones are skipped)
    val tabOrder: List<String> = listOf("queues", "now", "albums", "artists", "playlists", "folders", "genres", "tracks"),
    val hiddenTabs: List<String> = listOf("genres", "tracks"),
    val hideNp: List<String> = emptyList(), // Now Playing buttons the user switched off
    val tabsBottom: Boolean = false,
    // now playing background: 0 album colour, 1 blurred album art, 2 aurora gradient, 3 plain, 4 black, 5 custom image
    val nowBg: Int = 0,
    val nowBgDim: Int = 35, // 0..80 % darkening for image backgrounds
    val customBgUri: String = "",
    // appearance (themeMode 3 = black / AMOLED)
    val accentColor: Long = 0xFF007CC3, // 0 = default / system colours
    val keepScreenOn: Boolean = false,
    // library
    val minDurationSec: Int = 30,
    val excludedFolders: List<String> = emptyList(),
    // playback
    val pauseOnUnplug: Boolean = true,
    val handleAudioFocus: Boolean = true,
    val prevRestarts: Boolean = true,
    val tapPlaysList: Boolean = true,
    val skipSilence: Boolean = false,
    val fadeInMs: Int = 0,
    val fadeOutMs: Int = 0,
    val pauseOnMute: Boolean = true,
    val resumeOnUnmute: Boolean = true,
    val blockPlayMuted: Boolean = false,
    val resumeOnBt: Boolean = false,
    val resumeOnWired: Boolean = false,
    val resumeOnlyIfPaused: Boolean = true,
    // advanced
    val stopOnTaskRemoved: Boolean = false,
    val showFileNames: Boolean = false,
    val hideWebInfo: Boolean = false, // remove website names and other junk from song tags
    val rememberPositions: Boolean = false,
    val rememberMinMin: Int = 2,
    val askToResume: Boolean = false,
    val positions: Map<Long, Long> = emptyMap(),
    val minPlaySec: Int = 15,
    val prevRestartPct: Int = 0, // previous restarts the song once this % has played (0 = after 3 seconds)
    val playCountPct: Int = 0, // > 0: a play counts after this percentage of the song instead of a fixed time
    val autoPlayOnStart: Boolean = false,
    val loadArt: Boolean = true,
    val ffSec: Int = 10,
    val rewindSec: Int = 10,
    val ignoreWords: Boolean = false,
    val confirmExit: Boolean = false,
    val backMode: Int = 0,
    // lyrics: preferred source "saved" | "embedded" | "file"; per-song override ("embedded"/"file"/"saved"/"online")
    val lyricsPreferred: String = "saved",
    val lyricsSource: Map<Long, String> = emptyMap(),
    // audio focus: 1 ignore everything .. 5 pause for everything
    val focusLevel: Int = 3,
    val resumeAfterCall: Boolean = true,
    // queues
    val sourceQueues: Boolean = true, // playing an album/playlist/folder... opens a queue named after it
    val queueMerge: Boolean = false, // if that queue already exists: false = replace, true = merge
    // lock screen
    val lockSwipeRight: Boolean = true,
    // sound
    val crossfadeSec: Int = 0,
    val replayGain: Boolean = false,
    val perSongSpeed: Boolean = false,
    val speeds: Map<Long, Float> = emptyMap(),
    // library
    val splitArtists: Boolean = false,
    val artistSeparators: String = ",;/&",
    val foldersTree: Boolean = true,
    val showSeekButtons: Boolean = true,
    val idleStopMin: Int = 0,
    val shuffleBelowOnly: Boolean = true,
    val randomizeBelowOnly: Boolean = true,
    val albumCols: Int = 3,
    val albumInfo: Int = 0,
    val artistExtra: Boolean = false,
    val nextPrevSeek: Boolean = false,
    val preventAutoplay: Boolean = false,
    val showElapsed: Boolean = false,
    val unplayedDays: Int = 7,
    val eqSameForAll: Boolean = false,
    val seekKnobOnly: Boolean = false,
    val albumMergeByName: Boolean = true,
    val earDouble: Int = 0,
    val earTriple: Int = 1,
    val externalControl: Boolean = true,
    val smartShuffle: Boolean = false,
    val alphaNum: Boolean = false,
    val hiddenMenu: List<String> = emptyList(),
    val hiddenSmart: List<String> = emptyList(),
    val mixExcludeFolders: List<String> = emptyList(), val mixExcludePlaylists: List<String> = emptyList(), val mixSize: Int = 40,
    val playlistCounts: Boolean = true,
    val genreExtra: Boolean = false,
    val folderPath: Boolean = true,
    val tabSort: Map<String, Int> = emptyMap(),
    val tabSortRev: Map<String, Boolean> = emptyMap(),
    val pitches: Map<Long, Float> = emptyMap(),
    val reverbPreset: Int = 0,   // 0 off, 1 small room, 2 medium room, 3 large hall, 4 plate
    val reverbLevel: Int = 50,   // how much of the sound goes into the reverb, percent
    val mono: Boolean = false,
    val balance: Int = 0,
    val songEnd: Int = 2,        // 0 stop there, 1 load next and pause, 2 play next, 3 repeat the song
    val queueEnd: Int = 0,       // 0 stop, 1 jump to next queue, 2 repeat the queue
    val reshuffleOnEnd: Boolean = true,
    // bookmarks & audio notes
    val bookmarks: List<Bookmark> = emptyList(),
)

/** All persisted app state. Backed by SharedPreferences (JSON) and exposed as Compose state. */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("aurora", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    var data by mutableStateOf(load())
        private set

    private fun load(): Persisted = try {
        prefs.getString("d", null)?.let {
            val p = json.decodeFromString<Persisted>(it)
            // one-time: widgets that were on "Match with system" move to the new Musicolet-style look
            var q = p
            if (!prefs.getBoolean("wt4", false)) {
                prefs.edit().putBoolean("wt4", true).apply()
                if (q.queueTheme == 0) q = q.copy(queueTheme = 4)
            }
            // one-time: albums with the same name are merged by default now
            if (!prefs.getBoolean("am1", false)) {
                prefs.edit().putBoolean("am1", true).apply()
                q = q.copy(albumMergeByName = true)
            }
            q
        } ?: Persisted()
    } catch (e: Exception) {
        Persisted()
    }

    init { com.aurora.player.ui.Motion.sync(data); com.aurora.player.ui.SortPrefs.natural = data.alphaNum; com.aurora.player.data.AlbumIndex.mergeByName = data.albumMergeByName; com.aurora.player.data.WebClean.on = data.hideWebInfo }

    fun update(f: (Persisted) -> Persisted) {
        data = f(data)
        com.aurora.player.ui.Motion.sync(data); com.aurora.player.ui.SortPrefs.natural = data.alphaNum; com.aurora.player.data.AlbumIndex.mergeByName = data.albumMergeByName; com.aurora.player.data.WebClean.on = data.hideWebInfo
        scheduleWrite()
    }

    // Serialising everything on the main thread (every 5 s while playing, every toggle) caused hitches: write on a worker, coalescing bursts.
    private val writer = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val writePending = java.util.concurrent.atomic.AtomicBoolean(false)
    private fun scheduleWrite() {
        if (!writePending.compareAndSet(false, true)) return
        writer.execute {
            writePending.set(false)
            try { prefs.edit().putString("d", json.encodeToString(data)).commit() } catch (_: Throwable) {}
        }
    }

    // favourites
    fun isFavourite(id: Long) = id in data.favourites
    fun toggleFavourite(id: Long) = update {
        it.copy(favourites = if (id in it.favourites) it.favourites - id else it.favourites + id)
    }

    // playlists
    fun createPlaylist(name: String, ids: List<Long> = emptyList()): String {
        val id = UUID.randomUUID().toString()
        update { it.copy(playlists = it.playlists + Playlist(id, name.trim().ifEmpty { "Playlist" }, ids)) }
        return id
    }

    fun renamePlaylist(id: String, name: String) = update { p ->
        p.copy(playlists = p.playlists.map { if (it.id == id) it.copy(name = name.trim().ifEmpty { it.name }) else it })
    }

    fun deletePlaylist(id: String) = update { p -> p.copy(playlists = p.playlists.filter { it.id != id }) }

    fun addToPlaylist(id: String, ids: List<Long>) = update { p ->
        p.copy(playlists = p.playlists.map {
            if (it.id == id) it.copy(trackIds = it.trackIds + ids.filter { n -> n !in it.trackIds }) else it
        })
    }

    fun removeFromPlaylist(id: String, trackId: Long) = update { p ->
        p.copy(playlists = p.playlists.map {
            if (it.id == id) it.copy(trackIds = it.trackIds - trackId) else it
        })
    }

    fun recordPlay(id: Long) = update {
        it.copy(
            playCounts = it.playCounts + (id to ((it.playCounts[id] ?: 0) + 1)),
            lastPlayed = (listOf(id) + it.lastPlayed.filter { x -> x != id }).take(100),
        )
    }
}
