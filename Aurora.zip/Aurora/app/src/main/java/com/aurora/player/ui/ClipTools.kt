package com.aurora.player.ui

import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aurora.player.data.ClipCutter
import com.aurora.player.data.NameTags
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Cut a piece of a song and save it as a ringtone, alarm, notification sound or a plain clip. The original is not touched. */
@Composable
fun ClipTrimmerDialog(c: PlayerController, t: Track, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dur = t.durationMs.coerceAtLeast(1000L).toFloat()
    var start by remember { mutableFloatStateOf(0f) }
    var end by remember { mutableFloatStateOf(minOf(dur, 30_000f)) }
    var kind by remember { mutableStateOf(1) }
    var name by remember { mutableStateOf(t.title + " clip") }
    var busy by remember { mutableStateOf(false) }
    val isCur = c.current?.id == t.id
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text("Cut a clip") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(t.title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                Text("From ${formatTime(start.toLong())}", fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                Slider(start, { start = it.coerceAtMost(end - 1000f).coerceAtLeast(0f) }, valueRange = 0f..dur)
                Text("To ${formatTime(end.toLong())}", fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                Slider(end, { end = it.coerceAtLeast(start + 1000f).coerceAtMost(dur) }, valueRange = 0f..dur)
                Text("Length ${formatTime((end - start).toLong())}", style = MaterialTheme.typography.bodySmall)
                if (isCur) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton({ start = c.positionMs.toFloat().coerceAtMost(end - 1000f).coerceAtLeast(0f) }) { Text("Start = now") }
                    TextButton({ end = c.positionMs.toFloat().coerceAtLeast(start + 1000f).coerceAtMost(dur) }) { Text("End = now") }
                }
                Text("Save as", Modifier.padding(top = 6.dp), style = MaterialTheme.typography.labelLarge)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Ringtone", "Alarm", "Alert", "Clip").forEachIndexed { i, l ->
                        val k = if (i == 3) 0 else i + 1
                        FilterChip(kind == k, { kind = k }, label = { Text(l) })
                    }
                }
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
                Text(
                    "Works for MP3 and M4A/AAC songs. Choose the sound in Android's Sound settings afterwards.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton(enabled = !busy && name.isNotBlank(), onClick = {
                busy = true
                scope.launch {
                    val msg = withContext(Dispatchers.IO) {
                        val tmp = File(ctx.cacheDir, "clip_tmp")
                        val r = ClipCutter.cut(ctx, android.net.Uri.parse(t.uri), start.toLong(), end.toLong(), tmp)
                        val res = if (r.startsWith("ok:")) {
                            val ok = ClipCutter.publish(ctx, tmp, name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_"), if (r.endsWith("mpeg")) "audio/mpeg" else "audio/mp4", kind)
                            if (ok) "Saved “${name.trim()}”" else "Could not save the clip"
                        } else "Could not cut: $r"
                        tmp.delete(); res
                    }
                    Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                    busy = false
                    if (msg.startsWith("Saved")) onClose()
                }
            }) { Text(if (busy) "Cutting…" else "Save") }
        },
        dismissButton = { TextButton({ if (!busy) onClose() }) { Text("Cancel") } },
    )
}

/** Fills artist, title, album, track and year from the file names of the chosen songs. */
@Composable
fun NameTagsDialog(tracks: List<Track>, onClose: () -> Unit, onApply: (String) -> Unit) {
    var pattern by remember { mutableStateOf(NameTags.PATTERNS.first()) }
    val hits = tracks.count { NameTags.parse(it.path.ifEmpty { it.title }, pattern) != null }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Tags from file names") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Pick how the file names are written. Use %artist, %title, %album, %track and %year.", style = MaterialTheme.typography.bodySmall)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    NameTags.PATTERNS.forEach { p -> FilterChip(pattern == p, { pattern = p }, label = { Text(p) }) }
                }
                OutlinedTextField(pattern, { pattern = it }, singleLine = true, label = { Text("Pattern") }, modifier = Modifier.fillMaxWidth())
                Text("$hits of ${tracks.size} songs fit this pattern", fontWeight = androidx.compose.ui.text.font.FontWeight.Medium)
                tracks.take(3).forEach { t ->
                    val r = NameTags.parse(t.path.ifEmpty { t.title }, pattern)
                    Text(
                        if (r == null) "✗ ${t.path.substringAfterLast('/')}" else "✓ " + listOf(r.artist, r.title, r.album, r.track, r.year).filter { it.isNotEmpty() }.joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall, maxLines = 1,
                    )
                }
            }
        },
        confirmButton = { TextButton({ onApply(pattern) }, enabled = hits > 0) { Text("Apply to $hits") } },
        dismissButton = { TextButton(onClose) { Text("Cancel") } },
    )
}



