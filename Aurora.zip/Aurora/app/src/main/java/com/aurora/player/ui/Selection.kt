package com.aurora.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileCopy
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistPlay
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

/**
 * The bar shown at the bottom while songs are selected (long-press a song to start): count, total time,
 * Options, advanced select (all / invert) and Cancel. [inQueue] adds "Remove from this queue" to Options.
 */
@Composable
fun SelectionBar(
    c: PlayerController,
    selected: List<Track>,
    inQueue: Boolean,
    onRemove: () -> Unit,
    onSelectAll: () -> Unit,
    onInvert: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var options by remember { mutableStateOf(false) }
    var advanced by remember { mutableStateOf(false) }
    Column(
        modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp)).padding(vertical = 8.dp),
    ) {
        Text(
            "${selected.size} songs selected · ${formatTime(selected.sumOf { it.durationMs })}",
            Modifier.fillMaxWidth().padding(bottom = 6.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            style = MaterialTheme.typography.titleSmall,
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            BarButton(Icons.Rounded.MoreHoriz, "Options") { options = true }
            Box {
                BarButton(Icons.Rounded.SelectAll, "Advanced select") { advanced = true }
                DropdownMenu(advanced, { advanced = false }) {
                    DropdownMenuItem(text = { Text("Select all") }, onClick = { advanced = false; onSelectAll() })
                    DropdownMenuItem(text = { Text("Invert selection") }, onClick = { advanced = false; onInvert() })
                }
            }
            BarButton(Icons.Rounded.Close, "Cancel", onCancel)
        }
    }
    if (options) SelectionOptionsDialog(c, selected, inQueue, onRemove, onCancel) { options = false }
}

@Composable
private fun BarButton(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.bounceClick(onClick).padding(horizontal = 12.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(26.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun SelectionOptionsDialog(
    c: PlayerController,
    tracks: List<Track>,
    inQueue: Boolean,
    onRemove: () -> Unit,
    onDone: () -> Unit,
    onDismiss: () -> Unit,
) {
    val actions = LocalActions.current
    var closeAfter by remember { mutableStateOf(true) }
    var sub by remember { mutableStateOf<String?>(null) }
    val ids = tracks.map { it.id }

    fun run(block: () -> Unit) {
        block()
        onDismiss()
        if (closeAfter) onDone()
    }

    @Composable
    fun Item(icon: ImageVector, text: String, onClick: () -> Unit) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text, Modifier.padding(start = 20.dp))
        }
    }

    when (sub) {
        "queue" -> AlertDialog(
            onDismissRequest = { sub = null },
            title = { Text("Add to a queue") },
            text = {
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) {
                    c.store.data.queues.forEachIndexed { i, q ->
                        Text(
                            "${q.name}  (${q.trackIds.size})",
                            Modifier.fillMaxWidth().clickable { run { c.addToOtherQueue(i, tracks) } }.padding(vertical = 12.dp),
                        )
                    }
                }
            },
            confirmButton = { TextButton({ sub = null }) { Text("Cancel") } },
        )
        "batch" -> BatchTagDialog(tracks.size, { sub = null }) { d ->
            sub = null; onDismiss(); actions.batchTags(tracks, d); if (closeAfter) onDone()
        }
        "rename" -> NameDialog("Rename file", tracks.first().path.substringAfterLast('/').substringBeforeLast('.'), "Rename", { sub = null }) { n ->
            sub = null; onDismiss(); actions.renameTrack(tracks.first(), n); if (closeAfter) onDone()
        }
        "move" -> NameDialog("Move to (e.g. Music/Rock)", "Music/", "Move", { sub = null }) { n ->
            sub = null; onDismiss()
            val clean = n.trim().trim('/')
            if (clean.isNotEmpty()) actions.moveTracks(tracks, "$clean/")
            if (closeAfter) onDone()
        }
        "playlist" -> AddToPlaylistDialog(c, ids) { sub = null; onDismiss(); if (closeAfter) onDone() }
        "tags" -> TagEditorDialog(tracks.first(), { sub = null }) { data ->
            sub = null; onDismiss(); actions.editTags(tracks.first(), data); if (closeAfter) onDone()
        }
        "delete" -> AlertDialog(
            onDismissRequest = { sub = null },
            title = { Text("Delete ${tracks.size} songs?") },
            text = { Text("The audio files are permanently removed from your device. This can't be undone.") },
            confirmButton = { TextButton({ run { actions.deleteTracks(tracks) } }) { Text("Delete") } },
            dismissButton = { TextButton({ sub = null }) { Text("Cancel") } },
        )
        else -> AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Options for ${tracks.size} selected songs") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    if (inQueue) Item(Icons.Rounded.RemoveCircleOutline, "Remove from this queue") { run(onRemove) }
                    Item(Icons.Rounded.PlayArrow, "Play") { run { c.playTracks(tracks, 0, false) } }
                    Item(Icons.Rounded.Shuffle, "Shuffle and play") { run { c.playTracks(tracks.shuffled(), 0, true) } }
                    Item(Icons.Rounded.SkipNext, "Play after current song") { run { c.playAfterCurrent(tracks) } }
                    Item(Icons.Rounded.PlaylistPlay, "Add to currently playing queue") { run { c.addAllToQueue(tracks) } }
                    Item(Icons.AutoMirrored.Rounded.QueueMusic, "Add to a queue") { sub = "queue" }
                    Item(Icons.AutoMirrored.Rounded.PlaylistAdd, "Add to playlists") { sub = "playlist" }
                    Item(Icons.Rounded.Favorite, "Add to favorites") {
                        run { c.store.update { p -> p.copy(favourites = p.favourites + ids.filter { it !in p.favourites }) } }
                    }
                    Item(Icons.Rounded.FavoriteBorder, "Remove from favorites") {
                        run { c.store.update { p -> p.copy(favourites = p.favourites.filter { it !in ids }) } }
                    }
                    Item(Icons.Rounded.Edit, if (tracks.size == 1) "Edit tags" else "Edit tags of all ${tracks.size} songs") { sub = if (tracks.size == 1) "tags" else "batch" }
                    Item(Icons.Rounded.Edit, "Embed cover art from an image") { run { actions.embedArt(tracks) } }
                    if (tracks.size == 1) Item(Icons.Rounded.Edit, "Rename file") { sub = "rename" }
                    Item(Icons.Rounded.FileCopy, "Move to another folder") { sub = "move" }
                    Item(Icons.Rounded.FileCopy, "Copy to a folder") { run { actions.copyTracks(tracks) } }
                    Item(Icons.Rounded.Delete, "Delete from device") { sub = "delete" }
                }
            },
            confirmButton = {
                Row(Modifier.clickable { closeAfter = !closeAfter }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(closeAfter, null)
                    Text("Close selection after an option is selected", Modifier.padding(start = 8.dp), style = MaterialTheme.typography.bodySmall)
                }
            },
        )
    }
}
