package com.aurora.player.widget

import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import androidx.core.graphics.ColorUtils

/**
 * Colours for the queue widget.
 *  - Wallpaper mode on Android 12+: the system's Material You palette, which Android derives from your wallpaper.
 *  - Wallpaper mode on Android 8.1-11: the wallpaper's dominant colour, turned into a light or dark palette.
 *  - Light / Dark modes: a fixed Aurora palette.
 * In wallpaper mode light vs dark follows how bright the wallpaper picture is (the phone's dark mode if that can't be read).
 */
object WidgetTheme {
    class Colors(
        val header: Int, val headerAlpha: Int,
        val panel: Int, val panelAlpha: Int,
        val text: Int, val sub: Int, val accent: Int, val divider: Int, val onAccent: Int = Color.WHITE,
        /** Musicolet look: no filled panels or buttons, coral text and icons straight on a faint dark panel. */
        val flat: Boolean = false,
    )

    /** Colour of the current cover, set by WidgetUpdater; used by the "Adapt from album art" theme. */
    @Volatile var artSeed: Int? = null

    private const val AURORA_SEED = 0xFF7C6CF0.toInt()

    fun resolve(ctx: Context, mode: Int): Colors {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        return when (mode) {
            4 -> Colors(
                header = Color.BLACK, headerAlpha = 0, panel = Color.BLACK, panelAlpha = 0x70,
                text = 0xFFEFEFEF.toInt(), sub = 0xFFB4B4B4.toInt(), accent = 0xFFE8706A.toInt(), divider = 0x33FFFFFF,
                onAccent = 0xFFE8706A.toInt(), flat = true,
            )
            1 -> fromSeed(AURORA_SEED, dark = false)
            2 -> fromSeed(AURORA_SEED, dark = true)
            3 -> fromSeed(artSeed ?: AURORA_SEED, night)
            else -> {
                // follow the wallpaper itself: its main colour, and whether it is a dark or a light picture
                val w = wallpaper(ctx)
                val seed = w.seed
                if (seed == null && Build.VERSION.SDK_INT >= 31) dynamic(ctx, w.dark ?: night)
                else fromSeed(seed ?: AURORA_SEED, w.dark ?: night)
            }
        }
    }

    @SuppressLint("NewApi")
    private fun dynamic(ctx: Context, dark: Boolean): Colors {
        fun c(id: Int) = ctx.getColor(id)
        return if (!dark) Colors(
            header = c(android.R.color.system_accent1_100), headerAlpha = 0xE6,
            panel = c(android.R.color.system_accent1_50), panelAlpha = 0xCC,
            text = c(android.R.color.system_neutral1_900), sub = c(android.R.color.system_neutral2_700),
            accent = c(android.R.color.system_accent1_600), divider = c(android.R.color.system_accent1_200),
            onAccent = c(android.R.color.system_accent1_0),
        ) else Colors(
            header = c(android.R.color.system_accent2_800), headerAlpha = 0xE6,
            panel = c(android.R.color.system_neutral1_900), panelAlpha = 0xD9,
            text = c(android.R.color.system_neutral1_100), sub = c(android.R.color.system_neutral2_300),
            accent = c(android.R.color.system_accent1_200), divider = c(android.R.color.system_accent2_700),
            onAccent = c(android.R.color.system_accent1_800),
        )
    }

    class Wallpaper(val seed: Int?, val dark: Boolean?)

    @Volatile private var cached: Wallpaper? = null

    /** Forget the wallpaper analysis (call when the wallpaper changes). */
    fun invalidate() { cached = null }

    private fun wallpaper(ctx: Context): Wallpaper {
        cached?.let { return it }
        val bmp = analyseBitmap(ctx)
        val wc = fromWallpaperColors(ctx)
        val w = Wallpaper(
            seed = bmp?.seed ?: wc?.first,
            dark = bmp?.dark ?: wc?.second,
        )
        cached = w
        return w
    }

    /** The system's own reading of the wallpaper: (main colour, is it dark). Works without any permission. */
    private fun fromWallpaperColors(ctx: Context): Pair<Int, Boolean>? {
        if (Build.VERSION.SDK_INT < 27) return null
        return try {
            val wc = WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM) ?: return null
            val all = listOfNotNull(wc.primaryColor, wc.secondaryColor, wc.tertiaryColor).map { it.toArgb() }
            if (all.isEmpty()) return null
            val hsl = FloatArray(3)
            fun sat(c: Int): Float { ColorUtils.colorToHSL(c, hsl); return hsl[1] * (1f - kotlin.math.abs(2 * hsl[2] - 1f)) }
            // the biggest colour is the "main" one unless it is basically grey; then take the most colourful
            val main = all.first().takeIf { sat(it) > 0.12f } ?: all.maxByOrNull { sat(it) }!!
            val dark = if (Build.VERSION.SDK_INT >= 31) (wc.colorHints and 1) == 0 // HINT_SUPPORTS_DARK_TEXT unset = dark picture
            else ColorUtils.calculateLuminance(all.first()) < 0.40
            main to dark
        } catch (_: Throwable) {
            null
        }
    }

    private class Bmp(val seed: Int?, val dark: Boolean)

    /** Reads the real wallpaper, shrinks it, finds the colour that covers most of it and how bright the picture is. */
    private fun analyseBitmap(ctx: Context): Bmp? = try {
        val d = WallpaperManager.getInstance(ctx).peekDrawable()
        val src = (d as? android.graphics.drawable.BitmapDrawable)?.bitmap
        val w = 56; val h = 56
        val soft = src?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
        val bmp = soft?.let { android.graphics.Bitmap.createScaledBitmap(it, w, h, true) }
        if (bmp == null) null else {
            val weight = FloatArray(36); val sat = FloatArray(36); val lig = FloatArray(36)
            val hsl = FloatArray(3)
            var total = 0f; var lumSum = 0.0
            for (x in 0 until w) for (y in 0 until h) {
                val px = bmp.getPixel(x, y)
                lumSum += ColorUtils.calculateLuminance(px)
                ColorUtils.colorToHSL(px, hsl)
                // near-white, near-black and grey pixels don't define a wallpaper's colour
                if (hsl[1] < 0.12f || hsl[2] > 0.94f || hsl[2] < 0.06f) continue
                val k = 0.15f + hsl[1] * (1f - kotlin.math.abs(2 * hsl[2] - 1f)) // area counts; colourful pixels count a bit more
                val bin = (hsl[0] / 10f).toInt().coerceIn(0, 35)
                weight[bin] += k; sat[bin] += hsl[1] * k; lig[bin] += hsl[2] * k
                total += k
            }
            val mean = lumSum / (w * h)
            // perceived brightness: sRGB luminance of the average is ~0.2 for a mid-grey, so compare against a lower line
            val dark = mean < 0.22
            if (total < 6f) Bmp(null, dark)
            else {
                var best = 0; var bestW = -1f
                for (i in 0 until 36) {
                    val ww = weight[i] + 0.6f * (weight[(i + 35) % 36] + weight[(i + 1) % 36])
                    if (ww > bestW) { bestW = ww; best = i }
                }
                val bw = weight[best].coerceAtLeast(0.0001f)
                Bmp(ColorUtils.HSLToColor(floatArrayOf(best * 10f + 5f, (sat[best] / bw).coerceIn(0f, 1f), (lig[best] / bw).coerceIn(0.25f, 0.7f))), dark)
            }
        }
    } catch (_: Throwable) {
        null
    }

    private fun fromSeed(seed: Int, dark: Boolean): Colors {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(seed, hsl)
        // pinks and reds all become a true red (the pastel version of red reads as pink)
        val red = hsl[0] >= 325f || hsl[0] <= 22f
        val h = if (red) 352f else hsl[0]
        val s = hsl[1].coerceIn(0.45f, 0.95f)
        fun hsl(sat: Float, light: Float) = ColorUtils.HSLToColor(floatArrayOf(h, sat.coerceIn(0f, 1f), light.coerceIn(0f, 1f)))
        // yellows and greens look muddy at the same lightness as blues: nudge them
        val warm = h in 45f..160f
        fun onColor(bg: Int) = if (ColorUtils.calculateContrast(Color.WHITE, bg) >= 3.0) Color.WHITE else hsl(0.35f, 0.08f)
        /** Moves [fg] lighter/darker until it reads clearly (>= 4.5:1) on [bg]. */
        fun readable(fg: Int, bg: Int, darkText: Boolean): Int {
            var c = fg; var n = 0
            val f = FloatArray(3)
            while (ColorUtils.calculateContrast(c, bg) < 4.5 && n++ < 12) {
                ColorUtils.colorToHSL(c, f)
                f[2] = (f[2] + if (darkText) -0.04f else 0.04f).coerceIn(0f, 1f)
                c = ColorUtils.HSLToColor(f)
            }
            return c
        }
        // Material-style tonal palette: soft pastel accent on a tinted dark surface (or a deep accent on a pale one), never raw saturated colours
        val c = hsl[1].coerceIn(0.35f, 0.85f)
        return if (!dark) {
            val accent = if (red) hsl(0.78f, 0.46f) else hsl(c, if (warm) 0.30f else 0.38f)
            Colors(
                header = hsl(0.42f, 0.89f), headerAlpha = 0xF2,
                panel = hsl(0.40f, 0.94f), panelAlpha = 0xE6,
                text = hsl(0.25f, 0.12f), sub = hsl(0.18f, 0.35f),
                accent = accent, divider = hsl(0.30f, 0.80f), onAccent = Color.WHITE,
            )
        } else {
            val accent = if (red) hsl(0.88f, 0.66f) else hsl(c, if (warm) 0.74f else 0.80f)
            Colors(
                header = hsl(0.20f, 0.24f), headerAlpha = 0xF2,
                panel = hsl(0.17f, 0.18f), panelAlpha = 0xE6,
                text = hsl(0.20f, 0.94f), sub = hsl(0.14f, 0.74f),
                accent = accent, divider = hsl(0.15f, 0.30f), onAccent = if (red) Color.WHITE else hsl(0.60f, 0.13f),
            )
        }
    }
}
