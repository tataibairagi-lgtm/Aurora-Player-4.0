package com.aurora.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

/** A quick look at a song (opened by a long press when that is switched on): cover, facts and the usual actions. */
@Composable
fun SongPeek(c: PlayerController, t: Track, onSelect: () -> Unit, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose) {
        Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Column(Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AlbumArt(t, Modifier.size(92.dp), RoundedCornerShape(18.dp), 36.dp, 400)
                    Column(Modifier.padding(start = 16.dp)) {
                        Text(t.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(t.artist, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (t.album.isNotBlank()) Text(t.album, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                val plays = c.store.data.playCounts[t.id] ?: 0
                Text(
                    "${formatTime(t.durationMs)}  ·  played $plays ${if (plays == 1) "time" else "times"}",
                    Modifier.padding(top = 12.dp, bottom = 14.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                val fav = c.store.isFavourite(t.id)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    PeekAction(Icons.Rounded.PlayArrow, "Play") { c.playTracks(listOf(t)); onClose() }
                    PeekAction(Icons.Rounded.SkipNext, "Play next") { c.playNext(t); onClose() }
                    PeekAction(Icons.AutoMirrored.Rounded.PlaylistAdd, "Queue") { c.addToQueue(t); onClose() }
                    PeekAction(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, if (fav) "Unfavourite" else "Favourite") { c.store.toggleFavourite(t.id); onClose() }
                    PeekAction(Icons.Rounded.CheckCircle, "Select") { onClose(); onSelect() }
                }
            }
        }
    }
}

@Composable
private fun PeekAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.bounceClick(onClick).padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primaryContainer) {
            Icon(icon, label, Modifier.padding(12.dp).size(22.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
        }
        Text(label, Modifier.padding(top = 4.dp), style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}
