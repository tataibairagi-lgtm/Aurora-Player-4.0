package com.aurora.player.player

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.aurora.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

/** Decodes a song with the phone's own codecs and hands over mono samples. Used for the waveform and the tempo estimate. */
object AudioDecode {
    /**
     * [onFrames] gets (mono samples -1..1, count, sample rate, presentation time of the first sample in microseconds)
     * and returns false to stop. Returns the song length in microseconds (-1 if unknown or on failure).
     */
    fun run(
        ctx: Context, uri: Uri, startMs: Long, maxMs: Long, cancelled: () -> Boolean,
        onFrames: (FloatArray, Int, Int, Long) -> Boolean,
    ): Long {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { idx = i; fmt = f; break }
            }
            if (idx < 0 || fmt == null) return -1
            ex.selectTrack(idx)
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else -1L
            if (startMs > 0) ex.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val c = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()
            val info = MediaCodec.BufferInfo()
            var inDone = false; var outDone = false
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var enc = AudioFormat.ENCODING_PCM_16BIT
            var buf = FloatArray(4096)
            val endUs = if (maxMs > 0) (startMs + maxMs) * 1000 else Long.MAX_VALUE
            var guard = 0
            while (!outDone && !cancelled()) {
                if (!inDone) {
                    val i = c.dequeueInputBuffer(5000)
                    if (i >= 0) {
                        val b = c.getInputBuffer(i)!!
                        val n = ex.readSampleData(b, 0)
                        if (n < 0 || ex.sampleTime > endUs) { c.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { c.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val o = c.dequeueOutputBuffer(info, 5000)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT).coerceAtLeast(1)
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    enc = if (f.containsKey("pcm-encoding")) f.getInteger("pcm-encoding") else AudioFormat.ENCODING_PCM_16BIT
                } else if (o >= 0) {
                    val ob = c.getOutputBuffer(o)!!
                    if (info.size > 0) {
                        ob.position(info.offset); ob.limit(info.offset + info.size); ob.order(ByteOrder.nativeOrder())
                        val isFloat = enc == AudioFormat.ENCODING_PCM_FLOAT
                        val frames = info.size / (if (isFloat) 4 else 2) / ch
                        if (buf.size < frames) buf = FloatArray(frames)
                        for (f in 0 until frames) {
                            var s = 0f
                            for (k in 0 until ch) s += if (isFloat) ob.float else ob.short / 32768f
                            buf[f] = s / ch
                        }
                        if (!onFrames(buf, frames, sr, info.presentationTimeUs)) outDone = true
                    }
                    c.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_TRY_AGAIN_LATER && inDone && ++guard > 400) outDone = true
            }
            return durUs
        } catch (_: Throwable) {
            return -1
        } finally {
            try { codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            try { ex.release() } catch (_: Throwable) {}
        }
    }
}

/** Waveform peaks for the seek bar: one value 0..1 per bar. Cached in memory and on disk. */
object Waveform {
    const val BARS = 180
    private val mem = object : android.util.LruCache<Long, FloatArray>(60) {}

    suspend fun load(ctx: Context, t: Track): FloatArray? = withContext(Dispatchers.IO) {
        mem.get(t.id)?.let { return@withContext it }
        val dir = File(ctx.cacheDir, "wave").apply { mkdirs() }
        val f = File(dir, "${t.id}_${t.size}_${t.durationMs}.wf")
        if (f.exists() && f.length() == BARS * 4L) {
            try {
                val b = java.nio.ByteBuffer.wrap(f.readBytes())
                val a = FloatArray(BARS) { b.float }
                mem.put(t.id, a); return@withContext a
            } catch (_: Throwable) {}
        }
        val peaks = FloatArray(BARS)
        val durUs = t.durationMs * 1000
        if (durUs <= 0) return@withContext null
        val job = kotlinx.coroutines.currentCoroutineContext()[kotlinx.coroutines.Job]
        AudioDecode.run(ctx, Uri.parse(t.uri), 0, 0, { job?.isActive == false }) { buf, n, sr, pts ->
            val perBar = sr.toDouble() * durUs / 1_000_000.0 / BARS
            val first = pts * sr.toDouble() / 1_000_000.0
            for (i in 0 until n) {
                val bar = ((first + i) / perBar).toInt()
                if (bar in 0 until BARS) { val v = abs(buf[i]); if (v > peaks[bar]) peaks[bar] = v }
            }
            true
        }
        if (job?.isActive == false) return@withContext null
        // scale so the loud parts reach the top; a high percentile ignores a single click
        val sorted = peaks.sortedArray()
        val top = sorted[(BARS * 0.95).toInt().coerceAtMost(BARS - 1)].coerceAtLeast(1e-4f)
        val out = FloatArray(BARS) { (peaks[it] / top).coerceIn(0f, 1f).pow(0.8f).coerceAtLeast(0.05f) }
        try {
            val bb = java.nio.ByteBuffer.allocate(BARS * 4)
            out.forEach { bb.putFloat(it) }
            f.writeBytes(bb.array())
        } catch (_: Throwable) {}
        mem.put(t.id, out)
        out
    }
}

/** Estimates tempo (BPM) and energy for songs by looking at about a minute of audio. Runs in the background while the app is open. */
object BpmAnalyzer {
    var running by mutableStateOf(false); private set
    var done by mutableIntStateOf(0); private set
    var total by mutableIntStateOf(0); private set
    @Volatile private var cancel = false
    private val main = Handler(Looper.getMainLooper())

    fun stop() { cancel = true }

    fun start(c: PlayerController, ctx: Context) {
        if (running) return
        val todo = c.library.filter { it.id !in c.store.data.bpm }
        if (todo.isEmpty()) return
        running = true; cancel = false; done = 0; total = todo.size
        val app = ctx.applicationContext
        Thread {
            val pend = HashMap<Long, Pair<Int, Int>>()
            fun flush() {
                if (pend.isEmpty()) return
                val copy = HashMap(pend); pend.clear()
                main.post { c.store.update { p -> p.copy(sg = p.sg.copy(bpm = p.bpm + copy.mapValues { it.value.first }, energy = p.energy + copy.mapValues { it.value.second })) } }
            }
            try {
                for (t in todo) {
                    if (cancel) break
                    // 0 = could not be analysed: remembered so it is not tried again every time
                    val r = try { analyse(app, t) } catch (_: Throwable) { null } ?: (0 to 0)
                    pend[t.id] = r
                    main.post { done++ }
                    if (pend.size >= 8) flush()
                }
            } finally {
                flush()
                main.post { running = false }
            }
        }.also { it.priority = Thread.MIN_PRIORITY; it.isDaemon = true }.start()
    }

    /** (bpm, energy 0..100) or null. */
    fun analyse(ctx: Context, t: Track): Pair<Int, Int>? {
        val start = if (t.durationMs > 100_000) (t.durationMs * 0.3).toLong() else 0L
        var hop = 0; var acc = 0.0; var inHop = 0
        val env = ArrayList<Float>(6200)
        var sumSq = 0.0; var count = 0L
        AudioDecode.run(ctx, Uri.parse(t.uri), start, 60_000, { cancel }) { buf, n, sr, _ ->
            if (hop == 0) hop = (sr / 100).coerceAtLeast(1)
            for (i in 0 until n) {
                val v = abs(buf[i])
                acc += v; sumSq += buf[i] * buf[i]; count++
                if (++inHop == hop) { env.add((acc / hop).toFloat()); acc = 0.0; inHop = 0 }
            }
            true
        }
        if (env.size < 1500) return null
        val rms = sqrt(sumSq / count.coerceAtLeast(1))
        // onset strength: rises in the loudness envelope
        val on = FloatArray(env.size) { if (it == 0) 0f else (env[it] - env[it - 1]).coerceAtLeast(0f) }
        val mean = on.average().toFloat()
        for (i in on.indices) on[i] = (on[i] - mean).coerceAtLeast(0f)
        // autocorrelation over lags for 60..200 BPM (the envelope runs at 100 values per second)
        val minLag = 30; val maxLag = 100
        val ac = DoubleArray(maxLag * 2 + 2)
        for (lag in minLag..maxLag * 2) {
            var s = 0.0
            for (i in 0 until on.size - lag) s += on[i] * on[i + lag]
            ac[lag] = s / (on.size - lag)
        }
        var best = minLag; var bestScore = -1.0
        for (lag in minLag..maxLag) {
            // a real beat also repeats at double the lag: count that too, which avoids picking half-time
            val score = ac[lag] + 0.5 * ac[lag * 2]
            if (score > bestScore) { bestScore = score; best = lag }
        }
        // sharpen between neighbouring lags
        val y0 = ac[best - 1]; val y1 = ac[best]; val y2 = ac[best + 1]
        val den = y0 - 2 * y1 + y2
        val frac = if (abs(den) > 1e-12) (0.5 * (y0 - y2) / den).coerceIn(-0.5, 0.5) else 0.0
        var bpm = 6000.0 / (best + frac)
        while (bpm < 75) bpm *= 2
        while (bpm > 175) bpm /= 2
        val loud = ((20 * log10(rms.coerceAtLeast(1e-5)) + 36) / 30 * 100).coerceIn(0.0, 100.0)
        val tempo = ((bpm - 60) / 110 * 100).coerceIn(0.0, 100.0)
        return bpm.toInt() to (0.6 * loud + 0.4 * tempo).toInt().coerceIn(0, 100)
    }
}
