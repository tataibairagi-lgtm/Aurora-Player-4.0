# Aurora – offline music player with floating "desktop lyrics"

A Musicolet-style offline player for Android (Kotlin, Jetpack Compose, Media3/ExoPlayer) with extra
animation and a built-in floating lyrics window that stays on top of other apps.

## Open & run
1. Open the `Aurora` folder in **Android Studio** (Koala or newer). Let Gradle sync (it creates the Gradle wrapper).
2. Run on a device/emulator with Android 10+ (API 29+). Use the **release** build for smooth scrolling (the debug build is slow by design).
3. Grant the music + notification permissions on first launch.

> This source was written without access to an Android SDK, so it has not been compiled here. If sync or build
> reports a version mismatch, use Android Studio's suggested fixes; the code only uses stable APIs.

## Features
**Library** – Tracks, Albums, Artists, **Genres**, Folders, Playlists, Favourites tabs (show/hide and reorder them: sort menu > Customize tabs, or Settings > Library tabs; the first tab is the start page); search; 5 sort orders; smart lists
(Recently added / Recently played / Most played).

**Playback** – background play with notification and lock-screen controls, headset buttons, gapless playback,
shuffle, repeat (off/all/one), seek, **two switchable queues** (queue screen: swipe to remove, move up/down/top),
play next / add to queue, save queue as playlist, resume where you left off.

**Equalizer (Musicolet-style)** – a separate setup for each output: Speaker, Headphones, Bluetooth, Other. The
one matching what you're currently listening on is applied automatically and switches when you plug in or connect
something. Each has its own on/off switch, band sliders with a live response curve, the device's built-in presets,
your own saved presets, bass boost, virtualizer and loudness gain.

**Sound** – playback speed and pitch, fade between songs (0–12 s), sleep timer (minutes or end of song),
**A–B repeat**.

**Widgets** – five home-screen widgets: **Queue** (scrollable current queue like Musicolet's, tap a song to play it,
colours follow your wallpaper, see below) plus four more: Mini (4×1), Standard (4×2, cover + progress + favourite), Square (2×2, big
cover) and Large (4×4, all controls incl. shuffle/repeat plus an up-next list). Buttons work with the app closed.
Progress bars refresh when the song or play state changes, not every second.

**Most played** – Playlists tab > Most played, laid out like Musicolet's. Tabs for *This week*, the current *month*,
the current *year* and *All time*, with arrows to browse earlier weeks/months/years (weeks start on Monday). Every song
shows how many times you played it (blue badge) and its duration. For each period you get its own details: number of
songs, total plays, time listened and top artist. The **Artists** button opens a ranking with each artist's share of
all plays (%) and a bar; **Save / Share** sends the list as text. You can also play, shuffle, share, add to queue,
save as a playlist, and search inside the list. Each play (after 15 s) is logged with its date, so weekly/monthly
history builds up from the day you start using Aurora (older plays only count towards *All time*). Also available:
*Recently played*, *Recently added* and *Not played yet*. The play history is included in backups.

**Queue widget theme** – Settings > Queue widget: *Wallpaper* (default), *Light*, *Dark*. Wallpaper mode uses the Material
You palette Android builds from your wallpaper on Android 12+, and the wallpaper's dominant colour on Android 8.1–11.
It follows the phone's dark mode and redraws when the wallpaper or dark mode changes (while Aurora is running; otherwise
at the next song/play change or when you open the app).

**Backup & restore** – Settings > Backup & restore. Backups are ordinary `.zip` files (`backup.json` + cached lyrics)
saved in a folder you choose. Restore lets you pick what to bring back: settings & equalizer, favourites, individual
playlists (with Musicolet's Skip / Replace / Merge / Keep both for name clashes), play counts & queues, lyrics. Songs are
matched by path, then title + artist + duration, so a backup works after moving phones. **Automatic backup** runs in the
background (daily / weekly / monthly) and keeps the latest 3, 5 or 10.

**Lock-screen player** – Settings > Lock screen. When music is playing and the screen turns off, Aurora's player (cover,
clock, controls, favourite, current lyric line) is shown over the lock screen; swipe up to unlock. Needs the
"Display over other apps" permission. Some phone makers block apps from starting screens over the lock screen; the
normal media notification controls keep working either way.

**Organising** – playlists (create, rename, delete, add/remove), import `.m3u/.m3u8/.pls` playlist files (such as
ones exported from Musicolet) and export playlists as `.m3u`, favourites, tag editor (updates the Android
media library entry; the audio file itself is not rewritten).

**Lyrics** – synced `.lrc` and plain lyrics. Sources in order: lyrics you imported/downloaded (stored in the app),
a `.lrc` file next to the song (needs the optional all-files access in Settings), then LRCLIB download.
Everything downloaded is cached, so lyrics work offline afterwards.

**Desktop lyrics (floating window)** – toggle from the Now Playing screen (subtitle icon) or Settings. Karaoke-style
sweep across the current line, previous/next lines, drag anywhere, play/pause/skip, text size, colour and a
lock mode (touch-through). Needs "Display over other apps" permission. Unlock from Settings > Lock position.

**Settings** – Appearance (theme incl. pure-black AMOLED, accent colour, vinyl or square cover, tabs), Now playing
(background: album colour, blurred album art, animated Aurora, plain, black or your own image, with a darkening slider;
the palette button on the Now Playing screen cycles them; keep screen on), Playback (pause on unplug, pause for
calls/other apps, previous restarts the song, tap plays whole list or only that song, skip silence), Library (ignore
short songs, excluded folders, rescan), plus desktop lyrics, lyrics sources, backup & restore, lock screen, queue widget.

**Animations** – spinning vinyl art with pulsing glow (or breathing square cover), background colour taken from
the album art, animated equaliser bars on the playing row, spring-press feedback on every button, staggered list
and grid entrances, animated play/pause and favourite morphs, sliding track titles, animated lyric scrolling,
swipe the cover to change songs, animated page transitions and mini player.

**Queues** – up to 20 queues. Queues tab: pick a queue from the drop-down, new / rename / delete, play, sort / reverse /
randomize, total duration, save as playlist, export as .csv or .m3u8. Drag the handle to reorder, long-press to multi-select
(Options: remove, play, shuffle, play after current song, add to a queue / playlists / favourites, edit tags, copy to a folder,
delete from device; Advanced select: all / invert). Search box at the bottom. Playing an album/playlist/folder opens a queue
named after it (replace or merge if it exists).

**Sleep timer** – after N minutes, at the end of this song, after N songs, or after a song you choose; volume fades over the last 5 seconds.

**Audio focus** – 5 levels (ignore everything … pause for every interruption) plus resume after calls.

**Lock screen** – swipe right to unlock, queue viewer (tap a song to jump to it).

**Privacy** – no INTERNET permission, no ads, no tracking. Lyrics come from song tags, .lrc files or imports.

## Not included / honest limits
- Not implemented: crossfade overlap, ReplayGain, Chromecast, Android Auto, bookmarks/audio notes, hierarchical folder tree,
  launcher shortcuts, per-song speed memory, batch tag editing, embedding cover art, APE/DSF playback, settings search.
- "Fade between songs" is a fade-out/fade-in, not an overlapping crossfade.
- Musicolet's own backup zip cannot be read: every file inside is encrypted with a key that lives inside the Musicolet app.
  Use Musicolet's "Export as .M3U" per playlist and import that in Aurora instead.
- Android Auto and home-screen shortcuts for albums/artists/folders are not implemented.
- The tag editor changes MediaStore metadata only; a media rescan may restore the file's own tags.
- The app asks for INTERNET only to fetch lyrics on demand, and MANAGE_EXTERNAL_STORAGE only for sidecar
  `.lrc` files. Delete either line in `AndroidManifest.xml` (and the matching setting) for a purely offline,
  Play-Store-friendly build.

## Layout
- `data/` – MediaStore scanner, persisted state (JSON in SharedPreferences), LRC parser + LRCLIB client
- `player/` – `PlayerController` (all playback logic), `PlaybackService` (notification/media session)
- `lyrics/` – `LyricsOverlayService` (floating window)
- `ui/` – Compose screens: Library, Now Playing, Queue, Sound, Settings, overlay content

## Added in this version
Crossfade overlap, ReplayGain (lowers loud songs only), per-song speed, bookmarks with notes (Now playing ⋮), batch tag editing, embedding cover art, rename/move for files and folders (internal storage), folder tree, multi-artist splitting, sort by year / size / track number / reverse, listening-history CSV, settings search, launcher shortcuts (long-press the icon, or pin from a folder/album menu).

Not included: Chromecast (needs the Cast SDK and internet permission), APE/DSF playback (ExoPlayer can't decode them without a native ffmpeg build), Android Auto (needs a browsable media-library service; not added yet).

Also: play-mode dialog (when a song / queue ends), speed & pitch dialog (all files or this file only), equalizer knobs page (bass, surround, preamp, volume, mono/stereo, balance), notification with favourite and close buttons plus an "Upcoming songs" list. Everything targets Android 10 and up.
