package com.aurora.player.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PlayCircleOutline
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.VerticalAlignTop
import androidx.compose.material.icons.rounded.VerticalAlignBottom
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController

private fun iconFor(label: String): ImageVector = when {
    label.startsWith("Remove") -> Icons.Rounded.RemoveCircleOutline
    label.contains("top", true) -> Icons.Rounded.VerticalAlignTop
    label.contains("end", true) -> Icons.Rounded.VerticalAlignBottom
    label.startsWith("Stop after") -> Icons.Rounded.Block
    else -> Icons.Rounded.PlayCircleOutline
}

/**
 * The menu behind a song's three dots, laid out like Musicolet's: the song name with a heart, then groups of
 * icon items separated by lines. [extraMenu] carries what only some lists have (in the queue: remove, stop after, move...).
 */
@Composable
fun SongMenuDialog(
    c: PlayerController,
    t: Track,
    extraMenu: List<Pair<String, () -> Unit>>,
    onDismiss: () -> Unit,
    onInfo: () -> Unit,
    onPreview: () -> Unit,
    onTags: () -> Unit,
    onRename: () -> Unit,
    onPlaylist: () -> Unit,
    onDelete: () -> Unit,
    onSub: (String) -> Unit, // "queue", "move" or "speed": opened by the caller, because this menu closes itself on every tap
) {
    val ctx = LocalContext.current
    val hm = c.store.data.hiddenMenu

    val removeItems = extraMenu.filter { it.first.startsWith("Remove") }
    val stopItems = extraMenu.filter { it.first.startsWith("Stop after") }
    val otherItems = extraMenu.filter { !it.first.startsWith("Remove") && !it.first.startsWith("Stop after") }

    @Composable
    fun Item(icon: ImageVector, text: String, onClick: () -> Unit) {
        Row(
            Modifier.fillMaxWidth().clickable { onDismiss(); onClick() }.padding(horizontal = 22.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(icon, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text, Modifier.padding(start = 22.dp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
    @Composable
    fun Line() = HorizontalDivider(Modifier.padding(horizontal = 18.dp, vertical = 4.dp))

    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) {
            Column(Modifier.widthIn(max = 420.dp).verticalScroll(rememberScrollState()).padding(bottom = 8.dp)) {
                val fav = c.store.isFavourite(t.id)
                Row(Modifier.fillMaxWidth().padding(start = 22.dp, end = 10.dp, top = 12.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(t.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                    Icon(
                        if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null,
                        Modifier.size(44.dp).clip(CircleShape).clickable { c.store.toggleFavourite(t.id) }.padding(10.dp),
                        tint = if (fav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    )
                }
                if ("info" !in hm) Item(Icons.Rounded.Info, "Song info", onInfo)
                removeItems.forEach { (label, act) -> Item(iconFor(label), if (label == "Remove from queue") "Remove from this queue" else label, act) }
                otherItems.forEach { (label, act) -> Item(iconFor(label), label, act) }
                Line()
                if ("playnext" !in hm) Item(Icons.Rounded.SkipNext, "Play after current song") { c.playNext(t) }
                if ("queue" !in hm) Item(Icons.AutoMirrored.Rounded.QueueMusic, "Add to a queue") { onSub("queue") }
                if ("playlist" !in hm) Item(Icons.AutoMirrored.Rounded.PlaylistAdd, "Add to playlists", onPlaylist)
                Line()
                Item(Icons.Rounded.Speed, if (c.store.data.trimStart[t.id] != null || c.store.data.trimEnd[t.id] != null) "Trim: set" else "Trim start and end") { onSub("trim") }
                Item(Icons.Rounded.Speed, "Cut a clip or ringtone") { onSub("clip") }
                Item(Icons.Rounded.Star, "Share as picture") { onSub("card") }
                Item(Icons.Rounded.Block, if (c.store.isSnoozed(t.id)) "Bring back to shuffle" else "Snooze or hide from shuffle") { if (c.store.isSnoozed(t.id)) c.store.unsnooze(t.id) else onSub("snooze") }
                Item(Icons.Rounded.Star, c.store.data.ratings[t.id]?.let { "Rating: $it of 5" } ?: "Rate this song") { onSub("rate") }
                if ("preview" !in hm) Item(Icons.Rounded.PlayCircleOutline, "Preview", onPreview)
                stopItems.forEach { (label, act) -> Item(iconFor(label), label, act) }
                if ("tags" !in hm) Item(Icons.Rounded.Edit, "Edit tags", onTags)
                if ("tags" !in hm) Item(Icons.Rounded.Edit, "Fill tags from file name") { onSub("nametags") }
                if ("rename" !in hm) Item(Icons.Rounded.TextFields, "Rename file", onRename)
                if ("move" !in hm) Item(Icons.Rounded.DriveFileMove, "Move to a folder") { onSub("move") }
                if ("ringtone" !in hm) Item(Icons.Rounded.Notifications, "Set as ringtone") {
                    if (!Settings.System.canWrite(ctx)) {
                        Toast.makeText(ctx, "Allow Aurora to change system settings, then try again", Toast.LENGTH_LONG).show()
                        try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                    } else try {
                        android.media.RingtoneManager.setActualDefaultRingtoneUri(ctx, android.media.RingtoneManager.TYPE_RINGTONE, Uri.parse(t.uri))
                        Toast.makeText(ctx, "“${t.title}” is now your ringtone", Toast.LENGTH_LONG).show()
                    } catch (_: Exception) {
                        Toast.makeText(ctx, "Couldn't set this song as the ringtone", Toast.LENGTH_LONG).show()
                    }
                }
                if ("speed" !in hm) Item(Icons.Rounded.Speed, "Play speed and Pitch") { onSub("speed") }
                if ("delete" !in hm) Item(Icons.Rounded.Delete, "Delete permanently", onDelete)
            }
        }
    }

}

/** Dialogs opened from the menu (queue picker, move, speed). Kept separate because the menu dismisses itself on every tap. */
@Composable
fun SongMenuSubDialogs(c: PlayerController, t: Track, sub: String?, close: () -> Unit) {
    val actions = LocalActions.current
    when (sub) {
        "card" -> SongCardDialog(c, t, close)
        "clip" -> ClipTrimmerDialog(c, t, close)
        "nametags" -> NameTagsDialog(listOf(t), close) { p -> close(); actions.tagsFromNames(listOf(t), p) }
        "snooze" -> AlertDialog(
            onDismissRequest = close,
            title = { Text("Leave out of shuffle") },
            text = {
                Column {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    Text("The song stays in your library and plays when you pick it. Shuffle and Smart mixes skip it.", Modifier.padding(top = 6.dp), style = MaterialTheme.typography.bodySmall)
                    listOf(7 to "For 7 days", 30 to "For 30 days", 0 to "Until I bring it back").forEach { (days, label) ->
                        Text(label, Modifier.fillMaxWidth().clickable { c.store.snooze(t.id, days); close() }.padding(vertical = 12.dp), fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(close) { Text("Cancel") } },
        )
        "trim" -> {
            val dur = t.durationMs.coerceAtLeast(2000L)
            var s by remember { mutableStateOf((c.store.data.trimStart[t.id] ?: 0L).toFloat()) }
            var e by remember { mutableStateOf((c.store.data.trimEnd[t.id] ?: dur).toFloat()) }
            fun fmt(ms: Float) = "%d:%02d".format((ms / 60000).toInt(), ((ms / 1000).toInt()) % 60)
            AlertDialog(
                onDismissRequest = close,
                title = { Text("Trim start and end") },
                text = {
                    Column {
                        Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                        Text("Start at ${fmt(s)}", Modifier.padding(top = 10.dp))
                        Slider(s, { s = it.coerceAtMost(e - 1000f) }, valueRange = 0f..dur.toFloat())
                        Text("End at ${fmt(e)}")
                        Slider(e, { e = it.coerceAtLeast(s + 1000f) }, valueRange = 0f..dur.toFloat())
                        Text("Plays only this part of the song, every time. The file itself isn't changed.", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton({ c.setTrim(t.id, s.toLong(), if (e >= dur - 1000f) 0L else e.toLong()); close() }) { Text("Apply") } },
                dismissButton = { TextButton({ c.setTrim(t.id, 0L, 0L); close() }) { Text("Remove trim") } },
            )
        }
        "rate" -> AlertDialog(
            onDismissRequest = close,
            title = { Text("Rate this song") },
            text = {
                Column {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                    val cur = c.store.data.ratings[t.id] ?: 0
                    Row(Modifier.padding(top = 12.dp)) {
                        for (i in 1..5) Icon(
                            if (i <= cur) Icons.Rounded.Star else Icons.Rounded.StarBorder, "$i stars",
                            Modifier.size(44.dp).clip(CircleShape).clickable { c.store.setRating(t.id, i); close() }.padding(6.dp),
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    }
                }
            },
            confirmButton = { TextButton({ c.store.setRating(t.id, 0); close() }) { Text("Clear rating") } },
            dismissButton = { TextButton(close) { Text("Cancel") } },
        )
        "queue" -> AlertDialog(
            onDismissRequest = close,
            title = { Text("Add to a queue") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    c.store.data.queues.forEachIndexed { i, q ->
                        Text("${i + 1}. ${q.name}", Modifier.fillMaxWidth().clickable { c.addToOtherQueue(i, listOf(t)); close() }.padding(vertical = 12.dp))
                    }
                }
            },
            confirmButton = { TextButton(close) { Text("Cancel") } },
        )
        "move" -> NameDialog("Move to (e.g. Music/Rock)", "Music/", "Move", close) { n ->
            close()
            val clean = n.trim().trim('/')
            if (clean.isNotEmpty()) actions.moveTracks(listOf(t), "$clean/")
        }
        "speed" -> {
            var sp by remember { mutableStateOf(c.store.data.speeds[t.id] ?: 1f) }
            var pt by remember { mutableStateOf(c.store.data.pitches[t.id] ?: 1f) }
            AlertDialog(
                onDismissRequest = close,
                title = { Text("Play speed and Pitch") },
                text = {
                    Column {
                        Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                        Text("Speed  %.2fx".format(sp), Modifier.padding(top = 10.dp))
                        Slider(sp, { sp = (it * 20).toInt() / 20f }, valueRange = 0.5f..2f)
                        Text("Pitch  %.2fx".format(pt))
                        Slider(pt, { pt = (it * 20).toInt() / 20f }, valueRange = 0.5f..2f)
                        Text("Applies to this song only.", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton({ c.setSpeedPitchForTracks(listOf(t.id), sp, pt); close() }) { Text("Apply") } },
                dismissButton = { TextButton(close) { Text("Cancel") } },
            )
        }
    }
}
