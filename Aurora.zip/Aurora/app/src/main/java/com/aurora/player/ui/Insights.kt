package com.aurora.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurora.player.data.PlayEvent
import java.util.Calendar

/** Listening streak and a 24-hour "listening clock" built from the play log. */
@Composable
fun InsightsCard(events: List<PlayEvent>, modifier: Modifier = Modifier) {
    if (events.isEmpty()) return
    val stats = remember(events) {
        val cal = Calendar.getInstance()
        val hours = IntArray(24)
        for (e in events) {
            cal.timeInMillis = e.at
            hours[cal.get(Calendar.HOUR_OF_DAY)]++
        }
        // day numbers in the phone's time zone
        fun dayOf(t: Long) = (t + java.util.TimeZone.getDefault().getOffset(t)) / 86_400_000L
        val set = events.map { dayOf(it.at) }.toSortedSet()
        val today = dayOf(System.currentTimeMillis())
        var cur = 0
        var d = if (today in set) today else today - 1
        while (d in set) { cur++; d-- }
        var best = 0; var run = 0; var prev = Long.MIN_VALUE
        for (x in set) { run = if (x == prev + 1) run + 1 else 1; if (run > best) best = run; prev = x }
        Triple(cur, best, hours)
    }
    val (cur, best, hours) = stats
    val peak = hours.indices.maxByOrNull { hours[it] } ?: 0
    fun hr(h: Int) = when { h == 0 -> "12 am"; h < 12 -> "$h am"; h == 12 -> "12 pm"; else -> "${h - 12} pm" }
    Column(modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("$cur", if (cur == 1) "day streak" else "days streak")
            Stat("$best", "best streak")
            Stat(hr(peak), "favourite hour")
        }
        Text("Listening clock", Modifier.padding(top = 14.dp, bottom = 6.dp), fontWeight = FontWeight.SemiBold)
        val bar = MaterialTheme.colorScheme.primary
        val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
        Canvas(Modifier.fillMaxWidth().height(64.dp)) {
            val mx = (hours.maxOrNull() ?: 1).coerceAtLeast(1)
            val w = size.width / 24f
            for (h in 0 until 24) {
                val bh = size.height * (hours[h].toFloat() / mx).coerceAtLeast(0.04f)
                drawRoundRect(if (h == peak) bar else bar.copy(alpha = 0.45f).let { if (hours[h] == 0) dim else it }, Offset(h * w + w * 0.15f, size.height - bh), Size(w * 0.7f, bh), CornerRadius(w * 0.3f))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            listOf("12 am", "6 am", "12 pm", "6 pm", "12 am").forEach { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun Stat(big: String, small: String) {
    Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(big, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(small, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
