package com.aurora.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController

private class Hit(val key: String, val title: String, val sub: String, val art: Track?, val open: () -> Unit)

/** Search everything at once: artists, albums, playlists and songs. */
@Composable
fun SearchTab(c: PlayerController, push: (Route) -> Unit) {
    var q by remember { mutableStateOf("") }
    val d = c.store.data
    val words = remember(q) { normalizeForSearch(q).split(' ').filter { it.isNotEmpty() } }
    fun nameOk(name: String): Boolean { val n = normalizeForSearch(name); return words.all { it in n } }

    val songs = remember(c.library, q) { if (words.isEmpty()) emptyList() else c.library.filter { searchMatches(it, q) }.take(150) }
    val artists = remember(c.library, q, d.splitArtists, d.artistSeparators) {
        if (words.isEmpty()) emptyList() else {
            val m = LinkedHashMap<String, MutableList<Track>>()
            for (t in c.library) for (a in artistsOf(t, d.splitArtists, d.artistSeparators)) if (nameOk(a)) m.getOrPut(a) { ArrayList() }.add(t)
            m.entries.sortedByDescending { it.value.size }.take(6).map { e ->
                Hit("ar" + e.key, e.key, "${e.value.size} songs", e.value.first()) { push(Route.Detail("artist", e.key)) }
            }
        }
    }
    val albums = remember(c.library, q) {
        if (words.isEmpty()) emptyList() else c.library.filter { nameOk(it.album) }
            .groupBy { if (it.albumId > 0) it.albumId.toString() else it.album }.values.take(8).map { l ->
                val f = l.first()
                Hit("al" + f.albumId + f.album, f.album, "${f.artist} · ${l.size} songs", f) {
                    push(Route.Detail("album", if (f.albumId > 0) f.albumId.toString() else f.album))
                }
            }
    }
    val playlists = remember(d.playlists, q) {
        if (words.isEmpty()) emptyList() else d.playlists.filter { nameOk(it.name) }.map { p ->
            Hit("pl" + p.id, p.name, "${p.trackIds.size} songs", p.trackIds.firstNotNullOfOrNull { c.track(it) }) { push(Route.Detail("playlist", p.id)) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        SearchField(q, { q = it }, "Search songs, albums, artists, playlists…", Modifier.padding(top = 6.dp))
        if (words.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Type to search your whole library.\nEvery word you type must match.",
                    textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(32.dp),
                )
            }
        } else if (songs.isEmpty() && artists.isEmpty() && albums.isEmpty() && playlists.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No matches.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 140.dp)) {
                fun section(name: String, list: List<Hit>) {
                    if (list.isEmpty()) return
                    item(key = "h$name") { SectionTitle(name) }
                    items(list, key = { it.key }) { h -> ResultRow(h) }
                }
                section("Artists", artists)
                section("Albums", albums)
                section("Playlists", playlists)
                if (songs.isNotEmpty()) {
                    item(key = "hSongs") { SectionTitle("Songs") }
                    items(songs, key = { "s" + it.id }) { t ->
                        TrackRow(t, c) { c.playFromSource("Search", songs, songs.indexOf(t), false) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text, Modifier.padding(start = 20.dp, top = 14.dp, bottom = 4.dp),
        style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun ResultRow(h: Hit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = h.open).padding(horizontal = 16.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AlbumArt(h.art, Modifier.size(48.dp), RoundedCornerShape(10.dp), 22.dp)
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(h.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(h.sub, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
