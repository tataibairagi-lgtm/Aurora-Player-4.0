package com.aurora.player.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

@Serializable
data class Persisted(
    // Several small options are packed into one number each. The Android runtime cannot call a function with more than
    // 255 parameter slots, and this class had grown past that (it crashed at start-up). Read them as d.uiSquiggly, d.gestTap and so on;
    // change them with it.withUi(UI_X, on) and it.withGest(slot, value).
    val uiBits: Int = 0,
    val gest: Int = 6 or (1 shl 8) or (2 shl 12),
    val favourites: List<Long> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val queues: List<QueueData> = listOf(QueueData("Queue 1"), QueueData("Queue 2")),
    val activeQueue: Int = 0,
    val playCounts: Map<Long, Int> = emptyMap(),
    val lastPlayed: List<Long> = emptyList(),
    val ratings: Map<Long, Int> = emptyMap(),
    /** song id to the time (ms) until which it is left out of shuffle and mixes; Long.MAX_VALUE = until you bring it back */
    val snoozed: Map<Long, Long> = emptyMap(),
    val sleepFadeSec: Int = 5,
    val swipeArtVertical: Boolean = false,
    // what the cover does (action codes: see COVER_ACTIONS); 0 = nothing
    val splitGenres: Boolean = false,
    // PIN lock
    val pinHash: String = "",
    val pinSalt: String = "",
    val pinLen: Int = 4,
    val pinRelockSec: Int = 30,
    // saved themes and the day / night schedule
    val themePresets: List<ThemePreset> = emptyList(),
    val themeSchedule: Boolean = false,
    val dayTheme: String = "",
    val nightTheme: String = "",
    val dayStartHour: Int = 7,
    val nightStartHour: Int = 19,
    // playlist alarms and Bluetooth auto-play
    val alarms: List<AlarmItem> = emptyList(),
    val btRules: List<BtRule> = emptyList(),
    val genreSeparators: String = ";/,",
    val trimStart: Map<Long, Long> = emptyMap(), // per song: skip the first N ms
    val trimEnd: Map<Long, Long> = emptyMap(), // per song: end the song at N ms
    // audio
    val eqProfiles: Map<String, EqProfile> = emptyMap(),
    val customPresets: List<EqPreset> = emptyList(),
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val fadeSec: Int = 0,
    // ui
    val themeMode: Int = 0, // 0 system, 1 light, 2 dark
    val discArt: Boolean = true,
    val npSkin: Int = 0, // Now Playing layout: 0 default, 1 vinyl spin, 2 full-bleed poster, 3 typography, 4 classic utility
    val onlineLyrics: Boolean = true,
    // desktop lyrics
    val overlayTextSp: Int = 22,
    val overlayColor: Long = 0xFFFFFFFF,
    val lyricSize: Int = 1,
    val notifAdapt: Boolean = true,
    val notifAdaptStyle: Int = 1,  // 0 cover edge colour, 1 cover swatch colour (Musicolet-like)
    val lockAdapt: Boolean = true,
    val folderArt: Boolean = true,   // use folder.jpg / cover.jpg when a song has no embedded picture
    val keepOnNp: Boolean = false,   // keep the screen on while Now Playing is shown
    val lockAdaptStyle: Int = 0,   // 0 blurred cover, 1 cover swatch colour (Musicolet-like)
    val lyricsDim: Int = 40,       // darkening of the full-screen lock-screen lyrics
    val lockLyricSize: Int = 26,
    val lockLyricAlign: Int = 1,   // 0 left, 1 centre, 2 right
    val lockLyricBold: Boolean = true,
    val lockAlways: Boolean = true,
    val lockSkipPaused: Boolean = false, // do not show the lock-screen player when music has been paused for over a minute
    val notifUpcoming: Boolean = true,
    val notifArt: Boolean = true,
    val notifButtons: List<String> = listOf("fav", "overlay", "close"),
    val lyricAlign: Int = 0, // old setting, no longer used
    val lyricAlignC: Int = 1, // 0 left, 1 centre, 2 right
    val lyricColor: Long = 0, // 0 = default / theme colour for the current line and sung words
    val lyricDim: Int = 40, // opacity of the other lines, percent
    val lyricInactiveScale: Int = 85, // size of the other lines relative to the current one, percent
    val lyricAnchor: Int = 50, // where the current line sits in the lyrics area, percent from the top
    val lyricScrollMs: Int = 300, // scroll animation length
    val lyricBilingual: Boolean = false, // translation line smaller and dimmer under the lyric
    val lyricEstimate: Boolean = false, // guess word times for lines that have none
    val lyricWordDim: Int = 40, // opacity of words not yet sung, percent
    val lyricShowSong: Boolean = true, // song title row above the lyrics
    val lyricSerif: Boolean = false,
    val lyricScale: Int = 100, // percent
    val lyricBold: Boolean = true,
    val lyricBlur: Boolean = true,
    val lyricSmooth: Boolean = true, // animations; off = lighter on slow phones
    val lyricWordSync: Boolean = true,
    val lyricAccent: Boolean = false,
    val lyricOffsetMs: Int = 200, // lyrics appear this much early
    val lyricSpacing: Int = 100, // percent
    val overlayX: Int = 0,
    val overlayY: Int = 160,
    val overlayLocked: Boolean = false,
    val lyricMotion: Int = 0,
    val swipeRemove: Boolean = true,
    val shakeAction: Int = 0, // 0 off, 1 next song, 2 previous song, 3 play / pause
    val shakeStrength: Int = 1, // 0 light, 1 normal, 2 hard
    // motion
    val motionSpeed: Int = 2, // 0 off, 1 relaxed, 2 normal, 3 snappy
    val navStyle: Int = 0,
    val listAnim: Int = 1,
    val listStagger: Boolean = true,
    val pressMode: Int = 2,
    val artFade: Boolean = true,
    // lock screen player
    val lockScreenPlayer: Boolean = false,
    val lockShowLyrics: Boolean = true,
    // queue widget colours: 0 follow wallpaper, 1 light, 2 dark
    val queueTheme: Int = 4, // 4 = Musicolet style, 3 = adapt from album art
    val shareSongs: Int = 10, val shareArtists: Int = 3, val sharePal: Int = 0, // Most played share picture
    val addedDays: Int = 30, // "Recently added" period in days (0 = all time)
    val playedDays: Int = 7, // "Recently played" period in days (0 = all time)
    val customDays: Int = 0, // the user's own extra period chip
    val customNotif: Boolean = true, // Musicolet-style notification layout (off = Android's standard media notification)
    val widgetsLive: Boolean = true, // redraw home-screen widgets while music plays
    val qsTileLive: Boolean = true, // keep the Quick Settings tile in sync while music plays
    val fastLyrics: Boolean = true, // update synced lyrics about 25 times a second (off = 8 times, lighter)
    val safeNote: Boolean = false, // Aurora switched heavy features off after the app stopped while playing
    val soundEngine: Boolean = true, // Aurora's own equalizer / mono / balance engine in the audio chain
    val wAlpha: Int = 30, // widget transparency, percent
    val wqArt: Boolean = true, val wqFav: Boolean = true, val wqFfRew: Boolean = false, val wqOverlay: Boolean = true,
    val wsArt: Boolean = true, val wsFav: Boolean = true, val wsProg: Boolean = true,
    val waArt: Boolean = true, val waFav: Boolean = true, val waProg: Boolean = true, val waModes: Boolean = true, val waNext: Boolean = true,
    // backup (device specific: never restored from a backup)
    val backupFolder: String = "",
    val autoBackup: Boolean = false,
    val autoBackupDays: Int = 1,
    val autoCsv: Boolean = false,           // export most played songs/artists to .csv at the end of each week, month and year
    val csvDone: List<String> = emptyList(), // periods already exported
    val autoBackupKeep: Int = 5,
    val lastBackupAt: Long = 0,
    // library tabs (ids in display order; hidden ones are skipped)
    val tabOrder: List<String> = listOf("queues", "now", "albums", "artists", "playlists", "folders", "genres", "tracks"),
    val hiddenTabs: List<String> = listOf("genres", "tracks"),
    val hideNp: List<String> = emptyList(), // Now Playing buttons the user switched off
    val tabsBottom: Boolean = false,
    // now playing background: 0 album colour, 1 blurred album art, 2 aurora gradient, 3 plain, 4 black, 5 custom image
    val nowBg: Int = 0,
    val nowBgDim: Int = 35, // 0..80 % darkening for image backgrounds
    val customBgUri: String = "",
    // appearance (themeMode 3 = black / AMOLED)
    val accentColor: Long = 0xFF007CC3, // 0 = default / system colours
    val keepScreenOn: Boolean = false,
    // library
    val minDurationSec: Int = 30,
    val excludedFolders: List<String> = emptyList(),
    // playback
    val pauseOnUnplug: Boolean = true,
    val handleAudioFocus: Boolean = true,
    val prevRestarts: Boolean = true,
    val tapPlaysList: Boolean = true,
    val skipSilence: Boolean = false,
    val fadeInMs: Int = 0,
    val fadeOutMs: Int = 0,
    val pauseOnMute: Boolean = true,
    val resumeOnUnmute: Boolean = true,
    val blockPlayMuted: Boolean = false,
    val resumeOnBt: Boolean = false,
    val resumeOnWired: Boolean = false,
    val resumeOnlyIfPaused: Boolean = true,
    // advanced
    val stopOnTaskRemoved: Boolean = false,
    val showFileNames: Boolean = false,
    val hideWebInfo: Boolean = false, // remove website names and other junk from song tags
    val rememberPositions: Boolean = false,
    val rememberMinMin: Int = 2,
    val askToResume: Boolean = false,
    val positions: Map<Long, Long> = emptyMap(),
    val minPlaySec: Int = 15,
    val prevRestartPct: Int = 0, // previous restarts the song once this % has played (0 = after 3 seconds)
    val playCountPct: Int = 0, // > 0: a play counts after this percentage of the song instead of a fixed time
    val autoPlayOnStart: Boolean = false,
    val loadArt: Boolean = true,
    val ffSec: Int = 10,
    val rewindSec: Int = 10,
    val ignoreWords: Boolean = false,
    val confirmExit: Boolean = false,
    val backMode: Int = 0,
    // lyrics: preferred source "saved" | "embedded" | "file"; per-song override ("embedded"/"file"/"saved"/"online")
    val lyricsPreferred: String = "saved",
    val lyricsSource: Map<Long, String> = emptyMap(),
    // audio focus: 1 ignore everything .. 5 pause for everything
    val focusLevel: Int = 3,
    val resumeAfterCall: Boolean = true,
    // queues
    val sourceQueues: Boolean = true, // playing an album/playlist/folder... opens a queue named after it
    val queueMerge: Boolean = false, // if that queue already exists: false = replace, true = merge
    // lock screen
    val lockSwipeRight: Boolean = true,
    // sound
    val crossfadeSec: Int = 0,
    val replayGain: Boolean = false,
    val perSongSpeed: Boolean = false,
    val speeds: Map<Long, Float> = emptyMap(),
    // library
    val splitArtists: Boolean = false,
    val artistSeparators: String = ",;/&",
    val foldersTree: Boolean = true,
    val showSeekButtons: Boolean = true,
    val idleStopMin: Int = 0,
    val shuffleBelowOnly: Boolean = true,
    val randomizeBelowOnly: Boolean = true,
    val albumCols: Int = 3,
    val albumInfo: Int = 0,
    val artistExtra: Boolean = false,
    val nextPrevSeek: Boolean = false,
    val preventAutoplay: Boolean = false,
    val showElapsed: Boolean = false,
    val unplayedDays: Int = 7,
    val eqSameForAll: Boolean = false,
    val seekKnobOnly: Boolean = false,
    // opt-in "expressive" looks, all off by default
    val uiFont: Int = 0,
    val welcomeSeen: Boolean = false,
    /** full-screen lock-screen lyrics: line by line with the lyric animation of the lock player (true) or one scrolling list (false) */
    val lockLyricsLines: Boolean = true,
    /** how soft the blurred cover is, 0 (sharp) .. 100 (very soft); used on Now playing and the lock screen */
    val blurPct: Int = 50,
    val uiWaveform: Boolean = false,
    val uiVisualizer: Boolean = false,
    val autoEqOn: Boolean = false,
    val autoEq: List<AutoEqRule> = emptyList(),
    /** song id to estimated tempo (beats per minute) and energy (0..100), filled by Settings > Song library > Analyse tempo */
    val bpm: Map<Long, Int> = emptyMap(),
    val energy: Map<Long, Int> = emptyMap(),
    val albumMergeByName: Boolean = true,
    val earDouble: Int = 0,
    val earTriple: Int = 1,
    val externalControl: Boolean = true,
    val smartShuffle: Boolean = false,
    val alphaNum: Boolean = false,
    val hiddenMenu: List<String> = emptyList(),
    val hiddenSmart: List<String> = emptyList(),
    val mixExcludeFolders: List<String> = emptyList(), val mixExcludePlaylists: List<String> = emptyList(), val mixSize: Int = 40, val mixArtists: Int = 40,
    val playlistCounts: Boolean = true,
    val genreExtra: Boolean = false,
    val folderPath: Boolean = true,
    val tabSort: Map<String, Int> = emptyMap(),
    val tabSortRev: Map<String, Boolean> = emptyMap(),
    val pitches: Map<Long, Float> = emptyMap(),
    val reverbPreset: Int = 0,   // 0 off, 1 small room, 2 medium room, 3 large hall, 4 plate
    val reverbLevel: Int = 50,   // how much of the sound goes into the reverb, percent
    val mono: Boolean = false,
    val balance: Int = 0,
    val songEnd: Int = 2,        // 0 stop there, 1 load next and pause, 2 play next, 3 repeat the song
    val queueEnd: Int = 0,       // 0 stop, 1 jump to next queue, 2 repeat the queue
    val reshuffleOnEnd: Boolean = true,
    // bookmarks & audio notes
    val bookmarks: List<Bookmark> = emptyList(),
) {
    val uiSquiggly: Boolean get() = (uiBits and UI_SQUIGGLY) != 0
    val uiMorphPlay: Boolean get() = (uiBits and UI_MORPH) != 0
    val uiSpecPill: Boolean get() = (uiBits and UI_SPEC) != 0
    val uiMarquee: Boolean get() = (uiBits and UI_MARQUEE) != 0
    val uiAmoled: Boolean get() = (uiBits and UI_AMOLED) != 0
    val uiCarousel: Boolean get() = (uiBits and UI_CAROUSEL) != 0
    val uiMiniExpand: Boolean get() = (uiBits and UI_MINI) != 0
    val uiPillNav: Boolean get() = true // the floating tab pill is the only tab bar now
    val uiQueueChips: Boolean get() = (uiBits and UI_QCHIPS) != 0
    val uiFastScroll: Boolean get() = (uiBits and UI_FASTSCROLL) != 0
    val uiCollapseHeader: Boolean get() = (uiBits and UI_COLLAPSE) != 0
    val uiGridSwitch: Boolean get() = (uiBits and UI_GRID) != 0
    val uiMiniHide: Boolean get() = (uiBits and UI_MINI_HIDE) != 0
    val uiPillSwipe: Boolean get() = (uiBits and UI_PILL_SWIPE) != 0
    val uiSleepFinish: Boolean get() = (uiBits and UI_SLEEP_FINISH) != 0
    val uiNpBgEdge: Boolean get() = (uiBits and UI_NPBG_EDGE) != 0
    val uiPillAutoHide: Boolean get() = (uiBits and UI_PILL_AUTOHIDE) != 0
    val uiWaveThin: Boolean get() = (uiBits and UI_WAVE_THIN) != 0
    val uiVisMirror: Boolean get() = (uiBits and UI_VIS_MIRROR) != 0
    val uiVisTall: Boolean get() = (uiBits and UI_VIS_TALL) != 0
    val gestTap: Int get() = gest and 15
    val gestDouble: Int get() = (gest shr 4) and 15
    val gestLeft: Int get() = (gest shr 8) and 15
    val gestRight: Int get() = (gest shr 12) and 15
    val gestUp: Int get() = (gest shr 16) and 15
    val gestDown: Int get() = (gest shr 20) and 15

    fun withUi(bit: Int, on: Boolean): Persisted = copy(uiBits = if (on) uiBits or bit else uiBits and bit.inv())
    /** slot: 0 tap, 1 double tap, 2 left, 3 right, 4 up, 5 down */
    fun withGest(slot: Int, v: Int): Persisted = copy(gest = (gest and (15 shl (slot * 4)).inv()) or ((v and 15) shl (slot * 4)))
}

const val UI_SQUIGGLY = 1
const val UI_MORPH = 2
const val UI_SPEC = 4
const val UI_MARQUEE = 8
const val UI_AMOLED = 16
const val UI_CAROUSEL = 32
const val UI_MINI = 64
const val UI_PILL = 128
const val UI_QCHIPS = 256
const val UI_FASTSCROLL = 512
const val UI_COLLAPSE = 1024
const val UI_GRID = 2048
const val UI_WAVE_THIN = 4096
const val UI_PILL_AUTOHIDE = 32768
const val UI_NPBG_EDGE = 65536
const val UI_SLEEP_FINISH = 131072
const val UI_PILL_SWIPE = 262144
const val UI_MINI_HIDE = 524288
const val UI_VIS_MIRROR = 8192
const val UI_VIS_TALL = 16384

/** All persisted app state. Backed by SharedPreferences (JSON) and exposed as Compose state. */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("aurora", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    var data by mutableStateOf(load())
        private set

    private fun load(): Persisted = try {
        prefs.getString("d", null)?.let {
            val p = json.decodeFromString<Persisted>(it)
            // one-time: widgets that were on "Match with system" move to the new Musicolet-style look
            var q = p
            if (!prefs.getBoolean("wt4", false)) {
                prefs.edit().putBoolean("wt4", true).apply()
                if (q.queueTheme == 0) q = q.copy(queueTheme = 4)
            }
            // one-time: albums with the same name are merged by default now
            if (!prefs.getBoolean("am1", false)) {
                prefs.edit().putBoolean("am1", true).apply()
                q = q.copy(albumMergeByName = true)
            }
            // one-time: percentages saved by the old sliders (38, 84, 57...) are tidied to the nearest 5
            if (!prefs.getBoolean("pct5", false)) {
                prefs.edit().putBoolean("pct5", true).apply()
                fun r5(v: Int) = ((v + 2) / 5) * 5
                q = q.copy(
                    lyricDim = r5(q.lyricDim), lyricInactiveScale = r5(q.lyricInactiveScale), lyricAnchor = r5(q.lyricAnchor),
                    lyricWordDim = r5(q.lyricWordDim), lyricScale = r5(q.lyricScale), lyricSpacing = r5(q.lyricSpacing),
                    lyricsDim = r5(q.lyricsDim), nowBgDim = r5(q.nowBgDim),
                )
            }
            q
        } ?: Persisted()
    } catch (e: Exception) {
        Persisted()
    }

    init { com.aurora.player.ui.Motion.sync(data); com.aurora.player.ui.SortPrefs.natural = data.alphaNum; com.aurora.player.data.AlbumIndex.mergeByName = data.albumMergeByName; com.aurora.player.data.WebClean.on = data.hideWebInfo }

    fun update(f: (Persisted) -> Persisted) {
        data = f(data)
        com.aurora.player.ui.Motion.sync(data); com.aurora.player.ui.SortPrefs.natural = data.alphaNum; com.aurora.player.data.AlbumIndex.mergeByName = data.albumMergeByName; com.aurora.player.data.WebClean.on = data.hideWebInfo
        scheduleWrite()
    }

    // Serialising everything on the main thread (every 5 s while playing, every toggle) caused hitches: write on a worker, coalescing bursts.
    private val writer = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val writePending = java.util.concurrent.atomic.AtomicBoolean(false)
    private fun scheduleWrite() {
        if (!writePending.compareAndSet(false, true)) return
        writer.execute {
            writePending.set(false)
            try { prefs.edit().putString("d", json.encodeToString(data)).commit() } catch (_: Throwable) {}
        }
    }

    // ratings (1..5 stars, 0 clears)
    fun setRating(id: Long, stars: Int) = update {
        it.copy(ratings = if (stars <= 0) it.ratings - id else it.ratings + (id to stars.coerceAtMost(5)))
    }

    // snooze / hide from shuffle
    fun isSnoozed(id: Long): Boolean = (data.snoozed[id] ?: 0L) > System.currentTimeMillis()
    fun snooze(id: Long, days: Int) = update {
        it.copy(snoozed = it.snoozed + (id to (if (days <= 0) Long.MAX_VALUE else System.currentTimeMillis() + days * 86_400_000L)))
    }
    fun unsnooze(id: Long) = update { it.copy(snoozed = it.snoozed - id) }

    // favourites
    fun isFavourite(id: Long) = id in data.favourites
    fun toggleFavourite(id: Long) = update {
        it.copy(favourites = if (id in it.favourites) it.favourites - id else it.favourites + id)
    }

    // playlists
    fun createPlaylist(name: String, ids: List<Long> = emptyList()): String {
        val id = UUID.randomUUID().toString()
        update { it.copy(playlists = it.playlists + Playlist(id, name.trim().ifEmpty { "Playlist" }, ids)) }
        return id
    }

    fun renamePlaylist(id: String, name: String) = update { p ->
        p.copy(playlists = p.playlists.map { if (it.id == id) it.copy(name = name.trim().ifEmpty { it.name }) else it })
    }

    fun deletePlaylist(id: String) = update { p -> p.copy(playlists = p.playlists.filter { it.id != id }) }

    fun addToPlaylist(id: String, ids: List<Long>) = update { p ->
        p.copy(playlists = p.playlists.map {
            if (it.id == id) it.copy(trackIds = it.trackIds + ids.filter { n -> n !in it.trackIds }) else it
        })
    }

    fun removeFromPlaylist(id: String, trackId: Long) = update { p ->
        p.copy(playlists = p.playlists.map {
            if (it.id == id) it.copy(trackIds = it.trackIds - trackId) else it
        })
    }

    fun recordPlay(id: Long) = update {
        it.copy(
            playCounts = it.playCounts + (id to ((it.playCounts[id] ?: 0) + 1)),
            lastPlayed = (listOf(id) + it.lastPlayed.filter { x -> x != id }).take(100),
        )
    }
}
