package com.aurora.player.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore

object MediaScanner {
    fun hasAudioPermission(ctx: Context): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_AUDIO
        else android.Manifest.permission.READ_EXTERNAL_STORAGE
        return androidx.core.content.ContextCompat.checkSelfPermission(ctx, p) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    /** audio id -> genre name (empty map if the device doesn't expose genres). */
    private fun genreMap(ctx: Context): Map<Long, String> {
        val out = HashMap<Long, String>()
        try {
            val g = MediaStore.Audio.Genres.EXTERNAL_CONTENT_URI
            ctx.contentResolver.query(g, arrayOf(MediaStore.Audio.Genres._ID, MediaStore.Audio.Genres.NAME), null, null, null)?.use { gc ->
                while (gc.moveToNext()) {
                    val gid = gc.getLong(0)
                    val name = gc.getString(1)?.trim().orEmpty()
                    if (name.isEmpty() || name == "<unknown>") continue
                    val m = MediaStore.Audio.Genres.Members.getContentUri("external", gid)
                    ctx.contentResolver.query(m, arrayOf(MediaStore.Audio.Genres.Members.AUDIO_ID), null, null, null)?.use { mc ->
                        while (mc.moveToNext()) out[mc.getLong(0)] = name
                    }
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun scan(ctx: Context, minDurationSec: Int = 30): List<Track> {
        val genres = genreMap(ctx)
        val out = ArrayList<Track>()
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

        val hasAlbumArtist = android.os.Build.VERSION.SDK_INT >= 30
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.SIZE,
            "composer",
        ) + (if (hasAlbumArtist) arrayOf("album_artist") else emptyArray())
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= ${minDurationSec * 1000L}"
        val cursor = ctx.contentResolver.query(
            collection, proj, sel, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        ) ?: return out
        cursor.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            val iYear = c.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
            val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val iComposer = c.getColumnIndex("composer")
            val iAlbumArtist = c.getColumnIndex("album_artist")
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                fun clean(s: String?, fallback: String) =
                    if (s.isNullOrBlank() || s == "<unknown>") fallback else s
                out += Track(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id).toString(),
                    title = clean(c.getString(iTitle), "Unknown title"),
                    artist = clean(c.getString(iArtist), "Unknown artist"),
                    album = clean(c.getString(iAlbum), "Unknown album"),
                    albumId = c.getLong(iAlbumId),
                    durationMs = c.getLong(iDur),
                    path = c.getString(iData) ?: "",
                    dateAdded = c.getLong(iAdded),
                    trackNo = c.getInt(iTrack) % 1000,
                    genre = genres[id] ?: "",
                    year = c.getInt(iYear),
                    size = c.getLong(iSize),
                    composer = if (iComposer >= 0) clean(c.getString(iComposer), "") else "",
                    albumArtist = if (iAlbumArtist >= 0) clean(c.getString(iAlbumArtist), "") else "",
                )
            }
        }
        return out
    }
}
