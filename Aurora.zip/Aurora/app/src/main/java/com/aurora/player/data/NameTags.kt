package com.aurora.player.data

/** Fills tags from a file name. A pattern uses %artist, %title, %album, %track and %year, for example "%artist - %title". */
object NameTags {
    val PATTERNS = listOf("%artist - %title", "%track - %title", "%track %title", "%title - %artist", "%artist - %album - %title", "%title")

    private val token = Regex("%(artist|title|album|track|year)")

    /** Tags found in [fileName] (with or without extension), or null when the name does not fit the pattern. */
    fun parse(fileName: String, pattern: String): TagData? {
        val base = fileName.substringAfterLast('/').let { if (it.length - it.lastIndexOf('.') in 2..5 && it.contains('.')) it.substringBeforeLast('.') else it }
            .replace('_', ' ').trim()
        if (pattern.isBlank()) return null
        val names = ArrayList<String>()
        val rx = StringBuilder("^")
        var last = 0
        for (m in token.findAll(pattern)) {
            rx.append(Regex.escape(pattern.substring(last, m.range.first)))
            val n = m.groupValues[1]
            names += n
            rx.append(if (n == "track" || n == "year") "(\\d+)" else "(.+?)")
            last = m.range.last + 1
        }
        rx.append(Regex.escape(pattern.substring(last))).append("$")
        if (names.isEmpty()) return null
        val m = Regex(rx.toString()).find(base) ?: return null
        val v = names.indices.associate { names[it] to m.groupValues[it + 1].trim() }
        if (v.values.any { it.isEmpty() }) return null
        return TagData(title = v["title"].orEmpty(), artist = v["artist"].orEmpty(), album = v["album"].orEmpty(), track = v["track"].orEmpty(), year = v["year"].orEmpty())
    }
}
