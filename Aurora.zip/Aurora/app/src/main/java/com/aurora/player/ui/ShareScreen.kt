package com.aurora.player.ui

import android.graphics.Bitmap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun listenedText(ms: Long): String {
    val h = ms / 3_600_000L
    return if (h >= 1) "$h ${if (h == 1L) "hour" else "hours"}+" else "${ms / 60_000L} minutes+"
}

/**
 * Full-screen preview of the Most played pictures, like Musicolet: swipe between the songs and artists pictures,
 * choose how many songs / artists to show, pick a colour scheme, then save or share the picture on screen.
 */
@Composable
fun ShareScreen(
    c: PlayerController,
    songs: List<Pair<Track, Int>>,
    artists: List<Pair<String, Int>>,
    artistTotal: Int,
    period: String,
    listenedMs: Long,
    startPage: Int,
    onClose: () -> Unit,
) {
    val ctx = LocalContext.current
    val actions = LocalActions.current
    val scope = rememberCoroutineScope()
    val d = c.store.data
    val nSongs = d.shareSongs
    val nArt = d.shareArtists
    val palIdx = d.sharePal.coerceIn(0, SHARE_PALETTES.lastIndex)
    val pal = SHARE_PALETTES[palIdx]
    var pages by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var countMenu by remember { mutableStateOf(false) }
    var palDialog by remember { mutableStateOf(false) }
    val pager = rememberPagerState(initialPage = startPage.coerceIn(0, 1)) { 2 }
    val button = Color(0xFF1F1F1F)
    val teal = Color(0xFF9CC5BA)

    LaunchedEffect(nSongs, nArt, palIdx, songs, artists) {
        pages = withContext(Dispatchers.Default) {
            val rows = songs.take(nSongs).map { (t, n) -> SongRow(t.title, t.artist, n, ArtLoader.load(ctx, t, 128)) }
            val chips = artists.take(nArt).map { (name, n) -> "${Math.round(n * 100f / artistTotal.coerceAtLeast(1))}% $name" }
            val aRows = artists.take(10).map { (name, n) ->
                val f = n.toFloat() / artistTotal.coerceAtLeast(1)
                val p = f * 100
                ArtistRow(name, (if (p % 1f < 0.05f || p % 1f > 0.95f) "%d%%".format(Math.round(p)) else "%.1f%%".format(p)), f)
            }
            try { ShareCard.logoBmp = android.graphics.BitmapFactory.decodeResource(ctx.resources, com.aurora.player.R.drawable.ic_qs_tile) } catch (_: Throwable) {}
            val listened = listenedText(listenedMs)
            listOf(
                ShareCard.songs(rows, period, listened, chips, pal),
                ShareCard.artists(aRows, period, listened, pal),
            )
        }
    }

    fun act(save: Boolean) {
        val bmp = pages.getOrNull(pager.currentPage) ?: return
        val name = (if (pager.currentPage == 0) "Most played songs " else "Most played artists ") + period
        scope.launch {
            val uri = withContext(Dispatchers.IO) { ShareCard.save(ctx, bmp, name) }
            if (uri == null) Toast.makeText(ctx, "Couldn't save the picture", Toast.LENGTH_LONG).show()
            else if (save) Toast.makeText(ctx, "Saved to Pictures/Aurora", Toast.LENGTH_LONG).show()
            else ShareCard.share(ctx, uri)
        }
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        var shown by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { shown = true }
        // make the dialog window really full screen: under the status bar, the navigation bar and the camera cut-out
        val dialogView = androidx.compose.ui.platform.LocalView.current
        androidx.compose.runtime.SideEffect {
            try {
                val w = (dialogView.parent as? androidx.compose.ui.window.DialogWindowProvider)?.window
                if (w != null) {
                    w.setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT)
                    w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
                    androidx.core.view.WindowCompat.setDecorFitsSystemWindows(w, false)
                    w.statusBarColor = android.graphics.Color.TRANSPARENT
                    w.navigationBarColor = android.graphics.Color.TRANSPARENT
                    if (android.os.Build.VERSION.SDK_INT >= 28) w.attributes = w.attributes.also {
                        it.layoutInDisplayCutoutMode = if (android.os.Build.VERSION.SDK_INT >= 30) android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                        else android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
            } catch (_: Throwable) {}
        }
        val scrim by androidx.compose.animation.core.animateFloatAsState(if (shown) 0.72f else 0f, androidx.compose.animation.core.tween(300), label = "scrim")
        Box(
            Modifier.fillMaxSize().background(Color.Black.copy(alpha = scrim))
                .clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null, onClick = onClose)
                ,
            contentAlignment = Alignment.Center,
        ) {
        androidx.compose.animation.AnimatedVisibility(
            shown,
            enter = androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(380, easing = androidx.compose.animation.core.FastOutSlowInEasing), initialScale = 0.86f) +
                androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(300)) +
                androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(380, easing = androidx.compose.animation.core.FastOutSlowInEasing)) { it / 10 },
        ) {
        Column(
            Modifier.fillMaxSize()
                .background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(pal.fg).copy(alpha = 0.16f).compositeOver(Color(0xFF111111)), Color(0xFF0C0C0C))))
                .systemBarsPadding()
                .clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null) {},
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Share your top songs", Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1)
                Box(Modifier.size(44.dp).clip(CircleShape).background(button).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Close, null, tint = Color.White)
                }
                Box {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(button).clickable { countMenu = true }, contentAlignment = Alignment.Center) {
                        Text(nSongs.toString(), color = Color.White, fontSize = 18.sp)
                    }
                    DropdownMenu(countMenu, { countMenu = false }) {
                        listOf(5, 10).forEach { n ->
                            DropdownMenuItem(
                                text = { Text("$n songs") },
                                trailingIcon = { RadioButton(nSongs == n, null) },
                                onClick = { c.store.update { it.copy(shareSongs = n) } },
                            )
                        }
                        HorizontalDivider()
                        (0..5).forEach { n ->
                            DropdownMenuItem(
                                text = { Text(if (n == 1) "1 artist" else "$n artists") },
                                trailingIcon = { RadioButton(nArt == n, null) },
                                onClick = { c.store.update { it.copy(shareArtists = n) } },
                            )
                        }
                    }
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(button).clickable { palDialog = true }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Palette, null, tint = Color.White)
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (pages.size == 2) {
                    HorizontalPager(pager, Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 36.dp, vertical = 6.dp), pageSpacing = 16.dp) { i ->
                        // the card is drawn at its own shape and the shadow hugs it, so no dark box shows around it
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            val bmp = pages[i]
                            Image(
                                bmp.asImageBitmap(), null,
                                Modifier.aspectRatio(bmp.width.toFloat() / bmp.height.toFloat()).shadow(10.dp, RoundedCornerShape(20.dp)).clip(RoundedCornerShape(20.dp)),
                                contentScale = ContentScale.Fit, alignment = Alignment.Center,
                            )
                        }
                    }
                }
            }

            Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                repeat(2) { i ->
                    Box(
                        Modifier.height(6.dp).width(if (pager.currentPage == i) 16.dp else 6.dp).clip(CircleShape)
                            .background(if (pager.currentPage == i) teal else Color(0xFF555555)),
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(true to "Save", false to "Share").forEach { (save, label) ->
                    Row(
                        Modifier.weight(1f).clip(RoundedCornerShape(26.dp))
                            .background(if (save) teal else button).clickable { act(save) }.padding(vertical = 15.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center,
                    ) {
                        Icon(if (save) Icons.Rounded.Save else Icons.Rounded.Share, null, tint = if (save) Color(0xFF0C1F1A) else teal)
                        Text(label, Modifier.padding(start = 10.dp), color = if (save) Color(0xFF0C1F1A) else teal, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    }
                }
            }
            Row(Modifier.padding(top = 8.dp, bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    Modifier.clip(RoundedCornerShape(20.dp)).clickable {
                        val list = songs.take(100).map { it.first }
                        val file = ("Most played " + period).replace(Regex("[^A-Za-z0-9 _.-]"), "-") + ".m3u8"
                        if (list.isEmpty()) Toast.makeText(ctx, "No songs to save", Toast.LENGTH_SHORT).show()
                        else actions.saveText(file, "audio/x-mpegurl", queueM3u8(list))
                    }.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.AutoMirrored.Rounded.PlaylistAdd, null, tint = teal, modifier = Modifier.size(20.dp))
                    Text("Save as .m3u8", Modifier.padding(start = 6.dp), color = teal, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                }
                Row(
                    Modifier.clip(RoundedCornerShape(20.dp)).clickable {
                        // the same list as plain text, handy for chats
                        val text = buildString {
                            append("My most played songs on Aurora (").append(period).append(")\n")
                            songs.take(nSongs).forEachIndexed { i, (t, n) -> append(i + 1).append(". ").append(t.title).append(" - ").append(t.artist).append("  (").append(n).append("x)\n") }
                        }
                        val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/plain").putExtra(android.content.Intent.EXTRA_TEXT, text)
                        try { ctx.startActivity(android.content.Intent.createChooser(send, "Share as text").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
                    }.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Share, null, tint = teal, modifier = Modifier.size(18.dp))
                    Text("Share as text", Modifier.padding(start = 6.dp), color = teal, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                }
            }
        }
        }
        }

        if (palDialog) Dialog(onDismissRequest = { palDialog = false }) {
            Column(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF232323)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SHARE_PALETTES.chunked(6).forEachIndexed { r, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEachIndexed { j, p ->
                            val idx = r * 6 + j
                            Box(
                                Modifier.size(46.dp).clip(CircleShape).background(Color(p.bg)).clickable {
                                    c.store.update { it.copy(sharePal = idx) }; palDialog = false
                                },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(if (idx == palIdx) Icons.Rounded.Check else Icons.Rounded.Palette, null, tint = Color(p.fg), modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
