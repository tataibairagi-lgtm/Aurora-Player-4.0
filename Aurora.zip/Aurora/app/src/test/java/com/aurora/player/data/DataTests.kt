package com.aurora.player.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LrcParserTest {
    @Test fun parsesTimedLines() {
        val l = LrcParser.parse("[00:12.50]Hello\n[00:20.00]World")!!
        assertTrue(l.synced)
        assertEquals(2, l.lines.size)
        assertEquals(12_500L, l.lines[0].timeMs)
        assertEquals("World", l.lines[1].text)
    }

    @Test fun plainTextIsNotSynced() {
        val l = LrcParser.parse("just words\nmore words")!!
        assertTrue(!l.synced)
        assertEquals(2, l.lines.size)
    }

    @Test fun repeatedTimestampBecomesTranslation() {
        val l = LrcParser.parse("[00:05.00]Hello\n[00:05.00]Bonjour\n[00:09.00]Bye")!!
        assertEquals(2, l.lines.size)
        assertEquals("Hello", l.lines[0].text)
        assertEquals("Bonjour", l.lines[0].sub)
    }

    @Test fun enhancedLrcGivesWordTimes() {
        val l = LrcParser.parse("[00:01.00]<00:01.00>one <00:01.50>two")!!
        val w = l.lines[0].words!!
        assertEquals(2, w.size)
        assertEquals(1500L, w[1].timeMs)
    }

    @Test fun indexAtFindsCurrentLine() {
        val l = LrcParser.parse("[00:01.00]a\n[00:05.00]b\n[00:09.00]c")!!
        assertEquals(-1, l.indexAt(500))
        assertEquals(1, l.indexAt(6000))
        assertEquals(2, l.indexAt(60000))
    }

    @Test fun emptyTextGivesNull() = assertNull(LrcParser.parse("   \n"))
}

class PlaylistIoTest {
    @Test fun readsM3uAndSkipsComments() {
        val p = PlaylistIo.parse("#EXTM3U\n#EXTINF:1,x\n/music/a.mp3\n\n/music/b.mp3\n")
        assertEquals(listOf("/music/a.mp3", "/music/b.mp3"), p)
    }

    @Test fun readsPls() {
        val p = PlaylistIo.parse("[playlist]\nFile1=/m/a.mp3\nTitle1=A\nNumberOfEntries=1\nVersion=2")
        assertEquals(listOf("/m/a.mp3"), p)
    }
}

class NameTagsTest {
    @Test fun artistDashTitle() {
        val t = NameTags.parse("Daft Punk - One More Time.mp3", "%artist - %title")!!
        assertEquals("Daft Punk", t.artist)
        assertEquals("One More Time", t.title)
    }

    @Test fun trackNumberAndTitle() {
        val t = NameTags.parse("/sdcard/Music/07 - Hello_World.flac", "%track - %title")!!
        assertEquals("07", t.track)
        assertEquals("Hello World", t.title)
    }

    @Test fun nonMatchingNameGivesNull() = assertNull(NameTags.parse("justatitle.mp3", "%artist - %title"))

    @Test fun threeParts() {
        val t = NameTags.parse("A - B - C.m4a", "%artist - %album - %title")
        assertNotNull(t)
        assertEquals("C", t!!.title)
    }
}

class FormatTest {
    @Test fun formatsTimes() {
        assertEquals("1:05", formatTime(65_000))
        assertEquals("0:00", formatTime(-5))
    }

    @Test fun estimatedWordsAreInOrder() {
        val w = estimateWords(LyricLine(1000, "one two three four"), 5000)
        assertEquals(4, w.size)
        assertTrue(w.zipWithNext().all { (a, b) -> a.timeMs <= b.timeMs })
    }
}
