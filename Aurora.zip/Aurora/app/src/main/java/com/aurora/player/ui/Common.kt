package com.aurora.player.ui

import android.content.Context
import android.graphics.Bitmap
import java.io.File
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Spring "press" animation used by every tappable thing in the app. */
fun Modifier.bounceClick(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val target = when (Motion.press) { 0 -> 1f; 1 -> 0.94f; 3 -> 0.78f; else -> 0.86f }
    val s by animateFloatAsState(
        if (pressed) target else 1f,
        if (Motion.scale == 0f) androidx.compose.animation.core.snap()
        else spring(dampingRatio = if (Motion.press == 3) Spring.DampingRatioHighBouncy else Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium * (1f / Motion.scale)),
        label = "bounce",
    )
    this
        .graphicsLayer { scaleX = s; scaleY = s }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

object ArtLoader {
    private val cache = object : LruCache<Long, Bitmap>((Runtime.getRuntime().maxMemory() / 6).toInt().coerceIn(24 shl 20, 96 shl 20)) {
        override fun sizeOf(key: Long, value: Bitmap) = value.byteCount
    }
    private val missing = HashSet<Long>()
    @Volatile var enabled = true
    @Volatile var folderArt = true

    /** A failed lookup is remembered so lists stay fast; the widget calls this to try again for the rows it is about to show. */
    fun retry(t: Track) { synchronized(missing) { missing.remove(key(t) shl 1); missing.remove((key(t) shl 1) or 1L) } }

    /** Removes the cover files older versions of Aurora saved in the app's storage. */
    fun cleanOldFiles(ctx: Context) {
        try { ctx.filesDir.listFiles { f -> f.name.startsWith("art_") && f.name.endsWith(".jpg") }?.forEach { it.delete() } } catch (_: Throwable) {}
    }

    private fun key(t: Track) = if (t.albumId > 0) t.albumId else -t.id

    /** [px] is the size the picture will be drawn at: small list thumbnails are decoded small and cached apart from the big ones. */
    suspend fun load(ctx: Context, t: Track, px: Int = 640): Bitmap? = withContext(Dispatchers.IO) {
        if (!enabled) return@withContext null
        val k = (key(t) shl 1) or (if (px <= 320) 1L else 0L)
        cache.get(k)?.let { return@withContext it }
        if (k in missing) return@withContext null

        // like Musicolet: nothing is saved on the phone. The cover is read straight out of the song file, shrunk while it is
        // decoded, and kept in memory only
        var bmp: Bitmap? = null
        run {
            val want = maxOf(px, 96)
            val mmr = MediaMetadataRetriever()
            try {
                mmr.setDataSource(ctx, Uri.parse(t.uri))
                mmr.embeddedPicture?.let { bytes ->
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                    var sample = 1
                    while (o.outWidth / (sample * 2) >= want) sample *= 2
                    bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                }
            } catch (_: Throwable) {
            } finally {
                try { mmr.release() } catch (_: Throwable) {}
            }
        }
        // like Musicolet: a folder.jpg / cover.jpg next to the song is used when the song has no picture of its own
        if (bmp == null && folderArt) {
            try {
                val dir = File(t.path).parentFile
                val want = maxOf(px, 96)
                val f = listOf("folder", "cover", "albumart", "front", "albumartsmall").flatMap { n -> listOf("jpg", "jpeg", "png").map { "$n.$it" } }
                    .firstNotNullOfOrNull { n -> dir?.listFiles { x -> x.name.equals(n, true) }?.firstOrNull() }
                if (f != null) {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(f.path, o)
                    var sample = 1
                    while (o.outWidth / (sample * 2) >= want) sample *= 2
                    bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
                }
            } catch (_: Throwable) {}
        }
        val result = bmp
        if (result != null) cache.put(k, result) else synchronized(missing) { missing.add(k) }
        result
    }
}

fun Bitmap.dominantColor(): Color {
    val px = Bitmap.createScaledBitmap(this, 1, 1, true).getPixel(0, 0)
    return Color(px)
}

@Composable
fun rememberArt(track: Track?, px: Int = 640): Bitmap? {
    val ctx = LocalContext.current
    val state = produceState<Bitmap?>(null, track?.albumId, track?.id, px) {
        value = track?.let { ArtLoader.load(ctx, it, px) }
    }
    return state.value
}

@Composable
fun AlbumArt(
    track: Track?,
    modifier: Modifier = Modifier,
    shape: Shape = CircleShape,
    iconSize: Dp = 24.dp,
    px: Int = 256,
) {
    val bmp = rememberArt(track, px)
    val c1 = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
    val c2 = MaterialTheme.colorScheme.secondary.copy(alpha = 0.45f)
    Box(
        modifier.clip(shape).background(Brush.linearGradient(listOf(c1, c2))),
        contentAlignment = Alignment.Center,
    ) {
        Crossfade(bmp, animationSpec = if (Motion.artFade && Motion.scale > 0f) tween(Motion.ms(350)) else tween(0), label = "art") { b ->
            if (b != null) {
                Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.MusicNote, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(iconSize))
                }
            }
        }
    }
}

/** Little animated equaliser bars shown next to the currently playing song. */
@Composable
fun EqualizerBars(active: Boolean, color: Color, modifier: Modifier = Modifier.size(18.dp)) {
    val t = rememberInfiniteTransition(label = "bars")
    val durations = listOf(520, 380, 640, 450)
    val hs = durations.mapIndexed { i, d ->
        t.animateFloat(
            0.25f, 1f,
            infiniteRepeatable(tween(d, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "bar$i",
        )
    }
    Canvas(modifier) {
        val n = hs.size
        val gap = size.width * 0.08f
        val w = (size.width - gap * (n - 1)) / n
        hs.forEachIndexed { i, h ->
            val v = if (active) h.value else 0.25f
            val bh = size.height * v
            drawRoundRect(
                color,
                topLeft = Offset(i * (w + gap), size.height - bh),
                size = androidx.compose.ui.geometry.Size(w, bh),
                cornerRadius = CornerRadius(w / 2, w / 2),
            )
        }
    }
}

fun Color.toLongArgb(): Long = toArgb().toLong() and 0xFFFFFFFFL
