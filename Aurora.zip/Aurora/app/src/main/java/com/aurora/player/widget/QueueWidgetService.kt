package com.aurora.player.widget

import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import com.aurora.player.R
import com.aurora.player.controller
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime

/** Feeds the scrolling song list of the queue widget. */
class QueueWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsService.RemoteViewsFactory = Factory(applicationContext)

    private class Factory(private val ctx: Context) : RemoteViewsService.RemoteViewsFactory {
        private var items: List<Track> = emptyList()
        private var current = -1
        private var showArt = true
        private var theme = WidgetTheme.resolve(ctx, 0)

        override fun onCreate() {}

        override fun onDataSetChanged() { try { load() } catch (_: Throwable) {} }

        private fun load() {
            val c = ctx.controller
            items = c.queue
            current = c.currentIndex
            showArt = c.store.data.wqArt
            theme = WidgetTheme.resolve(ctx, c.store.data.queueTheme)
        }

        override fun onDestroy() {}
        override fun getCount() = items.size
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = position.toLong()
        override fun hasStableIds() = true

        override fun getViewAt(position: Int): RemoteViews = try { buildRow(position) } catch (_: Throwable) { RemoteViews(ctx.packageName, R.layout.widget_queue_row) }

        private fun buildRow(position: Int): RemoteViews {
            val t = items.getOrNull(position) ?: return RemoteViews(ctx.packageName, R.layout.widget_queue_row)
            val isCurrent = position == current
            val th = theme
            val v = RemoteViews(ctx.packageName, R.layout.widget_queue_row)
            v.setTextViewText(R.id.w_row_title, t.title)
            v.setTextViewText(R.id.w_row_artist, t.artist)
            v.setTextViewText(R.id.w_row_dur, formatTime(t.durationMs))
            v.setTextViewText(R.id.w_row_idx, (position + 1).toString())

            val main = if (isCurrent) th.accent else th.text
            val sub = if (isCurrent) th.accent else th.sub
            v.setTextColor(R.id.w_row_title, main)
            v.setTextColor(R.id.w_row_artist, sub)
            v.setTextColor(R.id.w_row_dur, sub)
            v.setTextColor(R.id.w_row_idx, th.sub)
            // small cover thumbnail (cached on disk by ArtLoader); the track number shows when there is none
            val thumb = if (showArt) try { kotlinx.coroutines.runBlocking { com.aurora.player.ui.ArtLoader.load(ctx, t, 96) } } catch (_: Throwable) { null } else null
            if (thumb != null) {
                v.setImageViewBitmap(R.id.w_row_art, thumb)
                v.setViewVisibility(R.id.w_row_art, View.VISIBLE)
                v.setViewVisibility(R.id.w_row_idx, View.GONE)
            } else {
                v.setViewVisibility(R.id.w_row_art, View.VISIBLE)
                v.setViewVisibility(R.id.w_row_idx, if (isCurrent) View.GONE else View.VISIBLE)
            }
            v.setInt(R.id.w_row_art, "setColorFilter", if (isCurrent && thumb != null) 0x88000000.toInt() else 0)
            v.setViewVisibility(R.id.w_row_play, if (isCurrent) View.VISIBLE else View.GONE)
            v.setInt(R.id.w_row_play, "setColorFilter", if (thumb != null) android.graphics.Color.WHITE else th.accent)
            // the playing song sits in a soft accent-tinted pill
            v.setInt(R.id.w_row_bg, "setColorFilter", th.accent)
            v.setInt(R.id.w_row_bg, "setImageAlpha", if (isCurrent) 64 else 0)

            v.setOnClickFillInIntent(R.id.w_row_root, Intent().putExtra(EXTRA_INDEX, position))
            return v
        }
    }
}
