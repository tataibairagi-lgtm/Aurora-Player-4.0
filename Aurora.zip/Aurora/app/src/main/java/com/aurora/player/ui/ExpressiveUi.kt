package com.aurora.player.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.launch

/** Small bits of UI state shared between screens (the floating tab pill hides while a list scrolls). */
object ExpressiveState {
    var pillHidden by mutableStateOf(false)
}

/** Font pairings: name to the family used for every text style. */
val FONT_PRESETS = listOf("Aurora (default)", "Editorial (serif)", "Techy (monospace)", "Playful (cursive)", "Compact (condensed)")

fun fontFamilyFor(i: Int): FontFamily? = when (i) {
    1 -> FontFamily.Serif
    2 -> FontFamily.Monospace
    3 -> FontFamily.Cursive
    4 -> FontFamily(android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.NORMAL))
    else -> null
}

fun typographyFor(i: Int): androidx.compose.material3.Typography {
    val b = androidx.compose.material3.Typography()
    val f = fontFamilyFor(i) ?: return b
    return b.copy(
        displayLarge = b.displayLarge.copy(fontFamily = f), displayMedium = b.displayMedium.copy(fontFamily = f), displaySmall = b.displaySmall.copy(fontFamily = f),
        headlineLarge = b.headlineLarge.copy(fontFamily = f), headlineMedium = b.headlineMedium.copy(fontFamily = f), headlineSmall = b.headlineSmall.copy(fontFamily = f),
        titleLarge = b.titleLarge.copy(fontFamily = f), titleMedium = b.titleMedium.copy(fontFamily = f), titleSmall = b.titleSmall.copy(fontFamily = f),
        bodyLarge = b.bodyLarge.copy(fontFamily = f), bodyMedium = b.bodyMedium.copy(fontFamily = f), bodySmall = b.bodySmall.copy(fontFamily = f),
        labelLarge = b.labelLarge.copy(fontFamily = f), labelMedium = b.labelMedium.copy(fontFamily = f), labelSmall = b.labelSmall.copy(fontFamily = f),
    )
}

val ACCENT_PRESETS = listOf(
    "Aurora blue" to 0xFF007CC3L, "Coral" to 0xFFFF6B5EL, "Mint" to 0xFF2BB58AL, "Violet" to 0xFF7C5CFFL, "Amber" to 0xFFF5A524L,
    "Rose" to 0xFFE84C88L, "Teal" to 0xFF0FA3B1L, "Lime" to 0xFF8BC34AL, "Slate" to 0xFF5C6B7AL, "Crimson" to 0xFFC62828L,
)

/** A-Z strip on the right edge of a long list. Drag along it to jump; a big letter bubble shows where you are. */
@Composable
fun AlphaScroller(titles: List<String>, state: LazyListState, modifier: Modifier = Modifier) {
    val letters = remember { ('A'..'Z').toList() + '#' }
    val firstAt = remember(titles) {
        val m = HashMap<Char, Int>()
        titles.forEachIndexed { i, t ->
            val ch = t.trim().firstOrNull()?.uppercaseChar()?.takeIf { it in 'A'..'Z' } ?: '#'
            if (ch !in m) m[ch] = i
        }
        m
    }
    val scope = rememberCoroutineScope()
    var active by remember { mutableStateOf<Char?>(null) }
    val strength by animateFloatAsState(if (active != null || state.isScrollInProgress) 1f else 0.35f, label = "alphaStrip")
    fun jump(frac: Float) {
        val ch = letters[(frac * letters.size).toInt().coerceIn(0, letters.lastIndex)]
        active = ch
        // letters with no song fall through to the next letter that has one
        val target = letters.drop(letters.indexOf(ch)).firstNotNullOfOrNull { firstAt[it] } ?: firstAt.values.maxOrNull() ?: return
        scope.launch { state.scrollToItem(target) }
    }
    Box(modifier.fillMaxHeight().padding(vertical = 8.dp), contentAlignment = Alignment.CenterEnd) {
        active?.let { ch ->
            Box(
                Modifier.padding(end = 44.dp).size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) { Text(ch.toString(), color = MaterialTheme.colorScheme.onPrimary, fontSize = 30.sp, fontWeight = FontWeight.Bold) }
        }
        Column(
            Modifier.fillMaxHeight().width(30.dp).graphicsLayer { alpha = strength }
                .pointerInput(titles) {
                    detectVerticalDragGestures(
                        onDragStart = { p -> jump(p.y / size.height) },
                        onDragEnd = { active = null }, onDragCancel = { active = null },
                    ) { change, _ -> change.consume(); jump(change.position.y / size.height) }
                }
                .pointerInput(titles) { androidx.compose.foundation.gestures.detectTapGestures(onPress = { p -> jump(p.y / size.height); tryAwaitRelease(); active = null }) },
            verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            letters.forEach { ch ->
                Text(ch.toString(), fontSize = 10.sp, fontWeight = if (ch == active) FontWeight.Bold else FontWeight.Medium,
                    color = if (ch == active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Quick switch between queues at the top of the queue screen. */
@Composable
fun QueueChips(c: PlayerController) {
    val qs = c.store.data.queues
    if (qs.size < 2) return
    LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(qs) { i, q ->
            FilterChip(
                c.viewQueue == i, { c.viewQueue = i },
                label = { Text("${i + 1}. ${q.name}", maxLines = 1) },
                leadingIcon = if (i == c.activeQueue) ({ androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Rounded.GraphicEq, null, Modifier.size(16.dp)) }) else null,
            )
        }
    }
}

/** Previous and next covers peek in beside the current one; drag moves them together, the current cover lags a little (parallax). */
@Composable
fun CarouselCovers(c: PlayerController, dragPx: Float) {
    BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val side = minOf(maxWidth, maxHeight) * 0.78f
        val gap = 14.dp
        val i = c.currentIndex
        val prev = c.queue.getOrNull(i - 1)
        val next = c.queue.getOrNull(i + 1)
        val s by animateFloatAsState(if (c.isPlaying) 1f else 0.9f, label = "carS")
        if (prev != null) AlbumArt(prev, Modifier.size(side).offset(-(side + gap)).graphicsLayer { scaleX = 0.82f; scaleY = 0.82f; alpha = 0.55f }, RoundedCornerShape(26.dp), 48.dp, 480)
        if (next != null) AlbumArt(next, Modifier.size(side).offset(side + gap).graphicsLayer { scaleX = 0.82f; scaleY = 0.82f; alpha = 0.55f }, RoundedCornerShape(26.dp), 48.dp, 480)
        AlbumArt(
            c.current, Modifier.size(side).graphicsLayer { scaleX = s; scaleY = s; translationX = -dragPx * 0.18f; shadowElevation = 40f; shape = RoundedCornerShape(26.dp); clip = true },
            RoundedCornerShape(26.dp), 72.dp, 800,
        )
    }
}

/** Settings page: every opt-in look. All of them are off by default, so Aurora's own look stays as it is. */
@Composable
fun ExpressivePage(c: PlayerController) {
    val d = c.store.data
    Text(
        "Optional looks inspired by Material 3 Expressive. Everything here is off by default.",
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Section("Now playing")
    SwitchRow("Wavy seek bar", "The played part ripples while music plays and goes flat when paused", d.uiSquiggly) { v -> c.store.update { it.copy(uiSquiggly = v) } }
    SwitchRow("Morphing play button", "Softer square while playing, circle when paused, with a bounce and a tap buzz", d.uiMorphPlay) { v -> c.store.update { it.copy(uiMorphPlay = v) } }
    SwitchRow("Audio format pill", "Format, sample rate and bitrate above the seek bar; tap for song info", d.uiSpecPill) { v -> c.store.update { it.copy(uiSpecPill = v) } }
    SwitchRow("Scrolling long titles", "Title and artist slide sideways when they do not fit", d.uiMarquee) { v -> c.store.update { it.copy(uiMarquee = v) } }
    SwitchRow("Cover carousel", "Previous and next covers peek in beside the current one while you swipe (square cover style)", d.uiCarousel) { v -> c.store.update { it.copy(uiCarousel = v) } }
    SwitchRow("Pure black for Fluid mesh", "True black behind the Fluid mesh background (pick it in Now Playing, Background)", d.uiAmoled) { v -> c.store.update { it.copy(uiAmoled = v) } }
    Section("Mini-player and navigation")
    SwitchRow("Gesture mini-player", "Swipe it up to open the player, swipe sideways to skip; thin progress line along the bottom", d.uiMiniExpand) { v -> c.store.update { it.copy(uiMiniExpand = v) } }
    SwitchRow("Floating tab pill", "Tabs sit in a rounded floating bar at the bottom and slide away while you scroll down", d.uiPillNav) { v -> c.store.update { it.copy(uiPillNav = v) } }
    SwitchRow("Queue chips", "Switch between your queues with chips at the top of the queue screen", d.uiQueueChips) { v -> c.store.update { it.copy(uiQueueChips = v) } }
    Section("Library")
    SwitchRow("Fast scroller", "A-Z strip with a letter bubble on long song lists", d.uiFastScroll) { v -> c.store.update { it.copy(uiFastScroll = v) } }
    SwitchRow("Collapsing headers", "Album and artist pages open with a big cover that shrinks as you scroll, plus a Shuffle button", d.uiCollapseHeader) { v -> c.store.update { it.copy(uiCollapseHeader = v) } }
    SwitchRow("Grid size switcher", "Buttons on the Albums tab: list, 2 columns, 3 columns with covers only", d.uiGridSwitch) { v -> c.store.update { it.copy(uiGridSwitch = v) } }
    Section("Colours and fonts")
    ChipRow("Accent presets") {
        ACCENT_PRESETS.forEach { (n, col) -> FilterChip(d.accentColor == col, { c.store.update { it.copy(accentColor = col) } }, label = { Text(n) }) }
    }
    ChipRow("Font pairing") {
        FONT_PRESETS.forEachIndexed { i, n -> FilterChip(d.uiFont == i, { c.store.update { it.copy(uiFont = i) } }, label = { Text(n) }) }
    }
}

/** What a cover gesture can do. The index is the stored code. */
val COVER_ACTIONS = listOf("Nothing", "Next song", "Previous song", "Forward", "Back", "Favourite", "Lyrics", "Play / pause", "Shuffle")

fun coverAction(c: PlayerController, code: Int, openLyrics: () -> Unit) {
    when (code) {
        1 -> c.next()
        2 -> c.previous()
        3 -> c.fastForward()
        4 -> c.rewind()
        5 -> c.current?.let { c.store.toggleFavourite(it.id) }
        6 -> openLyrics()
        7 -> c.togglePlay()
        8 -> c.toggleShuffle()
    }
}
