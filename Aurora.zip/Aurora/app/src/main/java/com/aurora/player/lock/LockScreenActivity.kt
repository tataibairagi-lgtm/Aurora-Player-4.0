package com.aurora.player.lock

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.layout.layout
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import com.aurora.player.controller
import com.aurora.player.data.formatTime
import com.aurora.player.data.indexAt
import com.aurora.player.player.PlayerController
import com.aurora.player.ui.AddToPlaylistDialog
import com.aurora.player.ui.AlbumArt
import com.aurora.player.ui.AuroraTheme
import com.aurora.player.ui.bounceClick
import com.aurora.player.ui.dominantColor
import com.aurora.player.ui.rememberArt
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Aurora's own lock-screen player: drawn over the system lock screen while music is playing. */
class LockScreenActivity : ComponentActivity() {
    private val unlocked = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) setShowWhenLocked(true)
        @Suppress("DEPRECATION")
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { (getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager).cancel(7001) } catch (_: Exception) {}
        enableEdgeToEdge()
        // draw into the camera-cutout area too, so landscape is really full screen
        if (Build.VERSION.SDK_INT >= 28) window.attributes = window.attributes.also {
            it.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        ContextCompat.registerReceiver(this, unlocked, IntentFilter(Intent.ACTION_USER_PRESENT), ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent {
            AuroraTheme(2, controller.store.data.accentColor) { LockContent(controller, onUnlock = ::unlock) }
        }
    }

    private fun unlock() {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) {
            finish()
            return
        }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
        })
    }

    override fun onDestroy() {
        try { unregisterReceiver(unlocked) } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
private fun LockContent(c: PlayerController, onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val track = c.current
    var addDialog by remember { mutableStateOf(false) }
    var sleepSheet by remember { mutableStateOf(false) }
    val bmp = rememberArt(track)
    val swatchStyle = c.store.data.lockAdaptStyle == 1
    val meshStyle = c.store.data.lockAdaptStyle == 2
    val accent by animateColorAsState(
        (if (c.store.data.lockAdapt) bmp?.let { if (swatchStyle) Color(com.aurora.player.player.coverColor(it)) else it.dominantColor() } else null) ?: MaterialTheme.colorScheme.primary,
        tween(800), label = "lockAccent",
    )

    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(10_000) }
    }
    val time = remember(now) { DateFormat.getTimeFormat(ctx).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now)) }

    var showQueue by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    // a sleep timer that stopped the music also closes this screen
    val sleepAt0 = remember { c.sleepFiredAt }
    fun activityOf(x: Context): android.app.Activity? { var k: Context? = x; while (k is android.content.ContextWrapper) { if (k is android.app.Activity) return k; k = k.baseContext }; return null }
    androidx.compose.runtime.LaunchedEffect(c.sleepFiredAt) {
        if (c.sleepFiredAt != sleepAt0) activityOf(ctx)?.finish()
    }
    // a timer that ran out (or any stop while the timer was running) closes this screen; the screen may sleep again once music is paused
    var hadTimer by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(c.sleepLeftMs, c.isPlaying) {
        if (c.sleepLeftMs > 0) hadTimer = true
        else if (hadTimer && !c.isPlaying) activityOf(ctx)?.finish()
    }
    androidx.compose.runtime.LaunchedEffect(c.isPlaying) {
        val w = activityOf(ctx)?.window ?: return@LaunchedEffect
        if (c.isPlaying) w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    androidx.activity.compose.BackHandler(enabled = showLyrics || showQueue) { showLyrics = false; showQueue = false }
    val bob = rememberInfiniteTransition(label = "bob")
    val bobY by bob.animateFloat(0f, -14f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "bobY")

    Box(
        Modifier.fillMaxSize()
            .background(Color(0xFF0B0A12))
            .pointerInput(Unit) {
                var total = 0f
                var totalV = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total > 260f) onUnlock(); total = 0f },
                ) { _, dx -> total += dx }
            },
    ) {
        // background adapted from the cover: blurred art (Android 12+; plain art below that), tinted by its dominant colour
        if (c.store.data.lockAdapt && meshStyle) com.aurora.player.ui.FluidMesh(bmp, accent, true, false)
        if (c.store.data.lockAdapt && !swatchStyle && !meshStyle) bmp?.let {
            // Modifier.blur does nothing below Android 12, so blur by shrinking and stretching the cover there
            val soft = androidx.compose.runtime.remember(it, c.store.data.blurPct) { com.aurora.player.ui.blurBitmap(it, c.store.data.blurPct) }
            androidx.compose.foundation.Image(
                soft.asImageBitmap(), null, Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                filterQuality = androidx.compose.ui.graphics.FilterQuality.Medium,
            )
        }
        Box(
            Modifier.fillMaxSize().background(
                if (meshStyle && c.store.data.lockAdapt) Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.30f)))
                else if (swatchStyle && c.store.data.lockAdapt) Brush.verticalGradient(0f to accent.copy(alpha = 0.95f), 0.45f to accent.copy(alpha = 0.55f), 1f to Color(0xF20B0A12))
                else Brush.verticalGradient(listOf(accent.copy(alpha = 0.55f), Color(0xB30B0A12), Color(0xE60B0A12))),
            ),
        )
        if (swatchStyle && c.store.data.lockAdapt) {
            // a soft highlight from the top corner, like light falling across the swatch
            Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.16f), Color.Transparent), center = androidx.compose.ui.geometry.Offset(160f, 80f), radius = 900f)))
        }
        val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        val clock: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            if (land) Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(time, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Light)
                Text(date, color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp, modifier = Modifier.padding(bottom = 5.dp))
            } else {
                Text(time, color = Color.White, fontSize = 74.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(top = 18.dp))
                Text(date, color = Color.White.copy(alpha = 0.75f), fontSize = 16.sp)
            }
        }
        val artBox: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = if (land) 6.dp else 18.dp), contentAlignment = Alignment.Center) {
                val scale by animateFloatAsState(if (c.isPlaying) 1f else 0.9f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "lockArt")
                AnimatedContent(
                    track?.id,
                    transitionSpec = { (scaleIn(tween(450), 0.85f) + fadeIn(tween(450))) togetherWith (scaleOut(tween(300), 0.85f) + fadeOut(tween(250))) },
                    label = "lockArtSwap",
                ) {
                    AlbumArt(track, Modifier.fitSquare(if (land) 1f else 0.8f).scale(scale), RoundedCornerShape(if (land) 24.dp else 30.dp), 72.dp, 800)
                }
            }
        }
        val head: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = { clock(); artBox() }
        val body: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit = {
            AnimatedContent(
                track?.id,
                transitionSpec = {
                    (slideInVertically(tween(350)) { it / 2 } + fadeIn(tween(350))) togetherWith
                        (slideOutVertically(tween(250)) { -it / 2 } + fadeOut(tween(200)))
                },
                label = "lockTitle",
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(track?.title ?: "Nothing playing", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track?.artist ?: "", color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (track != null && track.album.isNotBlank()) Text(track.album, color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            // current + next lyric line (own composable so the per-tick position doesn't recompose the whole screen)
            LockLyrics(c) { showLyrics = true }

            var drag by remember { mutableStateOf<Float?>(null) }
            val dur = c.durationMs.coerceAtLeast(1L).toFloat()
            val seekBase = c.store.data.accentColor.let { if (it != 0L) Color(it) else MaterialTheme.colorScheme.primary }
            // the bar follows the app's appearance colour (lightened if it would vanish on the dark lock screen)
            val seekOn = if (androidx.core.graphics.ColorUtils.calculateLuminance(seekBase.toArgb()) < 0.18) androidx.compose.ui.graphics.lerp(seekBase, Color.White, 0.45f) else seekBase
            // the same seek bar style as Now playing: waveform, wavy or the plain one
            if (false && c.store.data.uiWaveform) com.aurora.player.ui.WaveformSeek(
                c, value = (drag ?: c.positionMs.toFloat()).coerceIn(0f, dur), max = dur, color = seekOn, trackColor = seekOn.copy(alpha = 0.28f),
                onChange = { drag = it }, onDone = { drag?.let { c.seekTo(it.toLong()) }; drag = null },
            ) else if (c.store.data.uiSquiggly) com.aurora.player.ui.SquigglySeek(
                value = (drag ?: c.positionMs.toFloat()).coerceIn(0f, dur), max = dur, oneUi = c.store.data.uiWaveOne, playing = c.isPlaying, color = seekOn, trackColor = seekOn.copy(alpha = 0.28f),
                onChange = { drag = it }, onDone = { drag?.let { c.seekTo(it.toLong()) }; drag = null },
            ) else Slider(
                value = (drag ?: c.positionMs.toFloat()).coerceIn(0f, dur),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { c.seekTo(it.toLong()) }; drag = null },
                valueRange = 0f..dur,
                colors = androidx.compose.material3.SliderDefaults.colors(thumbColor = seekOn, activeTrackColor = seekOn, inactiveTrackColor = seekOn.copy(alpha = 0.28f)),
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime((drag ?: c.positionMs.toFloat()).toLong()), color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.weight(1f))
                Text(formatTime(c.durationMs), color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = if (land) 2.dp else 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
            ) {
                LockIcon(Icons.Rounded.Shuffle, if (c.shuffle) Color.White else Color.White.copy(alpha = 0.45f)) { c.toggleShuffle() }
                LockIcon(Icons.Rounded.SkipPrevious, Color.White, 40.dp) { c.previous() }
                Box(
                    Modifier.size(if (land) 56.dp else 72.dp).clip(CircleShape).background(Color.White).bounceClick { c.togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    AnimatedContent(
                        c.isPlaying,
                        transitionSpec = { (scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
                        label = "lockPlay",
                    ) { p -> Icon(if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color(0xFF0B0A12), modifier = Modifier.size(if (land) 32.dp else 40.dp)) }
                }
                LockIcon(Icons.Rounded.SkipNext, Color.White, 40.dp) { c.next() }
                LockIcon(
                    if (c.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    if (c.repeatMode != Player.REPEAT_MODE_OFF) Color.White else Color.White.copy(alpha = 0.45f),
                ) { c.cycleRepeat() }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                LockIcon(Icons.AutoMirrored.Rounded.QueueMusic, Color.White.copy(alpha = 0.8f)) { showQueue = !showQueue }
                if (track != null) {
                    val fav = c.store.isFavourite(track.id)
                    LockIcon(
                        if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (fav) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.7f),
                    ) { c.store.toggleFavourite(track.id) }
                    // add to playlist while playing; a cross (closes the lock screen player) while paused
                    if (c.isPlaying) LockIcon(Icons.AutoMirrored.Rounded.PlaylistAdd, Color.White.copy(alpha = 0.7f)) { addDialog = true }
                    else {
                        // the cross only closes this player (the phone stays locked); it does not open the app
                        val act = androidx.compose.ui.platform.LocalContext.current as? android.app.Activity
                        LockIcon(Icons.Rounded.Close, Color.White.copy(alpha = 0.7f)) {
                            // the same as the cross on the notification: stop the music and shut the player down
                            try { c.player.pause() } catch (_: Throwable) {}
                            try { act?.let { a -> a.stopService(android.content.Intent(a, com.aurora.player.player.PlaybackService::class.java)) } } catch (_: Throwable) {}
                            act?.finish()
                        }
                    }
                }
            }

            if (!land) Row(
                Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp).offset { IntOffset(bobY.roundToInt().let { -it }, 0) },
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Swipe right to unlock", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                Icon(Icons.Rounded.KeyboardArrowRight, null, tint = Color.White.copy(alpha = 0.6f))
            }
        }
        if (land) {
            // landscape: clock above the cover on the left, the player controls on the right
            Row(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().displayCutoutPadding().padding(horizontal = 26.dp),
                horizontalArrangement = Arrangement.spacedBy(28.dp),
            ) {
                Column(Modifier.weight(0.8f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) { clock(); artBox() }
                Column(
                    Modifier.weight(1.2f).fillMaxHeight(),
                    verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally,
                ) { body() }
            }
        } else {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().displayCutoutPadding().padding(horizontal = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) { head(); body() }
        }
        // queue viewer: slides over the lower part of the screen, tap a song to jump to it
        androidx.compose.animation.AnimatedVisibility(
            showQueue, modifier = Modifier.align(if (land) Alignment.CenterEnd else Alignment.BottomCenter),
            enter = if (land) androidx.compose.animation.slideInHorizontally(tween(300)) { it } + fadeIn() else slideInVertically(tween(300)) { it } + fadeIn(),
            exit = if (land) androidx.compose.animation.slideOutHorizontally(tween(250)) { it } + fadeOut() else slideOutVertically(tween(250)) { it } + fadeOut(),
        ) {
            LockQueue(c, land) { showQueue = false }
        }
        // full-screen lyrics: tap the lyric lines under the album to open, tap the cross (or back) to close
        androidx.compose.animation.AnimatedVisibility(showLyrics, enter = fadeIn(tween(250)), exit = fadeOut(tween(200))) {
            LockLyricsFull(c, accent, bmp, c.store.data.lockAdapt && c.store.data.lockAdaptStyle == 0) { showLyrics = false }
        }
        if (addDialog && track != null) AddToPlaylistDialog(c, listOf(track.id)) { addDialog = false }
        if (sleepSheet) LockSleepSheet(c) { sleepSheet = false }
    }
}

@Composable
private fun LockQueue(c: PlayerController, land: Boolean, onClose: () -> Unit) {
    val state = androidx.compose.foundation.lazy.rememberLazyListState()
    androidx.compose.runtime.LaunchedEffect(Unit) { if (c.currentIndex > 2) state.scrollToItem(c.currentIndex - 1) }
    var pick by remember { mutableStateOf(false) }   // true: the list shows your queues so you can change to another one
    Column(
        (if (land) Modifier.fillMaxHeight().fillMaxWidth(0.56f).clip(RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp)).background(Color(0xFA110F18)).statusBarsPadding().navigationBarsPadding().displayCutoutPadding()
        else Modifier.fillMaxWidth().fillMaxHeight(0.62f).clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)).background(Color(0xF2121018)).navigationBarsPadding())
            .padding(top = 8.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(Modifier.clip(RoundedCornerShape(12.dp)).bounceClick { pick = !pick }, verticalAlignment = Alignment.CenterVertically) {
                    Text(c.store.data.queues.getOrNull(c.activeQueue)?.name ?: "Queue", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    Icon(if (pick) Icons.Rounded.KeyboardArrowUp else Icons.Rounded.KeyboardArrowDown, "Change queue", Modifier.padding(start = 2.dp).size(22.dp), tint = Color.White.copy(alpha = 0.85f))
                }
                Text(
                    "${c.queue.size} songs · ${formatTime(c.queue.sumOf { it.durationMs })}",
                    color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp,
                )
            }
            var songsSheet by remember { mutableStateOf(false) }
            if (songsSheet) LockSleepSheet(c) { songsSheet = false }
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(if (c.sleepActive) Color.White.copy(alpha = 0.2f) else Color.Transparent)
                    .bounceClick { songsSheet = true }.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Rounded.Bedtime, null, tint = Color.White)
                if (c.sleepLeftMs > 0) Text(" " + formatTime(c.sleepLeftMs), color = Color.White, fontSize = 12.sp)
            }
            Box(Modifier.size(44.dp).bounceClick(onClose), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
        }
        if (pick) androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize()) {
            val qs = c.store.data.queues
            itemsIndexed(qs) { i, q ->
                val on = i == c.activeQueue
                Row(
                    Modifier.fillMaxWidth().bounceClick {
                        if (!on) { c.switchQueue(i); if (c.queue.isNotEmpty()) c.play() }
                        pick = false
                    }.background(if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f) else Color.Transparent).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(q.name.ifBlank { "Queue ${i + 1}" }, color = Color.White, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${if (on) c.queue.size else q.trackIds.size} songs" + if (on) " · playing" else "", color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                    }
                    if (on) Icon(Icons.Rounded.Check, null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        } else androidx.compose.foundation.lazy.LazyColumn(state = state, modifier = Modifier.fillMaxSize()) {
            itemsIndexed(c.queue) { i, t ->
                val cur = i == c.currentIndex
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = if (land) 8.dp else 0.dp).clip(RoundedCornerShape(if (land) 14.dp else 0.dp)).bounceClick { c.jumpTo(i) }
                        .background(if (cur) MaterialTheme.colorScheme.primary.copy(alpha = 0.22f) else Color.Transparent).padding(horizontal = if (land) 10.dp else 18.dp, vertical = if (land) 5.dp else 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        (i + 1).toString(), Modifier.width(34.dp).padding(end = 8.dp), color = if (cur) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.55f),
                        fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End, maxLines = 1,
                    )
                    AlbumArt(t, Modifier.size(if (land) 40.dp else 44.dp), RoundedCornerShape(10.dp), 20.dp)
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text(t.title, color = Color.White, fontWeight = if (cur) FontWeight.Bold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(t.artist, color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(formatTime(t.durationMs), color = Color.White.copy(alpha = 0.65f), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun LockIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, size: androidx.compose.ui.unit.Dp = 28.dp, onClick: () -> Unit) {
    val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    Box(Modifier.size(if (land) 44.dp else 52.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(if (land) size * 0.9f else size))
    }
}

@Composable
private fun LockLyrics(c: PlayerController, onOpen: () -> Unit) {
    val lyr = c.lyrics
    if (!c.store.data.lockShowLyrics || lyr == null || !lyr.synced || lyr.lines.isEmpty()) {
        Spacer(Modifier.height(96.dp))
        return
    }
    val idx by remember(lyr) { androidx.compose.runtime.derivedStateOf { lyr.indexAt(c.lyricPosMs) } }
    androidx.compose.animation.AnimatedContent(
        targetState = idx,
        modifier = Modifier.padding(top = 10.dp).fillMaxWidth().height(104.dp).clickable { onOpen() },
        transitionSpec = { com.aurora.player.ui.lyricMotion(c.store.data.lyricMotion) },
        label = "lockLyricLines",
    ) { i ->
        val cur = lyr.lines.getOrNull(i)?.text.orEmpty().ifBlank { "♪" }
        val next = lyr.lines.getOrNull(i + 1)?.text.orEmpty()
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                cur, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            Text(
                next, color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp, fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}


@Composable
private fun LockLyricsFull(c: PlayerController, accent: Color, bmp: android.graphics.Bitmap?, adapt: Boolean, onClose: () -> Unit) {
    val lyr = c.lyrics
    val track = c.current
    val state = androidx.compose.foundation.lazy.rememberLazyListState()
    val idx by remember(lyr) { androidx.compose.runtime.derivedStateOf { lyr?.indexAt(c.lyricPosMs) ?: -1 } }
    val land = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE

    // keep the playing line in the middle of the list: first jump if it is far away, then glide slowly
    androidx.compose.runtime.LaunchedEffect(idx, lyr) {
        if (lyr == null || !lyr.synced || idx < 0) return@LaunchedEffect
        try {
            val target = idx + 1 // item 0 is the top spacer
            var item = state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == target }
            if (item == null) {
                state.scrollToItem(target)
                item = state.layoutInfo.visibleItemsInfo.firstOrNull { it.index == target }
            }
            if (item != null) {
                val info = state.layoutInfo
                val centre = (info.viewportEndOffset - info.viewportStartOffset) / 2f
                val delta = item.offset + item.size / 2f - centre
                // a long, soft ease-out glide; the further the next line is, the longer it takes
                val ms = (620 + kotlin.math.abs(delta) * 0.5f).toInt().coerceIn(620, 1100)
                state.animateScrollBy(delta, androidx.compose.animation.core.tween(ms, easing = androidx.compose.animation.core.CubicBezierEasing(0.22f, 1f, 0.36f, 1f)))
            }
        } catch (_: Throwable) {}
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF0B0A12))) {
        // follows the lock-screen background style, so every song gets its own look
        val lStyle = c.store.data.lockAdaptStyle
        if (adapt && lStyle == 2) {
            com.aurora.player.ui.FluidMesh(bmp, accent, true, false)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.30f)))))
        } else if (adapt && lStyle == 1) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to accent.copy(alpha = 0.95f), 0.5f to accent.copy(alpha = 0.6f), 1f to Color(0xF20B0A12))))
        } else {
            if (adapt) bmp?.let {
                val soft = remember(it, c.store.data.blurPct) { com.aurora.player.ui.blurBitmap(it, c.store.data.blurPct) }
                androidx.compose.foundation.Image(
                    soft.asImageBitmap(), null, Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    filterQuality = androidx.compose.ui.graphics.FilterQuality.Medium,
                )
            }
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.55f), accent.copy(alpha = 0.35f), accent.copy(alpha = 0.2f)))))
        }
        // darkening layer (adjustable in the tune sheet)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (c.store.data.lyricsDim / 100f).coerceIn(0f, 0.85f))))
        var tune by remember { mutableStateOf(false) }

        if (land) {
            Row(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().displayCutoutPadding().padding(horizontal = 20.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                Column(Modifier.weight(0.38f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Box(Modifier.size(44.dp).bounceClick { tune = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Tune, null, tint = Color.White) }
                        Box(Modifier.size(44.dp).bounceClick(onClose), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                        AlbumArt(track, Modifier.fitSquare(0.9f), RoundedCornerShape(22.dp), 56.dp, 600)
                    }
                    LyricsTitle(track, centered = true)
                }
                LyricsList(lyr, idx, state, Modifier.weight(0.62f).fillMaxHeight(), c.store.data) { ms -> c.seekAndPlay(ms) }
            }
        } else {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().displayCutoutPadding()) {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 6.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    AlbumArt(track, Modifier.size(56.dp), RoundedCornerShape(14.dp), 28.dp, 400)
                    Box(Modifier.weight(1f).height(56.dp).padding(horizontal = 14.dp)) { LyricsTitle(track, centered = false, matchHeight = true) }
                    Box(Modifier.size(44.dp).bounceClick { tune = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Tune, null, tint = Color.White) }
                    Box(Modifier.size(48.dp).bounceClick(onClose), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Close, null, tint = Color.White) }
                }
                LyricsList(lyr, idx, state, Modifier.weight(1f).fillMaxWidth(), c.store.data) { ms -> c.seekAndPlay(ms) }
            }
        }
        if (tune) LyricsTuneDialog(c) { tune = false }
    }
}

/** Size, alignment, weight and darkness of the full-screen lock-screen lyrics. */
@Composable
private fun LyricsTuneDialog(c: PlayerController, onClose: () -> Unit) {
    val d = c.store.data
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Lyrics style") },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                Text("Text size: ${d.lockLyricSize}")
                androidx.compose.material3.Slider(d.lockLyricSize.toFloat(), { v -> c.store.update { it.copy(lockLyricSize = v.roundToInt()) } }, valueRange = 16f..40f)
                Text("Background darkness: ${d.lyricsDim}%")
                androidx.compose.material3.Slider(d.lyricsDim.toFloat(), { v -> c.store.update { it.copy(lyricsDim = v.roundToInt()) } }, valueRange = 0f..85f)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Left", "Centre", "Right").forEachIndexed { i, n ->
                        androidx.compose.material3.FilterChip(d.lockLyricAlign == i, { c.store.update { it.copy(lockLyricAlign = i) } }, label = { Text(n) })
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Bold current line", Modifier.weight(1f))
                    androidx.compose.material3.Switch(d.lockLyricBold, { v -> c.store.update { it.copy(lockLyricBold = v) } })
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Focus on the current line", Modifier.weight(1f))
                    androidx.compose.material3.Switch(d.lockLyricsLines, { v -> c.store.update { it.copy(lockLyricsLines = v) } })
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onClose) { Text("Done") } },
    )
}

@Composable
private fun LyricsTitle(track: com.aurora.player.data.Track?, centered: Boolean, matchHeight: Boolean = false) {
    val al = if (centered) Alignment.CenterHorizontally else Alignment.Start
    // title, artist and album are spread over exactly the height of the cover beside them
    Column(if (matchHeight) Modifier.fillMaxHeight() else Modifier, horizontalAlignment = al, verticalArrangement = if (matchHeight) Arrangement.SpaceBetween else Arrangement.Top) {
        Text(track?.title ?: "", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = if (centered) TextAlign.Center else TextAlign.Start)
        Text(track?.artist ?: "", color = Color.White.copy(alpha = 0.78f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (track != null && track.album.isNotBlank()) Text(track.album, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun LyricsList(lyr: com.aurora.player.data.Lyrics?, idx: Int, state: androidx.compose.foundation.lazy.LazyListState, modifier: Modifier, d: com.aurora.player.data.Persisted, onSeek: (Long) -> Unit) {
    if (lyr == null || lyr.lines.isEmpty()) {
        Box(modifier, contentAlignment = Alignment.Center) { Text("No lyrics for this song", color = Color.White.copy(alpha = 0.7f)) }
        return
    }
    androidx.compose.foundation.layout.BoxWithConstraints(modifier) {
        val half = maxHeight / 2
        androidx.compose.foundation.lazy.LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 22.dp)) {
            item { Spacer(Modifier.height(half)) }
            itemsIndexed(lyr.lines) { i, l ->
                val cur = i == idx
                val dist = if (lyr.synced && idx >= 0) kotlin.math.abs(i - idx) else 0
                // only graphicsLayer values animate (scale, fade): the text never re-measures, so the list does not shake while it scrolls
                val sc by animateFloatAsState(if (!lyr.synced || cur) 1f else if (d.lockLyricsLines) 0.78f else 0.88f, tween(650, easing = androidx.compose.animation.core.CubicBezierEasing(0.22f, 1f, 0.36f, 1f)), label = "lyrScale")
                val a by animateFloatAsState(
                    if (!lyr.synced || cur) 1f else when (dist) { 1 -> 0.7f; 2 -> 0.5f; else -> 0.34f },
                    tween(650, easing = androidx.compose.animation.core.CubicBezierEasing(0.22f, 1f, 0.36f, 1f)), label = "lyrAlpha",
                )
                val origin = when (d.lockLyricAlign) { 0 -> 0f; 2 -> 1f; else -> 0.5f }
                Text(
                    l.text.ifBlank { "♪" },
                    // tap a line to play from there
                    Modifier.fillMaxWidth().clickable(
                        interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null,
                    ) { if (lyr.synced && l.timeMs >= 0) onSeek(l.timeMs) }.padding(vertical = 10.dp).graphicsLayer {
                        scaleX = sc; scaleY = sc; alpha = a
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(origin, 0.5f)
                    },
                    color = Color.White, fontSize = d.lockLyricSize.sp, lineHeight = (d.lockLyricSize * 1.25f).sp,
                    fontWeight = if (cur && lyr.synced && d.lockLyricBold) FontWeight.Bold else FontWeight.Medium,
                    textAlign = when (d.lockLyricAlign) { 0 -> TextAlign.Start; 2 -> TextAlign.End; else -> TextAlign.Center },
                )
            }
            item { Spacer(Modifier.height(half)) }
        }
    }
}

/** A square that fits the available width or height, whichever is smaller, times [frac]. */
private fun Modifier.fitSquare(frac: Float): Modifier = this.layout { m, c ->
    val side = (minOf(c.maxWidth, c.maxHeight) * frac).toInt().coerceAtLeast(0)
    val p = m.measure(androidx.compose.ui.unit.Constraints.fixed(side, side))
    layout(side, side) { p.place(0, 0) }
}


/** Sleep timer for the lock screen player: live countdown, quick durations, +/- 5 minutes, after this song, cancel. */
@Composable
private fun LockSleepSheet(c: PlayerController, onClose: () -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onClose,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        val accent = MaterialTheme.colorScheme.primary
        val conf = androidx.compose.ui.platform.LocalConfiguration.current
        val land = conf.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
        // landscape: a narrow, scrollable card instead of one that fills the whole screen
        Column(
            Modifier.padding(horizontal = 18.dp, vertical = if (land) 10.dp else 0.dp).then(if (land) Modifier.width(300.dp).heightIn(max = (conf.screenHeightDp * 0.9f).dp) else Modifier.fillMaxWidth())
                .clip(RoundedCornerShape(if (land) 24.dp else 30.dp)).background(Color(0xFF17161F))
                .then(if (land) Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()) else Modifier)
                .padding(horizontal = if (land) 14.dp else 18.dp, vertical = if (land) 12.dp else 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val active = c.sleepActive
            if (!land) Box(Modifier.size(52.dp).clip(CircleShape).background(accent.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Bedtime, null, tint = accent, modifier = Modifier.size(28.dp))
            }
            Text("Sleep timer", color = Color.White, fontSize = if (land) 16.sp else 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = if (land) 0.dp else 10.dp))
            Text(
                when {
                    c.sleepLeftMs > 0 -> "Stops in " + formatTime(c.sleepLeftMs)
                    c.sleepSongsLeft > 1 -> "Stops after " + c.sleepSongsLeft + " more songs"
                    active -> "Stops after this song"
                    else -> "Choose when the music should stop"
                },
                color = if (active) accent else Color.White.copy(alpha = 0.65f), fontSize = if (land) 12.sp else 14.sp, modifier = Modifier.padding(top = 2.dp, bottom = if (land) 8.dp else 16.dp),
            )
            @Composable
            fun RowScope.Chip(label: String, strong: Boolean = false, onClick: () -> Unit) {
                Box(
                    Modifier.weight(1f).height(if (land) 36.dp else 46.dp).clip(RoundedCornerShape(if (land) 14.dp else 16.dp))
                        .background(if (strong) accent.copy(alpha = 0.28f) else Color.White.copy(alpha = 0.09f))
                        .bounceClick(onClick),
                    contentAlignment = Alignment.Center,
                ) { Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1) }
            }
            Text("Minutes", Modifier.fillMaxWidth().padding(bottom = 6.dp), color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            listOf(listOf(5, 10, 15, 30), listOf(45, 60, 90, 120)).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { m -> Chip("$m") { c.setSleepMinutes(m); onClose() } }
                }
            }
            if (c.sleepLeftMs > 0) Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("- 5 min", true) { c.adjustSleepMinutes(-5) }
                Chip("+ 5 min", true) { c.adjustSleepMinutes(5) }
            }
            Text("Songs", Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 6.dp), color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            var songsN by androidx.compose.runtime.remember { androidx.compose.runtime.mutableIntStateOf(3) }
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = 0.07f)).padding(6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f)).bounceClick { songsN = (songsN - 1).coerceAtLeast(2) }, contentAlignment = Alignment.Center) {
                    Text("−", color = Color.White, fontSize = 22.sp)
                }
                Text("$songsN songs", Modifier.weight(1f), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
                Box(Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f)).bounceClick { songsN = (songsN + 1).coerceAtMost(50) }, contentAlignment = Alignment.Center) {
                    Text("+", color = Color.White, fontSize = 22.sp)
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Stop after $songsN", true) { c.setSleepSongs(songsN); onClose() }
                Chip("After this song", true) { c.setSleepEndOfTrack(); onClose() }
            }
            if (active) Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Chip("Cancel timer") { c.cancelSleep(); onClose() }
            }
        }
    }
}
