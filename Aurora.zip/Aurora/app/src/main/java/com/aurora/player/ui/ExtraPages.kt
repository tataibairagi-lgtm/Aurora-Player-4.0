package com.aurora.player.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Backspace
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.aurora.player.automation.Automation
import com.aurora.player.data.AlarmItem
import com.aurora.player.data.BtRule
import com.aurora.player.data.Persisted
import com.aurora.player.data.ThemePreset
import com.aurora.player.player.PlayerController
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.roundToInt

private val MODE_NAMES = listOf("System", "Light", "Dark", "Black")

// ---------------------------------------------------------------------------------------------
// PIN
// ---------------------------------------------------------------------------------------------

private fun hashPin(pin: String, salt: String): String =
    MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }

fun pinMatches(d: Persisted, pin: String): Boolean = d.pinHash.isNotEmpty() && hashPin(pin, d.pinSalt) == d.pinHash

private fun setPin(c: PlayerController, pin: String) {
    val salt = UUID.randomUUID().toString()
    c.store.update { it.copy(pinHash = hashPin(pin, salt), pinSalt = salt, pinLen = pin.length) }
}

/** Full-screen PIN pad shown when the app opens (and when it comes back after being away). */
@Composable
fun PinScreen(c: PlayerController, onUnlocked: () -> Unit) {
    val d = c.store.data
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    fun press(ch: String) {
        if (pin.length >= d.pinLen) return
        wrong = false
        pin += ch
        if (pin.length == d.pinLen) {
            if (pinMatches(d, pin)) onUnlocked() else { wrong = true; pin = "" }
        }
    }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    // fingerprint / face: asked for straight away, and again with the button below
    androidx.compose.runtime.LaunchedEffect(d.pinBio) { if (d.pinBio) promptBiometric(ctx, onUnlocked) }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
    ) {
        Icon(Icons.Rounded.Lock, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
        Text("Enter your PIN", Modifier.padding(top = 12.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(Modifier.padding(vertical = 22.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            repeat(d.pinLen) { i ->
                Box(
                    Modifier.size(16.dp).clip(CircleShape)
                        .background(if (i < pin.length) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f)),
                )
            }
        }
        Text(if (wrong) "Wrong PIN, try again" else " ", color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 10.dp))
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "<")).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.padding(vertical = 7.dp)) {
                row.forEach { k ->
                    Box(
                        Modifier.size(72.dp).clip(CircleShape)
                            .background(if (k.isEmpty()) Color.Transparent else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .clickable(enabled = k.isNotEmpty()) { if (k == "<") { pin = pin.dropLast(1); wrong = false } else press(k) },
                        contentAlignment = Alignment.Center,
                    ) {
                        if (k == "<") Icon(Icons.Rounded.Backspace, "Delete")
                        else Text(k, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        if (d.pinBio) androidx.compose.material3.TextButton({ promptBiometric(ctx, onUnlocked) }, Modifier.padding(top = 8.dp)) { Text("Use fingerprint") }
    }
}

/** The phone's own fingerprint / face prompt (the framework one, no extra library). Calls [onOk] when it succeeds; does nothing if it is unavailable or cancelled. */
fun promptBiometric(ctx: android.content.Context, onOk: () -> Unit) {
    try {
        val exec = androidx.core.content.ContextCompat.getMainExecutor(ctx)
        val prompt = android.hardware.biometrics.BiometricPrompt.Builder(ctx)
            .setTitle("Unlock Aurora")
            .setNegativeButton("Use PIN", exec) { _, _ -> }
            .build()
        prompt.authenticate(android.os.CancellationSignal(), exec, object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) { onOk() }
        })
    } catch (_: Throwable) {}
}

/** Asks for digits; [onSubmit] returns an error text to keep the dialog open, or null when it worked. */
@Composable
private fun PinEntryDialog(title: String, label: String, onDismiss: () -> Unit, onSubmit: (String) -> String?) {
    var text by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    text, { text = it.filter { ch -> ch.isDigit() }.take(8); err = null },
                    label = { Text(label) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    isError = err != null, modifier = Modifier.fillMaxWidth(),
                )
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp)) }
            }
        },
        confirmButton = { TextButton({ err = onSubmit(text) }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun PrivacyPage(c: PlayerController) {
    val d = c.store.data
    // which step is open: "new", "repeat", "verifyChange", "verifyRemove"
    var step by remember { mutableStateOf("") }
    var first by remember { mutableStateOf("") }
    Section("Pocket guard")
    SwitchRow("Pocket guard", "Blocks touches while the phone is covered (in a pocket or bag) so nothing is pressed by accident", d.pocketGuard) { v -> c.store.update { it.copy(pocketGuard = v) } }
    Section("PIN lock")
    Text(
        "Aurora asks for a PIN when it opens, and again when you come back after being away. Music keeps playing while it is locked.",
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (d.pinHash.isEmpty()) {
        ActionRow("Set a PIN", "4 to 8 digits") { step = "new" }
    } else {
        ActionRow("Change PIN", "You will be asked for the current one first") { step = "verifyChange" }
        ActionRow("Remove PIN", "Turns the lock off") { step = "verifyRemove" }
        SwitchRow("Unlock with fingerprint", "Use the phone's fingerprint or face unlock instead of typing the PIN (the PIN stays as a back-up)", d.pinBio) { v -> c.store.update { it.copy(pinBio = v) } }
        ChipRow("Ask again after being away for") {
            listOf(0 to "Right away", 30 to "30 s", 120 to "2 min", 600 to "10 min").forEach { (sec, label) ->
                FilterChip(d.pinRelockSec == sec, { c.store.update { it.copy(pinRelockSec = sec) } }, label = { Text(label) })
                androidx.compose.foundation.layout.Spacer(Modifier.size(6.dp))
            }
        }
        Text(
            "There is no way to get a forgotten PIN back. If it happens, the only way in is to clear Aurora's data in the phone's app settings, which also deletes your settings (a backup file keeps them).",
            Modifier.padding(horizontal = 24.dp, vertical = 10.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    when (step) {
        "new" -> PinEntryDialog("New PIN", "4 to 8 digits", { step = "" }) { v ->
            if (v.length < 4) "Use at least 4 digits" else { first = v; step = "repeat"; null }
        }
        "repeat" -> PinEntryDialog("Repeat the PIN", "Same digits again", { step = "" }) { v ->
            if (v != first) "The two PINs are not the same" else { setPin(c, v); first = ""; step = ""; null }
        }
        "verifyChange" -> PinEntryDialog("Current PIN", "Enter the PIN you use now", { step = "" }) { v ->
            if (pinMatches(d, v)) { step = "new"; null } else "Wrong PIN"
        }
        "verifyRemove" -> PinEntryDialog("Remove the PIN", "Enter the current PIN", { step = "" }) { v ->
            if (pinMatches(d, v)) { c.store.update { it.copy(pinHash = "", pinSalt = "") }; step = ""; null } else "Wrong PIN"
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Saved themes and the day / night schedule
// ---------------------------------------------------------------------------------------------

@Composable
fun ThemesPage(c: PlayerController) {
    val d = c.store.data
    var nameDlg by remember { mutableStateOf(false) }
    Section("Saved themes")
    Text(
        "Set the theme and accent colour you like in Theme and colours, then save it here. You can apply a saved theme with one tap or let the schedule switch between two of them.",
        Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    d.themePresets.forEach { p ->
        Row(Modifier.cardRow().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(28.dp).clip(CircleShape)
                    .background(if (p.accent != 0L) Color(p.accent) else MaterialTheme.colorScheme.primary),
            )
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(p.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(MODE_NAMES.getOrElse(p.mode) { "System" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            TextButton({ c.store.update { it.copy(themeMode = p.mode, accentColor = p.accent) } }) { Text("Apply") }
            TextButton({ c.store.update { it.copy(themePresets = it.themePresets.filter { x -> x.name != p.name }) } }) { Text("Delete") }
        }
    }
    ActionRow("Save the current look as a theme", "Light / dark / black and the accent colour you use now") { nameDlg = true }

    Section("Day and night")
    SwitchRow("Switch themes by time of day", "Uses your day theme in the daytime and your night theme in the evening", d.themeSchedule) { v ->
        c.store.update { it.copy(themeSchedule = v) }
    }
    if (d.themeSchedule) {
        if (d.themePresets.isEmpty()) Text("Save a theme first, then pick it here.", Modifier.padding(horizontal = 24.dp, vertical = 6.dp), color = MaterialTheme.colorScheme.error)
        ChipRow("Day theme") {
            d.themePresets.forEach { p ->
                FilterChip(d.dayTheme == p.name, { c.store.update { it.copy(dayTheme = p.name) } }, label = { Text(p.name) })
                androidx.compose.foundation.layout.Spacer(Modifier.size(6.dp))
            }
        }
        ChipRow("Night theme") {
            d.themePresets.forEach { p ->
                FilterChip(d.nightTheme == p.name, { c.store.update { it.copy(nightTheme = p.name) } }, label = { Text(p.name) })
                androidx.compose.foundation.layout.Spacer(Modifier.size(6.dp))
            }
        }
        SliderSetting("Day starts at", d.dayStartHour.toFloat(), 0f..23f, 22, "%02d:00".format(d.dayStartHour)) { v ->
            c.store.update { it.copy(dayStartHour = v.roundToInt().coerceIn(0, 23)) }
        }
        SliderSetting("Night starts at", d.nightStartHour.toFloat(), 0f..23f, 22, "%02d:00".format(d.nightStartHour)) { v ->
            c.store.update { it.copy(nightStartHour = v.roundToInt().coerceIn(0, 23)) }
        }
    }
    if (nameDlg) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { nameDlg = false },
            title = { Text("Name this theme") },
            text = { OutlinedTextField(name, { name = it.take(24) }, singleLine = true, label = { Text("For example Night blue") }) },
            confirmButton = {
                TextButton({
                    val n = name.trim().ifEmpty { "Theme ${d.themePresets.size + 1}" }
                    c.store.update { s -> s.copy(themePresets = s.themePresets.filter { it.name != n } + ThemePreset(n, s.themeMode, s.accentColor)) }
                    nameDlg = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton({ nameDlg = false }) { Text("Cancel") } },
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Alarms and Bluetooth auto-play
// ---------------------------------------------------------------------------------------------

/** A short note in a soft rounded card, with an info icon. */
@Composable
private fun InfoCard(text: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)).padding(14.dp),
        verticalAlignment = Alignment.Top,
    ) {
        androidx.compose.material3.Icon(Icons.Rounded.Info, null, Modifier.size(20.dp).padding(top = 1.dp), tint = MaterialTheme.colorScheme.primary)
        Text(text, Modifier.padding(start = 12.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private val DAY_LETTERS = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

private fun daysText(mask: Int) =
    if (mask == 0 || mask == 127) "Every day" else DAY_LETTERS.filterIndexed { i, _ -> ((mask shr i) and 1) == 1 }.joinToString(", ")

private fun playlistName(d: Persisted, id: String) = when (id) {
    "" -> "All songs"
    "fav" -> "Favourites"
    else -> if (id.startsWith("q:")) "Queue: " + (d.queues.getOrNull(id.removePrefix("q:").toIntOrNull() ?: -1)?.name ?: "missing") else d.playlists.firstOrNull { it.id == id }?.name ?: "Missing playlist"
}

@Composable
private fun PlaylistChips(d: Persisted, selected: String, onPick: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        FilterChip(selected == "", { onPick("") }, label = { Text("All songs") })
        FilterChip(selected == "fav", { onPick("fav") }, label = { Text("Favourites") })
        d.playlists.forEach { p -> FilterChip(selected == p.id, { onPick(p.id) }, label = { Text(p.name, maxLines = 1) }) }
    }
    Text("Or continue a queue", Modifier.padding(top = 8.dp, bottom = 4.dp), style = MaterialTheme.typography.labelMedium)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        d.queues.forEachIndexed { i, q -> FilterChip(selected == "q:$i", { onPick("q:$i") }, label = { Text(q.name, maxLines = 1) }) }
    }
}

/** Bluetooth auto-play: lives in Sound settings. */
@Composable
fun BluetoothAutoPlay(c: PlayerController) {
    val ctx = LocalContext.current
    val d = c.store.data
    var editRule by remember { mutableStateOf<Pair<Int, BtRule>?>(null) } // index (-1 = new) and the rule

    Section("Bluetooth auto-play")
    InfoCard("When a device you list here connects, Aurora starts the playlist you choose.")
    InfoCard("Tip: if Aurora was swiped away, Android may not let it start music by itself. It works best while Aurora is still in your recent apps or playing.")
    if (Build.VERSION.SDK_INT >= 31) {
        var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
        if (!granted) ActionRow("Allow Bluetooth access", "Android needs this so Aurora can notice a device connecting") { launcher.launch(Manifest.permission.BLUETOOTH_CONNECT) }
    }
    d.btRules.forEachIndexed { i, r ->
        ActionRow(r.device, "Plays: ${playlistName(d, r.playlistId)}" + if (r.shuffle && !r.playlistId.startsWith("q:")) " (Shuffled)" else "") { editRule = i to r }
    }
    ActionRow("Add a device", "Choose a headphone, speaker or car and the playlist to start") { editRule = -1 to BtRule("", "", true) }


    editRule?.let { (index, r) ->
        var name by remember(index) { mutableStateOf(r.device) }
        var pl by remember(index) { mutableStateOf(r.playlistId) }
        var shuffle by remember(index) { mutableStateOf(r.shuffle) }
        val connected = remember { Automation.connectedBluetooth(ctx) }
        AlertDialog(
            onDismissRequest = { editRule = null },
            title = { Text(if (index >= 0) "Edit device" else "Add a device") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(name, { name = it }, label = { Text("Device name, as shown in Bluetooth settings") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (connected.isNotEmpty()) {
                        Text("Connected now", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelMedium)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            connected.forEach { n -> FilterChip(name == n, { name = n }, label = { Text(n, maxLines = 1) }) }
                        }
                    }
                    Text("Playlist to start", Modifier.padding(top = 10.dp))
                    PlaylistChips(d, pl) { pl = it }
                    if (!pl.startsWith("q:")) Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Shuffle", Modifier.weight(1f))
                        Switch(shuffle, { shuffle = it })
                    }
                }
            },
            confirmButton = {
                TextButton({
                    if (name.isNotBlank()) {
                        val n = BtRule(name.trim(), pl, shuffle)
                        c.store.update { s -> s.copy(btRules = if (index >= 0) s.btRules.mapIndexed { i, x -> if (i == index) n else x } else s.btRules + n) }
                    }
                    editRule = null
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    if (index >= 0) TextButton({ c.store.update { s -> s.copy(btRules = s.btRules.filterIndexed { i, _ -> i != index }) }; editRule = null }) { Text("Delete") }
                    TextButton({ editRule = null }) { Text("Cancel") }
                }
            },
        )
    }
}

object AlarmsUi {
    var showSettings by androidx.compose.runtime.mutableStateOf(false)
    var addRequest by androidx.compose.runtime.mutableIntStateOf(0)
}

@Composable
fun AlarmsPage(c: PlayerController) {
    val ctx = LocalContext.current
    val d = c.store.data
    var editAlarm by remember { mutableStateOf<AlarmItem?>(null) }
    // the round "+" button in the settings screen asks for a new alarm
    val addReq = AlarmsUi.addRequest
    var lastAdd by remember { mutableIntStateOf(addReq) }
    androidx.compose.runtime.LaunchedEffect(addReq) { if (addReq != lastAdd) { lastAdd = addReq; editAlarm = AlarmItem(UUID.randomUUID().toString(), 7, 0) } }

    fun saveAlarms(list: List<AlarmItem>) {
        d.alarms.filter { old -> list.none { it.id == old.id } }.forEach { Automation.cancel(ctx, it) }
        c.store.update { it.copy(alarms = list) }
        Automation.schedule(ctx, list)
    }

    // keeps the "rings in ..." texts fresh
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    androidx.compose.runtime.LaunchedEffect(Unit) { while (true) { kotlinx.coroutines.delay(20_000); nowMs = System.currentTimeMillis() } }
    val cs = MaterialTheme.colorScheme
    val on = d.alarms.filter { it.enabled }
    val soonest = on.minByOrNull { Automation.nextTrigger(it, nowMs) }

    // header: the next alarm at a glance
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(28.dp))
            .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(cs.primaryContainer, cs.tertiaryContainer)))
            .padding(horizontal = 22.dp, vertical = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Alarm, null, Modifier.size(20.dp), tint = cs.onPrimaryContainer)
            Text("  Next alarm", style = MaterialTheme.typography.labelLarge, color = cs.onPrimaryContainer)
        }
        if (soonest == null) {
            Text("No alarm is on", Modifier.padding(top = 6.dp), fontSize = 26.sp, fontWeight = FontWeight.Light, color = cs.onPrimaryContainer)
            Text("Add one below to wake up to your music", style = MaterialTheme.typography.bodyMedium, color = cs.onPrimaryContainer.copy(alpha = 0.75f))
        } else {
            Text("Rings in ${Automation.ringsIn(Automation.nextTrigger(soonest, nowMs) - nowMs)}", Modifier.padding(top = 6.dp), fontSize = 26.sp, fontWeight = FontWeight.Light, color = cs.onPrimaryContainer)
            Text(String.format("%02d:%02d", soonest.hour, soonest.minute) + " · " + playlistName(d, soonest.playlistId), style = MaterialTheme.typography.bodyMedium, color = cs.onPrimaryContainer.copy(alpha = 0.75f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }

    if (d.alarms.isEmpty()) {
        Text("No alarms yet", Modifier.fillMaxWidth().padding(top = 18.dp), textAlign = TextAlign.Center, color = cs.onSurfaceVariant)
    }
    d.alarms.forEach { a ->
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clip(RoundedCornerShape(24.dp))
                .background(if (a.enabled) cs.surfaceContainerHigh else cs.surfaceContainerLow).clickable { editAlarm = a }.padding(horizontal = 20.dp, vertical = 14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("%02d:%02d".format(a.hour, a.minute), fontSize = 40.sp, fontWeight = FontWeight.Light, color = if (a.enabled) cs.onSurface else cs.onSurface.copy(alpha = 0.45f))
                Spacer(Modifier.weight(1f))
                Switch(a.enabled, { v -> saveAlarms(d.alarms.map { if (it.id == a.id) it.copy(enabled = v, onceAt = if (v && it.once) Automation.tomorrowAt(it) else it.onceAt) else it }) })
            }
            Text(playlistName(d, a.playlistId) + if (a.shuffle && !a.playlistId.startsWith("q:")) " · Shuffled" else "", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (a.once) Text("Tomorrow only", style = MaterialTheme.typography.labelLarge, color = cs.primary)
                else DAY_LETTERS.forEachIndexed { i, n ->
                    val sel = a.days == 0 || ((a.days shr i) and 1) == 1
                    Box(Modifier.padding(end = 5.dp).size(28.dp).clip(androidx.compose.foundation.shape.CircleShape).background(if (sel && a.enabled) cs.primary else if (sel) cs.outline.copy(alpha = 0.35f) else Color.Transparent), contentAlignment = Alignment.Center) {
                        Text(n.take(1), fontSize = 12.sp, color = if (sel && a.enabled) cs.onPrimary else cs.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.weight(1f))
                if (a.enabled) Text("Rings in ${Automation.ringsIn(Automation.nextTrigger(a, nowMs) - nowMs)}", style = MaterialTheme.typography.labelMedium, color = cs.primary)
            }
            val snoozeAt = Automation.snoozeUntil(LocalContext.current)[a.id] ?: 0L
            if (snoozeAt > nowMs) Text(
                "Snoozed: rings again at " + java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(snoozeAt)) + " (in " + Automation.ringsIn(snoozeAt - nowMs) + ")",
                Modifier.padding(top = 6.dp), style = MaterialTheme.typography.labelLarge, color = cs.tertiary,
            )
        }
    }

    if (AlarmsUi.showSettings) androidx.compose.ui.window.Dialog(onDismissRequest = { AlarmsUi.showSettings = false }) {
        androidx.compose.material3.Surface(shape = RoundedCornerShape(28.dp), color = cs.surface, tonalElevation = 6.dp) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 12.dp)) {
                Text("Alarm settings", Modifier.padding(start = 24.dp, top = 20.dp, bottom = 4.dp), style = MaterialTheme.typography.titleLarge)
                AlarmSettingCards(c)
                androidx.compose.material3.TextButton({ AlarmsUi.showSettings = false }, Modifier.align(Alignment.End).padding(end = 12.dp)) { Text("Done") }
            }
        }
    }

    editAlarm?.let { a ->
        var hour by remember(a.id) { mutableIntStateOf(a.hour) }
        var minute by remember(a.id) { mutableIntStateOf(a.minute) }
        var pl by remember(a.id) { mutableStateOf(a.playlistId) }
        var days by remember(a.id) { mutableIntStateOf(a.days) }
        var shuffle by remember(a.id) { mutableStateOf(a.shuffle) }
        var once by remember(a.id) { mutableStateOf(a.once) }
        val exists = d.alarms.any { it.id == a.id }
        // a new alarm starts with the clock dial, like the phone's own Clock app
        var stepTime by remember(a.id) { mutableStateOf(!exists) }
        if (stepTime) {
            AlarmTimeDialog(hour, minute, onCancel = { if (exists) stepTime = false else editAlarm = null }) { h, m -> hour = h; minute = m; stepTime = false }
        } else AlertDialog(
            onDismissRequest = { editAlarm = null },
            title = { Text(if (exists) "Edit alarm" else "New alarm") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(
                        "%02d:%02d".format(hour, minute),
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { stepTime = true }.padding(vertical = 6.dp),
                        fontSize = 48.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.primary,
                    )
                    Text("Tap the time to change it", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    // live preview of when it will ring
                    run {
                        val probe = AlarmItem(a.id, hour, minute, pl, if (once) 0 else days, shuffle, true, once, 0L)
                        val left = Automation.nextTrigger(probe, nowMs) - nowMs
                        Text("Rings in ${Automation.ringsIn(left)}", Modifier.fillMaxWidth().padding(top = 4.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Tomorrow")
                            Text("Rings once, tomorrow at this time, then switches off", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(once, { once = it })
                    }
                    Text("Playlist", Modifier.padding(top = 10.dp))
                    PlaylistChips(d, pl) { pl = it }
                    if (!once) Text("Repeat on", Modifier.padding(top = 10.dp))
                    if (!once) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        DAY_LETTERS.forEachIndexed { i, n ->
                            val on = days == 0 || ((days shr i) and 1) == 1
                            FilterChip(on, {
                                // 0 means "every day", so turning one day off first expands it to all seven
                                val cur = if (days == 0) 127 else days
                                val nxt = cur xor (1 shl i)
                                days = if (nxt == 0 || nxt == 127) 0 else nxt
                            }, label = { Text(n) })
                        }
                    }
                    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Shuffle", Modifier.weight(1f))
                        Switch(shuffle, { shuffle = it })
                    }
                }
            },
            confirmButton = {
                TextButton({
                    val base = a.copy(hour = hour, minute = minute, playlistId = pl, days = days, shuffle = shuffle, enabled = true, once = once)
                    val n = if (once) base.copy(onceAt = Automation.tomorrowAt(base)) else base.copy(onceAt = 0L)
                    saveAlarms(if (exists) d.alarms.map { if (it.id == a.id) n else it } else d.alarms + n)
                    android.widget.Toast.makeText(ctx, "Alarm rings in " + Automation.ringsIn(Automation.nextTrigger(n) - System.currentTimeMillis()), android.widget.Toast.LENGTH_LONG).show()
                    editAlarm = null
                }) { Text("Save") }
            },
            dismissButton = {
                Row {
                    if (exists) TextButton({ saveAlarms(d.alarms.filter { it.id != a.id }); editAlarm = null }) { Text("Delete") }
                    TextButton({ editAlarm = null }) { Text("Cancel") }
                }
            },
        )
    }
}

/** The clock-dial time picker (with a keyboard toggle), as in Android's Clock app. */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
internal fun AlarmTimeDialog(hour: Int, minute: Int, onCancel: () -> Unit, onOk: (Int, Int) -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val state = androidx.compose.material3.rememberTimePickerState(hour, minute, android.text.format.DateFormat.is24HourFormat(ctx))
    var keyboard by remember { mutableStateOf(false) }
    androidx.compose.ui.window.Dialog(onDismissRequest = onCancel, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        androidx.compose.material3.Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh, tonalElevation = 6.dp) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Select time", Modifier.fillMaxWidth().padding(bottom = 18.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (keyboard) androidx.compose.material3.TimeInput(state) else androidx.compose.material3.TimePicker(state)
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.material3.IconButton({ keyboard = !keyboard }) {
                        Icon(if (keyboard) Icons.Rounded.Schedule else Icons.Rounded.Keyboard, if (keyboard) "Dial" else "Keyboard")
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onCancel) { Text("Cancel") }
                    TextButton({ onOk(state.hour, state.minute) }) { Text("OK") }
                }
            }
        }
    }
}


@Composable
private fun AlarmSettingCards(c: PlayerController) {
    val ctx = LocalContext.current
    val d = c.store.data
    val cs = MaterialTheme.colorScheme
    // snooze length and counting
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(22.dp)).background(cs.surfaceContainer).padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text("Snooze for", style = MaterialTheme.typography.titleSmall)
        Text("Tap Snooze, swipe up or press the power button on the alarm screen; the alarm rings again after this long.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1, 5, 10, 15, 20, 30).forEach { m ->
                androidx.compose.material3.FilterChip(d.alarmSnoozeMin == m, { c.store.update { it.copy(alarmSnoozeMin = m) } }, label = { Text("$m min") })
            }
        }
        Text("Power button while ringing", Modifier.padding(top = 10.dp), style = MaterialTheme.typography.titleSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            var power by remember { mutableStateOf(Automation.powerAction(ctx)) }
            listOf(1 to "Snooze", 2 to "Stop alarm", 0 to "Do nothing").forEach { (v, n) ->
                androidx.compose.material3.FilterChip(power == v, { power = v; Automation.setPowerAction(ctx, v) }, label = { Text(n) })
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Don't count songs played by alarms")
                Text("They stay out of play counts, most played and year in review", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            Switch(d.skipAlarmCounts, { v -> c.store.update { it.copy(skipAlarmCounts = v) } })
        }
    }

    // the phone's own alarm volume
    run {
        val am = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
        val max = remember { am.getStreamMaxVolume(android.media.AudioManager.STREAM_ALARM).coerceAtLeast(1) }
        var vol by remember { mutableStateOf(am.getStreamVolume(android.media.AudioManager.STREAM_ALARM).toFloat()) }
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clip(RoundedCornerShape(22.dp)).background(cs.surfaceContainer).padding(horizontal = 18.dp, vertical = 12.dp)) {
            Text("Alarm volume", style = MaterialTheme.typography.titleSmall)
            Text("The same volume as your phone's alarm clock. Alarms never use the media volume.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Alarm, null, Modifier.size(18.dp), tint = cs.primary)
                androidx.compose.material3.Slider(
                    vol, { v -> vol = v; try { am.setStreamVolume(android.media.AudioManager.STREAM_ALARM, v.toInt(), 0) } catch (_: Throwable) {} },
                    Modifier.weight(1f).padding(start = 8.dp), valueRange = 0f..max.toFloat(), steps = (max - 1).coerceAtLeast(0),
                )
            }
        }
    }

}
