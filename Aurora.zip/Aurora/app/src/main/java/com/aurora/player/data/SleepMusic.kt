package com.aurora.player.data

/**
 * Picks songs that are likely to help you fall asleep: slow tempo (around a resting heartbeat), low energy, no sudden loudness,
 * and calm genres or titles. The tempo scan in Settings makes it much more accurate; without it only genre, title and length are used.
 */
object SleepMusic {
    private val calmGenres = listOf("ambient", "classical", "piano", "new age", "instrumental", "sleep", "meditation", "relax", "lullaby", "acoustic", "lo-fi", "lofi", "chill", "soundtrack", "nature", "easy listening", "jazz")
    private val calmWords = listOf("sleep", "lullaby", "calm", "relax", "dream", "night", "rain", "ocean", "peace", "slow", "quiet", "soft", "moon", "lofi", "lo-fi", "meditation", "piano")
    private val loudWords = listOf("remix", "club", "party", "workout", "hardstyle", "metal", "rock", "trap", "drill", "bass boosted", "nightcore")

    /** 0..100, higher = more sleep friendly. */
    fun score(t: Track, bpm: Int?, energy: Int?): Int {
        var s = 0f
        var weight = 0f
        if (bpm != null && bpm > 0) {
            // 45-70 BPM is ideal; falls off towards 100
            s += when { bpm <= 45 -> 70f; bpm <= 72 -> 100f; bpm <= 90 -> 100f - (bpm - 72) * 3f; bpm <= 110 -> 46f - (bpm - 90) * 2f; else -> 0f }.coerceAtLeast(0f) * 0.4f
            weight += 0.4f
        }
        if (energy != null) {
            s += (100 - energy).coerceIn(0, 100) * 0.4f
            weight += 0.4f
        }
        val g = t.genre.lowercase()
        val name = (t.title + " " + t.album).lowercase()
        var text = 40f
        if (calmGenres.any { it in g }) text += 40f
        if (calmWords.any { it in name }) text += 20f
        if (loudWords.any { it in name || it in g }) text -= 45f
        if (t.durationMs in 150_000..600_000) text += 10f else if (t.durationMs < 90_000) text -= 20f
        s += text.coerceIn(0f, 100f) * 0.2f
        weight += 0.2f
        // with no scan only the text part counts, so scale it up and be a bit stricter
        return if (weight >= 0.6f) (s / weight).toInt().coerceIn(0, 100) else (text.coerceIn(0f, 100f) * 0.85f).toInt()
    }

    /** The best matches, calmest first. */
    fun pick(library: List<Track>, bpm: Map<Long, Int>, energy: Map<Long, Int>, limit: Int = 60, minScore: Int = 62): List<Track> =
        library.map { it to score(it, bpm[it.id], energy[it.id]) }
            .filter { it.second >= minScore }
            .sortedByDescending { it.second }
            .take(limit).map { it.first }
}
