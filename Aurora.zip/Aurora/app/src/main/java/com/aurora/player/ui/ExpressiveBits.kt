package com.aurora.player.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

/** Long text scrolls sideways only when it does not fit. Off = unchanged. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.marqueeIf(on: Boolean): Modifier = if (on) this.basicMarquee(iterations = Int.MAX_VALUE) else this

/**
 * A seek bar drawn as a wave: it ripples while the song plays and flattens when paused.
 * [onChange] reports the position while dragging; [onDone] fires when the finger lifts or taps.
 */
@Composable
fun SquigglySeek(
    value: Float, max: Float, playing: Boolean, color: Color, trackColor: Color,
    onChange: (Float) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier,
    oneUi: Boolean = false,
) {
    val amp by animateFloatAsState(if (playing) 1f else 0f, tween(600), label = "waveAmp")
    var dragging by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (dragging) 1f else 0f, tween(180), label = "waveGrow")
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(if (oneUi) 1800 else 2200, easing = LinearEasing), RepeatMode.Restart), label = "wavePhase")
    Canvas(
        modifier.fillMaxWidth().height(if (oneUi) 34.dp else 44.dp)
            .pointerInput(max) { detectTapGestures { p -> onChange((p.x / size.width * max).coerceIn(0f, max)); onDone() } }
            .pointerInput(max) {
                detectHorizontalDragGestures(
                    onDragStart = { p -> dragging = true; onChange((p.x / size.width * max).coerceIn(0f, max)) },
                    onDragEnd = { dragging = false; onDone() }, onDragCancel = { dragging = false; onDone() },
                ) { change, _ -> change.consume(); onChange((change.position.x / size.width * max).coerceIn(0f, max)) }
            },
    ) {
        val w = size.width; val h = size.height; val mid = h / 2
        val pad = 10.dp.toPx()                      // room for the round thumb at both ends
        val span = (w - 2 * pad).coerceAtLeast(1f)
        val x = pad + (value / max.coerceAtLeast(1f)).coerceIn(0f, 1f) * span
        if (oneUi) {
            // thin style: a ripple that swells in the middle of the played part and calms to a flat line at both ends,
            // a thin line for what is left, and a round handle with a white rim
            val stroke = 3.dp.toPx()
            val r = (10f + 2f * grow).dp.toPx()
            val rim = 3.dp.toPx()
            val a = 5.dp.toPx() * amp
            val len = 15.dp.toPx()
            val end = (x - r).coerceAtLeast(pad)
            val ripple = Path()
            fun yAt(px: Float): Float {
                val span2 = (end - pad).coerceAtLeast(1f)
                val env = sin(PI.toFloat() * ((px - pad) / span2).coerceIn(0f, 1f))
                return mid + a * env * sin((px - pad) / len * 2f * PI.toFloat() - phase)
            }
            if (x + r < w - pad) drawLine(trackColor, Offset(x + r, mid), Offset(w - pad, mid), strokeWidth = stroke, cap = StrokeCap.Round)
            var px = pad
            ripple.moveTo(pad, yAt(pad))
            while (px < end) { px = (px + 1.5f).coerceAtMost(end); ripple.lineTo(px, yAt(px)) }
            if (end < x) ripple.lineTo(x, mid)
            drawPath(ripple, color, style = Stroke(stroke, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            drawCircle(Color.White, r, Offset(x, mid))
            drawCircle(color, r - rim, Offset(x, mid))
        } else {
            val waveStroke = 4.5.dp.toPx()
            val thumbW = (4f - 1.5f * grow).dp.toPx()            // the handle slims down while you hold it
            val thumbH = (22f + 6f * grow).dp.toPx()
            val gap = thumbW / 2 + 6.dp.toPx()
            val a = (3.6f - 1.2f * grow).dp.toPx() * amp          // the ripple eases off a little while you drag
            val len = 36.dp.toPx()
            val taper = 18.dp.toPx()
            val settle = 14.dp.toPx()
            val end = (x - gap).coerceAtLeast(pad)
            // the part still to play: a soft, rounded line with a small dot at its far end
            if (x + gap < w - pad) {
                drawLine(trackColor, Offset(x + gap, mid), Offset(w - pad, mid), strokeWidth = waveStroke, cap = StrokeCap.Round)
                drawCircle(color, 2.2.dp.toPx(), Offset(w - pad, mid))
            }
            // the part already played: an even wave that fades in from the left, flows towards the handle and settles flat just before it
            fun yAt(px: Float): Float {
                val k = ((end - px) / taper).coerceIn(0f, 1f).let { it * it * (3f - 2f * it) } *
                    ((px - pad) / settle).coerceIn(0f, 1f).let { it * it * (3f - 2f * it) }       // smoothstep both ends
                return mid + a * k * sin((px - pad) / len * 2f * PI.toFloat() - phase)
            }
            val wave = Path()
            var px = pad
            wave.moveTo(pad, yAt(pad))
            while (px < end) { px = (px + 1f).coerceAtMost(end); wave.lineTo(px, yAt(px)) }
            if (end < x - gap + 0.5f) wave.lineTo(x - gap, mid)
            drawPath(wave, color.copy(alpha = 0.22f), style = Stroke(waveStroke + 5.dp.toPx() * grow, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            drawPath(wave, color, style = Stroke(waveStroke, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            // handle: a tall rounded bar with a soft halo
            if (grow > 0.01f) drawCircle(color.copy(alpha = 0.16f * grow), 18.dp.toPx(), Offset(x, mid))
            drawRoundRect(color, Offset(x - thumbW / 2, mid - thumbH / 2), androidx.compose.ui.geometry.Size(thumbW, thumbH), androidx.compose.ui.geometry.CornerRadius(thumbW / 2))
        }
    }
}

/** "FLAC • 96 kHz • 1024 kbps": what is really being played. Tap to open the song info. */
@Composable
fun AudioSpecPill(c: PlayerController, t: Track, onClick: () -> Unit) {
    val spec by produceState("", t.id, c.isPlaying) {
        // the decoder reports its format a moment after the song starts
        for (wait in longArrayOf(0, 400, 1200)) {
            delay(wait)
            val f = try { c.player.audioFormat } catch (_: Throwable) { null }
            val ext = t.path.substringAfterLast('.', "").uppercase().ifEmpty { "AUDIO" }
            val parts = ArrayList<String>()
            parts.add(ext)
            val rate = f?.sampleRate?.takeIf { it > 0 }
            if (rate != null) parts.add(if (rate % 1000 == 0) "${rate / 1000} kHz" else "%.1f kHz".format(rate / 1000.0))
            val kbps = f?.bitrate?.takeIf { it > 0 }?.let { it / 1000 }
                ?: if (t.durationMs > 0 && t.size > 0) (t.size * 8 / t.durationMs).toInt() else null
            if (kbps != null && kbps > 0) parts.add("$kbps kbps")
            value = parts.joinToString(" • ")
            if (rate != null) break
        }
    }
    if (spec.isNotEmpty()) Box(
        Modifier.padding(top = 8.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) { Text(spec, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}
