package com.aurora.player.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext

private val AuroraDark = darkColorScheme(
    primary = Color(0xFFB4A8FF),
    onPrimary = Color(0xFF1E1550),
    secondary = Color(0xFF7FE3D0),
    background = Color(0xFF0F0D1A),
    surface = Color(0xFF151222),
    surfaceVariant = Color(0xFF241F38),
    onSurface = Color(0xFFEAE6FF),
    onSurfaceVariant = Color(0xFFB9B3D6),
)

private val AuroraLight = lightColorScheme(
    primary = Color(0xFF5B49D6),
    secondary = Color(0xFF00796B),
    background = Color(0xFFFBF9FF),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFEAE6F7),
)

/** A full colour scheme built from one accent colour, so nothing keeps the wallpaper's (e.g. purple) tint. */
private fun accentScheme(a: Color, dark: Boolean): androidx.compose.material3.ColorScheme {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(android.graphics.Color.argb(255, (a.red * 255).toInt(), (a.green * 255).toInt(), (a.blue * 255).toInt()), hsv)
    val h = hsv[0]
    val h2 = (h + 60f) % 360f
    fun t(s: Float, l: Float) = Color.hsl(h, s, l)
    fun t2(s: Float, l: Float) = Color.hsl(h2, s, l)
    val onP = if (a.luminance() > 0.5f) Color.Black else Color.White
    return if (!dark) androidx.compose.material3.lightColorScheme(
        primary = a, onPrimary = onP, primaryContainer = t(0.75f, 0.90f), onPrimaryContainer = t(0.9f, 0.12f),
        secondary = t(0.30f, 0.38f), onSecondary = Color.White, secondaryContainer = t(0.40f, 0.90f), onSecondaryContainer = t(0.5f, 0.12f),
        tertiary = t2(0.35f, 0.40f), onTertiary = Color.White, tertiaryContainer = t2(0.45f, 0.90f), onTertiaryContainer = t2(0.6f, 0.12f),
        background = t(0.25f, 0.985f), onBackground = t(0.15f, 0.10f), surface = t(0.25f, 0.985f), onSurface = t(0.15f, 0.10f),
        surfaceVariant = t(0.30f, 0.90f), onSurfaceVariant = t(0.15f, 0.30f), outline = t(0.10f, 0.46f), outlineVariant = t(0.20f, 0.80f),
        surfaceTint = a, inverseSurface = t(0.15f, 0.20f), inverseOnSurface = t(0.20f, 0.95f), inversePrimary = t(0.80f, 0.75f),
        surfaceContainerLowest = Color.White, surfaceContainerLow = t(0.30f, 0.96f), surfaceContainer = t(0.30f, 0.94f),
        surfaceContainerHigh = t(0.30f, 0.92f), surfaceContainerHighest = t(0.30f, 0.90f),
    ) else androidx.compose.material3.darkColorScheme(
        primary = a, onPrimary = onP, primaryContainer = t(0.55f, 0.28f), onPrimaryContainer = t(0.9f, 0.90f),
        secondary = t(0.30f, 0.75f), onSecondary = t(0.4f, 0.15f), secondaryContainer = t(0.30f, 0.26f), onSecondaryContainer = t(0.5f, 0.90f),
        tertiary = t2(0.40f, 0.75f), onTertiary = t2(0.5f, 0.15f), tertiaryContainer = t2(0.35f, 0.28f), onTertiaryContainer = t2(0.6f, 0.90f),
        background = t(0.15f, 0.08f), onBackground = t(0.10f, 0.92f), surface = t(0.15f, 0.08f), onSurface = t(0.10f, 0.92f),
        surfaceVariant = t(0.15f, 0.24f), onSurfaceVariant = t(0.15f, 0.78f), outline = t(0.10f, 0.56f), outlineVariant = t(0.15f, 0.30f),
        surfaceTint = a, inverseSurface = t(0.10f, 0.90f), inverseOnSurface = t(0.15f, 0.20f), inversePrimary = t(0.75f, 0.40f),
        surfaceContainerLowest = t(0.15f, 0.05f), surfaceContainerLow = t(0.15f, 0.10f), surfaceContainer = t(0.15f, 0.12f),
        surfaceContainerHigh = t(0.15f, 0.16f), surfaceContainerHighest = t(0.15f, 0.20f),
    )
}

@Composable
fun AuroraTheme(mode: Int, accent: Long = 0, content: @Composable () -> Unit) {
    // 0 system, 1 light, 2 dark, 3 black (AMOLED)
    val dark = when (mode) {
        1 -> false
        2, 3 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    var scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> AuroraDark
        else -> AuroraLight
    }
    if (accent != 0L) scheme = accentScheme(Color(accent), dark)
    if (mode == 3) {
        scheme = scheme.copy(
            background = Color.Black, surface = Color(0xFF0B0B0B),
            surfaceVariant = Color(0xFF1B1B1F), surfaceContainer = Color(0xFF111114),
        )
    }
    MaterialTheme(colorScheme = scheme) {
        // Without a Surface, text falls back to black, which is unreadable in dark mode.
        androidx.compose.material3.Surface(
            Modifier.fillMaxSize(), color = scheme.background, contentColor = scheme.onBackground,
        ) { content() }
    }
}
