package com.aurora.player.ui

import android.graphics.Bitmap
import kotlin.math.pow

/**
 * A softened copy of the cover. [pct] 0 keeps most detail, 100 is a very soft wash of colour.
 * It shrinks the picture in halving steps (which averages the pixels properly) and the caller stretches it back up with filtering.
 */
fun blurBitmap(src: Bitmap, pct: Int): Bitmap {
    val side = (512.0 * (12.0 / 512.0).pow(pct.coerceIn(0, 100) / 100.0)).toInt().coerceIn(12, 512)
    return try {
        var b = src
        while (b.width / 2 >= side && b.height / 2 >= side) b = Bitmap.createScaledBitmap(b, b.width / 2, b.height / 2, true)
        Bitmap.createScaledBitmap(b, side, side, true)
    } catch (_: Throwable) { src }
}
