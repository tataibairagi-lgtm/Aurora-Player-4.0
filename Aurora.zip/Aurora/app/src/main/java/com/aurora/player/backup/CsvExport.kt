package com.aurora.player.backup

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.aurora.player.controller
import com.aurora.player.data.MediaScanner
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Automatic export of the most played songs and artists as .csv files at the end of each week, month and year
 * (like Musicolet). Files go to the backup folder, or to Documents/Aurora/Backups/Most played when none is chosen.
 */
object CsvExport {
    private const val NAME = "aurora_auto_csv"
    private const val DEFAULT_DIR = "Documents/Aurora/Backups/Most played/"

    fun schedule(ctx: Context, on: Boolean) {
        val wm = WorkManager.getInstance(ctx.applicationContext)
        if (!on) { wm.cancelUniqueWork(NAME); return }
        val req = PeriodicWorkRequestBuilder<CsvWorker>(1, TimeUnit.DAYS)
            .setConstraints(Constraints.Builder().setRequiresStorageNotLow(true).build()).build()
        wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    private class Period(val key: String, val label: String, val start: Long, val end: Long)

    /** The week, month and year that most recently finished. */
    private fun finished(): List<Period> {
        fun cal() = Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        fun two(n: Int) = n.toString().padStart(2, '0')
        val out = ArrayList<Period>()
        // week: Monday to Monday
        val wEnd = cal().apply { set(Calendar.DAY_OF_WEEK, Calendar.MONDAY) }
        if (wEnd.timeInMillis > System.currentTimeMillis()) wEnd.add(Calendar.DAY_OF_YEAR, -7)
        val wStart = (wEnd.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, -7) }
        out += Period("W:" + wStart.timeInMillis, "week_" + wStart.get(Calendar.YEAR) + "-" + two(wStart.get(Calendar.MONTH) + 1) + "-" + two(wStart.get(Calendar.DAY_OF_MONTH)), wStart.timeInMillis, wEnd.timeInMillis)
        // month
        val mEnd = cal().apply { set(Calendar.DAY_OF_MONTH, 1) }
        val mStart = (mEnd.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
        out += Period("M:" + mStart.timeInMillis, "month_" + mStart.get(Calendar.YEAR) + "-" + two(mStart.get(Calendar.MONTH) + 1), mStart.timeInMillis, mEnd.timeInMillis)
        // year
        val yEnd = cal().apply { set(Calendar.DAY_OF_YEAR, 1) }
        val yStart = (yEnd.clone() as Calendar).apply { add(Calendar.YEAR, -1) }
        out += Period("Y:" + yStart.timeInMillis, "year_" + yStart.get(Calendar.YEAR), yStart.timeInMillis, yEnd.timeInMillis)
        return out
    }

    private fun q(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

    private fun build(c: PlayerController, p: Period): Pair<String, String>? {
        val counts = HashMap<Long, Int>()
        for (e in c.playLog.events) if (e.at >= p.start && e.at < p.end) counts[e.id] = (counts[e.id] ?: 0) + 1
        if (counts.isEmpty()) return null
        val rows = counts.entries.sortedByDescending { it.value }.mapNotNull { (id, n) -> c.track(id)?.let { it to n } }
        if (rows.isEmpty()) return null
        val songs = StringBuilder("Rank,Title,Artist,Album,Plays\n")
        rows.forEachIndexed { i, (t, n) -> songs.append("${i + 1},${q(t.title)},${q(t.artist)},${q(t.album)},$n\n") }
        val byArtist = HashMap<String, Int>()
        for ((t, n) in rows) byArtist[t.artist] = (byArtist[t.artist] ?: 0) + n
        val artists = StringBuilder("Rank,Artist,Plays\n")
        byArtist.entries.sortedByDescending { it.value }.forEachIndexed { i, (a, n) -> artists.append("${i + 1},${q(a)},$n\n") }
        return songs.toString() to artists.toString()
    }

    private fun save(ctx: Context, folder: String, name: String, text: String): Boolean {
        return try {
            if (folder.isNotEmpty()) {
                val dir = DocumentFile.fromTreeUri(ctx, Uri.parse(folder)) ?: return false
                if (!dir.canWrite()) return false
                val f = dir.createFile("text/csv", name) ?: return false
                ctx.contentResolver.openOutputStream(f.uri)?.use { it.write(text.toByteArray()) } ?: return false
                true
            } else {
                val v = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "$name.csv")
                    put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, DEFAULT_DIR)
                    put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val coll = android.provider.MediaStore.Files.getContentUri(android.provider.MediaStore.VOLUME_EXTERNAL_PRIMARY)
                val uri = ctx.contentResolver.insert(coll, v) ?: return false
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) } ?: return false
                v.clear(); v.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
                ctx.contentResolver.update(uri, v, null, null)
                true
            }
        } catch (_: Exception) { false }
    }

    /** Writes the files for every finished period not exported yet. Returns how many periods were exported. */
    fun run(ctx: Context, c: PlayerController): Int {
        val done = c.store.data.csvDone.toMutableList()
        var n = 0
        for (p in finished()) {
            if (p.key in done) continue
            val built = build(c, p)
            if (built == null) { done += p.key; continue }
            val (songs, artists) = built
            val folder = c.store.data.backupFolder
            val ok1 = save(ctx, folder, "most_played_songs_${p.label}.csv", songs)
            val ok2 = save(ctx, folder, "most_played_artists_${p.label}.csv", artists)
            if (ok1 && ok2) { done += p.key; n++ }
        }
        c.store.update { it.copy(csvDone = done.takeLast(60)) }
        return n
    }
}

class CsvWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext
        val c = app.controller
        if (c.library.isEmpty()) {
            if (!MediaScanner.hasAudioPermission(app)) return Result.failure()
            val list = withContext(Dispatchers.IO) { runCatching { MediaScanner.scan(app) }.getOrDefault(emptyList()) }
            withContext(Dispatchers.Main) { c.attachLibrary(list) }
        }
        withContext(Dispatchers.IO) { CsvExport.run(app, c) }
        return Result.success()
    }
}
