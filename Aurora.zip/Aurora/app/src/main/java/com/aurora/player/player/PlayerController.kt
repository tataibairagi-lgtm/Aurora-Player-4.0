package com.aurora.player.player

import android.app.Application
import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioFocusRequest
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.audiofx.Virtualizer
import android.os.Build
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.database.ContentObserver
import android.provider.Settings
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.aurora.player.data.EqPreset
import com.aurora.player.data.EqProfile
import com.aurora.player.data.LyricsRepo
import com.aurora.player.data.PlayLog
import com.aurora.player.widget.WidgetUpdater
import com.aurora.player.data.Lyrics
import com.aurora.player.data.QueueData
import com.aurora.player.data.Store
import com.aurora.player.data.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.min

class EqBand(val freqHz: Int, val minMb: Int, val maxMb: Int)

const val OUT_SPEAKER = "speaker"
const val OUT_WIRED = "wired"
const val OUT_BLUETOOTH = "bluetooth"
const val OUT_OTHER = "other"
val OUTPUTS = listOf(
    OUT_SPEAKER to "Speaker",
    OUT_WIRED to "Headphones",
    OUT_BLUETOOTH to "Bluetooth",
    OUT_OTHER to "Other",
)

/**
 * Single source of truth for playback. Owns the ExoPlayer (also used by [PlaybackService] for the
 * notification / media session) and exposes everything the UI needs as Compose state.
 */
class PlayerController(
    private val app: Application,
    val store: Store,
    val lyricsRepo: LyricsRepo,
) {
    private val audioProc = AuroraAudioProcessor()

    val player: ExoPlayer = ExoPlayer.Builder(
        app,
        object : DefaultRenderersFactory(app) {
            override fun buildAudioSink(context: Context, enableFloatOutput: Boolean, enableAudioTrackPlaybackParams: Boolean): AudioSink? =
                DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .apply {
                        // if Aurora's engine ever broke playback it is switched off (Settings > Audio) and the standard audio chain is used
                        if (store.data.soundEngine) setAudioProcessors(arrayOf(audioProc)) else audioProc.bypass = true
                    }
                    .build()
        },
    )
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true,
        )
        .setHandleAudioBecomingNoisy(true)
        .setWakeMode(C.WAKE_MODE_LOCAL)
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val playLog = PlayLog(app)
    private val handler = Handler(Looper.getMainLooper())

    // ---- stop the app after being idle ----
    private var idleSince = SystemClock.elapsedRealtime()
    private val idleCheck = object : Runnable {
        override fun run() {
            val min = store.data.idleStopMin
            if (min > 0 && !player.isPlaying && idleSince > 0 && SystemClock.elapsedRealtime() - idleSince >= min * 60_000L) {
                try { saveActiveQueue(); savePosition() } catch (_: Throwable) {}
                try { app.stopService(android.content.Intent(app, PlaybackService::class.java)) } catch (_: Throwable) {}
                // give the settings a moment to be written, then close the whole app
                handler.postDelayed({ android.os.Process.killProcess(android.os.Process.myPid()) }, 1500)
                return
            }
            handler.postDelayed(this, 20_000)
        }
    }


    // ---- library ----
    var library by mutableStateOf<List<Track>>(emptyList()); private set
    private var byId: Map<Long, Track> = emptyMap()
    fun track(id: Long): Track? = byId[id]

    // ---- queue / now playing ----
    var queue by mutableStateOf<List<Track>>(emptyList()); private set
    var currentIndex by mutableIntStateOf(-1); private set
    /** Bumped when something (e.g. the widget's queue button) asks the queue screen to jump to the playing song. */
    var queueScrollTick by mutableIntStateOf(0)
    var current by mutableStateOf<Track?>(null); private set
    var activeQueue by mutableIntStateOf(0); private set
    /** The queue shown on the Queues tab; playback stays in [activeQueue] until a song of another queue is tapped. */
    var viewQueue by mutableIntStateOf(0)
    /** Set when "Ask to resume" is on and a song with a remembered position starts. */
    var resumeAsk by mutableStateOf<Pair<Track, Long>?>(null)
    /** Full text of a playback error that couldn't be recovered; shown in a dialog you can copy from. */
    var playbackError by mutableStateOf<String?>(null)
    /** Songs selected in any list; the selection follows you between tabs until it is cleared. */
    val selection = androidx.compose.runtime.mutableStateListOf<Track>()
    /** Ids of [selection] as a hash set so every row can check "am I selected?" in O(1). */
    val selectedIdSet: Set<Long> by androidx.compose.runtime.derivedStateOf { selection.map { it.id }.toHashSet() }
    /** Set by PlaybackService so changing the notification settings refreshes the buttons at once. */
    var onNotifSettingsChanged: (() -> Unit)? = null

    private val shake = ShakeDetector(app) {
        when (store.data.shakeAction) { 1 -> next(); 2 -> previous(); 3 -> togglePlay() }
    }

    /** Listens for shakes only while a song is playing and the setting is on. */
    fun updateShake() {
        val d = store.data
        shake.threshold = when (d.shakeStrength) { 0 -> 11f; 2 -> 22f; else -> 16f }
        if (d.shakeAction != 0 && isPlaying) shake.start() else shake.stop()
    }

    // ---- transport ----
    var isPlaying by mutableStateOf(false); private set
    var positionMs by mutableLongStateOf(0L); private set
    /** Position used to pick the lyric line / word: a little ahead of the audio so lines never feel late. */
    val lyricPosMs: Long get() = positionMs + store.data.lyricOffsetMs + 60 // +60: the tick is up to ~40 ms old
    var durationMs by mutableLongStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF); private set
    var speed by mutableFloatStateOf(1f); private set
    var pitch by mutableFloatStateOf(1f); private set

    // ---- sleep timer / A-B ----
    var sleepLeftMs by mutableLongStateOf(0L); private set
    var sleepAfterTrack by mutableStateOf(false); private set
    private var sleepEndsAt = 0L
    var abA by mutableLongStateOf(-1L); private set
    var abB by mutableLongStateOf(-1L); private set

    // ---- lyrics ----
    var lyrics by mutableStateOf<Lyrics?>(null); private set
    var lyricsLoading by mutableStateOf(false); private set
    var overlayActive by mutableStateOf(false)
    private var lyricsJob: Job? = null

    // ---- effects ----
    private var eq: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudnessFx: LoudnessEnhancer? = null
    private var virtualizer: Virtualizer? = null
    var eqBands by mutableStateOf<List<EqBand>>(emptyList()); private set
    var eqSystemPresets by mutableStateOf<List<String>>(emptyList()); private set
    var activeOutput by mutableStateOf(OUT_SPEAKER); private set
    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val bassAvailable: Boolean get() = bassBoost?.strengthSupported == true
    val virtualizerAvailable: Boolean get() = virtualizer?.strengthSupported == true

    private var countedThisTrack = false
    private var lastSave = 0L

    init {
        val d = store.data
        activeQueue = d.activeQueue.coerceIn(0, d.queues.lastIndex)
        viewQueue = activeQueue
        speed = d.speed
        pitch = d.pitch
        player.playbackParameters = PlaybackParameters(speed, pitch)
        applyPlaybackPrefs()
        // run after the whole class has been constructed (these read properties declared further down)
        handler.post { applyEndModes(); applyChannelFx(); applyActiveProfile() }

        handler.postDelayed(idleCheck, 20_000)
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (store.data.qsTileLive || !isPlaying) com.aurora.player.QuickTileService.update(app)
                this@PlayerController.isPlaying = isPlaying
                updateShake()
                if (isPlaying) markPlayStart() else if (SystemClock.elapsedRealtime() - playStartAt > 4000) markHealthy()
                if (!isPlaying) stopCrossfade()
                idleSince = if (isPlaying) 0L else SystemClock.elapsedRealtime()
                if (isPlaying) {
                    // the notification lives in PlaybackService; bring it back if it was closed or stopped
                    try { app.startService(android.content.Intent(app, PlaybackService::class.java)) } catch (_: Throwable) {}
                }
                if (isPlaying) { requestFocus(); startTicker() } else if (!pausedByFocus) abandonFocus()
                WidgetUpdater.update(app)
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                com.aurora.player.CrashLog.write(app, "Playback error ${error.errorCodeName} on ${current?.title}", error)
                val root = generateSequence<Throwable>(error) { it.cause }.last()
                val where = root.stackTrace.firstOrNull()?.let { " at ${it.className.substringAfterLast('.')}.${it.methodName}" } ?: ""
                val why = "${root.javaClass.simpleName}: ${root.message ?: ""}$where".take(160)
                // an unexpected failure may come from Aurora's own audio engine: switch it off for good and retry, so the song still plays
                if (error.errorCode == androidx.media3.common.PlaybackException.ERROR_CODE_FAILED_RUNTIME_CHECK && !audioProc.bypass && store.data.soundEngine) {
                    audioProc.bypass = true
                    store.update { it.copy(soundEngine = false) }
                    handler.post { try { player.prepare(); player.play() } catch (_: Throwable) {} }
                    return
                }
                val full = "${error.errorCodeName}\n$why\n\n" + android.util.Log.getStackTraceString(error).take(3500)
                playbackError = full
                try {
                    android.widget.Toast.makeText(app, "Can't play this song (${error.errorCodeName}). Details are in the box on screen.", android.widget.Toast.LENGTH_LONG).show()
                } catch (_: Throwable) {}
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                // skipping from the notification, headset or lock screen fades in too, not only the in-app buttons
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK) skipFade()
                val prevIdx = currentIndex
                if (sleepAfterTrack) {
                    sleepAfterTrack = false
                    player.pauseAtEndOfMediaItems = false
                }
                if ((reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO || xfJustSwitched) && sleepSongsLeft > 1) sleepSongsLeft--
                xfJustSwitched = false
                clearAB()
                countedThisTrack = false
                syncCurrent()
                if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && queue.size > 1 && prevIdx == queue.lastIndex && currentIndex == 0 &&
                    shuffle && store.data.reshuffleOnEnd && store.data.queueEnd == 2) reshuffleRest()
                restorePosition(current)
                applyTrackExtras()
                updateSleepPause()
                persistSoon()
                WidgetUpdater.update(app)
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM) {
                    // a sleep timer (end of this song / after N songs / after a chosen song) just stopped the music
                    val bySleep = sleepAfterTrack || sleepSongsLeft == 1 || (sleepStopAtId != 0L && current?.id == sleepStopAtId)
                    sleepSongsLeft = 0; sleepStopAtId = 0L; sleepAfterTrack = false
                    updateSleepPause()
                    if (!bySleep && store.data.songEnd == 1 && player.hasNextMediaItem()) player.seekToNextMediaItem()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                durationMs = player.duration.coerceAtLeast(0)
                if (playbackState == Player.STATE_ENDED && store.data.queueEnd == 1 && store.data.queues.size > 1) {
                    switchQueue((activeQueue + 1) % store.data.queues.size)
                    playChecked()
                }
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                shuffle = shuffleModeEnabled
                WidgetUpdater.update(app)
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                this@PlayerController.repeatMode = repeatMode
                WidgetUpdater.update(app)
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                initEffects(audioSessionId)
            }
        })
        activeOutput = detectOutput()
        audioManager.registerAudioDeviceCallback(object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) {
                refreshOutput()
                val d = store.data
                val bt = addedDevices?.any {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
                } == true
                val wired = addedDevices?.any {
                    it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                        it.type == AudioDeviceInfo.TYPE_USB_HEADSET || it.type == AudioDeviceInfo.TYPE_USB_DEVICE
                } == true
                val want = (bt && d.resumeOnBt) || (wired && d.resumeOnWired)
                if (want && !player.isPlaying && player.mediaItemCount > 0 && (!d.resumeOnlyIfPaused || pausedByUnplug)) {
                    pausedByUnplug = false
                    play()
                }
            }

            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) {
                refreshOutput()
                if (SystemClock.elapsedRealtime() - lastPlayingAt < 4000) pausedByUnplug = true
            }
        }, handler)
        initEffects(player.audioSessionId)

        // pause when the media volume is turned to 0, resume when it comes back
        app.contentResolver.registerContentObserver(Settings.System.CONTENT_URI, true, object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) {
                val dd = store.data
                if (isMuted()) {
                    if (dd.pauseOnMute && player.isPlaying) { pausedByMute = true; player.pause() }
                } else if (pausedByMute) {
                    pausedByMute = false
                    if (dd.resumeOnUnmute && !player.isPlaying) player.play()
                }
            }
        })
    }

    // ---------------------------------------------------------------------------------------------
    // Library / queue
    // ---------------------------------------------------------------------------------------------

    /** Every folder that contains music (including excluded ones), for the "Excluded folders" setting. */
    var allFolders by mutableStateOf<List<String>>(emptyList())

    /** Pushes the playback-related settings into the player. Call after changing them. */
    fun applyPlaybackPrefs() {
        val d = store.data
        player.setHandleAudioBecomingNoisy(d.pauseOnUnplug)
        // Aurora handles audio focus itself (see onFocusChange), so ExoPlayer's own handling is off
        player.setAudioAttributes(
            AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
            false,
        )
        if (d.focusLevel <= 1) abandonFocus()
        player.skipSilenceEnabled = d.skipSilence
    }

    fun attachLibrary(list: List<Track>) {
        com.aurora.player.data.AlbumIndex.rebuild(list)
        library = list
        byId = list.associateBy { it.id }
        if (queue.isNotEmpty()) queue.indices.reversed().filter { queue[it].id !in byId }.forEach { removeAt(it) }
        if (player.mediaItemCount == 0) {
            val q = store.data.queues.getOrNull(activeQueue) ?: return
            val tracks = q.trackIds.mapNotNull { byId[it] }
            if (tracks.isNotEmpty()) {
                setQueue(tracks, q.index.coerceIn(0, tracks.lastIndex), q.positionMs, false)
                if (pendingPlay) play()
            }
        }
    }

    private fun item(t: Track): MediaItem {
        val md = MediaMetadata.Builder()
            .setTitle(t.title)
            .setArtist(t.artist)
            .setAlbumTitle(t.album)
        md.setArtworkUri(Uri.parse("content://${app.packageName}.art/${t.id}"))
        return MediaItem.Builder()
            .setMediaId(t.id.toString())
            .setUri(t.uri)
            .setMediaMetadata(md.build())
            .build()
    }

    private fun setQueue(input: List<Track>, startIn: Int, pos: Long, play: Boolean) {
        // a song is never in a queue twice
        val list = input.distinctBy { it.id }
        val startId = input.getOrNull(startIn)?.id
        val start = if (startId == null) startIn else list.indexOfFirst { it.id == startId }.coerceAtLeast(0)
        queue = list
        if (list.isEmpty()) {
            player.clearMediaItems()
        } else {
            player.setMediaItems(list.map(::item), start.coerceIn(0, list.lastIndex), pos)
            player.prepare()
            if (play) playChecked()
        }
        syncCurrent()
        persistSoon()
    }

    fun playTracks(list: List<Track>, start: Int = 0, shuffleOn: Boolean? = null) {
        if (list.isEmpty()) return
        // shuffle is never left to the player's hidden random order: the queue itself is re-ordered, so you can see what plays next
        player.shuffleModeEnabled = false
        if (shuffleOn == true) {
            val at = start.coerceIn(0, list.lastIndex)
            val first = list[at]
            val rest = list.filterIndexed { i, _ -> i != at }.shuffled()
            preShuffle = list; shuffle = true
            setQueue(listOf(first) + rest, 0, 0L, true)
        } else {
            preShuffle = null; shuffle = false
            setQueue(list, start, 0L, true)
        }
    }

    fun playNext(t: Track) {
        if (queue.isEmpty()) { playTracks(listOf(t)); return }
        val have = queue.indexOfFirst { it.id == t.id }
        if (have == player.currentMediaItemIndex) return
        if (have >= 0) removeAt(have) // already queued: move it instead of adding a second copy
        val at = (player.currentMediaItemIndex + 1).coerceAtMost(queue.size)
        player.addMediaItem(at, item(t))
        queue = queue.toMutableList().also { it.add(at, t) }
        persistSoon()
    }

    fun addToQueue(t: Track) = addAllToQueue(listOf(t))

    fun addAllToQueue(input: List<Track>) {
        if (input.isEmpty()) return
        if (queue.isEmpty()) { playTracks(input.distinctBy { it.id }); return }
        val have = queue.map { it.id }.toHashSet()
        val list = input.distinctBy { it.id }.filter { it.id !in have }
        if (list.isEmpty()) return
        player.addMediaItems(list.map(::item))
        queue = queue + list
        persistSoon()
    }

    fun removeAt(index: Int) {
        if (index !in queue.indices) return
        player.removeMediaItem(index)
        queue = queue.toMutableList().also { it.removeAt(index) }
        syncCurrent()
        persistSoon()
    }

    fun move(from: Int, to: Int) {
        if (from !in queue.indices || to !in queue.indices || from == to) return
        if (from == player.currentMediaItemIndex) {
            // moving the playing item itself can make the player re-open it: shift the others around it instead
            val target = queue.toMutableList().also { it.add(to, it.removeAt(from)) }
            if (applyOrder(target)) { syncCurrent(); persistSoon(); return }
        }
        player.moveMediaItem(from, to)
        queue = queue.toMutableList().also { it.add(to, it.removeAt(from)) }
        syncCurrent()
        persistSoon()
    }

    /**
     * Re-orders the player's items into [target] using only moves of OTHER songs, so the item that is playing is never
     * moved, re-prepared or interrupted (it just changes index). Returns false if the lists don't match.
     */
    private fun applyOrder(target: List<Track>): Boolean {
        if (target.size != queue.size) return false
        val work = queue.toMutableList()
        var cur = player.currentMediaItemIndex
        if (cur !in work.indices) return false
        val cid = work[cur].id
        val occ = work.take(cur).count { it.id == cid }
        var fc = -1; var seen = 0
        for (k in target.indices) if (target[k].id == cid) { if (seen == occ) { fc = k; break }; seen++ }
        if (fc < 0) return false
        fun mv(j: Int, p: Int) {
            player.moveMediaItem(j, p)
            work.add(p, work.removeAt(j))
            cur = when {
                j > cur && p <= cur -> cur + 1
                j < cur && p >= cur -> cur - 1
                else -> cur
            }
            queue = work.toList()
        }
        // songs that end up before the playing one: fill from the top
        for (p in 0 until fc) {
            val j = (p until work.size).firstOrNull { it != cur && work[it].id == target[p].id } ?: return false
            if (j != p) mv(j, p)
        }
        // songs that end up after it: fill from the bottom
        for (p in work.lastIndex downTo fc + 1) {
            val j = (p downTo 0).firstOrNull { it != cur && work[it].id == target[p].id } ?: return false
            if (j != p) mv(j, p)
        }
        queue = work.toList()
        return work.map { it.id } == target.map { it.id }
    }

    fun clearQueue() {
        player.pause()
        player.clearMediaItems()
        queue = emptyList()
        syncCurrent()
        persistSoon()
    }

    fun jumpTo(index: Int) {
        if (index !in queue.indices) return
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        player.seekTo(index, 0)
        playChecked()
    }

    fun switchQueue(i: Int) {
        viewQueue = i
        if (i == activeQueue || i !in store.data.queues.indices) return
        saveActiveQueue()
        activeQueue = i
        store.update { it.copy(activeQueue = i) }
        loadActiveQueue()
    }

    private fun loadActiveQueue() {
        val q = store.data.queues.getOrNull(activeQueue) ?: return
        val tracks = q.trackIds.mapNotNull { byId[it] }
        player.pause()
        if (tracks.isEmpty()) {
            player.clearMediaItems()
            queue = emptyList()
            syncCurrent()
        } else {
            setQueue(tracks, q.index.coerceIn(0, tracks.lastIndex), q.positionMs, false)
        }
    }

    /** Rebuilds the player's queue from the stored queues (used after restoring a backup). */
    fun reloadQueueFromStore() {
        activeQueue = store.data.activeQueue.coerceIn(0, store.data.queues.lastIndex)
        viewQueue = activeQueue
        loadActiveQueue()
    }

    val maxQueues = 20

    /** Adds an empty queue and switches to it. Returns false if the limit of 20 is reached. */
    fun newQueue(name: String): Boolean {
        if (store.data.queues.size >= maxQueues) return false
        saveActiveQueue()
        store.update { it.copy(queues = it.queues + QueueData(name.trim().ifEmpty { "Queue ${it.queues.size + 1}" })) }
        switchQueue(store.data.queues.lastIndex)
        return true
    }

    fun renameQueue(i: Int, name: String) = store.update { p ->
        p.copy(queues = p.queues.mapIndexed { n, q -> if (n == i && name.isNotBlank()) q.copy(name = name.trim()) else q })
    }

    fun deleteQueue(i: Int) {
        val d = store.data
        if (i !in d.queues.indices) return
        if (d.queues.size == 1) { clearQueue(); return }
        val wasActive = i == activeQueue
        if (wasActive) saveActiveQueueless()
        val newList = d.queues.filterIndexed { n, _ -> n != i }
        val newActive = if (wasActive) i.coerceAtMost(newList.lastIndex) else if (activeQueue > i) activeQueue - 1 else activeQueue
        activeQueue = newActive
        store.update { it.copy(queues = newList, activeQueue = newActive) }
        if (wasActive) loadActiveQueue()
        viewQueue = activeQueue
    }

    // ---- viewing a queue that is not the playing one ----
    fun viewTracks(i: Int): List<Track> =
        if (i == activeQueue) queue else store.data.queues.getOrNull(i)?.trackIds?.mapNotNull { byId[it] }.orEmpty()

    fun viewIndex(i: Int): Int =
        if (i == activeQueue) currentIndex else store.data.queues.getOrNull(i)?.index ?: 0

    private fun storeView(i: Int, list: List<Track>) = store.update { p ->
        p.copy(queues = p.queues.mapIndexed { n, q -> if (n == i) q.copy(trackIds = list.map { it.id }, index = q.index.coerceIn(0, (list.size - 1).coerceAtLeast(0))) else q })
    }

    /** Starts playing the viewed queue (from [index] if given), switching playback to it if needed. */
    fun playViewed(i: Int, index: Int?) {
        if (i != activeQueue) switchQueue(i)
        if (index != null) jumpTo(index) else if (!player.isPlaying) playChecked()
    }

    fun viewRemove(i: Int, idxs: Collection<Int>) {
        if (i == activeQueue) { removeMany(idxs); dropIfEmpty(i); return }
        val l = viewTracks(i).toMutableList()
        idxs.sortedDescending().forEach { if (it in l.indices) l.removeAt(it) }
        storeView(i, l)
        dropIfEmpty(i)
    }

    /** A queue with no songs left is removed (the last remaining queue just stays empty). */
    private fun dropIfEmpty(i: Int) {
        handler.post { if (store.data.queues.size > 1 && i in store.data.queues.indices && viewTracks(i).isEmpty()) deleteQueue(i) }
    }

    /** Removes empty queues that are neither playing nor being viewed (an empty queue you just created stays until you leave it). */
    fun pruneEmptyQueues() {
        val d = store.data
        if (d.queues.size <= 1) return
        val drop = d.queues.indices.filter { it != activeQueue && it != viewQueue && d.queues[it].trackIds.isEmpty() }
        if (drop.isEmpty()) return
        val newList = d.queues.filterIndexed { n, _ -> n !in drop }
        activeQueue -= drop.count { it < activeQueue }
        viewQueue -= drop.count { it < viewQueue }
        store.update { it.copy(queues = newList, activeQueue = activeQueue) }
    }

    fun viewMove(i: Int, from: Int, to: Int) {
        if (i == activeQueue) { move(from, to); return }
        val l = viewTracks(i).toMutableList()
        if (from !in l.indices || to !in l.indices || from == to) return
        l.add(to, l.removeAt(from)); storeView(i, l)
    }

    fun viewReorder(i: Int, list: List<Track>) {
        if (i == activeQueue) { if (list.isEmpty()) clearQueue() else reorderQueue(list) } else storeView(i, list)
        if (list.isEmpty()) dropIfEmpty(i)
    }

    /** Moves the songs at [idxs] together, dropping them on the song at [target]. Returns their new indices. */
    fun viewMoveBlock(i: Int, idxs: List<Int>, target: Int): List<Int> {
        val list = viewTracks(i).toMutableList()
        val sorted = idxs.filter { it in list.indices }.sorted()
        if (sorted.isEmpty() || target !in list.indices) return idxs
        val items = sorted.map { list[it] }
        val down = target > sorted.first()
        val at = if (down) target - sorted.count { it <= target } + 1 else target - sorted.count { it < target }
        sorted.reversed().forEach { list.removeAt(it) }
        val pos = at.coerceIn(0, list.size)
        list.addAll(pos, items)
        viewReorder(i, list)
        return items.indices.map { pos + it }
    }

    /**
     * Drops the songs at [idxs] together next to the row at [target] (after it if [after], else before it). When [target] is
     * one of the moved songs they simply gather where it was. Returns their new indices.
     */
    fun viewMoveBlockAt(i: Int, idxs: List<Int>, target: Int, after: Boolean): List<Int> {
        val list = viewTracks(i)
        val sel = idxs.filter { it in list.indices }.toSortedSet()
        if (sel.isEmpty()) return idxs
        val items = sel.map { list[it] }
        val rest = list.filterIndexed { k, _ -> k !in sel }
        val before = target - sel.count { it < target }
        val pos = (if (target in sel) before else before + if (after) 1 else 0).coerceIn(0, rest.size)
        val out = rest.toMutableList().also { it.addAll(pos, items) }
        viewReorder(i, out)
        return items.indices.map { pos + it }
    }

    fun moveQueue(from: Int, to: Int) {
        val d = store.data
        if (from !in d.queues.indices || to !in d.queues.indices || from == to) return
        saveActiveQueue()
        fun remap(i: Int) = when {
            i == from -> to
            from < to && i in (from + 1)..to -> i - 1
            from > to && i in to until from -> i + 1
            else -> i
        }
        val l = store.data.queues.toMutableList().also { it.add(to, it.removeAt(from)) }
        val na = remap(activeQueue); val nv = remap(viewQueue)
        activeQueue = na; viewQueue = nv
        store.update { it.copy(queues = l, activeQueue = na) }
    }

    /** Deletes every queue except [keep]; playback moves to it if it was not the playing one. */
    fun removeOtherQueues(keep: Int) {
        if (keep !in store.data.queues.indices) return
        if (keep != activeQueue) switchQueue(keep)
        saveActiveQueue()
        val only = store.data.queues[activeQueue]
        activeQueue = 0; viewQueue = 0
        store.update { it.copy(queues = listOf(only), activeQueue = 0) }
    }

    private fun saveActiveQueueless() { /* the queue is being deleted, nothing to save */ }

    /** Playing an album/playlist/folder/...: opens (or reuses) a queue named after it, replacing or merging as configured. */
    fun playFromSource(name: String, list: List<Track>, start: Int = 0, shuffleOn: Boolean? = null) {
        val d = store.data
        if (!d.sourceQueues || list.isEmpty()) { playTracks(list, start, shuffleOn); return }
        saveActiveQueue()
        val existing = d.queues.indexOfFirst { it.name == name }
        if (existing >= 0) {
            if (existing != activeQueue) switchQueue(existing)
            if (d.queueMerge && queue.isNotEmpty() && shuffleOn != true) {
                val have = queue.map { it.id }.toSet()
                addAllToQueue(list.filter { it.id !in have })
                val at = queue.indexOfFirst { it.id == list[start.coerceIn(0, list.lastIndex)].id }
                if (at >= 0) jumpTo(at)
            } else playTracks(list, start, shuffleOn)
            return
        }
        if (queue.isNotEmpty() && d.queues.size < maxQueues) {
            store.update { it.copy(queues = it.queues + QueueData(name)) }
            switchQueue(store.data.queues.lastIndex)
        } else {
            renameQueue(activeQueue, name)
        }
        playTracks(list, start, shuffleOn)
    }

    /** Re-orders the whole queue (sort / reverse / shuffle) and keeps the current song playing. */
    fun reorderQueue(sorted: List<Track>) {
        if (sorted.isEmpty()) return
        // same songs, new order: shuffle the entries around inside the player so the playing song carries on untouched
        if (sorted.size == queue.size && sorted.map { it.id }.sorted() == queue.map { it.id }.sorted()) {
            if (applyOrder(sorted)) {
                syncCurrent()
                persistSoon()
                return
            }
        }
        val cur = current
        val idx = sorted.indexOfFirst { it.id == cur?.id }.coerceAtLeast(0)
        setQueue(sorted, idx, player.currentPosition, player.isPlaying)
    }

    /** Puts [list] right after the song that is playing now. */
    fun playAfterCurrent(list: List<Track>) {
        if (queue.isEmpty()) { playTracks(list); return }
        val curId = current?.id
        val fresh = list.distinctBy { it.id }.filter { it.id != curId }
        fresh.map { it.id }.toHashSet().let { dupes -> queue.indices.reversed().filter { queue[it].id in dupes && it != player.currentMediaItemIndex }.forEach { removeAt(it) } }
        var at = (player.currentMediaItemIndex + 1).coerceAtMost(queue.size)
        for (t in fresh) { player.addMediaItem(at, item(t)); queue = queue.toMutableList().also { q -> q.add(at, t) }; at++ }
        persistSoon()
    }

    /** Adds [list] to another queue (by index) without switching to it. */
    fun addToOtherQueue(i: Int, list: List<Track>) {
        if (i == activeQueue) { addAllToQueue(list); return }
        store.update { p ->
            p.copy(queues = p.queues.mapIndexed { n, q -> if (n == i) q.copy(trackIds = q.trackIds + list.map { it.id }) else q })
        }
    }

    fun removeMany(indices: Collection<Int>) {
        indices.sortedDescending().forEach { removeAt(it) }
    }

    private fun saveActiveQueue() {
        val data = QueueData(
            name = store.data.queues.getOrNull(activeQueue)?.name ?: "Queue",
            trackIds = queue.map { it.id },
            index = player.currentMediaItemIndex.coerceAtLeast(0),
            positionMs = player.currentPosition,
        )
        store.update { p ->
            p.copy(queues = p.queues.toMutableList().also { if (activeQueue in it.indices) it[activeQueue] = data })
        }
    }

    private val persistRunnable = Runnable { saveActiveQueue() }
    private fun persistSoon() {
        handler.removeCallbacks(persistRunnable)
        handler.postDelayed(persistRunnable, 800)
    }

    private fun syncCurrent() {
        currentIndex = if (queue.isEmpty()) -1 else player.currentMediaItemIndex
        val t = queue.getOrNull(currentIndex)
        val changed = t?.id != current?.id
        current = t
        durationMs = if (t != null) player.duration.coerceAtLeast(0).let { if (it == 0L) t.durationMs else it } else 0
        positionMs = if (t != null) player.currentPosition else 0
        if (changed) loadLyrics(t)
    }

    // ---------------------------------------------------------------------------------------------
    // Transport
    // ---------------------------------------------------------------------------------------------

    /** Extra volume factor used for the fade-in / fade-out when pausing and resuming. */
    private var manualGain = 1f
    private var duckGain = 1f
    private var pausedByFocus = false
    private var focusRequest: AudioFocusRequest? = null
    private val focusAttrs = android.media.AudioAttributes.Builder()
        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build()
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change -> onFocusChange(change) }

    private fun requestFocus() {
        if (store.data.focusLevel <= 1) return
        val req = focusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(focusAttrs).setOnAudioFocusChangeListener(focusListener, handler)
            .setWillPauseWhenDucked(false).build().also { focusRequest = it }
        audioManager.requestAudioFocus(req)
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        focusRequest = null
        duckGain = 1f
    }

    /** Levels: 1 ignore all; 2 pause for calls; 3 + pause when another app takes focus; 4 + lower volume for short sounds; 5 pause for those too. */
    private fun onFocusChange(change: Int) {
        val d = store.data
        val lvl = d.focusLevel
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> if (lvl >= 3 && player.isPlaying) { pausedByFocus = false; player.pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> if (lvl >= 2 && player.isPlaying) { pausedByFocus = d.resumeAfterCall; player.pause() }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> when {
                lvl == 4 -> { duckGain = 0.25f; player.volume = (manualGain * duckGain).coerceIn(0f, 1f) }
                lvl >= 5 && player.isPlaying -> { pausedByFocus = true; player.pause() }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                duckGain = 1f
                player.volume = manualGain.coerceIn(0f, 1f)
                if (pausedByFocus) { pausedByFocus = false; player.play() }
            }
        }
    }
    private var lastPlayingAt = 0L
    private var pausedByUnplug = false
    private var pausedByMute = false
    private var rampToken = 0

    private fun ramp(from: Float, to: Float, ms: Int, done: () -> Unit = {}) {
        val token = ++rampToken
        val start = SystemClock.elapsedRealtime()
        manualGain = from
        val step = object : Runnable {
            override fun run() {
                if (token != rampToken) return
                val f = ((SystemClock.elapsedRealtime() - start) / ms.toFloat()).coerceIn(0f, 1f)
                manualGain = from + (to - from) * f
                player.volume = manualGain
                if (f < 1f) handler.postDelayed(this, 30) else done()
            }
        }
        handler.post(step)
    }

    /** Every way of starting a song goes through here, so "do not play when the volume is 0" can't be bypassed by tapping another song. */
    private fun playChecked() {
        if (store.data.blockPlayMuted && isMuted()) {
            player.pause()
            Toast.makeText(app, "Volume is 0. Turn the volume up to play.", Toast.LENGTH_SHORT).show()
            return
        }
        player.play()
    }

    private fun isMuted() = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0

    /** Set when play is pressed before the saved queue has been loaded (the app was just started by a widget or notification). */
    private var pendingPlay = false

    /** Makes sure the player can actually react: loaded, prepared, and not stuck at the end of the queue. */
    private fun ensureReady(): Boolean {
        if (player.mediaItemCount == 0) return false
        if (player.playbackState == Player.STATE_IDLE) player.prepare()
        if (player.playbackState == Player.STATE_ENDED) player.seekToDefaultPosition(0)
        return true
    }

    fun togglePlay() {
        val d = store.data
        val running = player.playWhenReady && (player.playbackState == Player.STATE_READY || player.playbackState == Player.STATE_BUFFERING)
        if (running) {
            pendingPlay = false
            if (d.fadeOutMs > 0 && player.isPlaying) ramp(manualGain, 0f, d.fadeOutMs) { player.pause(); manualGain = 1f; player.volume = 1f }
            else player.pause()
        } else {
            play()
        }
    }

    fun play() {
        val d = store.data
        if (d.blockPlayMuted && isMuted()) {
            Toast.makeText(app, "Volume is 0. Turn the volume up to play.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!ensureReady()) { pendingPlay = true; return } // the queue is still loading: start as soon as it is there
        pendingPlay = false
        rampToken++
        pausedByFocus = false
        requestFocus()
        if (d.fadeInMs > 0) { manualGain = 0f; player.volume = 0f; player.play(); ramp(0f, 1f, d.fadeInMs) }
        else { manualGain = 1f; player.volume = 1f; player.play() }
    }

    fun fastForward() = player.seekTo((player.currentPosition + store.data.ffSec * 1000L).coerceAtMost(player.duration.coerceAtLeast(0)))
    fun rewind() = player.seekTo((player.currentPosition - store.data.rewindSec * 1000L).coerceAtLeast(0))

    private fun savePosition() {
        val d = store.data
        val t = current ?: return
        if (!d.rememberPositions || durationMs < d.rememberMinMin * 60_000L) return
        store.update { it.copy(positions = it.positions + (t.id to player.currentPosition)) }
    }

    private fun restorePosition(t: Track?) {
        val d = store.data
        if (t == null || !d.rememberPositions) return
        val p = d.positions[t.id] ?: return
        if (t.durationMs < d.rememberMinMin * 60_000L || p <= 5000) return
        if (d.askToResume) resumeAsk = t to p else player.seekTo(p)
    }
    /** Short fade-in after skipping, so previous / next never start with a click. */
    private fun skipFade() {
        if (!player.playWhenReady) return
        manualGain = 0f
        player.volume = 0f
        ramp(0f, 1f, 320)
    }
    /** Previous restarts the song after 3 seconds, or after the chosen percentage of the song has played. */
    private fun prevShouldRestart(): Boolean {
        val pct = store.data.prevRestartPct
        val dur = player.duration
        return if (pct > 0 && dur > 0) player.currentPosition * 100 >= dur * pct else player.currentPosition > 3000
    }
    fun next() { if (!ensureReady()) return; player.seekToNextMediaItem(); skipFade() }
    fun previous() {
        if (!ensureReady()) return
        if (store.data.prevRestarts && prevShouldRestart()) player.seekTo(0) else player.seekToPreviousMediaItem()
        skipFade()
    }
    fun seekTo(ms: Long) {
        player.seekTo(ms)
        positionMs = ms
    }
    private var preShuffle: List<Track>? = null

    /** Shuffled copy of [list] plus the position of the playing song: either only the songs after it, or everything else. */
    private fun shuffleQueueList(list: List<Track>, idx: Int, belowOnly: Boolean): Pair<List<Track>, Int> =
        if (belowOnly) (list.take(idx + 1) + list.drop(idx + 1).shuffled()) to idx
        else (listOf(list[idx]) + list.filterIndexed { i, _ -> i != idx }.shuffled()) to 0

    /** The queue screen's "Randomize" sort option. */
    fun randomizeQueue() {
        if (queue.size < 2) return
        val idx = player.currentMediaItemIndex.coerceIn(0, queue.lastIndex)
        val (list, newIdx) = shuffleQueueList(queue, idx, store.data.randomizeBelowOnly)
        setQueue(list, newIdx, player.currentPosition, player.isPlaying)
    }

    /** Shuffle really re-orders the queue (current song stays first); turning it off restores the earlier order. */
    fun toggleShuffle() {
        val was = shuffle
        if (player.shuffleModeEnabled) player.shuffleModeEnabled = false
        if (queue.isEmpty()) { shuffle = false; return }
        val idx = player.currentMediaItemIndex.coerceIn(0, queue.lastIndex)
        if (!was) {
            preShuffle = queue
            shuffle = true
            val (shuffled, newIdx) = shuffleQueueList(queue, idx, store.data.shuffleBelowOnly)
            setQueue(shuffled, newIdx, player.currentPosition, player.isPlaying)
        } else {
            val orig = preShuffle
            preShuffle = null
            shuffle = false
            if (orig != null) {
                val have = queue.map { it.id }.toSet()
                val origIds = orig.map { it.id }.toSet()
                val restored = orig.filter { it.id in have } + queue.filter { it.id !in origIds }
                val curId = queue[idx].id
                setQueue(restored, restored.indexOfFirst { it.id == curId }.coerceAtLeast(0), player.currentPosition, player.isPlaying)
            }
        }
    }
    /** Applies "when a song ends" / "when the queue ends" to the player. */
    fun applyEndModes() {
        val d = store.data
        player.repeatMode = when {
            d.songEnd == 3 -> Player.REPEAT_MODE_ONE
            d.queueEnd == 2 -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
        updateSleepPause()
    }

    fun setEndModes(songEnd: Int, queueEnd: Int, reshuffle: Boolean = store.data.reshuffleOnEnd) {
        store.update { it.copy(songEnd = songEnd, queueEnd = queueEnd, reshuffleOnEnd = reshuffle) }
        applyEndModes()
    }

    /** Quick repeat toggle used by the lock screen and widgets: off → repeat queue → repeat song. */
    fun cycleRepeat() {
        val d = store.data
        when {
            d.songEnd == 3 -> setEndModes(2, 0)
            d.queueEnd == 2 -> setEndModes(3, d.queueEnd)
            else -> setEndModes(if (d.songEnd == 3) 2 else d.songEnd, 2)
        }
    }

    /** After the queue wraps around in shuffle mode: new random order for everything but the song now playing. */
    private fun reshuffleRest() {
        if (queue.size < 3) return
        val cur = queue[0]
        val rest = queue.drop(1).shuffled()
        try {
            player.replaceMediaItems(1, queue.size, rest.map(::item))
            queue = listOf(cur) + rest
            persistSoon()
        } catch (_: Throwable) {}
    }

    /** True when the playing song has its own speed / pitch. */
    val hasOwnSpeed: Boolean get() = current?.id?.let { it in store.data.speeds || it in store.data.pitches } == true

    /** Gives every song in [ids] its own speed and pitch (applied now if one of them is playing). */
    fun setSpeedPitchForTracks(ids: Collection<Long>, s: Float, p: Float) {
        store.update { it.copy(speeds = it.speeds + ids.map { id -> id to s }, pitches = it.pitches + ids.map { id -> id to p }) }
        if (current?.id in ids) pushSpeed(s, p)
    }

    /** Forgets play counts, last-played entries and the play log of these songs. */
    fun clearHistoryOf(ids: Set<Long>) {
        store.update { it.copy(playCounts = it.playCounts - ids, lastPlayed = it.lastPlayed.filter { x -> x !in ids }, positions = it.positions - ids) }
        playLog.replaceAll(playLog.events.filter { it.id !in ids })
    }

    private fun pushSpeed(s: Float, p: Float) {
        speed = s; pitch = p
        player.playbackParameters = PlaybackParameters(s, p)
    }

    /** Changes speed/pitch for the playing song if it has its own settings, otherwise for all songs. */
    fun setSpeedPitch(s: Float, p: Float) {
        if (hasOwnSpeed) setSpeedPitchForTrack(s, p) else setSpeedPitchForAll(s, p, false)
    }

    /** For all songs; with [overrideOwn] the songs that had their own settings lose them. */
    fun setSpeedPitchForAll(s: Float, p: Float, overrideOwn: Boolean) {
        store.update { it.copy(speed = s, pitch = p, speeds = if (overrideOwn) emptyMap() else it.speeds, pitches = if (overrideOwn) emptyMap() else it.pitches) }
        if (!hasOwnSpeed) pushSpeed(s, p)
    }

    fun setSpeedPitchForTrack(s: Float, p: Float) {
        val id = current?.id ?: return
        store.update { it.copy(speeds = it.speeds + (id to s), pitches = it.pitches + (id to p)) }
        pushSpeed(s, p)
    }

    /** Goes back to the all-songs speed for the playing song. */
    fun clearTrackSpeed() {
        val id = current?.id ?: return
        store.update { it.copy(speeds = it.speeds - id, pitches = it.pitches - id) }
        pushSpeed(store.data.speed, store.data.pitch)
    }

    // ---- channel effects (mono / balance) ----
    fun applyChannelFx() {
        audioProc.mono = store.data.mono
        audioProc.balance = store.data.balance
    }
    fun setMono(on: Boolean) { store.update { it.copy(mono = on) }; applyChannelFx() }
    fun setBalance(v: Int) { store.update { it.copy(balance = v.coerceIn(-100, 100)) }; applyChannelFx() }

    /** Extra attenuation from a negative preamp (the loudness enhancer can only add gain). */
    private var preampVol = 1f

    // ---- per-song speed, ReplayGain, crossfade ----
    private var rgFactor = 1f
    private var rgJob: Job? = null
    private var xf: ExoPlayer? = null
    private var xfStart = 0L
    private var xfMs = 0L
    private var xfJustSwitched = false

    /** Called whenever the song changes: restores this song's own speed and reads its ReplayGain. */
    private fun applyTrackExtras() {
        val t = current ?: return
        val d = store.data
        val sp = d.speeds[t.id] ?: d.speed
        val pt = d.pitches[t.id] ?: d.pitch
        speed = sp; pitch = pt
        player.playbackParameters = PlaybackParameters(sp, pt)
        rgJob?.cancel()
        rgFactor = 1f
        if (d.replayGain) {
            rgJob = scope.launch(Dispatchers.IO) {
                val db = com.aurora.player.data.TagIo.replayGainDb(app, t)
                if (db != null) {
                    val f = Math.pow(10.0, db / 20.0).toFloat().coerceIn(0.05f, 1f)
                    Handler(Looper.getMainLooper()).post { if (current?.id == t.id) rgFactor = f }
                }
            }
        }
    }

    private fun stopCrossfade() {
        try { xf?.release() } catch (_: Throwable) {}
        xf = null; xfMs = 0
    }

    /** Starts the old song fading out on a second player while the next song fades in on the main one. */
    private fun maybeStartCrossfade() {
        val cf = store.data.crossfadeSec * 1000L
        if (cf <= 0 || xf != null || !player.isPlaying) return
        if (!player.hasNextMediaItem() || player.repeatMode == Player.REPEAT_MODE_ONE || sleepAfterTrack) return
        val dur = player.duration
        if (dur <= 0 || dur < cf * 2) return
        val remaining = dur - player.currentPosition
        if (remaining > cf || remaining < 200) return
        val cur = queue.getOrNull(player.currentMediaItemIndex) ?: return
        try {
            val p2 = ExoPlayer.Builder(app).build()
            p2.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), false)
            p2.setMediaItem(item(cur), player.currentPosition)
            p2.playbackParameters = player.playbackParameters
            p2.volume = (manualGain * duckGain).coerceIn(0f, 1f)
            p2.prepare(); p2.play()
            xf = p2; xfStart = SystemClock.elapsedRealtime(); xfMs = remaining.coerceAtMost(cf)
            xfJustSwitched = true
            player.seekToNextMediaItem()
        } catch (_: Throwable) { stopCrossfade(); xfJustSwitched = false }
    }

    /** 0..1 volume for the song on the main player during a crossfade (1 when none). Also drives the outgoing player. */
    private fun crossfadeStep(): Float {
        val p2 = xf ?: return 1f
        val prog = ((SystemClock.elapsedRealtime() - xfStart) / xfMs.toFloat()).coerceIn(0f, 1f)
        try { p2.volume = ((1f - prog) * manualGain * duckGain).coerceIn(0f, 1f) } catch (_: Throwable) {}
        if (prog >= 1f || !player.isPlaying) stopCrossfade()
        return prog
    }

    fun setFadeSeconds(s: Int) = store.update { it.copy(fadeSec = s) }

    // ---- A-B repeat ----
    fun markAB() {
        when {
            abA < 0 -> abA = player.currentPosition
            abB < 0 -> {
                if (player.currentPosition > abA + 500) abB = player.currentPosition else abA = player.currentPosition
            }
            else -> clearAB()
        }
    }

    fun clearAB() { abA = -1; abB = -1 }

    // ---- sleep timer ----
    fun setSleepMinutes(min: Int) {
        clearSleepState()
        updateSleepPause()
        sleepEndsAt = SystemClock.elapsedRealtime() + min * 60_000L
        sleepLeftMs = min * 60_000L
        startTicker()
    }

    var sleepSongsLeft by mutableIntStateOf(0); private set
    var sleepStopAtId by mutableLongStateOf(0L); private set

    private fun updateSleepPause() {
        player.pauseAtEndOfMediaItems = sleepAfterTrack || sleepSongsLeft == 1 ||
            (sleepStopAtId != 0L && current?.id == sleepStopAtId) || store.data.songEnd <= 1
    }

    fun setSleepEndOfTrack() {
        clearSleepState()
        sleepAfterTrack = true
        updateSleepPause()
    }

    /** Stop after [n] songs have played (the current one counts as the first). */
    fun setSleepSongs(n: Int) {
        clearSleepState()
        sleepSongsLeft = n.coerceAtLeast(1)
        updateSleepPause()
    }

    /** Stop right after the song with this id finishes. */
    fun setSleepAfterSong(id: Long) {
        clearSleepState()
        sleepStopAtId = id
        updateSleepPause()
    }

    private fun clearSleepState() {
        sleepEndsAt = 0; sleepLeftMs = 0
        sleepAfterTrack = false; sleepSongsLeft = 0; sleepStopAtId = 0L
    }

    val sleepActive: Boolean get() = sleepLeftMs > 0 || sleepAfterTrack || sleepSongsLeft > 0 || sleepStopAtId != 0L

    fun cancelSleep() {
        clearSleepState()
        updateSleepPause()
        player.volume = 1f
    }

    // ---------------------------------------------------------------------------------------------
    // Ticker: position, A-B, fade, sleep, play counts
    // ---------------------------------------------------------------------------------------------

    private var ticking = false

    // ---- health marker: lets the next start know if playback died in its first seconds ----
    private val health = app.getSharedPreferences("aurora_health", Context.MODE_PRIVATE)
    private var healthy = true
    private var playStartAt = 0L
    private fun markPlayStart() {
        playStartAt = SystemClock.elapsedRealtime()
        if (healthy) { healthy = false; try { health.edit().putBoolean("play_ok", false).apply() } catch (_: Throwable) {} }
    }
    private fun markHealthy() {
        if (healthy) return
        healthy = true
        try { health.edit().putBoolean("play_ok", true).putInt("fails", 0).apply() } catch (_: Throwable) {}
    }
    private val ticker = object : Runnable {
        override fun run() {
            positionMs = player.currentPosition
            val dur = player.duration
            if (dur > 0) durationMs = dur

            if (abA >= 0 && abB > abA && positionMs >= abB) player.seekTo(abA)

            maybeStartCrossfade()
            var vol = crossfadeStep()
            val f = if (store.data.crossfadeSec > 0) 0L else store.data.fadeSec * 1000L
            if (f > 0 && durationMs > 0) {
                val fade = min(f, durationMs / 3)
                if (fade > 0) {
                    if (positionMs < fade) vol = min(vol, positionMs / fade.toFloat())
                    val remaining = durationMs - positionMs
                    if (remaining < fade) vol = min(vol, remaining / fade.toFloat())
                }
            }
            if (sleepEndsAt > 0) {
                val left = (sleepEndsAt - SystemClock.elapsedRealtime()).coerceAtLeast(0)
                sleepLeftMs = left
                if (left < 5_000) vol = min(vol, left / 5_000f)
                if (left == 0L) {
                    sleepEndsAt = 0
                    player.pause()
                    vol = 1f
                }
            }
            val outVol = vol * manualGain * duckGain * rgFactor * preampVol
            player.volume = if (outVol.isNaN()) 1f else outVol.coerceIn(0f, 1f)
            if (player.isPlaying) lastPlayingAt = SystemClock.elapsedRealtime()
            if (!healthy && player.isPlaying && SystemClock.elapsedRealtime() - playStartAt > 10_000) markHealthy()

            val t = current
            val pct = store.data.playCountPct
            val need = if (pct > 0 && durationMs > 0) durationMs * pct / 100 else store.data.minPlaySec * 1000L
            if (t != null && !countedThisTrack && positionMs >= need) {
                countedThisTrack = true
                store.recordPlay(t.id)
                playLog.append(t.id)
            }
            val now = SystemClock.elapsedRealtime()
            if (now - lastSave > 5000 && player.isPlaying) {
                lastSave = now
                saveActiveQueue()
                savePosition()
            }

            if (player.isPlaying || sleepEndsAt > 0) handler.postDelayed(this, if (lyrics?.synced == true) (if (store.data.fastLyrics) 40 else 120) else 200) else ticking = false
        }
    }

    private fun startTicker() {
        if (ticking) return
        ticking = true
        handler.post(ticker)
    }

    // ---------------------------------------------------------------------------------------------
    // Lyrics
    // ---------------------------------------------------------------------------------------------

    private fun lyricsOrder(t: Track): List<String> {
        val d = store.data
        d.lyricsSource[t.id]?.let { return listOf(it) }
        val all = listOf("saved", "file", "embedded")
        return (listOf(d.lyricsPreferred) + all).distinct().filter { it in all }
    }

    private fun loadLyrics(t: Track?, force: Boolean = false) {
        lyricsJob?.cancel()
        lyrics = null
        if (t == null) return
        lyricsJob = scope.launch {
            lyricsLoading = true
            lyrics = lyricsRepo.load(t, lyricsOrder(t), false, force)
            lyricsLoading = false
        }
    }

    /** Pick where the current song's lyrics come from: "auto", "embedded", "file", "saved" or "online". */
    fun setLyricsSource(src: String) {
        val t = current ?: return
        store.update { it.copy(lyricsSource = if (src == "auto") it.lyricsSource - t.id else it.lyricsSource + (t.id to src)) }
        loadLyrics(t)
    }

    fun importLyrics(text: String) {
        val t = current ?: return
        lyricsRepo.save(t, text)
        loadLyrics(t)
    }

    fun reloadLyrics() = loadLyrics(current, force = true)


    // ---------------------------------------------------------------------------------------------
    // Effects: one equalizer profile per audio output, switched automatically like Musicolet
    // ---------------------------------------------------------------------------------------------

    private fun detectOutput(): String {
        val types = try {
            audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { it.type }
        } catch (_: Exception) {
            emptyList()
        }
        val bt = types.any {
            it == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= 31 && (it == AudioDeviceInfo.TYPE_BLE_HEADSET || it == AudioDeviceInfo.TYPE_BLE_SPEAKER))
        }
        val wired = types.any {
            it == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val other = types.any {
            it == AudioDeviceInfo.TYPE_HDMI || it == AudioDeviceInfo.TYPE_USB_DEVICE ||
                it == AudioDeviceInfo.TYPE_USB_ACCESSORY || it == AudioDeviceInfo.TYPE_LINE_ANALOG ||
                it == AudioDeviceInfo.TYPE_LINE_DIGITAL || it == AudioDeviceInfo.TYPE_AUX_LINE
        }
        return when {
            bt -> OUT_BLUETOOTH
            wired -> OUT_WIRED
            other -> OUT_OTHER
            else -> OUT_SPEAKER
        }
    }

    private fun refreshOutput() {
        val o = detectOutput()
        if (o != activeOutput) {
            activeOutput = o
            applyActiveProfile()
        }
    }

    private fun initEffects(session: Int) {
        try { eq?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        try { loudnessFx?.release() } catch (_: Exception) {}
        eq = null; bassBoost = null; virtualizer = null; loudnessFx = null
        if (session == C.AUDIO_SESSION_ID_UNSET || session == 0) return
        try { bassBoost = BassBoost(0, session) } catch (_: Exception) {}
        try { virtualizer = Virtualizer(0, session) } catch (_: Exception) {}
        try { loudnessFx = LoudnessEnhancer(session) } catch (_: Exception) {}
        applyActiveProfile()
    }

    /** Profile for [key], with band levels sized to this device's band count. */
    fun profile(key: String): EqProfile {
        val p = store.data.eqProfiles[key] ?: EqProfile()
        return if (p.levels.size != EQ_FREQS.size) p.copy(levels = List(EQ_FREQS.size) { 0 }) else p
    }

    fun editProfile(key: String, f: (EqProfile) -> EqProfile) {
        val next = f(profile(key))
        store.update { it.copy(eqProfiles = it.eqProfiles + (key to next)) }
        if (key == activeOutput) applyActiveProfile()
    }

    fun applyActiveProfile() {
        val p = profile(activeOutput)
        val on = p.enabled
        audioProc.setEq(on, p.levels)
        try {
            bassBoost?.let { b ->
                if (b.strengthSupported) b.setStrength(p.bass.coerceIn(0, 1000).toShort())
                b.enabled = on && p.bass > 0
            }
        } catch (_: Exception) {
        }
        try {
            virtualizer?.let { v ->
                if (v.strengthSupported) v.setStrength(p.virtualizer.coerceIn(0, 1000).toShort())
                v.enabled = on && p.virtualizer > 0
            }
        } catch (_: Exception) {
        }
        preampVol = if (on && p.loudness < 0) Math.pow(10.0, p.loudness / 2000.0).toFloat() else 1f
        try {
            loudnessFx?.let { l ->
                l.setTargetGain(p.loudness.coerceIn(0, 1500))
                l.enabled = on && p.loudness > 0
            }
        } catch (_: Exception) {
        }
    }

    /** Band levels of one of the device's built-in presets. */
    fun systemPresetLevels(index: Int): List<Int>? {
        val e = eq ?: return null
        return try {
            e.usePreset(index.toShort())
            val l = (0 until e.numberOfBands).map { e.getBandLevel(it.toShort()).toInt() }
            applyActiveProfile() // put the live equalizer back to the active profile
            l
        } catch (_: Exception) {
            null
        }
    }

    /** Re-applies the stored equalizer profile (after settings were restored from a backup). */
    fun reapplyEffects() = applyActiveProfile()

    fun saveCustomPreset(name: String, levels: List<Int>) {
        val n = name.trim()
        if (n.isEmpty()) return
        store.update { it.copy(customPresets = it.customPresets.filter { p -> p.name != n } + EqPreset(n, levels)) }
    }

    fun deleteCustomPreset(name: String) =
        store.update { it.copy(customPresets = it.customPresets.filter { p -> p.name != name }) }

    // ---- widget helpers ----
    fun toggleFavouriteCurrent() {
        current?.let { store.toggleFavourite(it.id) }
    }
}
