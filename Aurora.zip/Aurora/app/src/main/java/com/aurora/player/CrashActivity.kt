package com.aurora.player

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Shown (in its own process) when Aurora crashes, so the error can be read and copied without a computer. Plain views on purpose. */
class CrashActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val trace = intent.getStringExtra("trace").orEmpty()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE); setPadding(32, 80, 32, 32) }
        root.addView(TextView(this).apply { text = "Aurora stopped"; textSize = 22f; setTextColor(Color.BLACK) })
        root.addView(TextView(this).apply { text = "Tap Copy and paste the text to the developer."; setTextColor(Color.DKGRAY); setPadding(0, 8, 0, 16) })
        val row = LinearLayout(this).apply { gravity = Gravity.START }
        row.addView(Button(this).apply {
            text = "Copy"
            setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Aurora crash", trace))
                Toast.makeText(this@CrashActivity, "Copied", Toast.LENGTH_SHORT).show()
            }
        })
        row.addView(Button(this).apply { text = "Close"; setOnClickListener { finishAndRemoveTask(); android.os.Process.killProcess(android.os.Process.myPid()) } })
        root.addView(row)
        root.addView(ScrollView(this).apply {
            addView(TextView(this@CrashActivity).apply { text = trace; textSize = 11f; setTextColor(Color.BLACK); setTextIsSelectable(true) })
        })
        setContentView(root)
    }
}
