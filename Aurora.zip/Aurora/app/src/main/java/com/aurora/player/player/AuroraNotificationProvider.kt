package com.aurora.player.player

import android.app.Notification
import android.content.Context
import android.os.Bundle
import android.widget.RemoteViews
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import com.aurora.player.R
import com.aurora.player.controller
import com.aurora.player.ui.dominantColor
import androidx.compose.ui.graphics.toArgb
import com.google.common.collect.ImmutableList

/**
 * Media notification in Musicolet's layout: cover on the left, title and artist, one row of buttons
 * (favourite, previous, play/pause, next, close) and the "Upcoming songs" list underneath.
 * Falls back to the standard notification if anything goes wrong.
 */
@UnstableApi
class AuroraNotificationProvider(private val ctx: Context) : MediaNotification.Provider {
    @Volatile private var broken = false
    @Volatile private var validated = false
    private val base = DefaultMediaNotificationProvider.Builder(ctx).build().also { it.setSmallIcon(R.drawable.ic_qs_tile) }

    private var lastSession: MediaSession? = null
    private var lastLayout: ImmutableList<CommandButton>? = null
    private var lastFactory: MediaNotification.ActionFactory? = null
    private var lastCallback: MediaNotification.Provider.Callback? = null

    /** Rebuilds and re-posts the notification, e.g. after a notification setting changed. */
    fun refresh() {
        try {
            val s = lastSession ?: return; val l = lastLayout ?: return
            val f = lastFactory ?: return; val cb = lastCallback ?: return
            cb.onNotificationChanged(createNotification(s, l, f, cb))
        } catch (_: Throwable) {}
    }

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback,
    ): MediaNotification {
        lastSession = mediaSession; lastLayout = customLayout; lastFactory = actionFactory; lastCallback = onNotificationChangedCallback
        val n = base.createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
        return try {
            val c = ctx.controller
            val d = c.store.data
            if (!d.customNotif) return n
            val t = c.current ?: return n
            val playing = mediaSession.player.playWhenReady

            // a small copy of the cover: full-size art inside RemoteViews can blow the binder limit on Android 10
            val artBmp: android.graphics.Bitmap? = try {
                (n.notification.getLargeIcon()?.loadDrawable(ctx) as? android.graphics.drawable.BitmapDrawable)?.bitmap?.let { src ->
                    val k = 256f / maxOf(src.width, src.height)
                    if (k >= 1f) src else android.graphics.Bitmap.createScaledBitmap(src, (src.width * k).toInt().coerceAtLeast(1), (src.height * k).toInt().coerceAtLeast(1), true)
                }
            } catch (_: Throwable) { null }

            // background = the cover's own background colour, taken from its outer edge (no darkening)
            val bg: Int = try {
                val bmp = artBmp
                // a deep shade of the cover's colour (like Musicolet's dark card) with a bright accent on top
                val base = if (d.notifAdapt && bmp != null) (if (d.notifAdaptStyle == 1) coverColor(bmp) else edgeColor(bmp)) else 0xFF3A3F55.toInt()
                val hh = FloatArray(3); androidx.core.graphics.ColorUtils.colorToHSL(base, hh)
                androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf(hh[0], hh[1].coerceIn(0.30f, 0.75f), hh[2].coerceIn(0.17f, 0.30f)))
            } catch (_: Throwable) { 0xFF3A3F55.toInt() }
            val light = androidx.core.graphics.ColorUtils.calculateLuminance(bg) > 0.5
            val white = if (light) 0xFF111111.toInt() else android.graphics.Color.WHITE
            val soft = if (light) 0xCC111111.toInt() else 0xCCFFFFFF.toInt()

            // the buttons live inside the layout (like Musicolet): Media3's own action PendingIntents are reused for them
            val acts = n.notification.actions?.toList() ?: emptyList()
            val customTitles = customLayout.map { it.displayName.toString() }
            val custom = acts.filter { a -> a.title?.toString() in customTitles }
            val std = acts.filter { a -> a !in custom }
            val firstCustom = custom.firstOrNull()
            val ordered = ArrayList<Notification.Action>()
            if (std.size >= 3) {
                firstCustom?.let { ordered += it }
                ordered += std[0]; ordered += std[1]; ordered += std[2]
                ordered += custom.drop(if (firstCustom != null) 1 else 0)
            } else { ordered += std; ordered += custom }
            val slots = intArrayOf(R.id.b1, R.id.b2, R.id.b3, R.id.b4, R.id.b5, R.id.b6, R.id.b7)

            // accent colour: the cover's background hue, made light (or dark) enough to read
            val accent: Int = try {
                val hsl = FloatArray(3); androidx.core.graphics.ColorUtils.colorToHSL(bg, hsl)
                hsl[1] = maxOf(hsl[1], 0.55f); hsl[2] = if (light) 0.28f else 0.68f
                androidx.core.graphics.ColorUtils.HSLToColor(hsl)
            } catch (_: Throwable) { white }

            fun build(withUpcoming: Boolean): RemoteViews {
                val rv = RemoteViews(ctx.packageName, if (withUpcoming) R.layout.notif_musicolet else R.layout.notif_musicolet_small)
                rv.setTextColor(R.id.n_title, accent); rv.setTextColor(R.id.n_artist, soft)
                rv.setTextColor(R.id.up_title, accent); rv.setTextColor(R.id.up1, soft); rv.setTextColor(R.id.up2, soft)
                rv.setTextViewText(R.id.n_title, t.title)
                rv.setTextViewText(R.id.n_artist, t.artist)
                if (d.notifArt && artBmp != null) { rv.setImageViewBitmap(R.id.art, com.aurora.player.widget.roundedSquare(artBmp, 256, 0.14f)); rv.setViewVisibility(R.id.art, android.view.View.VISIBLE) }
                else rv.setViewVisibility(R.id.art, android.view.View.GONE)

                for ((i, id) in slots.withIndex()) {
                    val a = ordered.getOrNull(i)
                    // the compact card only has room for previous / play / next, like Musicolet
                    val compactKeep = if (firstCustom != null) 1..3 else 0..2
                    if (a == null || (!withUpcoming && i !in compactKeep)) { rv.setViewVisibility(id, android.view.View.GONE); continue }
                    rv.setViewVisibility(id, android.view.View.VISIBLE)
                    try { a.getIcon()?.let { rv.setImageViewIcon(id, it) } } catch (_: Throwable) {}
                    rv.setInt(id, "setColorFilter", accent)
                    rv.setContentDescription(id, a.title)
                    a.actionIntent?.let { rv.setOnClickPendingIntent(id, it) }
                }

                val upcoming = if (withUpcoming && d.notifUpcoming) (c.queue.drop(c.currentIndex + 1) + c.queue.take(c.currentIndex)).filter { it.id != t.id }.take(2) else emptyList()
                rv.setViewVisibility(R.id.n_div, if (upcoming.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE)
                if (upcoming.isEmpty()) rv.setViewVisibility(R.id.up_box, android.view.View.GONE)
                else {
                    rv.setViewVisibility(R.id.up_box, android.view.View.VISIBLE)
                    rv.setTextViewText(R.id.up1, upcoming.getOrNull(0)?.let { it.title + " - " + it.artist } ?: "")
                    rv.setTextViewText(R.id.up2, upcoming.getOrNull(1)?.let { it.title + " - " + it.artist } ?: "")
                    rv.setViewVisibility(R.id.up2, if (upcoming.size > 1) android.view.View.VISIBLE else android.view.View.GONE)
                }
                return rv
            }

            if (broken) return n
            val small = build(false); val big = build(true)
            // the system inflates these in another process and kills the app if they are invalid, so prove they inflate here first
            if (!validated) {
                small.apply(ctx, android.widget.FrameLayout(ctx)); big.apply(ctx, android.widget.FrameLayout(ctx))
                validated = true
            }
            val b = Notification.Builder.recoverBuilder(ctx, n.notification)
            b.setColor(bg).setColorized(true)
            // the cover is drawn by the layout itself; a large icon would be stretched behind it on some phones
            b.setLargeIcon(null as android.graphics.drawable.Icon?)
            b.setCustomContentView(small)
            b.setCustomBigContentView(big)
            val token = mediaSession.sessionCompatToken.token as android.media.session.MediaSession.Token
            b.setStyle(Notification.DecoratedMediaCustomViewStyle().setMediaSession(token))
            val built = b.build()
            // the buttons are inside the layout now, so drop the system's own action row (no double buttons)
            if (ordered.isNotEmpty()) {
                built.actions = null
                // the standard notification remembered which actions to show when small; with no actions left that crashes the system UI
                try { built.extras.remove("android.compactActions") } catch (_: Throwable) {}
            }
            try { built.extras.remove("android.largeIcon"); built.extras.remove("android.largeIcon.big") } catch (_: Throwable) {}
            MediaNotification(n.notificationId, built)
        } catch (e: Throwable) {
            // never let the custom layout take the app down: remember the failure and use the standard notification from now on
            broken = true
            try { com.aurora.player.CrashLog.write(ctx, "Custom notification disabled", e) } catch (_: Throwable) {}
            n
        }
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        base.handleCustomCommand(session, action, extras)
}

/**
 * Picks the notification colour the way Musicolet does: the cover is sorted into colour swatches (vibrant, dark vibrant, muted…)
 * and the first one that is present, in a fixed order of preference, wins. A plain cover falls back to its edge colour.
 */
internal fun coverColor(src: android.graphics.Bitmap): Int {
    val sm = android.graphics.Bitmap.createScaledBitmap(src, 64, 64, true)
    val groups = Array(6) { ArrayList<Int>() }
    val hsl = FloatArray(3)
    for (x in 0 until 64) for (y in 0 until 64) {
        val px = sm.getPixel(x, y)
        androidx.core.graphics.ColorUtils.colorToHSL(px, hsl)
        val l = hsl[2]; val sat = hsl[1]
        if (l < 0.08f || l > 0.92f) continue
        val vib = sat >= 0.35f
        val k = when {
            l < 0.35f -> if (vib) 2 else 5      // dark vibrant / dark muted
            l > 0.65f -> if (vib) 1 else 4      // light vibrant / light muted
            else -> if (vib) 0 else 3           // vibrant / muted
        }
        groups[k].add(px)
    }
    val total = 64 * 64
    // order: dark vibrant, vibrant, dark muted, muted, light vibrant
    for (k in intArrayOf(2, 0, 5, 3, 1)) {
        // the most common colour family of the swatch, never a mix of different hues (a mix can land on a colour the cover doesn't have)
        if (groups[k].size >= total * 0.02) return commonColor(groups[k].toIntArray())
    }
    return edgeColor(src)
}

/**
 * The most common colour of [px]: pixels are sorted into coarse colour boxes and the fullest box is averaged.
 * Unlike a plain average this always gives a colour that is really in the picture.
 */
internal fun commonColor(px: IntArray): Int {
    if (px.isEmpty()) return 0xFF3A3F55.toInt()
    val cnt = IntArray(512); val sr = LongArray(512); val sg = LongArray(512); val sb = LongArray(512)
    for (p in px) {
        val r = android.graphics.Color.red(p); val g = android.graphics.Color.green(p); val b = android.graphics.Color.blue(p)
        val k = ((r shr 5) shl 6) or ((g shr 5) shl 3) or (b shr 5)
        cnt[k] = cnt[k] + 1; sr[k] = sr[k] + r; sg[k] = sg[k] + g; sb[k] = sb[k] + b
    }
    var best = 0
    for (k in 1 until 512) if (cnt[k] > cnt[best]) best = k
    val n = cnt[best].coerceAtLeast(1)
    return android.graphics.Color.rgb((sr[best] / n).toInt(), (sg[best] / n).toInt(), (sb[best] / n).toInt())
}

/** The cover's background colour: the most common colour along its outer ring of pixels. */
internal fun edgeColor(src: android.graphics.Bitmap): Int {
    val sm = android.graphics.Bitmap.createScaledBitmap(src, 48, 48, true)
    val last = 47
    val ring = ArrayList<Int>()
    for (i in 0..last) { ring.add(sm.getPixel(i, 0)); ring.add(sm.getPixel(i, last)); ring.add(sm.getPixel(0, i)); ring.add(sm.getPixel(last, i)) }
    return commonColor(ring.toIntArray())
}
