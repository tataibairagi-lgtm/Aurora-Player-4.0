package com.aurora.player.lock

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.animation.core.animateFloat
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.player.automation.Automation
import com.aurora.player.controller
import com.aurora.player.ui.AlbumArt
import com.aurora.player.ui.AuroraTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.math.roundToInt

/** Shown over the lock screen when an alarm rings: tap to stop, swipe up to snooze. */
class AlarmRingActivity : ComponentActivity() {
    private var alarmId = ""
    private var created = 0L
    private var done = false
    /** Pressing the power button turns the screen off: that counts as snooze (or stop, as chosen in the alarm settings). */
    private val screenOff = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context, intent: android.content.Intent) {
            if (done || System.currentTimeMillis() - created < 2500) return   // ignore the screen switching on
            when (controller.store.data.alarmPower) { 1 -> snoozeAlarm(); 2 -> stopAlarm() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alarmId = intent.getStringExtra(Automation.EXTRA_ID).orEmpty()
        created = System.currentTimeMillis()
        try { registerReceiver(screenOff, android.content.IntentFilter(android.content.Intent.ACTION_SCREEN_OFF)) } catch (_: Throwable) {}
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        @Suppress("DEPRECATION")
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).let { if (Build.VERSION.SDK_INT >= 26) it.requestDismissKeyguard(this, null) } } catch (_: Throwable) {}
        enableEdgeToEdge()
        setContent {
            AuroraTheme(2, controller.store.data.accentColor) {
                RingContent(
                    onStop = { stopAlarm() },
                    onSnooze = { snoozeAlarm() },
                )
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        alarmId = intent.getStringExtra(Automation.EXTRA_ID).orEmpty()
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenOff) } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun stopAlarm() {
        if (done) return
        done = true
        try { controller.pause(); controller.setAlarmAudio(false) } catch (_: Throwable) {}   // back to normal media volume and counting
        Automation.stopRing(this)
        finish()
    }

    private fun snoozeAlarm() {
        if (done) return
        done = true
        try { controller.pause(); controller.setAlarmAudio(false) } catch (_: Throwable) {}
        val min = controller.store.data.alarmSnoozeMin
        if (alarmId.isNotEmpty()) Automation.snooze(this, controller, alarmId, min)
                Automation.stopRing(this)
        finish()
    }
}

@Composable
private fun RingContent(onStop: () -> Unit, onSnooze: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val c = ctx.controller
    val cs = MaterialTheme.colorScheme
    val track = c.current
    val is24 = remember { android.text.format.DateFormat.is24HourFormat(ctx) }
    var now by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { now = Calendar.getInstance(); delay(1000) } }
    val h = now.get(Calendar.HOUR_OF_DAY); val m = now.get(Calendar.MINUTE)
    val timeText = if (is24) "%02d:%02d".format(h, m) else "%d:%02d".format(if (h % 12 == 0) 12 else h % 12, m)
    val dateText = remember(now.get(Calendar.DAY_OF_YEAR)) { java.text.SimpleDateFormat("EEEE, d MMMM", java.util.Locale.getDefault()).format(now.time) }
    val scope = rememberCoroutineScope()
    val drag = remember { Animatable(0f) }
    val snoozeMin = c.store.data.alarmSnoozeMin
    val accent = cs.primary
    // a soft pulse behind the alarm icon
    val pulse = androidx.compose.animation.core.rememberInfiniteTransition(label = "ring")
    val ps by pulse.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(1800, easing = androidx.compose.animation.core.LinearEasing)), label = "p")

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF14141C), accent.copy(alpha = 0.35f).compositeOver(Color(0xFF0B0B10)), Color(0xFF0B0B10))))
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = { scope.launch { if (drag.value < -220f) onSnooze() else drag.animateTo(0f) } },
                    onDragCancel = { scope.launch { drag.animateTo(0f) } },
                ) { _, dy -> scope.launch { drag.snapTo((drag.value + dy).coerceAtMost(0f)) } }
            },
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.padding(top = 20.dp).size(72.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size((44 + 28 * ps).dp).clip(CircleShape).background(accent.copy(alpha = 0.30f * (1f - ps))))
                Box(Modifier.size(48.dp).clip(CircleShape).background(accent.copy(alpha = 0.28f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Alarm, null, Modifier.size(28.dp), tint = Color.White)
                }
            }
            Text(timeText, fontSize = 92.sp, fontWeight = FontWeight.Light, color = Color.White, modifier = Modifier.padding(top = 4.dp))
            Text(dateText, color = Color.White.copy(alpha = 0.7f), fontSize = 16.sp)
            if (track != null) {
                androidx.compose.foundation.layout.Row(
                    Modifier.padding(top = 28.dp).fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = 0.08f)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AlbumArt(track, Modifier.size(64.dp), androidx.compose.foundation.shape.RoundedCornerShape(16.dp), 28.dp, 300)
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(track.title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            Box(Modifier.weight(1f))
            Column(Modifier.offset { IntOffset(0, drag.value.roundToInt()) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.KeyboardArrowUp, null, Modifier.size(30.dp), tint = Color.White.copy(alpha = 0.7f))
                Box(
                    Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.14f)).clickable(onClick = onSnooze).padding(horizontal = 28.dp, vertical = 14.dp),
                    contentAlignment = Alignment.Center,
                ) { Text("Snooze  ·  $snoozeMin min", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium) }
                Text("Tap, swipe up, or press the power button", Modifier.padding(top = 8.dp), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }
            Box(
                Modifier.padding(top = 26.dp, bottom = 10.dp).size(88.dp).clip(CircleShape).background(Color(0xFFE5484D)).clickable(onClick = onStop),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Stop, "Stop", Modifier.size(44.dp), tint = Color.White) }
            Text("Stop alarm", color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
        }
    }
}
