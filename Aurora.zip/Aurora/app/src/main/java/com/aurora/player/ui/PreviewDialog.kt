package com.aurora.player.ui

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.delay

/**
 * Listen to a short part of a song without touching the queue. It starts about a third of the way in and stops after 20 seconds;
 * drag the bar to hear another part. Your music is paused while the preview is open and resumes when you close it.
 */
@Composable
fun PreviewDialog(c: PlayerController, t: Track, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var playing by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(0) }
    var dur by remember { mutableIntStateOf(t.durationMs.toInt().coerceAtLeast(1)) }
    var drag by remember { mutableFloatStateOf(-1f) }
    var stopAt by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    val mp = remember { MediaPlayer() }

    DisposableEffect(Unit) {
        val wasPlaying = c.isPlaying
        if (wasPlaying) c.togglePlay()
        try {
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            mp.setDataSource(ctx, Uri.parse(t.uri))
            mp.setOnPreparedListener {
                dur = it.duration.coerceAtLeast(1)
                val start = (dur * 0.3f).toInt()
                it.seekTo(start); stopAt = start + 20_000
                it.start(); playing = true; ready = true
            }
            mp.setOnCompletionListener { playing = false }
            mp.setOnErrorListener { _, _, _ -> failed = true; playing = false; true }
            mp.prepareAsync()
        } catch (_: Throwable) { failed = true }
        onDispose {
            try { mp.release() } catch (_: Throwable) {}
            if (wasPlaying && !c.isPlaying) c.togglePlay()
        }
    }
    LaunchedEffect(ready) {
        while (ready) {
            try {
                if (drag < 0f) pos = mp.currentPosition
                if (playing && mp.currentPosition >= stopAt) { mp.pause(); playing = false }
            } catch (_: Throwable) {}
            delay(200)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Preview") },
        text = {
            Column {
                Text(t.title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(t.artist, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (failed) {
                    Text("This song can't be previewed.", Modifier.padding(top = 12.dp), color = MaterialTheme.colorScheme.error)
                } else {
                    Slider(
                        value = if (drag >= 0f) drag else pos.toFloat().coerceIn(0f, dur.toFloat()),
                        onValueChange = { drag = it },
                        onValueChangeFinished = {
                            try { mp.seekTo(drag.toInt()); stopAt = drag.toInt() + 20_000; if (!playing) { mp.start(); playing = true } } catch (_: Throwable) {}
                            pos = drag.toInt(); drag = -1f
                        },
                        valueRange = 0f..dur.toFloat(), enabled = ready,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                    Row(Modifier.fillMaxWidth()) {
                        Text(formatTime((if (drag >= 0f) drag.toInt() else pos).toLong()), style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(1f))
                        Text(formatTime(dur.toLong()), style = MaterialTheme.typography.labelMedium)
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Center) {
                        Box(
                            Modifier.size(56.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary).bounceClick {
                                if (!ready) return@bounceClick
                                try {
                                    if (playing) { mp.pause(); playing = false }
                                    else { if (mp.currentPosition >= stopAt) stopAt = mp.currentPosition + 20_000; mp.start(); playing = true }
                                } catch (_: Throwable) {}
                            },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(32.dp))
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton({ onDismiss(); c.playTracks(listOf(t), 0) }) { Text("Play song") } },
        dismissButton = { TextButton(onDismiss) { Text("Close") } },
    )
}
