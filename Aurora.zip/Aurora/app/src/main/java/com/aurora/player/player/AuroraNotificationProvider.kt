package com.aurora.player.player

import android.app.Notification
import android.content.Context
import android.os.Bundle
import android.widget.RemoteViews
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import com.aurora.player.R
import com.aurora.player.controller
import com.aurora.player.ui.dominantColor
import androidx.compose.ui.graphics.toArgb
import com.google.common.collect.ImmutableList

/**
 * Media notification in Musicolet's layout: cover on the left, title and artist, one row of buttons
 * (favourite, previous, play/pause, next, close) and the "Upcoming songs" list underneath.
 * Falls back to the standard notification if anything goes wrong.
 */
@UnstableApi
class AuroraNotificationProvider(private val ctx: Context) : MediaNotification.Provider {
    private val base = DefaultMediaNotificationProvider.Builder(ctx).build().also { it.setSmallIcon(R.drawable.ic_stat_aurora) }

    override fun createNotification(
        mediaSession: MediaSession,
        customLayout: ImmutableList<CommandButton>,
        actionFactory: MediaNotification.ActionFactory,
        onNotificationChangedCallback: MediaNotification.Provider.Callback,
    ): MediaNotification {
        val n = base.createNotification(mediaSession, customLayout, actionFactory, onNotificationChangedCallback)
        return try {
            val c = ctx.controller
            val d = c.store.data
            val t = c.current ?: return n
            val playing = mediaSession.player.playWhenReady

            // background = the cover's own background colour, taken from its outer edge (no darkening)
            val bg: Int = try {
                val bmp = (n.notification.getLargeIcon()?.loadDrawable(ctx) as? android.graphics.drawable.BitmapDrawable)?.bitmap
                if (d.notifAdapt && bmp != null) edgeColor(bmp) else 0xFF3A3F55.toInt()
            } catch (_: Throwable) { 0xFF3A3F55.toInt() }
            val light = androidx.core.graphics.ColorUtils.calculateLuminance(bg) > 0.5
            val white = if (light) 0xFF111111.toInt() else android.graphics.Color.WHITE
            val soft = if (light) 0xCC111111.toInt() else 0xCCFFFFFF.toInt()

            fun build(withUpcoming: Boolean): RemoteViews {
                val rv = RemoteViews(ctx.packageName, R.layout.notif_musicolet)
                rv.setInt(R.id.n_root, "setBackgroundColor", bg)
                rv.setTextColor(R.id.n_title, white); rv.setTextColor(R.id.n_artist, soft)
                rv.setTextColor(R.id.up_title, white); rv.setTextColor(R.id.up1, soft); rv.setTextColor(R.id.up2, soft)
                listOf(R.id.b_left, R.id.b_prev, R.id.b_play, R.id.b_next, R.id.b_r1, R.id.b_r2).forEach { rv.setInt(it, "setColorFilter", white) }
                rv.setTextViewText(R.id.n_title, t.title)
                rv.setTextViewText(R.id.n_artist, t.artist)
                val icon = n.notification.getLargeIcon()
                if (d.notifArt && icon != null) { rv.setImageViewIcon(R.id.art, icon); rv.setViewVisibility(R.id.art, android.view.View.VISIBLE) }
                else rv.setViewVisibility(R.id.art, android.view.View.GONE)

                fun media(id: Int, res: Int, cmd: Int) {
                    rv.setImageViewResource(id, res)
                    rv.setOnClickPendingIntent(id, actionFactory.createMediaActionPendingIntent(mediaSession, cmd.toLong()))
                }
                fun custom(id: Int, res: Int, action: String) {
                    rv.setImageViewResource(id, res)
                    rv.setOnClickPendingIntent(id, actionFactory.createCustomAction(mediaSession, androidx.core.graphics.drawable.IconCompat.createWithResource(ctx, res), action, action, Bundle.EMPTY).actionIntent)
                    rv.setViewVisibility(id, android.view.View.VISIBLE)
                }
                media(R.id.b_prev, R.drawable.ic_w_prev, Player.COMMAND_SEEK_TO_PREVIOUS)
                media(R.id.b_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play, Player.COMMAND_PLAY_PAUSE)
                media(R.id.b_next, R.drawable.ic_w_next, Player.COMMAND_SEEK_TO_NEXT)

                val fav = c.store.isFavourite(t.id)
                if ("fav" in d.notifButtons) custom(R.id.b_left, if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart, "aurora.fav")
                else rv.setViewVisibility(R.id.b_left, android.view.View.GONE)
                val right = d.notifButtons.filter { it != "fav" }
                listOf(R.id.b_r1, R.id.b_r2).forEachIndexed { i, id ->
                    when (right.getOrNull(i)) {
                        "close" -> custom(id, R.drawable.ic_close, "aurora.close")
                        "repeat" -> custom(id, R.drawable.ic_repeat, "aurora.repeat")
                        "shuffle" -> custom(id, R.drawable.ic_shuffle, "aurora.shuffle")
                        else -> rv.setViewVisibility(id, android.view.View.GONE)
                    }
                }

                val upcoming = if (withUpcoming && d.notifUpcoming) c.queue.drop(c.currentIndex + 1).take(2) else emptyList()
                if (upcoming.isEmpty()) rv.setViewVisibility(R.id.up_box, android.view.View.GONE)
                else {
                    rv.setViewVisibility(R.id.up_box, android.view.View.VISIBLE)
                    rv.setTextViewText(R.id.up1, upcoming.getOrNull(0)?.let { it.title + " - " + it.artist } ?: "")
                    rv.setTextViewText(R.id.up2, upcoming.getOrNull(1)?.let { it.title + " - " + it.artist } ?: "")
                }
                return rv
            }

            val b = Notification.Builder.recoverBuilder(ctx, n.notification)
            b.setColor(bg).setColorized(true)
            b.setCustomContentView(build(false))
            b.setCustomBigContentView(build(true))
            val token = mediaSession.sessionCompatToken.token as android.media.session.MediaSession.Token
            b.setStyle(Notification.DecoratedMediaCustomViewStyle().setMediaSession(token).setShowActionsInCompactView(0, 1, 2))
            MediaNotification(n.notificationId, b.build())
        } catch (_: Throwable) {
            n
        }
    }

    override fun handleCustomCommand(session: MediaSession, action: String, extras: Bundle): Boolean =
        base.handleCustomCommand(session, action, extras)
}

/** Average colour of the outer ring of pixels: that is the cover's background colour. */
private fun edgeColor(src: android.graphics.Bitmap): Int {
    val sm = android.graphics.Bitmap.createScaledBitmap(src, 32, 32, true)
    var r = 0L; var g = 0L; var b = 0L; var cnt = 0
    val last = 31
    for (i in 0..last) for (pos in listOf(i to 0, i to last, 0 to i, last to i)) {
        val px = sm.getPixel(pos.first, pos.second)
        r += android.graphics.Color.red(px); g += android.graphics.Color.green(px); b += android.graphics.Color.blue(px); cnt++
    }
    return android.graphics.Color.rgb((r / cnt).toInt(), (g / cnt).toInt(), (b / cnt).toInt())
}
