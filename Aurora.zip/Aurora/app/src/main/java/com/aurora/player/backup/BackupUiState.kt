package com.aurora.player.backup

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** What the backup/restore dialogs are currently showing. Lives on the Application so it survives screen changes. */
class BackupUiState {
    var busy by mutableStateOf(false)
    var picker by mutableStateOf(false)
    var files by mutableStateOf<List<BackupFile>>(emptyList())
    var preview by mutableStateOf<LoadedBackup?>(null)
    var previewName by mutableStateOf("")
}
