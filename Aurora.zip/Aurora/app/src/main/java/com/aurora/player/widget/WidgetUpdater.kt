package com.aurora.player.widget

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import com.aurora.player.MainActivity
import com.aurora.player.R
import com.aurora.player.controller
import com.aurora.player.data.MediaScanner
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController
import com.aurora.player.ui.ArtLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val ACTION_PLAY_PAUSE = "aurora.widget.PLAY_PAUSE"
const val ACTION_NEXT = "aurora.widget.NEXT"
const val ACTION_PREV = "aurora.widget.PREV"
const val ACTION_SHUFFLE = "aurora.widget.SHUFFLE"
const val ACTION_REPEAT = "aurora.widget.REPEAT"
const val ACTION_FAVOURITE = "aurora.widget.FAVOURITE"
const val ACTION_REWIND = "aurora.widget.REWIND"
const val ACTION_FF = "aurora.widget.FF"
const val ACTION_JUMP = "aurora.widget.JUMP"
const val ACTION_OVERLAY = "aurora.widget.OVERLAY"
const val ACTION_TICK = "aurora.widget.TICK"
const val EXTRA_INDEX = "index"

private class Spec(
    val provider: Class<*>,
    val layout: Int,
    val artPx: Int,
    val fav: Boolean = false,
    val progress: Boolean = false,
    val modes: Boolean = false,
    val queue: Boolean = false,
    val list: Boolean = false,
    val kind: Int = 0, // 1 standard (Simple tab), 2 large (Advanced tab), 3 queue
)

private val specs = listOf(
    Spec(MiniWidget::class.java, R.layout.widget_mini, 160),
    Spec(StandardWidget::class.java, R.layout.widget_standard, 280, fav = true, progress = true, kind = 1),
    Spec(SquareWidget::class.java, R.layout.widget_square, 360),
    Spec(LargeWidget::class.java, R.layout.widget_large, 420, fav = true, progress = true, modes = true, queue = true, kind = 2),
    Spec(QueueWidget::class.java, R.layout.widget_queue, 240, fav = true, list = true, kind = 3),
)

/** Redraws every Aurora widget on the home screen from the current player state. */
object WidgetUpdater {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var generation = 0

    fun update(ctx: Context) {
        val app = ctx.applicationContext
        try { val cc = app.controller; if (!cc.store.data.widgetsLive && cc.isPlaying) return } catch (_: Throwable) {}
        val mgr = AppWidgetManager.getInstance(app)
        val placed = specs.map { it to mgr.getAppWidgetIds(ComponentName(app, it.provider)) }
            .filter { it.second.isNotEmpty() }
        if (placed.isEmpty()) return
        scheduleTick(app, placed.any { it.first.list })

        val mine = ++generation
        scope.launch {
            kotlinx.coroutines.delay(250) // song changes fire several events at once: draw once, after they settle
            if (mine != generation) return@launch
            try {
            val c = app.controller
            // Cold start (e.g. widget tapped while the app is closed): load the library so the last song shows.
            if (c.library.isEmpty() && hasAudioPermission(app)) {
                val list = withContext(Dispatchers.IO) { runCatching { MediaScanner.scan(app) }.getOrDefault(emptyList()) }
                if (list.isNotEmpty()) c.attachLibrary(list)
            }
            val t = c.current
            val art = try { t?.let { ArtLoader.load(app, it) } } catch (_: Throwable) { null }
            WidgetTheme.artSeed = art?.let { artColor(it) }
            if (mine != generation) return@launch // a newer update is already on its way
            for ((spec, ids) in placed) {
                // a widget problem must never take the player down with it
                try {
                    val views = withContext(Dispatchers.Default) { build(app, spec, c, t, art) }
                    mgr.updateAppWidget(ids, views)
                    if (spec.list) {
                        mgr.notifyAppWidgetViewDataChanged(ids, R.id.w_list)
                        // the refresh above resets the list to the top, so the scroll is sent afterwards, on its own
                        // earlier songs stay above the playing one; the list is scrolled so the playing song is at the top.
                        // The scroll is sent a few times because the list may still be loading the first time.
                        forceScroll = false
                        // on the device the scroll puts the target row at the TOP of the list (aiming 3 rows past it left it two rows too high), so aim at the playing song itself
                        val at = c.currentIndex.coerceIn(0, (c.queue.size - 1).coerceAtLeast(0))
                        for (wait in longArrayOf(300, 700, 1500, 2600)) {
                            kotlinx.coroutines.delay(wait)
                            if (mine != generation) break
                            scrollList(app, ids, at)
                        }
                    }
                } catch (e: Throwable) {
                    com.aurora.player.CrashLog.write(app, "Widget update failed (${spec.provider.simpleName})", e)
                }
            }
            } catch (e: Throwable) {
                com.aurora.player.CrashLog.write(app, "Widget update failed", e)
            }
        }
    }

    private fun hasAudioPermission(ctx: Context): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    }

    /** Average colour of a small copy of the cover. */
    private fun artColor(b: Bitmap): Int? = try {
        val s = Bitmap.createScaledBitmap(b, 32, 32, true)
        val px = IntArray(32 * 32)
        s.getPixels(px, 0, 32, 0, 0, 32, 32)
        com.aurora.player.player.commonColor(px)
    } catch (_: Throwable) { null }

    /** Themes the Simple (standard) and Advanced (large) widgets and applies their checkboxes. */
    private fun decorateCard(ctx: Context, v: RemoteViews, s: Spec, c: PlayerController) {
        val d = c.store.data
        val th = WidgetTheme.resolve(ctx, d.queueTheme)
        val opacity = ((100 - d.wAlpha.coerceIn(0, 100)) * 255 / 100)
        v.setInt(R.id.w_bg, "setColorFilter", th.panel)
        v.setInt(R.id.w_bg, "setImageAlpha", if (th.flat) opacity * th.panelAlpha / 255 else opacity)
        v.setTextColor(R.id.w_title, if (th.flat) th.accent else th.text); v.setTextColor(R.id.w_artist, if (th.flat) th.accent else th.sub)
        if (th.flat) {
            runCatching { v.setInt(R.id.w_play, "setBackgroundResource", 0) }
            runCatching { v.setInt(R.id.w_play, "setColorFilter", th.accent) }
        }
        for (id in intArrayOf(R.id.w_fav, R.id.w_prev, R.id.w_next, R.id.w_shuffle, R.id.w_repeat)) runCatching { v.setInt(id, "setColorFilter", th.accent) }
        val adv = s.kind == 2
        val art = if (adv) d.waArt else d.wsArt
        val fav = if (adv) d.waFav else d.wsFav
        val prog = if (adv) d.waProg else d.wsProg
        v.setViewVisibility(R.id.w_art, if (art) View.VISIBLE else View.GONE)
        v.setViewVisibility(R.id.w_fav, if (fav) View.VISIBLE else View.GONE)
        v.setViewVisibility(R.id.w_progress, if (prog) View.VISIBLE else View.GONE)
        if (adv) {
            v.setViewVisibility(R.id.w_shuffle, if (d.waModes) View.VISIBLE else View.GONE)
            v.setViewVisibility(R.id.w_repeat, if (d.waModes) View.VISIBLE else View.GONE)
            for (id in intArrayOf(R.id.w_q1, R.id.w_q2, R.id.w_q3)) {
                runCatching { v.setTextColor(id, th.sub) }
                if (!d.waNext) v.setViewVisibility(id, View.GONE)
            }
        }
    }

    private fun scaled(b: Bitmap, px: Int): Bitmap {
        if (b.width <= px && b.height <= px) return b
        val f = px / maxOf(b.width, b.height).toFloat()
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
    }

    private fun action(ctx: Context, act: String): PendingIntent = PendingIntent.getBroadcast(
        ctx, act.hashCode(), Intent(ctx, WidgetActionReceiver::class.java).setAction(act),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun build(ctx: Context, s: Spec, c: PlayerController, t: Track?, art: Bitmap?): RemoteViews {
        val v = RemoteViews(ctx.packageName, s.layout)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        v.setOnClickPendingIntent(R.id.w_root, open)
        v.setOnClickPendingIntent(R.id.w_art, open)

        v.setTextViewText(R.id.w_title, t?.title ?: "Aurora")
        v.setTextViewText(R.id.w_artist, t?.artist ?: "Tap to open your music")
        if (art != null) v.setImageViewBitmap(
            R.id.w_art,
            // the large and square widgets use the cover full-bleed; the others show a framed thumbnail, so it gets rounded corners
            if (s.layout == R.layout.widget_large || s.layout == R.layout.widget_square) scaled(art, s.artPx) else roundedSquare(art, s.artPx, 0f),
        )
        else v.setImageViewResource(R.id.w_art, R.drawable.ic_logo)

        v.setImageViewResource(R.id.w_play, if (c.isPlaying) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        v.setOnClickPendingIntent(R.id.w_play, action(ctx, ACTION_PLAY_PAUSE))
        v.setOnClickPendingIntent(R.id.w_next, action(ctx, ACTION_NEXT))
        v.setOnClickPendingIntent(R.id.w_prev, action(ctx, ACTION_PREV))

        if (s.fav) {
            val fav = t != null && c.store.isFavourite(t.id)
            v.setImageViewResource(R.id.w_fav, if (fav) R.drawable.ic_w_fav else R.drawable.ic_w_fav_off)
            v.setOnClickPendingIntent(R.id.w_fav, action(ctx, ACTION_FAVOURITE))
        }
        if (s.progress) {
            val p = if (c.durationMs > 0) (c.positionMs * 1000 / c.durationMs).toInt().coerceIn(0, 1000) else 0
            v.setProgressBar(R.id.w_progress, 1000, p, false)
        }
        if (s.modes) {
            v.setImageViewResource(
                R.id.w_repeat,
                if (c.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_w_repeat_one else R.drawable.ic_w_repeat,
            )
            // dim the buttons that are switched off
            v.setInt(R.id.w_shuffle, "setImageAlpha", if (c.shuffle) 255 else 110)
            v.setInt(R.id.w_repeat, "setImageAlpha", if (c.repeatMode != Player.REPEAT_MODE_OFF) 255 else 110)
            v.setOnClickPendingIntent(R.id.w_shuffle, action(ctx, ACTION_SHUFFLE))
            v.setOnClickPendingIntent(R.id.w_repeat, action(ctx, ACTION_REPEAT))
        }
        if (s.queue) {
            val ids = intArrayOf(R.id.w_q1, R.id.w_q2, R.id.w_q3)
            ids.forEachIndexed { i, id ->
                val n = c.queue.getOrNull(c.currentIndex + 1 + i)
                v.setTextViewText(id, n?.let { "${i + 1}. ${it.title} · ${it.artist}" } ?: "")
                v.setViewVisibility(id, if (n != null || i == 0) View.VISIBLE else View.GONE)
            }
        }
        if (s.list) decorateQueue(ctx, v, c, t)
        if (s.kind == 1 || s.kind == 2) decorateCard(ctx, v, s, c)
        return v
    }

    private var lastScrolledTo: Long = -1
    @Volatile private var forceScroll = false

    /** The queue widget refreshes itself every minute and puts the playing song at the top. */
    private fun scheduleTick(app: Context, wanted: Boolean) {
        try {
            val am = app.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            val pi = PendingIntent.getBroadcast(
                app, 91, Intent(app, WidgetActionReceiver::class.java).setAction(ACTION_TICK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            if (wanted) am.setAndAllowWhileIdle(android.app.AlarmManager.ELAPSED_REALTIME_WAKEUP, android.os.SystemClock.elapsedRealtime() + 60_000L, pi)
            else am.cancel(pi)
        } catch (_: Throwable) {}
    }

    private fun scrollList(app: Context, ids: IntArray, index: Int) {
        try {
            val rv = RemoteViews(app.packageName, R.layout.widget_queue)
            rv.setScrollPosition(R.id.w_list, index.coerceAtLeast(0))
            AppWidgetManager.getInstance(app).partiallyUpdateAppWidget(ids, rv)
        } catch (_: Throwable) {
        }
    }

    /** Scrolls the queue widget's list to the playing song (used when the widget's queue button is tapped). */
    fun scrollQueueToCurrent(ctx: Context) {
        forceScroll = true
        update(ctx)
    }

    /** Queue widget: wallpaper-based colours, the scrolling list and the header shortcuts. */
    private fun decorateQueue(ctx: Context, v: RemoteViews, c: PlayerController, t: Track?) {
        val th = WidgetTheme.resolve(ctx, c.store.data.queueTheme)

        // translucent rounded panels: colour filter for the colour, image alpha for the see-through part
        v.setInt(R.id.w_bg_header, "setColorFilter", th.header)
        val opacity = ((100 - c.store.data.wAlpha.coerceIn(0, 100)) * 255 / 100)
        v.setInt(R.id.w_bg_header, "setImageAlpha", if (th.flat) 0 else opacity)
        v.setInt(R.id.w_bg_panel, "setColorFilter", th.panel)
        v.setInt(R.id.w_bg_panel, "setImageAlpha", if (th.flat) opacity * th.panelAlpha / 255 else opacity)
        v.setInt(R.id.w_fab_bg, "setColorFilter", th.accent)
        v.setInt(R.id.w_fab, "setColorFilter", th.onAccent)
        v.setInt(R.id.w_play_bg, "setColorFilter", th.accent)
        if (th.flat) { v.setInt(R.id.w_fab_bg, "setImageAlpha", 0); v.setInt(R.id.w_play_bg, "setImageAlpha", 0) }

        v.setTextColor(R.id.w_title, if (th.flat) th.accent else th.text)
        v.setTextColor(R.id.w_artist, if (th.flat) th.accent else th.sub)
        v.setTextColor(R.id.w_q_title, th.text)
        v.setTextColor(R.id.w_empty, th.sub)
        for (id in intArrayOf(R.id.w_fav, R.id.w_prev, R.id.w_next, R.id.w_open_queue, R.id.w_rew, R.id.w_ff, R.id.w_overlay)) {
            v.setInt(id, "setColorFilter", th.accent)
        }
        v.setInt(R.id.w_play, "setColorFilter", th.onAccent)
        val dd = c.store.data
        v.setViewVisibility(R.id.w_art, if (dd.wqArt) View.VISIBLE else View.GONE)
        v.setViewVisibility(R.id.w_fav, if (dd.wqFav) View.VISIBLE else View.GONE)
        v.setViewVisibility(R.id.w_rew, if (dd.wqFfRew) View.VISIBLE else View.GONE)
        v.setViewVisibility(R.id.w_ff, if (dd.wqFfRew) View.VISIBLE else View.GONE)
        v.setOnClickPendingIntent(R.id.w_rew, action(ctx, ACTION_REWIND))
        v.setOnClickPendingIntent(R.id.w_overlay, action(ctx, ACTION_OVERLAY))
        v.setViewVisibility(R.id.w_overlay, if (dd.wqOverlay) View.VISIBLE else View.GONE)
        v.setOnClickPendingIntent(R.id.w_ff, action(ctx, ACTION_FF))

        val size = c.queue.size
        val qn = c.store.data.queues.getOrNull(c.activeQueue)?.name?.takeIf { it.isNotBlank() } ?: "Current Queue"
        v.setTextViewText(R.id.w_q_title, if (size == 0) qn else "$qn (${c.currentIndex + 1}/$size)")

        val openQueue = PendingIntent.getActivity(
            ctx, 1,
            Intent(ctx, MainActivity::class.java).putExtra("route", "queue")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        v.setOnClickPendingIntent(R.id.w_open_queue, openQueue)
        v.setOnClickPendingIntent(R.id.w_fab, openQueue)

        v.setRemoteAdapter(R.id.w_list, Intent(ctx, QueueWidgetService::class.java))
        v.setEmptyView(R.id.w_list, R.id.w_empty)
        // tapping a row plays it (the row supplies its own index; the template must be mutable for that)
        val template = PendingIntent.getBroadcast(
            ctx, 77, Intent(ctx, WidgetActionReceiver::class.java).setAction(ACTION_JUMP),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0),
        )
        v.setPendingIntentTemplate(R.id.w_list, template)

    }
}
