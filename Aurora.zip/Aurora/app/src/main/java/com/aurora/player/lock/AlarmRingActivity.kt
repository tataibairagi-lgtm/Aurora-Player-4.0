package com.aurora.player.lock

import android.app.KeyguardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.player.automation.Automation
import com.aurora.player.controller
import com.aurora.player.ui.AlbumArt
import com.aurora.player.ui.AuroraTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.math.roundToInt

/** Shown over the lock screen when an alarm rings: tap to stop, swipe up to snooze. */
class AlarmRingActivity : ComponentActivity() {
    private var alarmId = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alarmId = intent.getStringExtra(Automation.EXTRA_ID).orEmpty()
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        @Suppress("DEPRECATION")
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try { (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).let { if (Build.VERSION.SDK_INT >= 26) it.requestDismissKeyguard(this, null) } } catch (_: Throwable) {}
        enableEdgeToEdge()
        setContent {
            AuroraTheme(2, controller.store.data.accentColor) {
                RingContent(
                    onStop = { stopAlarm() },
                    onSnooze = { snoozeAlarm() },
                )
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        alarmId = intent.getStringExtra(Automation.EXTRA_ID).orEmpty()
    }

    private fun stopAlarm() {
        try { controller.pause(); controller.setAlarmAudio(false) } catch (_: Throwable) {}   // back to normal media volume and counting
        Automation.stopRing(this)
        finish()
    }

    private fun snoozeAlarm() {
        try { controller.pause(); controller.setAlarmAudio(false) } catch (_: Throwable) {}
        val min = controller.store.data.alarmSnoozeMin
        if (alarmId.isNotEmpty()) Automation.snooze(this, alarmId, min)
        android.widget.Toast.makeText(this, "Snoozed for $min min", android.widget.Toast.LENGTH_SHORT).show()
        Automation.stopRing(this)
        finish()
    }
}

@Composable
private fun RingContent(onStop: () -> Unit, onSnooze: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val c = ctx.controller
    val cs = MaterialTheme.colorScheme
    val track = c.current
    val is24 = remember { android.text.format.DateFormat.is24HourFormat(ctx) }
    var now by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { now = Calendar.getInstance(); delay(1000) } }
    val h = now.get(Calendar.HOUR_OF_DAY); val m = now.get(Calendar.MINUTE)
    val timeText = if (is24) "%02d:%02d".format(h, m) else "%d:%02d".format(if (h % 12 == 0) 12 else h % 12, m)
    val scope = rememberCoroutineScope()
    val drag = remember { Animatable(0f) }
    val snoozeMin = c.store.data.alarmSnoozeMin

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF14141C), cs.primary.copy(alpha = 0.35f).compositeOver(Color(0xFF0B0B10)), Color(0xFF0B0B10))))
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (drag.value < -220f) onSnooze() else drag.animateTo(0f)
                        }
                    },
                    onDragCancel = { scope.launch { drag.animateTo(0f) } },
                ) { _, dy -> scope.launch { drag.snapTo((drag.value + dy).coerceAtMost(0f)) } }
            },
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Alarm, null, Modifier.padding(top = 24.dp).size(34.dp), tint = Color.White.copy(alpha = 0.8f))
            Text(timeText, fontSize = 84.sp, fontWeight = FontWeight.Light, color = Color.White, modifier = Modifier.padding(top = 8.dp))
            if (track != null) {
                AlbumArt(track, Modifier.padding(top = 28.dp).size(150.dp), androidx.compose.foundation.shape.RoundedCornerShape(28.dp), 40.dp, 400)
                Text(track.title, Modifier.padding(top = 16.dp), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                Text(track.artist, color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(Modifier.weight(1f))
            // swipe up to snooze
            Column(Modifier.offset { IntOffset(0, drag.value.roundToInt()) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.KeyboardArrowUp, null, Modifier.size(34.dp), tint = Color.White.copy(alpha = 0.8f))
                Text("Swipe up to snooze ($snoozeMin min)", color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp)
            }
            // tap to stop
            Box(
                Modifier.padding(top = 28.dp, bottom = 12.dp).size(96.dp).clip(CircleShape).background(Color(0xFFE5484D)).clickable(onClick = onStop),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Stop, "Stop", Modifier.size(48.dp), tint = Color.White) }
            Text("Tap to stop", color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp)
        }
    }
}
