package com.aurora.player.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.aurora.player.player.OUTPUTS
import com.aurora.player.player.PlayerController
import kotlin.math.roundToInt

@Composable
fun EqualizerScreen(c: PlayerController, back: () -> Unit) {
    val d = c.store.data
    // Which output's profile is being edited. The active output's profile is the one actually heard.
    var key by remember { mutableStateOf(c.activeOutput) }
    val p = c.profile(key)
    val editingActive = key == c.activeOutput
    var saveDialog by remember { mutableStateOf(false) }

    var page by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
    Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).bounceClick(back), contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, null)
            }
            Text("Equalizer", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Switch(p.enabled, { v -> c.editProfile(key) { it.copy(enabled = v) } }, Modifier.padding(end = 16.dp))
        }

        // One profile per output, like Musicolet. The one currently playing gets a pulsing dot.
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(OUTPUTS) { (k, name) ->
                FilterChip(
                    selected = key == k, onClick = { key = k },
                    label = { Text(name) },
                    leadingIcon = if (k == c.activeOutput) ({ ActiveDot() }) else null,
                )
            }
        }
        Text(
            if (editingActive) "Applies to your current output (${OUTPUTS.first { it.first == key }.second}). It switches automatically when you plug in or connect something else."
            else "Not your current output, these settings are used when you switch to ${OUTPUTS.first { it.first == key }.second}.",
            Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (page == 1) KnobsPage(c, key) else if (c.eqBands.isEmpty()) {
            Text(
                "Equalizer isn't available on this device or audio session yet. Start playing a song and come back.",
                Modifier.padding(20.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            val band0 = c.eqBands.first()

            ResponseCurve(
                p.levels, band0.minMb, band0.maxMb, MaterialTheme.colorScheme.primary,
                Modifier.fillMaxWidth().height(90.dp).padding(horizontal = 20.dp),
            )

            // presets: the device's own + the ones you saved
            LazyRow(
                Modifier.padding(top = 8.dp), contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(c.eqSystemPresets.size) { i ->
                    val name = c.eqSystemPresets[i]
                    FilterChip(
                        selected = p.preset == name,
                        onClick = {
                            c.systemPresetLevels(i)?.let { lv -> c.editProfile(key) { it.copy(levels = lv, preset = name) } }
                        },
                        label = { Text(name) },
                    )
                }
                items(d.customPresets, key = { it.name }) { cp ->
                    FilterChip(
                        selected = p.preset == cp.name,
                        onClick = {
                            val n = c.eqBands.size
                            val lv = List(n) { i -> cp.levels.getOrElse(i) { 0 } }
                            c.editProfile(key) { it.copy(levels = lv, preset = cp.name) }
                        },
                        label = { Text(cp.name) },
                    )
                }
            }
            Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                PillButton("Save preset", Icons.Rounded.Save, false) { saveDialog = true }
                PillButton("Reset", Icons.Rounded.RestartAlt, false) {
                    c.editProfile(key) { it.copy(levels = List(c.eqBands.size) { 0 }, preset = "Custom", bass = 0, virtualizer = 0, loudness = 0) }
                }
                if (d.customPresets.any { it.name == p.preset }) {
                    PillButton("Delete", Icons.Rounded.Delete, false) { c.deleteCustomPreset(p.preset) }
                }
            }

            Row(
                Modifier.fillMaxWidth().height(250.dp).padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                c.eqBands.forEachIndexed { i, band ->
                    val level = p.levels.getOrNull(i) ?: 0
                    val animated by animateFloatAsState(level.toFloat(), spring(), label = "band$i")
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("%.1f".format(level / 100f), style = MaterialTheme.typography.labelSmall)
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            VerticalSlider(animated, band.minMb.toFloat()..band.maxMb.toFloat()) { v ->
                                c.editProfile(key) { cur ->
                                    cur.copy(levels = cur.levels.toMutableList().also { l -> if (i < l.size) l[i] = v.roundToInt() }, preset = "Custom")
                                }
                            }
                        }
                        Text(
                            if (band.freqHz >= 1000) "${band.freqHz / 1000}k" else "${band.freqHz}",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }

        if (page == 0) {
        Text(
            "Playback", Modifier.padding(start = 20.dp, top = 20.dp, bottom = 4.dp),
            style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
        )
        SliderRow("Speed", c.speed, 0.5f..2f, "%.2fx".format(c.speed)) { c.setSpeedPitch((it * 20).roundToInt() / 20f, c.pitch) }
        SliderRow("Pitch", c.pitch, 0.5f..2f, "%.2f".format(c.pitch)) { c.setSpeedPitch(c.speed, (it * 20).roundToInt() / 20f) }
        SliderRow("Fade between songs", d.fadeSec.toFloat(), 0f..12f, if (d.fadeSec == 0) "Off" else "${d.fadeSec}s", steps = 11) {
            c.setFadeSeconds(it.roundToInt())
        }
        Text(
            "Fade softly lowers the volume at the end of a song and raises it at the start of the next. Gapless playback is always on.",
            Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Box(Modifier.height(24.dp))
        }
    }
    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        listOf(Icons.Rounded.Tune, Icons.Rounded.RadioButtonChecked).forEachIndexed { i, ic ->
            Box(Modifier.size(52.dp).bounceClick { page = i }, contentAlignment = Alignment.Center) {
                Icon(ic, null, Modifier.size(28.dp), tint = if (page == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    }

    if (saveDialog) NameDialog("Save preset", if (p.preset == "Custom") "" else p.preset, "Save", { saveDialog = false }) { name ->
        c.saveCustomPreset(name, p.levels)
        c.editProfile(key) { it.copy(preset = name.trim()) }
        saveDialog = false
    }
}

@Composable
private fun ActiveDot() {
    val t = rememberInfiniteTransition(label = "dot")
    val s by t.animateFloat(0.7f, 1.2f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "dotScale")
    Box(Modifier.size(10.dp).scale(s).background(MaterialTheme.colorScheme.secondary, CircleShape))
}

@Composable
private fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, display: String, steps: Int = 0, onChange: (Float) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        Row {
            Text(label, Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text(display, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(value, onChange, valueRange = range, steps = steps)
    }
}

/** Smooth frequency-response curve that animates as the sliders move. */
@Composable
private fun ResponseCurve(levels: List<Int>, minMb: Int, maxMb: Int, color: Color, modifier: Modifier) {
    val animated = levels.mapIndexed { i, l -> animateFloatAsState(l.toFloat(), spring(), label = "curve$i").value }
    Canvas(modifier.clip(RoundedCornerShape(16.dp))) {
        if (animated.size < 2) return@Canvas
        val n = animated.size
        val range = (maxMb - minMb).coerceAtLeast(1).toFloat()
        val pts = animated.mapIndexed { i, v ->
            Offset(size.width * i / (n - 1), size.height * (1f - (v - minMb) / range))
        }
        val line = Path().apply {
            moveTo(pts[0].x, pts[0].y)
            for (i in 1 until n) {
                val a = pts[i - 1]
                val b = pts[i]
                val mx = (a.x + b.x) / 2
                cubicTo(mx, a.y, mx, b.y, b.x, b.y)
            }
        }
        val fill = Path().apply {
            addPath(line)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        val zeroY = size.height * (1f - (0 - minMb) / range)
        drawLine(color.copy(alpha = 0.25f), Offset(0f, zeroY), Offset(size.width, zeroY), strokeWidth = 2f)
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(line, color, style = Stroke(width = 5f, cap = StrokeCap.Round))
    }
}

/** A slider rotated to run bottom-to-top. */
@Composable
private fun VerticalSlider(value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Slider(
        value = value.coerceIn(range.start, range.endInclusive),
        onValueChange = onChange,
        valueRange = range,
        modifier = Modifier
            .graphicsLayer { rotationZ = 270f }
            .layout { measurable, constraints ->
                val p = measurable.measure(
                    Constraints(
                        minWidth = constraints.minHeight, maxWidth = constraints.maxHeight,
                        minHeight = constraints.minWidth, maxHeight = constraints.maxWidth,
                    )
                )
                layout(p.height, p.width) {
                    p.place(-(p.width / 2 - p.height / 2), -(p.height / 2 - p.width / 2))
                }
            },
    )
}

/** Musicolet-style round knob: drag around the circle. [value] is 0..1 (7 o'clock to 5 o'clock). */
@Composable
private fun Knob(value: Float, size: androidx.compose.ui.unit.Dp, onChange: (Float) -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val fill = MaterialTheme.colorScheme.surfaceVariant
    val rim = MaterialTheme.colorScheme.outline
    val latest = androidx.compose.runtime.rememberUpdatedState(onChange)
    Canvas(
        Modifier.size(size).pointerInput(Unit) {
            androidx.compose.foundation.gestures.detectDragGestures { change, _ ->
                val cx = this.size.width / 2f
                val cy = this.size.height / 2f
                val ang = Math.toDegrees(Math.atan2((change.position.x - cx).toDouble(), -(change.position.y - cy).toDouble())).toFloat()
                latest.value(((ang.coerceIn(-135f, 135f)) + 135f) / 270f)
            }
        },
    ) {
        val r = this.size.minDimension / 2f
        drawCircle(fill, r - 3f)
        drawCircle(rim, r - 3f, style = Stroke(width = 5f))
        val ang = Math.toRadians((-135.0 + 270.0 * value.coerceIn(0f, 1f)))
        val dx = Math.sin(ang).toFloat()
        val dy = -Math.cos(ang).toFloat()
        val c0 = center
        drawLine(primary, Offset(c0.x + dx * r * 0.35f, c0.y + dy * r * 0.35f), Offset(c0.x + dx * r * 0.7f, c0.y + dy * r * 0.7f), strokeWidth = 8f, cap = StrokeCap.Round)
    }
}

/** Second page of the equalizer: bass, surround, preamp, volume, stereo/mono and balance. */
@Composable
private fun KnobsPage(c: PlayerController, key: String) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val p = c.profile(key)
    val d = c.store.data
    val am = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var vol by remember { mutableStateOf(am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) / maxVol.toFloat()) }

    Column(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob(p.bass / 1000f, 130.dp) { v -> c.editProfile(key) { it.copy(bass = (v * 1000).roundToInt()) } }
                Text("Bass boost", Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
                Text("${p.bass / 10}%", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob(p.virtualizer / 1000f, 130.dp) { v -> c.editProfile(key) { it.copy(virtualizer = (v * 1000).roundToInt()) } }
                Text("Surround Sound", Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold)
                Text("${p.virtualizer / 10}%", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 40.dp, vertical = 16.dp))
        Text("Preamp", fontWeight = FontWeight.Bold)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(-600 to "Headroom\n-6 dB", 0 to "Off\n0 dB", 900 to "Boost\n+9 dB").forEach { (mb, label) ->
                FilterChip(p.loudness == mb, { c.editProfile(key) { it.copy(loudness = mb) } }, label = { Text(label, textAlign = androidx.compose.ui.text.style.TextAlign.Center) })
            }
        }
        Slider(
            p.loudness.toFloat().coerceIn(-600f, 900f), { v -> c.editProfile(key) { it.copy(loudness = (v / 50f).roundToInt() * 50) } },
            valueRange = -600f..900f, modifier = Modifier.padding(horizontal = 36.dp),
        )
        Text("%+.1f dB".format(p.loudness / 100f), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 40.dp, vertical = 16.dp))
        Text("Volume", fontWeight = FontWeight.Bold)
        Slider(
            vol, { v -> vol = v; try { am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (v * maxVol).roundToInt(), 0) } catch (_: Exception) {} },
            modifier = Modifier.padding(horizontal = 36.dp),
        )
        androidx.compose.material3.HorizontalDivider(Modifier.padding(horizontal = 40.dp, vertical = 16.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(!d.mono, { c.setMono(false) }, label = { Text("Stereo") })
                FilterChip(d.mono, { c.setMono(true) }, label = { Text("Mono") })
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Knob((d.balance + 100) / 200f, 120.dp) { v ->
                    val b = (v * 200f - 100f).roundToInt()
                    c.setBalance(if (kotlin.math.abs(b) < 6) 0 else b)
                }
                Text("Audio channel balance", Modifier.padding(top = 10.dp), fontWeight = FontWeight.Bold)
                Text("Left:${100 - maxOf(0, d.balance)}, Right:${100 + minOf(0, d.balance)}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Box(Modifier.height(24.dp))
    }
}
