package com.aurora.player.data

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.nio.ByteBuffer

/** Cuts a piece out of a song without re-encoding. MP3 and AAC/M4A songs are supported. */
object ClipCutter {
    /** Writes the clip to [out]; returns "ok:<mime>" on success or a short error message. */
    fun cut(ctx: Context, uri: Uri, startMs: Long, endMs: Long, out: File): String? {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { idx = i; fmt = f; break }
            }
            if (idx < 0 || fmt == null) return "no audio found"
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            ex.selectTrack(idx)
            ex.seekTo(startMs * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val buf = ByteBuffer.allocate(1 shl 18)
            val info = MediaCodec.BufferInfo()
            val endUs = endMs * 1000
            when (mime) {
                "audio/mpeg" -> out.outputStream().use { os ->
                    val arr = ByteArray(buf.capacity())
                    while (true) {
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0 || ex.sampleTime > endUs) break
                        buf.position(0); buf.get(arr, 0, n); os.write(arr, 0, n)
                        ex.advance()
                    }
                }
                "audio/mp4a-latm" -> {
                    val mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                    val t = mux.addTrack(fmt)
                    mux.start()
                    var base = -1L
                    while (true) {
                        val n = ex.readSampleData(buf, 0)
                        val ts = ex.sampleTime
                        if (n < 0 || ts > endUs) break
                        if (base < 0) base = ts
                        info.set(0, n, (ts - base).coerceAtLeast(0), if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
                        mux.writeSampleData(t, buf, info)
                        ex.advance()
                    }
                    mux.stop(); mux.release()
                }
                else -> return "this format ($mime) can't be cut yet; MP3 and M4A/AAC work"
            }
            return if (out.length() > 0) "ok:$mime" else "nothing was written"
        } catch (e: Throwable) {
            return e.message ?: e.javaClass.simpleName
        } finally {
            try { ex.release() } catch (_: Throwable) {}
        }
    }

    /** Adds the file to the media library under Ringtones, Alarms, Notifications or Music/Clips. [kind]: 0 clip, 1 ringtone, 2 alarm, 3 notification. */
    fun publish(ctx: Context, file: File, name: String, mime: String, kind: Int): Boolean {
        val ext = if (mime == "audio/mpeg") "mp3" else "m4a"
        val (dir, flag) = when (kind) {
            1 -> Environment.DIRECTORY_RINGTONES to MediaStore.Audio.Media.IS_RINGTONE
            2 -> Environment.DIRECTORY_ALARMS to MediaStore.Audio.Media.IS_ALARM
            3 -> Environment.DIRECTORY_NOTIFICATIONS to MediaStore.Audio.Media.IS_NOTIFICATION
            else -> Environment.DIRECTORY_MUSIC + "/Clips" to MediaStore.Audio.Media.IS_MUSIC
        }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.$ext")
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.TITLE, name)
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, dir)
            put(flag, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v) ?: return false
        return try {
            ctx.contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
            true
        } catch (_: Throwable) {
            try { ctx.contentResolver.delete(uri, null, null) } catch (_: Throwable) {}
            false
        }
    }
}
