package com.aurora.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Sell
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.PlayCircleFilled
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.NewReleases
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.albumKey
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

sealed interface Route {
    object Library : Route
    data class Detail(val kind: String, val key: String) : Route
    object Queue : Route
    object Equalizer : Route
    object Settings : Route
    object MostPlayed : Route
    object Mixes : Route
}

/** Sort choices for song lists (All songs, and inside playlists, folders, albums...). */
val SONG_SORTS = listOf(
    "Title", "Artist", "Album", "Recently added", "Duration", "Year", "File size", "Track number",
    "Album artist", "Composer", "Genre", "File name", "Play count", "Last played",
)


val ALBUM_INFO_OPTIONS = listOf("Decide automatically as per the sorting type", "None", "Number of songs", "Duration", "Date updated", "Year", "Artist", "Album-Artist", "Composer")

/** The extra line shown under an album's artist. mode 0 picks it from the current sort. */
/** The name shown under an album: its album artist, else the artist most of its songs have. */
fun albumOwner(tracks: List<com.aurora.player.data.Track>): String =
    tracks.firstOrNull { it.albumArtist.isNotBlank() }?.albumArtist
        ?: tracks.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }?.key ?: ""

fun albumExtraInfo(tracks: List<com.aurora.player.data.Track>, mode: Int, sortName: String): String {
    val m = if (mode != 0) mode else when (sortName) {
        "Year" -> 5; "Recently added" -> 4; "Total duration" -> 3; "Number of songs" -> 2
        else -> 1 // default / name / artist sort: just the artist under the album
    }
    val f = tracks.first()
    return when (m) {
        1 -> ""
        2 -> "${tracks.size} songs"
        3 -> formatTime(tracks.sumOf { it.durationMs })
        4 -> java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM).format(java.util.Date(tracks.maxOf { it.dateAdded } * 1000))
        5 -> tracks.maxOf { it.year }.let { if (it > 0) it.toString() else "" }
        6 -> f.artist
        7 -> f.albumArtist.ifBlank { f.artist }
        8 -> f.composer
        else -> ""
    }
}

/** Sort choices per tab (the chosen index is remembered per tab in the settings store). */
private val SORTS = mapOf(
    "tracks" to SONG_SORTS,
    "albums" to listOf("Name", "Artist", "Year", "Number of songs", "Recently added", "Total duration", "Total size", "Play count"),
    "artists" to listOf("Name", "Number of songs", "Recently added", "Total duration", "Play count"),
    "genres" to listOf("Name", "Number of songs", "Total duration", "Play count"),
    "folders" to listOf("Name", "Number of songs", "Recently added", "Total duration", "Total size", "Play count"),
    "playlists" to listOf("Name", "Number of songs", "Total duration"),
)

fun sortSongs(list: List<Track>, idx: Int, ignore: Boolean, d: com.aurora.player.data.Persisted): List<Track> = when (idx) {
    1 -> list.sortedWith(compareBy({ it.artist.nk() }, { it.album.nk() }, { it.trackNo }))
    2, 7 -> list.sortedWith(compareBy({ it.album.nk() }, { it.trackNo }))
    3 -> list.sortedByDescending { it.dateAdded }
    4 -> list.sortedByDescending { it.durationMs }
    5 -> list.sortedWith(compareByDescending<Track> { it.year }.thenBy { it.title.nk() })
    6 -> list.sortedByDescending { it.size }
    8 -> list.sortedWith(compareBy({ it.albumArtist.ifBlank { it.artist }.nk() }, { it.album.nk() }, { it.trackNo }))
    9 -> list.sortedWith(compareBy({ it.composer.nk() }, { it.title.nk() }))
    10 -> list.sortedWith(compareBy({ it.genre.nk() }, { it.title.nk() }))
    11 -> list.sortedBy { it.path.substringAfterLast('/').nk() }
    12 -> list.sortedByDescending { d.playCounts[it.id] ?: 0 }
    13 -> list.sortedBy { t -> d.lastPlayed.indexOf(t.id).let { if (it < 0) Int.MAX_VALUE else it } }
    else -> list.sortedBy { sortKey(it.title, ignore) }
}

/** Sorts groups (albums, artists, folders...) by the chosen label. */
private fun <T> sortGroups(
    items: List<T>, label: String, name: (T) -> String, tracks: (T) -> List<Track>,
    d: com.aurora.player.data.Persisted, ignore: Boolean,
): List<T> = when (label) {
    "Number of songs" -> items.sortedByDescending { tracks(it).size }
    "Recently added" -> items.sortedByDescending { t -> tracks(t).maxOfOrNull { it.dateAdded } ?: 0L }
    "Total duration" -> items.sortedByDescending { t -> tracks(t).sumOf { it.durationMs } }
    "Total size" -> items.sortedByDescending { t -> tracks(t).sumOf { it.size } }
    "Play count" -> items.sortedByDescending { t -> tracks(t).sumOf { d.playCounts[it.id] ?: 0 } }
    "Artist" -> items.sortedBy { t -> tracks(t).firstOrNull()?.artist?.lowercase() ?: "" }
    "Year" -> items.sortedByDescending { t -> tracks(t).maxOfOrNull { it.year } ?: 0 }
    else -> items.sortedBy { sortKey(name(it), ignore) }
}

/** True when every word typed appears in a group's own name (album, artist, folder...), not in its songs. */
private fun nameMatch(name: String, q: String): Boolean {
    if (q.isBlank()) return true
    val n = normalizeForSearch(name)
    return normalizeForSearch(q).split(' ').filter { it.isNotEmpty() }.all { it in n }
}

private fun <T> List<T>.reversedIf(rev: Boolean): List<T> = if (rev) reversed() else this

val ALL_TABS = listOf(
    "queues" to "Queues", "now" to "Now playing", "albums" to "Albums", "artists" to "Artists",
    "playlists" to "Playlists", "search" to "Search", "folders" to "Folders", "genres" to "Genres", "tracks" to "All songs",
)

private fun tabIcon(id: String): androidx.compose.ui.graphics.vector.ImageVector = when (id) {
    "queues" -> Icons.AutoMirrored.Rounded.QueueMusic
    "now" -> Icons.Rounded.PlayCircleFilled
    "albums" -> Icons.Rounded.Album
    "artists" -> Icons.Rounded.Person
    "playlists" -> Icons.Rounded.LibraryMusic
    "search" -> Icons.Rounded.Search
    "folders" -> Icons.Rounded.Folder
    "genres" -> Icons.Rounded.Sell
    else -> Icons.Rounded.MusicNote
}

/** Tab ids in the user's order, minus hidden ones (never empty). Unknown/new ids are appended. */
fun visibleTabs(d: com.aurora.player.data.Persisted): List<String> {
    val known = ALL_TABS.map { it.first }
    var ordered = d.tabOrder.filter { it in known } + known.filter { it !in d.tabOrder }
    // the Search tab sits right after Playlists until the user arranges it somewhere else
    if ("search" !in d.tabOrder) {
        ordered = ordered.filter { it != "search" }
        val at = ordered.indexOf("playlists")
        ordered = if (at >= 0) ordered.toMutableList().also { it.add(at + 1, "search") } else ordered + "search"
    }
    return ordered.filter { it !in d.hiddenTabs }.ifEmpty { listOf("playlists") }
}

/** The individual artists of a song; with "split artists" on, "A & B; C" becomes A, B and C. */
fun artistsOf(t: Track, split: Boolean, seps: String): List<String> {
    if (!split || seps.isEmpty()) return listOf(t.artist)
    val parts = t.artist.split(*seps.toCharArray()).map { it.trim() }.filter { it.isNotEmpty() }
    return parts.ifEmpty { listOf(t.artist) }
}

/** Genres of a song: split at the genre separators ("Pop; Dance" becomes Pop and Dance) when the setting is on. Empty tag = "Unknown genre". */
fun genresOf(t: Track, split: Boolean, seps: String): List<String> {
    val base = t.genre.ifBlank { "Unknown genre" }
    if (!split || seps.isEmpty()) return listOf(base)
    val parts = base.split(*seps.toCharArray()).map { it.trim() }.filter { it.isNotEmpty() }.distinct()
    return parts.ifEmpty { listOf(base) }
}

/** Album artists of a song: its album artist, or the artist when that tag is empty; split like artists when the setting is on. */
fun albumArtistsOf(t: Track, split: Boolean, seps: String): List<String> {
    val base = t.albumArtist.ifBlank { t.artist }
    if (!split || seps.isEmpty()) return listOf(base)
    val parts = base.split(*seps.toCharArray()).map { it.trim() }.filter { it.isNotEmpty() }
    return parts.ifEmpty { listOf(base) }
}

/** Global sort switch kept outside Compose state; screens re-sort because the setting is part of their remember keys. */
object SortPrefs { @Volatile var natural = false }

/** Lower-case sort key; with alphanumeric sorting on, numbers inside the text compare by value ("Track 2" before "Track 10"). */
fun String.nk(): String {
    val l = lowercase()
    return if (SortPrefs.natural) l.replace(Regex("[0-9]+")) { it.value.padStart(12, '0') } else l
}

/** Ignores a leading "The ", "A ", "An " when sorting, if the setting is on. */
private fun sortKey(s: String, ignore: Boolean): String {
    val l = s.trim().nk()
    if (!ignore) return l
    for (w in listOf("the ", "an ", "a ")) if (l.startsWith(w) && l.length > w.length) return l.substring(w.length)
    return l
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(
    c: PlayerController,
    push: (Route) -> Unit,
    tabRequest: String?,
    onTabRequestHandled: () -> Unit,
    onTabChanged: (String) -> Unit,
    startTab: String = "",
    nowPage: @Composable (close: () -> Unit, openQueue: () -> Unit) -> Unit,
) {
    val tabIds = visibleTabs(c.store.data)
    // coming back from an album / artist / settings page lands on the tab you left, not the first one
    val pager = rememberPagerState(initialPage = tabIds.indexOf(startTab).coerceAtLeast(0)) { tabIds.size }
    val scope = rememberCoroutineScope()
    val queries = remember { androidx.compose.runtime.mutableStateMapOf<String, String>() }
    var menu by remember { mutableStateOf(false) }
    var arrange by remember { mutableStateOf(false) }
    val actions = LocalActions.current
    val pill = c.store.data.uiPillNav
    val landscape = androidx.compose.ui.platform.LocalConfiguration.current.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val bottom = c.store.data.tabsBottom || pill
    val edgeOnly = pill && c.store.data.uiPillSwipe
    val edgeOnlyNow by androidx.compose.runtime.rememberUpdatedState({ edgeOnly })
    val pillConn = remember {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (available.y < -10f) ExpressiveState.pillHidden = true else if (available.y > 10f && !edgeOnlyNow()) ExpressiveState.pillHidden = false
                return androidx.compose.ui.geometry.Offset.Zero
            }
        }
    }
    androidx.compose.runtime.DisposableEffect(pill) { onDispose { ExpressiveState.pillHidden = false } }
    // optional: the pill tucks itself away after 5 seconds without a touch and comes back at the next one
    val autoHide = pill && c.store.data.uiPillAutoHide
    // watched with snapshotFlow so a finger-down does not recompose the whole library screen
    LaunchedEffect(autoHide, edgeOnly) {
        if (edgeOnly) {
            // only swiping up at the bottom edge brings the pill; it tucks away again after 5 seconds without a touch
            androidx.compose.runtime.snapshotFlow { ExpressiveState.touch to ExpressiveState.pillHidden }.collectLatest { (_, hidden) ->
                if (!hidden) { kotlinx.coroutines.delay(5000); ExpressiveState.pillHidden = true }
            }
        } else if (autoHide) {
            androidx.compose.runtime.snapshotFlow { ExpressiveState.touch }.collectLatest {
                ExpressiveState.pillHidden = false; kotlinx.coroutines.delay(5000); ExpressiveState.pillHidden = true
            }
        }
    }
    LaunchedEffect(edgeOnly) { if (edgeOnly) ExpressiveState.pillHidden = true }
    val current = tabIds.getOrNull(pager.currentPage) ?: ""

    LaunchedEffect(current) { onTabChanged(current) }
    LaunchedEffect(tabRequest, tabIds) {
        if (tabRequest != null) {
            val i = tabIds.indexOf(tabRequest)
            if (i >= 0) pager.animateScrollToPage(i)
            onTabRequestHandled()
        }
    }

    val bar: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().height(if (pill && landscape) 46.dp else 56.dp), verticalAlignment = Alignment.CenterVertically) {
            tabIds.forEachIndexed { i, id ->
                val sel = pager.currentPage == i
                Box(
                    Modifier.weight(1f).fillMaxSize().then(
                        if (id == "search") Modifier.pointerInput(i) {
                            // double tap on the search icon: go there and open the keyboard
                            detectTapGestures(
                                onTap = { scope.launch { pager.animateScrollToPage(i) } },
                                onDoubleTap = { SearchRequest.pending = true; scope.launch { pager.animateScrollToPage(i) } },
                            )
                        } else Modifier.clickable { if (sel && id == "queues") c.queueScrollTick++; scope.launch { pager.animateScrollToPage(i) } },
                    ),
                    contentAlignment = Alignment.Center,
                ) {
                    if (pill) {
                        // a soft capsule pops in behind the tab you are on
                        val a by androidx.compose.animation.core.animateFloatAsState(
                            if (sel) 1f else 0f,
                            androidx.compose.animation.core.spring(androidx.compose.animation.core.Spring.DampingRatioMediumBouncy, androidx.compose.animation.core.Spring.StiffnessMedium), label = "pillSel",
                        )
                        Box(
                            Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 9.dp)
                                .graphicsLayer { alpha = a.coerceIn(0f, 1f); scaleX = 0.55f + 0.45f * a; scaleY = 0.8f + 0.2f * a }
                                .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(50)),
                        )
                    }
                    Icon(
                        tabIcon(id), ALL_TABS.first { it.first == id }.second,
                        tint = if (sel) (if (pill) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary) else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (!pill) Box(
                        Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(3.dp)
                            .background(if (sel) MaterialTheme.colorScheme.primary else Color.Transparent),
                    )
                }
            }
            Box {
                HeaderIcon(Icons.Rounded.MoreVert) { menu = true }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Settings") }, leadingIcon = { Icon(androidx.compose.material.icons.Icons.Rounded.Settings, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary) }, onClick = { menu = false; push(Route.Settings) })
                    val hmm = c.store.data.hiddenMenu
                    if ("m_eq" !in hmm) DropdownMenuItem(text = { Text("Equalizer") }, leadingIcon = { Icon(androidx.compose.material.icons.Icons.Rounded.GraphicEq, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary) }, onClick = { menu = false; push(Route.Equalizer) })
                    if ("m_shuffle" !in hmm) DropdownMenuItem(text = { Text("Shuffle all songs") }, leadingIcon = { Icon(androidx.compose.material.icons.Icons.Rounded.Shuffle, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary) }, onClick = {
                        menu = false
                        if (c.library.isNotEmpty()) c.playTracks(c.library.shuffled(), 0, true)
                    })
                    if ("m_arrange" !in hmm) DropdownMenuItem(text = { Text("Arrange tabs") }, leadingIcon = { Icon(androidx.compose.material.icons.Icons.Rounded.Tune, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary) }, onClick = { menu = false; arrange = true })
                    if ("m_rescan" !in hmm) DropdownMenuItem(text = { Text("Rescan music") }, leadingIcon = { Icon(androidx.compose.material.icons.Icons.Rounded.Refresh, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary) }, onClick = { menu = false; actions.rescan() })
                }
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
    // Now Playing's background runs under the tab bar and the status bar too, fading in as you swipe to that tab
    val nowIdx = tabIds.indexOf("now")
    if (nowIdx >= 0) {
        val a = (1f - kotlin.math.abs(pager.currentPage + pager.currentPageOffsetFraction - nowIdx)).coerceIn(0f, 1f)
        if (a > 0.01f) Box(Modifier.fillMaxSize().graphicsLayer { alpha = a }) { NowBackdrop(c) }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().then(if (pill) Modifier.nestedScroll(pillConn) else Modifier)) {
        if (!bottom) bar()
        HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth(), beyondViewportPageCount = 0, key = { tabIds.getOrNull(it) ?: it }) { page ->
            val padPill by androidx.compose.animation.core.animateDpAsState(
                if (pill && !ExpressiveState.pillHidden) (if (landscape) 62.dp else 76.dp) + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() else 0.dp, label = "pillPad")
            Box(Modifier.fillMaxSize().padding(bottom = if (tabIds.getOrNull(page) == "queues" || tabIds.getOrNull(page) == "now") padPill else 0.dp)) {
            when (tabIds.getOrNull(page)) {
                "queues" -> QueueScreen(c, {}, embedded = true)
                "now" -> nowPage(
                    { scope.launch { pager.animateScrollToPage(tabIds.indexOf("playlists").coerceAtLeast(0)) } },
                    { scope.launch { pager.animateScrollToPage(tabIds.indexOf("queues").let { if (it < 0) page else it }) } },
                )
                "search" -> SearchTab(c, push)
                "tracks", "albums", "artists", "genres", "folders", "playlists" -> {
                    val id = tabIds[page]
                    val q = queries[id] ?: ""
                    Column(Modifier.fillMaxSize()) {
                        TabToolbar(c, id, q) { queries[id] = it }
                        Box(Modifier.weight(1f).fillMaxWidth()) {
                            when (id) {
                                "tracks" -> TracksTab(c, q)
                                "albums" -> AlbumsTab(c, q, push)
                                "artists" -> ArtistsTab(c, q, push)
                                "genres" -> GenresTab(c, q, push)
                                "folders" -> FoldersTab(c, q, push)
                                else -> PlaylistsTab(c, push, q)
                            }
                        }
                    }
                }
                else -> {}
            }
            }
        }
        if (!pill && bottom) Box(Modifier.navigationBarsPadding()) { bar() }
    }
    // swipe-up handle: the only way back to the pill when "only on swipe up" is on
    if (edgeOnly && ExpressiveState.pillHidden) Box(
        Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().height(26.dp)
            .pointerInput(Unit) {
                androidx.compose.foundation.gestures.detectVerticalDragGestures { _, drag -> if (drag < -6f) ExpressiveState.pillHidden = false }
            }
            .pointerInput(Unit) { detectTapGestures { ExpressiveState.pillHidden = false } },
        contentAlignment = Alignment.BottomCenter,
    ) {
        Box(Modifier.padding(bottom = 6.dp).size(width = 40.dp, height = 4.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.28f)))
    }
    // the pill floats over the page like the mini-player (lists scroll behind it)
    if (pill) androidx.compose.animation.AnimatedVisibility(
        !ExpressiveState.pillHidden,
        modifier = Modifier.align(Alignment.BottomCenter),
        enter = androidx.compose.animation.slideInVertically(androidx.compose.animation.core.spring(androidx.compose.animation.core.Spring.DampingRatioMediumBouncy, androidx.compose.animation.core.Spring.StiffnessMediumLow)) { it } + androidx.compose.animation.fadeIn(),
        exit = androidx.compose.animation.slideOutVertically(androidx.compose.animation.core.tween(250)) { it } + androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)),
    ) {
        Box(
            Modifier.navigationBarsPadding().padding(horizontal = 12.dp, vertical = if (landscape) 8.dp else 10.dp)
                .widthIn(max = if (landscape) 520.dp else 600.dp)
                .shadow(14.dp, RoundedCornerShape(28.dp))
                .clip(RoundedCornerShape(28.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) { bar() }
    }
    }
    if (arrange) ArrangeTabsDialog(c) { arrange = false }
}

/** Search box, sort menu and (for albums) a grid-size menu at the top of each list tab. */
@Composable
private fun TabToolbar(c: PlayerController, tab: String, query: String, onQuery: (String) -> Unit) {
    var sortMenu by remember { mutableStateOf(false) }
    var gearMenu by remember { mutableStateOf(false) }
    val d = c.store.data
    val opts = SORTS[tab].orEmpty()
    val sel = d.tabSort[tab] ?: 0
    val rev = d.tabSortRev[tab] ?: false
    val hint = when (tab) {
        "albums" -> "Search an album…"
        "artists" -> "Search an artist…"
        "genres" -> "Search a genre…"
        "folders" -> "Search a folder…"
        "playlists" -> "Search a playlist…"
        else -> "Search a song…"
    }
    Row(Modifier.fillMaxWidth().padding(start = 0.dp, end = 4.dp, top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        SearchField(query, onQuery, hint, Modifier.weight(1f))
        Box {
            HeaderIcon(Icons.AutoMirrored.Rounded.Sort) { sortMenu = true }
            if (sortMenu) androidx.compose.ui.window.Dialog(onDismissRequest = { sortMenu = false }) {
                Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                    Column(Modifier.padding(vertical = 18.dp)) {
                        Text("Sort by", Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                            opts.forEachIndexed { i, label ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { c.store.update { it.copy(tabSort = it.tabSort + (tab to i)) }; sortMenu = false }.padding(horizontal = 20.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    androidx.compose.material3.RadioButton(i == sel, null)
                                    Text(label, Modifier.padding(start = 14.dp), fontWeight = if (i == sel) FontWeight.Bold else FontWeight.Normal)
                                }
                            }
                        }
                        androidx.compose.material3.HorizontalDivider(Modifier.padding(vertical = 6.dp))
                        Row(
                            Modifier.fillMaxWidth().clickable { c.store.update { it.copy(tabSortRev = it.tabSortRev + (tab to !rev)) } }.padding(horizontal = 24.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("Reverse order", Modifier.weight(1f))
                            androidx.compose.material3.Switch(rev, { c.store.update { it.copy(tabSortRev = it.tabSortRev + (tab to !rev)) } })
                        }
                        Row(Modifier.fillMaxWidth().padding(end = 16.dp), horizontalArrangement = Arrangement.End) {
                            androidx.compose.material3.TextButton({ sortMenu = false }) { Text("Close") }
                        }
                    }
                }
            }
        }
        if (tab == "albums") Box {
            HeaderIcon(Icons.Rounded.Settings) { gearMenu = true }
            DropdownMenu(gearMenu, { gearMenu = false }) {
                Text("Albums per row", Modifier.padding(start = 16.dp, top = 6.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                listOf(1, 2, 3, 4, 5).forEach { n ->
                    DropdownMenuItem(
                        text = { Text(if (n == 1) "List" else "$n", fontWeight = if (d.albumCols == n) FontWeight.Bold else FontWeight.Normal) },
                        onClick = { c.store.update { it.copy(albumCols = n) }; gearMenu = false },
                    )
                }
            }
        }
    }
}

/** Show/hide and reorder the tabs, like Musicolet's "Arrange tabs". Everything below the divider is hidden. */
@Composable
fun ArrangeTabsDialog(c: PlayerController, onDismiss: () -> Unit) {
    val d = c.store.data
    val known = ALL_TABS.map { it.first }
    val order = d.tabOrder.filter { it in known } + known.filter { it !in d.tabOrder }
    val visible = order.filter { it !in d.hiddenTabs }
    val hidden = order.filter { it in d.hiddenTabs }
    fun save(v: List<String>, h: List<String>) {
        if (v.isEmpty()) return // keep at least one tab
        c.store.update { it.copy(tabOrder = v + h, hiddenTabs = h) }
    }

    @Composable
    fun Item(id: String, isHidden: Boolean, up: (() -> Unit)?, down: (() -> Unit)?) {
        Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(tabIcon(id), null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(end = 14.dp))
            Text(
                ALL_TABS.first { it.first == id }.second, Modifier.weight(1f),
                color = if (isHidden) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface,
                textDecoration = if (isHidden) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
            )
            Box(Modifier.size(38.dp).bounceClick { up?.invoke() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.KeyboardArrowUp, null, tint = if (up != null) MaterialTheme.colorScheme.onSurface else Color.Transparent)
            }
            Box(Modifier.size(38.dp).bounceClick { down?.invoke() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.KeyboardArrowDown, null, tint = if (down != null) MaterialTheme.colorScheme.onSurface else Color.Transparent)
            }
        }
    }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Arrange tabs") },
        text = {
            Column(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                visible.forEachIndexed { i, id ->
                    Item(
                        id, false,
                        up = if (i > 0) ({ save(visible.toMutableList().also { l -> l.add(i - 1, l.removeAt(i)) }, hidden) }) else null,
                        down = if (i < visible.lastIndex) ({ save(visible.toMutableList().also { l -> l.add(i + 1, l.removeAt(i)) }, hidden) })
                        else if (visible.size > 1) ({ save(visible - id, listOf(id) + hidden) }) else null,
                    )
                }
                Text(
                    "Tabs below this line are hidden ↓", Modifier.padding(vertical = 10.dp),
                    style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
                )
                hidden.forEachIndexed { i, id ->
                    Item(
                        id, true,
                        up = if (i > 0) ({ save(visible, hidden.toMutableList().also { l -> l.add(i - 1, l.removeAt(i)) }) })
                        else ({ save(visible + id, hidden - id) }),
                        down = if (i < hidden.lastIndex) ({ save(visible, hidden.toMutableList().also { l -> l.add(i + 1, l.removeAt(i)) }) }) else null,
                    )
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onDismiss) { Text("Done") } },
    )
}

@Composable
private fun HeaderIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface)
    }
}

private fun matches(t: Track, q: String) = searchMatches(t, q)

@Composable
private fun Empty(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(32.dp))
    }
}

/** Remembers where each tab's list was scrolled to, so coming back from an artist or album page lands on the same spot. */
object ScrollMemory { val m = HashMap<String, IntArray>() }

@Composable
fun rememberSavedListState(key: String): androidx.compose.foundation.lazy.LazyListState {
    val saved = ScrollMemory.m[key]
    val st = androidx.compose.foundation.lazy.rememberLazyListState(saved?.getOrNull(0) ?: 0, saved?.getOrNull(1) ?: 0)
    androidx.compose.runtime.DisposableEffect(key) { onDispose { ScrollMemory.m[key] = intArrayOf(st.firstVisibleItemIndex, st.firstVisibleItemScrollOffset) } }
    return st
}

@Composable
fun rememberSavedGridState(key: String): androidx.compose.foundation.lazy.grid.LazyGridState {
    val saved = ScrollMemory.m[key]
    val st = androidx.compose.foundation.lazy.grid.rememberLazyGridState(saved?.getOrNull(0) ?: 0, saved?.getOrNull(1) ?: 0)
    androidx.compose.runtime.DisposableEffect(key) { onDispose { ScrollMemory.m[key] = intArrayOf(st.firstVisibleItemIndex, st.firstVisibleItemScrollOffset) } }
    return st
}

@Composable
fun TrackList(
    c: PlayerController,
    tracks: List<Track>,
    emptyText: String,
    extraMenu: (Track) -> List<Pair<String, () -> Unit>> = { emptyList() },
    sourceName: String? = null,
    scrollKey: String? = null,
) {
    if (tracks.isEmpty()) { Empty(emptyText); return }
    val sel = IdSel(c, tracks)
    androidx.activity.compose.BackHandler(enabled = sel.isNotEmpty()) { sel.clear() }
    fun toggle(i: Int) { if (i in sel) sel.remove(i) else sel.add(i) }
    Box(Modifier.fillMaxSize()) {
        val listState = if (scrollKey != null) rememberSavedListState(scrollKey) else androidx.compose.foundation.lazy.rememberLazyListState()
        LazyColumn(state = listState, contentPadding = PaddingValues(bottom = if (sel.isEmpty()) 140.dp else 200.dp, top = 4.dp)) {
            itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
                TrackRow(
                    t, c, extraMenu = extraMenu(t),
                    selected = i in sel, onLongClick = { toggle(i) },
                ) {
                    if (sel.isNotEmpty()) toggle(i)
                    else if (!c.store.data.tapPlaysList) c.playTracks(listOf(t))
                    else if (sourceName != null) c.playFromSource(sourceName, tracks, i)
                    else c.playTracks(tracks, i)
                }
            }
        }
        // A-Z strip, only on long lists that are in title order (otherwise the letters would jump to the wrong places)
        if (c.store.data.uiFastScroll && tracks.size > 30) {
            val byTitle = remember(tracks) { tracks.zipWithNext().count { (a, b) -> a.title.lowercase() <= b.title.lowercase() } >= (tracks.size - 1) * 0.95 }
            if (byTitle) AlphaScroller(tracks.map { it.title }, listState, Modifier.align(Alignment.CenterEnd))
        }
        if (sel.isNotEmpty()) {
            SelectionBar(
                c, c.selection.toList(), inQueue = false, onRemove = {},
                onSelectAll = { sel.clear(); sel.addAll(tracks.indices) },
                onInvert = { val rest = tracks.indices.filter { it !in sel }; sel.clear(); sel.addAll(rest) },
                onCancel = { sel.clear() },
                onDeselectAll = { sel.clear() },
                onBetween = { val lo = sel.min(); val hi = sel.max(); sel.clear(); sel.addAll(lo..hi) },
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }
}

@Composable
private fun TracksTab(c: PlayerController, query: String) {
    val ignore = c.store.data.ignoreWords
    val sort = c.store.data.tabSort["tracks"] ?: 0
    val reverse = c.store.data.tabSortRev["tracks"] ?: false
    val dd = c.store.data
    val list = remember(c.library, query, sort, ignore, reverse, dd.playCounts, dd.lastPlayed, dd.alphaNum) {
        sortSongs(c.library.filter { matches(it, query) }, sort, ignore, dd).reversedIf(reverse)
    }
    TrackList(c, list, if (c.library.isEmpty()) "No music found on this device." else "No matches.", sourceName = "All songs", scrollKey = "tracks")
}

private fun albumLine(artist: String, extra: String) = if (extra.isBlank() || extra == artist) artist else "$artist · $extra"

@Composable
private fun AlbumsTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    if (!c.store.data.uiGridSwitch) { AlbumsTabBody(c, query, push); return }
    Column(Modifier.fillMaxSize()) {
        val cols = c.store.data.albumCols
        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1 to "List", 2 to "2 columns", 3 to "Covers only").forEach { (n, label) ->
                androidx.compose.material3.FilterChip(cols == n, { c.store.update { it.copy(albumCols = n) } }, label = { Text(label) })
            }
        }
        Box(Modifier.weight(1f)) { AlbumsTabBody(c, query, push) }
    }
}

@Composable
private fun AlbumsTabBody(c: PlayerController, query: String, push: (Route) -> Unit) {
    val ignore = c.store.data.ignoreWords
    val sort = c.store.data.tabSort["albums"] ?: 0
    val reverse = c.store.data.tabSortRev["albums"] ?: false
    val cols = c.store.data.albumCols.coerceIn(1, 5)
    val dd = c.store.data
    val albums = remember(c.library, query, ignore, sort, reverse, dd.playCounts, dd.alphaNum, dd.albumMergeByName) {
        val g = c.library.groupBy { it.albumKey() }.values
            .filter { l -> nameMatch(l.first().album, query) || nameMatch(l.first().albumArtist.ifBlank { l.first().artist }, query) }
        sortGroups(g, SORTS["albums"]!!.getOrElse(sort) { "Name" }, { it.first().album }, { it }, dd, ignore).reversedIf(reverse)
    }
    if (albums.isEmpty()) { Empty("No albums."); return }
    if (cols == 1) {
        LazyColumn(state = rememberSavedListState("albums"), contentPadding = PaddingValues(bottom = 140.dp)) {
            itemsIndexed(albums, key = { _, a -> a.first().albumKey() }) { i, tracks ->
                val first = tracks.first()
                GroupRow(i, first.album, albumLine(albumOwner(tracks), albumExtraInfo(tracks, dd.albumInfo, SORTS["albums"]!!.getOrElse(sort) { "Name" })), first, null) {
                    push(Route.Detail("album", first.albumKey()))
                }
            }
        }
        return
    }
    val small = cols >= 3
    val coverOnly = dd.uiGridSwitch && cols == 3
    LazyVerticalGrid(
        GridCells.Fixed(cols), state = rememberSavedGridState("albums_grid"), contentPadding = PaddingValues(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 140.dp),
        horizontalArrangement = Arrangement.spacedBy(if (small) 8.dp else 14.dp), verticalArrangement = Arrangement.spacedBy(if (small) 10.dp else 14.dp),
    ) {
        itemsIndexed(albums, key = { _, a -> a.first().albumKey() }) { i, tracks ->
            val first = tracks.first()
            Column(
                Modifier.clickable { push(Route.Detail("album", first.albumKey())) },
            ) {
                AlbumArt(first, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(if (small) 12.dp else 18.dp), if (small) 24.dp else 40.dp, if (small) 256 else 480)
                if (!coverOnly) Text(
                    first.album, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 4.dp),
                    style = if (small) MaterialTheme.typography.labelLarge else MaterialTheme.typography.bodyLarge,
                )
                if (!coverOnly) Text(
                    albumOwner(tracks), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 4.dp),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                albumExtraInfo(tracks, dd.albumInfo, SORTS["albums"]!!.getOrElse(sort) { "Name" }).takeIf { !coverOnly && it.isNotBlank() && it != first.artist }?.let { x ->
                    Text(
                        x, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 4.dp),
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline,
                    )
                }
            }
        }
    }
}

@Composable
private fun GroupRow(
    index: Int, title: String, subtitle: String, art: Track?, icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    modifier: Modifier = Modifier, onClick: () -> Unit,
) {
    Row(
        modifier.staggerIn(index, title + "|" + index).fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center,
            ) {
                AlbumArt(null, Modifier.fillMaxSize(), RoundedCornerShape(14.dp))
                Icon(icon, null, tint = androidx.compose.ui.graphics.Color.White)
            }
        } else {
            AlbumArt(art, Modifier.size(52.dp), CircleShape, 24.dp)
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ArtistsTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val ignore = c.store.data.ignoreWords
    val split = c.store.data.splitArtists
    val seps = c.store.data.artistSeparators
    val sort = c.store.data.tabSort["artists"] ?: 0
    val reverse = c.store.data.tabSortRev["artists"] ?: false
    var kind by remember { mutableStateOf(0) } // 0 artists, 1 album artists, 2 composers
    val artists = remember(c.library, query, ignore, split, seps, kind, sort, reverse, c.store.data.playCounts, c.store.data.alphaNum) {
        val m = LinkedHashMap<String, MutableList<Track>>()
        for (t in c.library) {
            val names = when (kind) {
                1 -> albumArtistsOf(t, split, seps)
                2 -> listOf(t.composer.ifBlank { "Unknown composer" })
                else -> artistsOf(t, split, seps)
            }
            for (a in names) m.getOrPut(a) { ArrayList() }.add(t)
        }
        val dd = c.store.data
        val g = m.entries.filter { nameMatch(it.key, query) }
        sortGroups(g, SORTS["artists"]!!.getOrElse(sort) { "Name" }, { it.key }, { it.value }, dd, ignore).reversedIf(reverse)
    }
    val kindName = when (kind) { 1 -> "albumartist"; 2 -> "composer"; else -> "artist" }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Artists", "Album-Artists", "Composers").forEachIndexed { i, n ->
                androidx.compose.material3.FilterChip(kind == i, { kind = i }, label = { Text(n) })
            }
        }
        if (artists.isEmpty()) { Empty("Nothing here."); return@Column }
        LazyColumn(state = rememberSavedListState("artists"), contentPadding = PaddingValues(bottom = 140.dp)) {
            itemsIndexed(artists, key = { _, e -> kindName + e.key }) { i, e ->
                GroupRow(i, e.key, "${e.value.size} songs" + if (c.store.data.artistExtra) " · ${e.value.map { it.albumKey() }.distinct().size} albums · ${formatTime(e.value.sumOf { it.durationMs })}" else "", e.value.first(), null) { push(Route.Detail(kindName, e.key)) }
            }
        }
    }
}

@Composable
private fun GenresTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val gSort = c.store.data.tabSort["genres"] ?: 0
    val gRev = c.store.data.tabSortRev["genres"] ?: false
    val gd = c.store.data
    val genres = remember(c.library, query, gSort, gRev, gd.playCounts, gd.splitGenres, gd.genreSeparators) {
        val byGenre = HashMap<String, MutableList<Track>>()
        for (t in c.library) for (g in genresOf(t, gd.splitGenres, gd.genreSeparators)) byGenre.getOrPut(g) { ArrayList() }.add(t)
        val g = byGenre.entries.filter { nameMatch(it.key, query) }
        sortGroups(g, SORTS["genres"]!!.getOrElse(gSort) { "Name" }, { it.key }, { it.value }, gd, false).reversedIf(gRev)
    }
    if (genres.isEmpty()) { Empty("No genres."); return }
    LazyColumn(state = rememberSavedListState("genres"), contentPadding = PaddingValues(bottom = 140.dp)) {
        itemsIndexed(genres, key = { _, e -> e.key }) { i, e ->
            GroupRow(i, e.key, "${e.value.size} songs" + if (gd.genreExtra) " · ${formatTime(e.value.sumOf { it.durationMs })}" else "", e.value.first(), null) { push(Route.Detail("genre", e.key)) }
        }
    }
}

@Composable
private fun FoldersTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val tree = c.store.data.foldersTree
    var cur by remember { mutableStateOf("") }
    var menuFor by remember { mutableStateOf<String?>(null) }
    var renameFor by remember { mutableStateOf<String?>(null) }
    var moveFor by remember { mutableStateOf<String?>(null) }
    val actions = LocalActions.current
    val matched = c.library
    val fd = c.store.data
    val fSort = c.store.data.tabSort["folders"] ?: 0
    val fRev = c.store.data.tabSortRev["folders"] ?: false

    fun under(dir: String) = matched.filter { it.folder == dir || it.folder.startsWith("$dir/") }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (tree && cur.isNotEmpty()) cur else if (tree) "Folder tree" else "All folders",
                Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            androidx.compose.material3.TextButton({ c.store.update { it.copy(foldersTree = !it.foldersTree) }; cur = "" }) { Text(if (tree) "Show as list" else "Show as tree") }
        }
        if (!tree || query.isNotBlank()) {
            val folders = remember(matched, fSort, fRev, query, fd.playCounts) {
                val g = matched.groupBy { it.folder }.entries.filter { nameMatch(it.key.substringAfterLast('/'), query) }
                sortGroups(g, SORTS["folders"]!!.getOrElse(fSort) { "Name" }, { it.key }, { it.value }, fd, false).reversedIf(fRev)
            }
            if (folders.isEmpty()) { Empty("No folders."); return@Column }
            LazyColumn(state = rememberSavedListState("folders_tree"), contentPadding = PaddingValues(bottom = 140.dp)) {
                itemsIndexed(folders, key = { _, e -> e.key }) { i, e ->
                    GroupRow(i, e.key.substringAfterLast('/').ifEmpty { "/" }, "${e.value.size} songs" + if (fd.folderPath) " · ${e.key}" else "", null, Icons.Rounded.Folder) {
                        push(Route.Detail("folder", e.key))
                    }
                }
            }
        } else {
            // children of the current folder; when there is only one path to follow, skip straight down it
            val inside = if (cur.isEmpty()) matched else under(cur)
            val base = if (cur.isEmpty()) "" else "$cur/"
            val children = inside.filter { it.folder.startsWith(base) && it.folder != cur }
                .groupBy { base + it.folder.removePrefix(base).substringBefore('/') }
                .entries.toList().let { g -> sortGroups(g, SORTS["folders"]!!.getOrElse(fSort) { "Name" }, { it.key }, { it.value }, fd, false).reversedIf(fRev) }
            val direct = inside.filter { it.folder == cur }
            if (cur.isEmpty() && children.size == 1 && direct.isEmpty()) {
                // jump past shared prefixes like /storage/emulated/0
                var d = children.first().key
                while (true) {
                    val sub = matched.filter { it.folder.startsWith("$d/") }.map { d + "/" + it.folder.removePrefix("$d/").substringBefore('/') }.distinct()
                    val here = matched.any { it.folder == d }
                    if (sub.size == 1 && !here) d = sub.first() else break
                }
                cur = d
            }
            BackHandlerIfNested(cur.isNotEmpty()) { cur = cur.substringBeforeLast('/', "") }
            LazyColumn(state = rememberSavedListState("folders_flat"), contentPadding = PaddingValues(bottom = 140.dp)) {
                if (cur.isNotEmpty()) item(key = "up") {
                    GroupRow(0, "..", "Up one level", null, Icons.Rounded.Folder) { cur = if (cur.count { it == '/' } <= 1) "" else cur.substringBeforeLast('/') }
                }
                if (direct.isNotEmpty()) item(key = "here") {
                    GroupRow(1, "Songs in this folder", "${direct.size} songs", direct.first(), null) { push(Route.Detail("folder", cur)) }
                }
                itemsIndexed(children, key = { _, e -> e.key }) { i, e ->
                    val path = e.key
                    val hasSub = matched.any { it.folder.startsWith("$path/") }
                    Box {
                        GroupRow(i + 2, path.substringAfterLast('/'), "${e.value.size} songs" + if (hasSub) " · has sub-folders" else "", null, Icons.Rounded.Folder) {
                            if (hasSub) cur = path else push(Route.Detail("folder", path))
                        }
                        Box(Modifier.align(Alignment.CenterEnd)) {
                            Icon(
                                Icons.Rounded.MoreVert, null,
                                Modifier.padding(end = 12.dp).size(36.dp).clip(CircleShape).clickable { menuFor = path }.padding(6.dp),
                            )
                            DropdownMenu(menuFor == path, { menuFor = null }) {
                                DropdownMenuItem(text = { Text("Play all") }, onClick = { menuFor = null; c.playFromSource(path.substringAfterLast('/'), under(path), 0, false) })
                                DropdownMenuItem(text = { Text("Shuffle all") }, onClick = { menuFor = null; c.playFromSource(path.substringAfterLast('/'), under(path).shuffled(), 0, true) })
                                DropdownMenuItem(text = { Text("Add to queue") }, onClick = { menuFor = null; c.addAllToQueue(under(path)) })
                                DropdownMenuItem(text = { Text("Rename folder") }, onClick = { renameFor = path; menuFor = null })
                                DropdownMenuItem(text = { Text("Move songs to another folder") }, onClick = { moveFor = path; menuFor = null })
                                DropdownMenuItem(text = { Text("Pin shortcut to home screen") }, onClick = { menuFor = null; actions.pinShortcut("folder" + path.hashCode(), path.substringAfterLast('/'), "detail|folder|$path") })
                            }
                        }
                    }
                }
            }
        }
    }
    renameFor?.let { path ->
        NameDialog("Rename folder", path.substringAfterLast('/'), "Rename", { renameFor = null }) { n ->
            val clean = n.trim().replace("/", "")
            if (clean.isNotEmpty()) actions.renameFolder(under(path), path, path.substringBeforeLast('/') + "/" + clean)
            renameFor = null; cur = ""
        }
    }
    moveFor?.let { path ->
        NameDialog("Move to (e.g. Music/Rock)", "Music/", "Move", { moveFor = null }) { n ->
            val clean = n.trim().trim('/')
            if (clean.isNotEmpty()) actions.moveTracks(under(path), "$clean/")
            moveFor = null; cur = ""
        }
    }
}

@Composable
private fun BackHandlerIfNested(enabled: Boolean, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler(enabled = enabled, onBack = onBack)
}

private class SmartEntry(val icon: androidx.compose.ui.graphics.vector.ImageVector, val title: String, val count: String?, val onClick: () -> Unit)

@Composable
private fun PlaylistsTab(c: PlayerController, push: (Route) -> Unit, q: String) {
    var creating by remember { mutableStateOf(false) }
    val actions = LocalActions.current
    val pSort = c.store.data.tabSort["playlists"] ?: 0
    val pRev = c.store.data.tabSortRev["playlists"] ?: false
    val pd = c.store.data
    val pls = sortGroups(
        pd.playlists.filter { nameMatch(it.name, q) }, SORTS["playlists"]!!.getOrElse(pSort) { "Name" }, { it.name },
        { p -> p.trackIds.mapNotNull { c.track(it) } }, pd, false,
    ).reversedIf(pRev)

    val hid = pd.hiddenSmart
    var reviewDlg by remember { mutableStateOf(false) }
    if (reviewDlg) YearInReviewDialog(c) { reviewDlg = false }
    val smart = buildList {
        if ("all" !in hid) add(SmartEntry(Icons.Rounded.MusicNote, "All songs", "${c.library.size}") { push(Route.Detail("smart", "all")) })
        if ("fav" !in hid) add(SmartEntry(Icons.Rounded.Favorite, "Favorites", "${pd.favourites.size}") { push(Route.Detail("smart", "fav")) })
        if ("added" !in hid) add(SmartEntry(Icons.Rounded.AutoAwesome, "Recently added", null) { push(Route.Detail("smart", "added")) })
        if ("played" !in hid) add(SmartEntry(Icons.Rounded.History, "Recently played", null) { push(Route.Detail("smart", "played")) })
        if ("most" !in hid) add(SmartEntry(Icons.Rounded.LocalFireDepartment, "Most played", null) { push(Route.MostPlayed) })
        if ("mixes" !in hid) add(SmartEntry(Icons.Rounded.AutoAwesome, "Smart mixes", null) { push(Route.Mixes) })
        add(SmartEntry(Icons.Rounded.AutoAwesome, "Year in review", null) { reviewDlg = true })
        if ("unplayed" !in hid) add(SmartEntry(Icons.Rounded.Block, "Not played", null) { push(Route.Detail("smart", "unplayed")) })
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), state = rememberSavedListState("playlists"), contentPadding = PaddingValues(bottom = 140.dp)) {
            // smart lists as two columns of rounded tiles
            item {
                Column(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    smart.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { e ->
                                Row(
                                    Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                        .bounceClick(e.onClick).padding(horizontal = 10.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Box(
                                        Modifier.size(38.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                                        contentAlignment = Alignment.Center,
                                    ) { Icon(e.icon, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.primary) }
                                    Column(Modifier.weight(1f).padding(start = 10.dp)) {
                                        Text(e.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        if (e.count != null) Text(e.count, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
            item {
                Text(
                    "Your playlists", Modifier.padding(start = 16.dp, top = 20.dp, bottom = 6.dp),
                    style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
                )
            }
            items(pls, key = { it.id }) { p ->
                val tracks = remember(p.trackIds, c.library) { p.trackIds.mapNotNull { c.track(it) } }
                Row(
                    Modifier.fillMaxWidth().bounceClick { push(Route.Detail("playlist", p.id)) }.padding(horizontal = 16.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    MixCover(tracks, Modifier.size(64.dp), 14.dp)
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            (if (pd.playlistCounts) "${tracks.size} songs · " else "") + formatTime(tracks.sumOf { it.durationMs }),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
            item {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    androidx.compose.material3.OutlinedButton({ creating = true }, shape = RoundedCornerShape(10.dp)) {
                        Icon(Icons.Rounded.Add, null, Modifier.size(20.dp)); Text("  New playlist")
                    }
                    androidx.compose.material3.OutlinedButton({ actions.importPlaylist() }, shape = RoundedCornerShape(10.dp)) {
                        Icon(Icons.Rounded.FileDownload, null, Modifier.size(20.dp)); Text("  External playlists (.m3u)")
                    }
                }
            }
        }
    }
    if (creating) NameDialog("New playlist", confirm = "Create", onDismiss = { creating = false }) {
        c.store.createPlaylist(it); creating = false
    }
}

// -------------------------------------------------------------------------------------------------
// Detail (album / artist / folder / playlist / smart list)
// -------------------------------------------------------------------------------------------------

@Composable
fun DetailScreen(c: PlayerController, kind: String, key: String, back: () -> Unit) {
    if (kind == "smart" && (key == "added" || key == "played" || key == "unplayed")) { PeriodListScreen(c, key, back); return }
    val d = c.store.data
    val playlist = if (kind == "playlist") d.playlists.find { it.id == key } else null
    val (title, baseTracks) = remember(kind, key, c.library, d.playlists, d.playCounts, d.lastPlayed, d.favourites, d.splitArtists, d.artistSeparators, d.ratings, d.splitGenres, d.genreSeparators) {
        when (kind) {
            "album" -> {
                val l = c.library.filter { it.albumKey() == key }
                (l.firstOrNull()?.album ?: "Album") to l.sortedBy { it.trackNo }
            }
            "artist" -> key to c.library.filter { key in artistsOf(it, d.splitArtists, d.artistSeparators) || key in artistsOf(it, true, d.artistSeparators) }.sortedBy { it.album.lowercase() + "%03d".format(it.trackNo) }
            "albumartist" -> key to c.library.filter { key in albumArtistsOf(it, d.splitArtists, d.artistSeparators) }.sortedBy { it.album.lowercase() + "%03d".format(it.trackNo) }
            "composer" -> key to c.library.filter { it.composer.ifBlank { "Unknown composer" } == key }.sortedBy { it.title.lowercase() }
            "genre" -> key to c.library.filter { key in genresOf(it, d.splitGenres, d.genreSeparators) }.sortedBy { it.title.lowercase() }
            "folder" -> key.substringAfterLast('/') to c.library.filter { it.folder == key }.sortedBy { it.title.lowercase() }
            "playlist" -> (playlist?.name ?: "Playlist") to (playlist?.trackIds?.mapNotNull { c.track(it) } ?: emptyList())
            else -> when (key) {
                "all" -> "All songs" to c.library.sortedBy { it.title.lowercase() }
                "fav" -> "Favourites" to d.favourites.mapNotNull { c.track(it) }
                "added" -> "Recently added" to c.library.sortedByDescending { it.dateAdded }.take(100)
                "played" -> "Recently played" to d.lastPlayed.mapNotNull { c.track(it) }
                "unplayed" -> "Not played yet" to c.library.filter { (d.playCounts[it.id] ?: 0) == 0 }.sortedBy { it.title.lowercase() }
                else -> "Most played" to d.playCounts.entries.sortedByDescending { it.value }.take(100).mapNotNull { c.track(it.key) }
            }
        }
    }
    val sortId = "d:$kind:$key"
    val sortIdx = d.tabSort[sortId] ?: 0
    val sortRev = d.tabSortRev[sortId] ?: false
    var artistsOpen by remember { mutableStateOf(true) }
    var artistSel by remember(key) { mutableStateOf<String?>(null) }
    val albumArtists = remember(baseTracks) { baseTracks.map { it.artist }.distinct() }
    val tracks = remember(baseTracks, sortIdx, sortRev, d.playCounts, d.lastPlayed, d.ignoreWords, d.alphaNum, artistSel) {
        val b = if (kind == "album" && artistSel != null) baseTracks.filter { it.artist == artistSel } else baseTracks
        (if (sortIdx > 0) sortSongs(b, sortIdx - 1, d.ignoreWords, d) else b).reversedIf(sortRev)
    }
    var menu by remember { mutableStateOf(false) }
    var sortDlg by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var saveAs by remember { mutableStateOf(false) }
    var moveDlg by remember { mutableStateOf(false) }
    val actions = LocalActions.current

    val collapse = d.uiCollapseHeader && (kind == "album" || kind == "artist")
    val heroFull = with(androidx.compose.ui.platform.LocalDensity.current) { 300.dp.toPx() }
    val heroMin = with(androidx.compose.ui.platform.LocalDensity.current) { 72.dp.toPx() }
    var heroH by remember(key) { mutableStateOf(heroFull) }
    val heroConn = remember(heroFull, heroMin) {
        object : androidx.compose.ui.input.nestedscroll.NestedScrollConnection {
            // scrolling up shrinks the header first; scrolling down grows it back only once the list is at its top
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (available.y >= 0f) return androidx.compose.ui.geometry.Offset.Zero
                val next = (heroH + available.y).coerceIn(heroMin, heroFull)
                val used = next - heroH; heroH = next
                return androidx.compose.ui.geometry.Offset(0f, used)
            }
            override fun onPostScroll(consumed: androidx.compose.ui.geometry.Offset, available: androidx.compose.ui.geometry.Offset, source: androidx.compose.ui.input.nestedscroll.NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (available.y <= 0f) return androidx.compose.ui.geometry.Offset.Zero
                val next = (heroH + available.y).coerceIn(heroMin, heroFull)
                val used = next - heroH; heroH = next
                return androidx.compose.ui.geometry.Offset(0f, used)
            }
        }
    }
    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().then(if (collapse) Modifier.nestedScroll(heroConn) else Modifier.statusBarsPadding())) {
        if (collapse) {
            val hDp = with(androidx.compose.ui.platform.LocalDensity.current) { heroH.toDp() }
            val frac = ((heroH - heroMin) / (heroFull - heroMin)).coerceIn(0f, 1f)
            Box(Modifier.fillMaxWidth().height(hDp).clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))) {
                // the cover slides up a little more slowly than the header shrinks (parallax)
                AlbumArt(tracks.firstOrNull(), Modifier.fillMaxSize().graphicsLayer { translationY = -(1f - frac) * 40f; scaleX = 1.15f; scaleY = 1.15f }, androidx.compose.ui.graphics.RectangleShape, 80.dp, 800)
                Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Transparent, Color.Black.copy(alpha = 0.75f)))))
                Row(Modifier.statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    HeaderIcon(Icons.AutoMirrored.Rounded.ArrowBack, back)
                    Spacer(Modifier.weight(1f))
                    HeaderIcon(Icons.AutoMirrored.Rounded.Sort) { sortDlg = true }
                    HeaderIcon(Icons.Rounded.MoreVert) { menu = true }
                }
                Column(Modifier.align(Alignment.BottomStart).padding(horizontal = 20.dp, vertical = 14.dp)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = if (frac > 0.5f) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleLarge)
                    Text("${tracks.size} songs · ${formatTime(tracks.sumOf { it.durationMs })}", color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else if (kind == "album") {
            Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                HeaderIcon(Icons.AutoMirrored.Rounded.ArrowBack, back)
                Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                HeaderIcon(Icons.Rounded.Settings) { menu = true }
            }
            Row(
                Modifier.fillMaxWidth().clickable { artistsOpen = !artistsOpen }.padding(horizontal = 20.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Artists", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                val rot by androidx.compose.animation.core.animateFloatAsState(if (artistsOpen) 0f else -90f, androidx.compose.animation.core.tween(Motion.ms(220)), label = "arrow")
                Icon(Icons.Rounded.KeyboardArrowDown, null, Modifier.padding(start = 6.dp).graphicsLayer { rotationZ = rot })
            }
            androidx.compose.animation.AnimatedVisibility(artistsOpen) {
                Column {
                    androidx.compose.foundation.lazy.LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        item { PeriodCard("All artists", artistSel == null, wrap = true) { artistSel = null } }
                        items(albumArtists.size) { i ->
                            val n = albumArtists[i]
                            PeriodCard(n, artistSel == n, wrap = true) { artistSel = if (artistSel == n) null else n }
                        }
                    }
                    Text(
                        "${if (artistSel == null) albumArtists.size else 1}/${albumArtists.size} artists",
                        Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${tracks.size} songs", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.width(16.dp))
                Icon(Icons.Rounded.Timer, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(6.dp))
                Text(formatTime(tracks.sumOf { it.durationMs }), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleMedium)
            }
            androidx.compose.material3.HorizontalDivider()
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                HeaderIcon(Icons.Rounded.Shuffle) { if (tracks.isNotEmpty()) c.playFromSource(title, tracks.shuffled(), 0, true) }
                HeaderIcon(Icons.AutoMirrored.Rounded.Sort) { sortDlg = true }
                HeaderIcon(Icons.Rounded.MoreHoriz) { menu = true }
            }
        } else {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            HeaderIcon(Icons.AutoMirrored.Rounded.ArrowBack, back)
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            HeaderIcon(Icons.Rounded.MoreVert) { menu = true }
        }
        Row(Modifier.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(tracks.firstOrNull(), Modifier.size(96.dp), RoundedCornerShape(20.dp), 40.dp)
            Column(Modifier.padding(start = 16.dp)) {
                Text("${tracks.size} songs · ${formatTime(tracks.sumOf { it.durationMs })}", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        // play, shuffle and sort sit together
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            PillButton("Play", Icons.Rounded.PlayArrow, true) { c.playFromSource(title, tracks, 0, false) }
            PillButton("Shuffle", Icons.Rounded.Shuffle, false) { c.playFromSource(title, tracks.shuffled(), 0, true) }
            Spacer(Modifier.weight(1f))
            PillButton(if (sortIdx == 0) "Sort" else (SONG_SORTS.getOrNull(sortIdx - 1) ?: "Sort") + if (sortRev) " ↓" else "", Icons.AutoMirrored.Rounded.Sort, sortIdx != 0) { sortDlg = true }
        }
        Spacer(Modifier.height(6.dp))
        }
        Spacer(Modifier.height(4.dp))
        TrackList(
            c, tracks, "Nothing here yet.", sourceName = title,
            extraMenu = { t ->
                if (playlist != null) listOf("Remove from playlist" to { c.store.removeFromPlaylist(playlist.id, t.id) }) else emptyList()
            },
        )
    }
    if (collapse && tracks.isNotEmpty()) androidx.compose.material3.FloatingActionButton(
        onClick = { c.playFromSource(title, tracks.shuffled(), 0, true) },
        modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 20.dp, bottom = 90.dp),
    ) { Icon(Icons.Rounded.Shuffle, "Shuffle") }
    }
    if (sortDlg) androidx.compose.ui.window.Dialog(onDismissRequest = { sortDlg = false }) {
        Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Column(Modifier.padding(vertical = 18.dp)) {
                Text("Sort by", Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    (listOf("Default order") + SONG_SORTS).forEachIndexed { i, label ->
                        Row(
                            Modifier.fillMaxWidth().clickable { c.store.update { it.copy(tabSort = it.tabSort + (sortId to i)) }; sortDlg = false }.padding(horizontal = 20.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            androidx.compose.material3.RadioButton(i == sortIdx, null)
                            Text(label, Modifier.padding(start = 14.dp), fontWeight = if (i == sortIdx) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
                androidx.compose.material3.HorizontalDivider(Modifier.padding(vertical = 6.dp))
                Row(
                    Modifier.fillMaxWidth().clickable { c.store.update { it.copy(tabSortRev = it.tabSortRev + (sortId to !sortRev)) } }.padding(horizontal = 24.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("Reverse order", Modifier.weight(1f))
                    androidx.compose.material3.Switch(sortRev, { c.store.update { it.copy(tabSortRev = it.tabSortRev + (sortId to !sortRev)) } })
                }
                Row(Modifier.fillMaxWidth().padding(end = 16.dp), horizontalArrangement = Arrangement.End) {
                    androidx.compose.material3.TextButton({ sortDlg = false }) { Text("Close") }
                }
            }
        }
    }
    if (menu) androidx.compose.ui.window.Dialog(onDismissRequest = { menu = false }) {
        Surface(shape = RoundedCornerShape(28.dp), color = MaterialTheme.colorScheme.surfaceContainerHigh) {
            Column(Modifier.padding(vertical = 16.dp)) {
                Text(title, Modifier.padding(horizontal = 24.dp, vertical = 4.dp), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${tracks.size} songs · ${formatTime(tracks.sumOf { it.durationMs })}", Modifier.padding(horizontal = 24.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                @Composable
                fun Item(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, danger: Boolean = false, onClick: () -> Unit) {
                    Row(
                        Modifier.fillMaxWidth().clickable { menu = false; onClick() }.padding(horizontal = 24.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(icon, null, tint = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(label, Modifier.padding(start = 18.dp), color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
                    }
                }
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                    Item(Icons.AutoMirrored.Rounded.QueueMusic, "Add all to queue") { c.addAllToQueue(tracks) }
                    Item(Icons.AutoMirrored.Rounded.PlaylistAdd, "Save as playlist") { saveAs = true }
                    Item(Icons.Rounded.FileDownload, "Export as .m3u") { actions.exportPlaylist(title, tracks) }
                    if (kind != "smart" || key != "all") Item(Icons.Rounded.PushPin, "Pin shortcut to home screen") { actions.pinShortcut("d" + (kind + key).hashCode(), title, "detail|$kind|$key") }
                    if (kind == "folder") Item(Icons.Rounded.DriveFileMove, "Move songs to another folder") { moveDlg = true }
                    if (playlist != null) {
                        Item(Icons.Rounded.Edit, "Rename playlist") { rename = true }
                        Item(Icons.Rounded.Delete, "Delete playlist", danger = true) { c.store.deletePlaylist(playlist.id); back() }
                    }
                }
            }
        }
    }
    if (rename && playlist != null) NameDialog("Rename playlist", playlist.name, "Rename", { rename = false }) {
        c.store.renamePlaylist(playlist.id, it); rename = false
    }
    if (moveDlg) NameDialog("Move to (e.g. Music/Rock)", "Music/", "Move", { moveDlg = false }) { n ->
        val clean = n.trim().trim('/'); if (clean.isNotEmpty()) actions.moveTracks(tracks, "$clean/"); moveDlg = false
    }
    if (saveAs) NameDialog("Save as playlist", title, "Save", { saveAs = false }) {
        c.store.createPlaylist(it, tracks.map { t -> t.id }); saveAs = false
    }
}

@Composable
fun PillButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, filled: Boolean, onClick: () -> Unit) {
    val bg = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier.clip(RoundedCornerShape(50)).then(Modifier.bounceClick(onClick))
            .background(bg).padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp))
        Spacer(Modifier.size(6.dp))
        Text(label, color = fg, fontWeight = FontWeight.SemiBold)
    }
}


// -------------------------------------------------------------------------------------------------
// Recently added / Recently played: pick a period (past day, 3 days, week...) like Musicolet
// -------------------------------------------------------------------------------------------------

private val PERIODS = listOf(1, 3, 7, 15, 30, 60, 90, 180, 365)

private fun periodLabel(days: Int) = when (days) {
    0 -> "All time"
    1 -> "Past 1 day"
    365 -> "Past 1 year"
    else -> "Past $days days"
}

@Composable
private fun PeriodCard(label: String, selected: Boolean, wrap: Boolean = false, onClick: () -> Unit) {
    val line = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
    Box(
        (if (wrap) Modifier.widthIn(min = 80.dp, max = 220.dp).height(78.dp) else Modifier.size(width = 80.dp, height = 78.dp)).clip(RoundedCornerShape(16.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
            .border(if (selected) 2.dp else 1.5.dp, line, RoundedCornerShape(16.dp))
            .bounceClick(onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label, Modifier.padding(start = if (wrap) 14.dp else 6.dp, end = if (wrap) 14.dp else 6.dp, bottom = if (wrap) 10.dp else 0.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            maxLines = if (wrap) 2 else Int.MAX_VALUE, overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium, color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        )
        Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp).size(width = 52.dp, height = 2.dp).background(line))
    }
}

@Composable
private fun PeriodListScreen(c: PlayerController, key: String, back: () -> Unit) {
    val d = c.store.data
    val added = key == "added"
    val unplayed = key == "unplayed"
    val days = if (added) d.addedDays else if (unplayed) d.unplayedDays else d.playedDays
    val title = if (added) "Recently added" else if (unplayed) "Not played" else "Recently played"
    val options = remember(d.customDays) {
        (PERIODS + listOfNotNull(d.customDays.takeIf { it > 0 && it !in PERIODS })).sorted() + 0
    }
    var query by remember { mutableStateOf("") }
    var gear by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var saveAs by remember { mutableStateOf(false) }
    val actions = LocalActions.current

    val cutoff = if (days > 0) System.currentTimeMillis() - days * 86_400_000L else 0L
    val events = c.playLog.events
    val base = remember(added, unplayed, c.library, events, cutoff, d.lastPlayed, d.playCounts, days) {
        if (unplayed) {
            // songs not played within the period (or, with "Never played", songs that were never played at all)
            val lastAt = HashMap<Long, Long>()
            for (e in events) if (e.at > (lastAt[e.id] ?: 0L)) lastAt[e.id] = e.at
            if (days == 0) c.library.filter { (d.playCounts[it.id] ?: 0) == 0 && it.id !in lastAt }.sortedBy { it.title.lowercase() }
            else c.library.filter { val la = lastAt[it.id]; la == null || la < cutoff }.sortedBy { it.title.lowercase() }
        } else if (added) c.library.filter { it.dateAdded * 1000L >= cutoff }.sortedByDescending { it.dateAdded }
        else {
            val fromLog = events.asReversed().filter { it.at >= cutoff }.map { it.id }.distinct().mapNotNull { c.track(it) }
            // plays from before the play log existed have no date, so they only show under "All time"
            if (days == 0) (fromLog + d.lastPlayed.mapNotNull { c.track(it) }).distinctBy { it.id } else fromLog
        }
    }
    val shown = remember(base, query) { if (query.isBlank()) base else base.filter { matches(it, query) } }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            HeaderIcon(Icons.AutoMirrored.Rounded.ArrowBack, back)
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
            HeaderIcon(Icons.Rounded.Settings) { gear = true }
        }
        androidx.compose.foundation.lazy.LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(options.size) { i ->
                val n = options[i]
                PeriodCard(if (unplayed && n == 0) "Never played" else periodLabel(n), n == days) {
                    c.store.update { if (added) it.copy(addedDays = n) else if (unplayed) it.copy(unplayedDays = n) else it.copy(playedDays = n) }
                }
            }
        }
        Row(Modifier.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${shown.size} songs", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.width(16.dp))
            Icon(Icons.Rounded.Timer, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(6.dp))
            Text(formatTime(shown.sumOf { it.durationMs }), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleMedium)
        }
        androidx.compose.material3.HorizontalDivider()
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            HeaderIcon(Icons.Rounded.Shuffle) { if (shown.isNotEmpty()) c.playFromSource(title, shown.shuffled(), 0, true) }
            Box {
                HeaderIcon(Icons.Rounded.MoreHoriz) { menu = true }
                DropdownMenu(menu, { menu = false }) {
                    val hmd = c.store.data.hiddenMenu
                    if ("d_play" !in hmd) DropdownMenuItem(text = { Text("Play all") }, onClick = { menu = false; if (shown.isNotEmpty()) c.playFromSource(title, shown, 0, false) })
                    if ("d_queue" !in hmd) DropdownMenuItem(text = { Text("Add all to queue") }, onClick = { menu = false; c.addAllToQueue(shown) })
                    if ("d_export" !in hmd) DropdownMenuItem(text = { Text("Export as .m3u") }, onClick = { menu = false; actions.exportPlaylist(title, shown) })
                    if ("d_save" !in hmd) DropdownMenuItem(text = { Text("Save as playlist") }, onClick = { menu = false; saveAs = true })
                }
            }
        }
        Box(Modifier.weight(1f)) {
            TrackList(c, shown, if (query.isBlank()) (if (unplayed) "Every song was played in this period." else "Nothing in this period.") else "No match.", sourceName = title)
        }
        androidx.compose.material3.OutlinedTextField(
            query, { query = it }, singleLine = true, placeholder = { Text("Search in this list…") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 12.dp, vertical = 6.dp),
        )
    }

    if (gear) {
        var text by remember { mutableStateOf(if (d.customDays > 0) d.customDays.toString() else "") }
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { gear = false },
            title = { Text("$title settings") },
            text = {
                Column {
                    Text("Add your own period. It appears as an extra card.", style = MaterialTheme.typography.bodySmall)
                    androidx.compose.material3.OutlinedTextField(
                        text, { v -> text = v.filter { it.isDigit() }.take(4) }, singleLine = true, label = { Text("Number of days") },
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    )
                }
            },
            confirmButton = {
                androidx.compose.material3.TextButton({
                    val n = text.toIntOrNull() ?: 0
                    c.store.update { if (added) it.copy(customDays = n, addedDays = if (n > 0) n else it.addedDays) else if (unplayed) it.copy(customDays = n, unplayedDays = if (n > 0) n else it.unplayedDays) else it.copy(customDays = n, playedDays = if (n > 0) n else it.playedDays) }
                    gear = false
                }) { Text("Save") }
            },
            dismissButton = { androidx.compose.material3.TextButton({ gear = false }) { Text("Cancel") } },
        )
    }
    if (saveAs) NameDialog("Save as playlist", title, "Save", { saveAs = false }) {
        c.store.createPlaylist(it, shown.map { t -> t.id }); saveAs = false
    }
}
