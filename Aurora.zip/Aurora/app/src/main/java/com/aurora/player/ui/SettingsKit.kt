package com.aurora.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Persisted
import com.aurora.player.player.PlayerController
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject

private val kitJson = Json { ignoreUnknownKeys = true; encodeDefaults = true }

/** Puts the settings whose names pass [pick] back to their factory values. Your songs, playlists and history are never touched by this. */
fun resetSettings(c: PlayerController, pick: (String) -> Boolean) {
    try {
        val cur = kitJson.encodeToJsonElement(Persisted.serializer(), c.store.data).jsonObject
        val def = kitJson.encodeToJsonElement(Persisted.serializer(), Persisted()).jsonObject
        val merged = JsonObject(cur.toMutableMap().also { m -> def.forEach { (k, v) -> if (pick(k)) m[k] = v } })
        val next = kitJson.decodeFromJsonElement(Persisted.serializer(), merged)
        c.store.update { next }
        c.applyPlaybackPrefs()
        c.applyActiveProfile()
    } catch (_: Throwable) {}
}

/** Which settings each page owns, for "Reset this page to defaults". */
val PAGE_RESETS: Map<String, (String) -> Boolean> = mapOf(
    "theme" to { k -> k in setOf("themeMode", "accentColor", "nowBg", "nowBgDim", "blurPct") },
    "audio" to { k -> k in setOf("fadeSec", "fadeInMs", "fadeOutMs", "crossfadeSec", "replayGain", "focusLevel", "handleAudioFocus", "sleepFadeSec", "mono", "balance", "skipSilence") },
    "headset" to { k -> k in setOf("pauseOnUnplug", "resumeOnBt", "resumeOnWired", "resumeOnlyIfPaused", "pauseOnMute", "resumeOnUnmute", "blockPlayMuted", "resumeAfterCall", "preventAutoplay", "earDouble", "earTriple") },
    "lyrics" to { k -> k.startsWith("lyric") },
    "desktop" to { k -> k.startsWith("overlay") },
    "notification" to { k -> k.startsWith("notif") || k == "customNotif" },
    "lock" to { k -> k.startsWith("lock") || k == "queueTheme" },
    "motion" to { k -> k in setOf("motionSpeed", "reduceMotion", "haptics", "contrast", "navStyle", "listAnim", "listStagger", "pressMode", "artFade") },
    "expressive" to { k -> (k.startsWith("ui") && k != "uiWaveform" && k != "uiVisualizer") || k == "blurPct" },
    "analysis" to { k -> k in setOf("uiWaveform", "uiVisualizer", "autoEqOn", "autoEq") },
)

/** Button at the bottom of a settings page that sets only that page's options back to default (after a confirmation). */
@Composable
fun ResetPageRow(c: PlayerController, pageName: String, pick: (String) -> Boolean) {
    var ask by remember { mutableStateOf(false) }
    ActionRow("Reset this page to defaults", "Only the options on “$pageName” go back to how they were. Your music and playlists are not touched") { ask = true }
    if (ask) AlertDialog(
        onDismissRequest = { ask = false },
        title = { Text("Reset “$pageName”?") },
        text = { Text("Every option on this page returns to its default value.") },
        confirmButton = { TextButton({ ask = false; resetSettings(c, pick) }) { Text("Reset") } },
        dismissButton = { TextButton({ ask = false }) { Text("Cancel") } },
    )
}

/** A group of options under a heading that folds open and closed. */
@Composable
fun CollapsibleGroup(title: String, sub: String = "", startOpen: Boolean = false, content: @Composable () -> Unit) {
    var open by rememberSaveable(title) { mutableStateOf(startOpen) }
    val rot by animateFloatAsState(if (open) 180f else 0f, label = "grp")
    Column(Modifier.fillMaxWidth().animateContentSize()) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(start = 24.dp, end = 16.dp, top = 18.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Rounded.ExpandMore, null, Modifier.rotate(rot), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        AnimatedVisibility(open) { Column { content() } }
    }
}

/** A switch whose extra options appear underneath only while it is on. */
@Composable
fun SwitchWithOptions(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().animateContentSize()) {
        SwitchRow(title, sub, checked, onChange)
        AnimatedVisibility(checked) { Column { content() } }
    }
}
