package com.aurora.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController

/** The Home tab: a greeting, what is playing, and shelves of queues, mixes, playlists and songs to jump into. */
@Composable
fun HomeScreen(c: PlayerController, push: (Route) -> Unit, goTab: (String) -> Unit, openNow: () -> Unit) {
    val d = c.store.data
    val cs = MaterialTheme.colorScheme
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val hello = when { hour < 5 -> "Good night"; hour < 12 -> "Good morning"; hour < 17 -> "Good afternoon"; hour < 22 -> "Good evening"; else -> "Good night" }
    val byId = remember(c.library) { c.library.associateBy { it.id } }
    val recent = remember(d.lastPlayed, byId) { d.lastPlayed.mapNotNull { byId[it] }.distinctBy { it.id }.take(15) }
    val added = remember(c.library) { c.library.sortedByDescending { it.dateAdded }.take(15) }
    val most = remember(d.playCounts, c.library) { c.library.filter { (d.playCounts[it.id] ?: 0) > 0 }.sortedByDescending { d.playCounts[it.id] ?: 0 }.take(15) }
    val mixes = remember(c.library.size, d.mixSize, d.mixArtists) { try { buildMixes(c, (System.currentTimeMillis() / 3_600_000L).toInt()).take(10) } catch (_: Throwable) { emptyList() } }
    val favs = remember(d.favourites, byId) { d.favourites.mapNotNull { byId[it] } }

    @Composable
    fun Shelf(title: String, action: String? = null, onAction: () -> Unit = {}, content: @Composable () -> Unit) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontSize = 19.sp, fontWeight = FontWeight.Bold)
            if (action != null) Text(action, Modifier.clip(RoundedCornerShape(10.dp)).bounceClick(onAction).padding(horizontal = 8.dp, vertical = 4.dp), color = cs.primary, fontWeight = FontWeight.Medium, fontSize = 13.sp)
        }
        content()
    }
    @Composable
    fun Row2(content: @Composable () -> Unit) {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) { content() }
    }
    @Composable
    fun SongCard(t: Track, list: List<Track>) {
        Column(Modifier.width(120.dp).bounceClick { c.playTracks(list, list.indexOf(t)) }) {
            AlbumArt(t, Modifier.size(120.dp), RoundedCornerShape(18.dp), 32.dp, 256)
            Text(t.title, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 13.sp)
            Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = cs.onSurfaceVariant)
        }
    }
    @Composable
    fun Tile(brush: Brush, title: String, sub: String, w: Int = 150, onClick: () -> Unit, badge: @Composable () -> Unit = {}) {
        Box(Modifier.width(w.dp).height(104.dp).clip(RoundedCornerShape(20.dp)).background(brush).bounceClick(onClick).padding(12.dp)) {
            Column(Modifier.align(Alignment.BottomStart)) {
                Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White, lineHeight = 18.sp)
                Text(sub, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, color = Color.White.copy(alpha = 0.8f))
            }
            Box(Modifier.align(Alignment.TopEnd)) { badge() }
        }
    }
    fun hue(name: String, light: Float = 0.42f): Brush {
        val h = (name.hashCode().toLong().and(0x7fffffff) % 360).toFloat()
        val a = Color(androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf(h, 0.55f, light)))
        val b = Color(androidx.core.graphics.ColorUtils.HSLToColor(floatArrayOf((h + 40f) % 360f, 0.6f, light - 0.12f)))
        return Brush.linearGradient(listOf(a, b))
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 150.dp)) {
        // header
        Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 10.dp)) {
            Text(hello, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("${c.library.size} songs · ${d.playlists.size} playlists", color = cs.onSurfaceVariant, fontSize = 14.sp)
        }

        // now playing card
        val cur = c.current
        if (cur != null) Row(
            Modifier.padding(horizontal = 16.dp, vertical = 16.dp).fillMaxWidth().clip(RoundedCornerShape(26.dp))
                .background(cs.primaryContainer.copy(alpha = 0.55f)).bounceClick(openNow).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AlbumArt(cur, Modifier.size(64.dp), RoundedCornerShape(18.dp), 28.dp, 256)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(if (c.isPlaying) "Now playing" else "Paused", fontSize = 11.sp, color = cs.onPrimaryContainer.copy(alpha = 0.7f), fontWeight = FontWeight.SemiBold)
                Text(cur.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = cs.onPrimaryContainer)
                Text(cur.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 13.sp, color = cs.onPrimaryContainer.copy(alpha = 0.75f))
            }
            Box(Modifier.size(48.dp).clip(CircleShape).background(cs.primary).bounceClick { c.togglePlay() }, contentAlignment = Alignment.Center) {
                Icon(if (c.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = cs.onPrimary)
            }
        } else Spacer(Modifier.height(14.dp))

        // quick actions
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            @Composable
            fun Quick(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, onClick: () -> Unit) = Row(
                Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(cs.surfaceVariant.copy(alpha = 0.55f)).bounceClick(onClick).padding(vertical = 13.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(icon, null, Modifier.size(20.dp), tint = cs.primary)
                Text("  $text", fontWeight = FontWeight.Medium, fontSize = 13.sp, maxLines = 1)
            }
            Quick(Icons.Rounded.Shuffle, "Shuffle all") { if (c.library.isNotEmpty()) c.playTracks(c.library.shuffled(), 0, true) }
            Quick(Icons.Rounded.Favorite, "Favorites") { push(Route.Detail("smart", "fav")) }
            Quick(Icons.Rounded.LocalFireDepartment, "Most played") { push(Route.MostPlayed) }
        }

        // queues
        val qs = d.queues
        if (qs.isNotEmpty()) Shelf("Your queues", "Open", { goTab("queues") }) {
            Row2 {
                qs.forEachIndexed { i, q ->
                    val first = q.trackIds.firstNotNullOfOrNull { byId[it] }
                    val active = i == c.activeQueue
                    Tile(hue(q.name + i), q.name, "${q.trackIds.size} songs" + if (active) " · playing" else "", 160, {
                        c.switchQueue(i); goTab("queues")
                    }) { if (first != null) AlbumArt(first, Modifier.size(34.dp), RoundedCornerShape(10.dp), 16.dp, 96) }
                }
            }
        }

        // recently played
        if (recent.isNotEmpty()) Shelf("Jump back in", "All", { push(Route.Detail("smart", "played")) }) { Row2 { recent.forEach { SongCard(it, recent) } } }

        // mixes
        if (mixes.isNotEmpty()) Shelf("Made for you", "All mixes", { push(Route.Mixes) }) {
            Row2 {
                mixes.forEach { m ->
                    Tile(hue(m.name, 0.40f), m.name, "${m.tracks.size} songs", 150, { c.playTracks(m.tracks, 0, false) }) {
                        Box(Modifier.size(30.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(16.dp), tint = Color.White)
                        }
                    }
                }
            }
        }

        // playlists
        if (d.playlists.isNotEmpty()) Shelf("Playlists", "All", { goTab("playlists") }) {
            Row2 {
                d.playlists.take(14).forEach { p ->
                    val first = p.trackIds.firstNotNullOfOrNull { byId[it] }
                    Column(Modifier.width(120.dp).bounceClick { push(Route.Detail("playlist", p.id)) }) {
                        AlbumArt(first, Modifier.size(120.dp), RoundedCornerShape(18.dp), 32.dp, 256)
                        Text(p.name, Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                        Text("${p.trackIds.size} songs", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    }
                }
            }
        }

        // most played
        if (most.isNotEmpty()) Shelf("Most played", "More", { push(Route.MostPlayed) }) { Row2 { most.forEach { SongCard(it, most) } } }

        // recently added
        if (added.isNotEmpty()) Shelf("Recently added", "All", { push(Route.Detail("smart", "added")) }) { Row2 { added.forEach { SongCard(it, added) } } }

        // favourites
        if (favs.isNotEmpty()) Shelf("Favourites", "All", { push(Route.Detail("smart", "fav")) }) { Row2 { favs.take(15).forEach { SongCard(it, favs) } } }
    }
}
