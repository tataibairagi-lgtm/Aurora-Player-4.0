package com.aurora.player.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.sin

/** Long text scrolls sideways only when it does not fit. Off = unchanged. */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.marqueeIf(on: Boolean): Modifier = if (on) this.basicMarquee(iterations = Int.MAX_VALUE) else this

/**
 * A seek bar drawn as a wave: it ripples while the song plays and flattens when paused.
 * [onChange] reports the position while dragging; [onDone] fires when the finger lifts or taps.
 */
@Composable
fun SquigglySeek(
    value: Float, max: Float, playing: Boolean, color: Color, trackColor: Color,
    onChange: (Float) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier,
    oneUi: Boolean = false,
) {
    val amp by animateFloatAsState(if (playing) 1f else 0f, tween(600), label = "waveAmp")
    var dragging by remember { mutableStateOf(false) }
    val grow by animateFloatAsState(if (dragging) 1f else 0f, tween(180), label = "waveGrow")
    val t = rememberInfiniteTransition(label = "wave")
    // the wave only moves while music plays (and while it settles); a paused wave costs no frames at all
    val running = playing || amp > 0.01f
    val phaseState: androidx.compose.runtime.State<Float> = if (running) t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(if (oneUi) 1800 else 2200, easing = LinearEasing), RepeatMode.Restart), label = "wavePhase") else remember { mutableStateOf(0f) }
    Canvas(
        modifier.fillMaxWidth().height(if (oneUi) 46.dp else 44.dp)
            .pointerInput(max) { detectTapGestures { p -> onChange((p.x / size.width * max).coerceIn(0f, max)); onDone() } }
            .pointerInput(max) {
                detectHorizontalDragGestures(
                    onDragStart = { p -> dragging = true; onChange((p.x / size.width * max).coerceIn(0f, max)) },
                    onDragEnd = { dragging = false; onDone() }, onDragCancel = { dragging = false; onDone() },
                ) { change, _ -> change.consume(); onChange((change.position.x / size.width * max).coerceIn(0f, max)) }
            },
    ) {
        val phase = phaseState.value               // read while drawing, so the wave redraws without recomposing
        val w = size.width; val h = size.height; val mid = h / 2
        val pad = 10.dp.toPx()                      // room for the round thumb at both ends
        val span = (w - 2 * pad).coerceAtLeast(1f)
        val x = pad + (value / max.coerceAtLeast(1f)).coerceIn(0f, 1f) * span
        if (oneUi) {
            // layered "swell" look: a thick rounded played line with soft translucent hills rising out of it,
            // low at the left, highest a little before the handle, moving gently while music plays
            val base = h * 0.72f
            val stroke = 6.dp.toPx()
            val r = (9f + 2f * grow).dp.toPx()
            val rim = 3.5.dp.toPx()
            val end = (x - r * 0.3f).coerceAtLeast(pad + 1f)
            val maxH = 15.dp.toPx() * (0.2f + 0.8f * amp) * (1f - 0.3f * grow)
            // what is still to play is a thin, flat, pale line
            if (x + r < w - pad) drawLine(trackColor, Offset(x + r, base), Offset(w - pad, base), strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
            // the swell: one soft dome over the last stretch before the handle, flat (just the thick line) before that
            val s0 = (end - 190.dp.toPx()).coerceAtLeast(pad)
            val len = (end - s0).coerceAtLeast(1f)
            fun hill(shift: Float, speed: Float, f1: Float, scale: Float, skew: Float): Path {
                val path = Path()
                path.moveTo(s0, base)
                var px = s0
                while (px <= end) {
                    val u = ((px - s0) / len).coerceIn(0f, 1f)
                    val us = Math.pow(u.toDouble(), skew.toDouble()).toFloat()           // moves the crest left or right
                    val dome = sin(us * PI.toFloat()).coerceAtLeast(0f)
                    val n = 0.78f + 0.22f * sin(u * f1 * 2f * PI.toFloat() - phase * speed + shift)   // the surface drifts gently
                    path.lineTo(px, base - maxH * scale * dome * n)
                    px += 2f
                }
                path.lineTo(end, base); path.close()
                return path
            }
            val glassy = androidx.compose.ui.graphics.lerp(color, Color.White, 0.30f)
            val cream = androidx.compose.ui.graphics.lerp(color, Color.White, 0.78f)
            // back to front: a faint grey swell, a bright body, then a pale cream crest, each fading upward into the background
            fun fade(a1: Float, a0: Float, c: Color) = Brush.verticalGradient(0f to c.copy(alpha = a1), 1f to c.copy(alpha = a0), startY = base - maxH, endY = base)
            drawPath(hill(0.0f, 1f, 2.0f, 1.00f, 1.20f), fade(0.0f, 0.45f, trackColor))
            drawPath(hill(2.0f, -1f, 2.6f, 0.85f, 0.85f), fade(0.30f, 0.95f, glassy))
            drawPath(hill(4.1f, 1f, 3.2f, 0.62f, 0.95f), fade(0.45f, 0.90f, cream))
            // a soft glow where the line meets the handle
            drawCircle(Brush.radialGradient(0f to color.copy(alpha = 0.45f), 1f to Color.Transparent, center = Offset(x, base), radius = r * 3.2f), r * 3.2f, Offset(x, base))
            drawLine(color, Offset(pad, base), Offset(x, base), strokeWidth = stroke, cap = StrokeCap.Round)
            drawCircle(Color.White, r, Offset(x, base))
            drawCircle(color, r - rim, Offset(x, base))
        } else {
            val waveStroke = 4.5.dp.toPx()
            val thumbW = (4f - 1.5f * grow).dp.toPx()            // the handle slims down while you hold it
            val thumbH = (22f + 6f * grow).dp.toPx()
            val gap = thumbW / 2 + 1.dp.toPx()                    // the wave runs right up to the handle
            val a = (3.6f - 1.2f * grow).dp.toPx() * amp          // the ripple eases off a little while you drag
            val len = 36.dp.toPx()
            val taper = 9.dp.toPx()                               // only the last few dp ease onto the centre line, where the handle sits
            val settle = 34.dp.toPx()                             // the wave grows out of the centre line at the left in one smooth sweep, with no kink
            val end = x.coerceAtLeast(pad)                         // the wave runs to the middle point of the handle
            // the part still to play: a soft, rounded line with a small dot at its far end
            if (x + gap < w - pad) {
                drawLine(trackColor, Offset(x + gap, mid), Offset(w - pad, mid), strokeWidth = waveStroke, cap = StrokeCap.Round)
                if (w - pad - x > 40.dp.toPx()) drawCircle(color, 2.2.dp.toPx(), Offset(w - pad, mid))   // no end dot once the handle is nearly there
            }
            // the part already played: a full-height wave that starts at a fixed spot on the left, flows towards the handle and ends right at it
            fun yAt(px: Float): Float {
                val k = ((end - px) / taper).coerceIn(0f, 1f).let { it * it * (3f - 2f * it) } *
                    ((px - pad) / settle).coerceIn(0f, 1f).let { it * it * (3f - 2f * it) }       // smoothstep both ends
                return mid + a * k * sin((px - pad) / len * 2f * PI.toFloat() - phase)
            }
            val wave = Path()
            var px = pad
            wave.moveTo(pad, yAt(pad))
            while (px < end) { px = (px + 1f).coerceAtMost(end); wave.lineTo(px, yAt(px)) }
            drawPath(wave, color.copy(alpha = 0.22f), style = Stroke(waveStroke + 5.dp.toPx() * grow, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            drawPath(wave, color, style = Stroke(waveStroke, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            // handle: a tall rounded bar with a soft halo
            if (grow > 0.01f) drawCircle(color.copy(alpha = 0.16f * grow), 18.dp.toPx(), Offset(x, mid))
            drawRoundRect(color, Offset(x - thumbW / 2, mid - thumbH / 2), androidx.compose.ui.geometry.Size(thumbW, thumbH), androidx.compose.ui.geometry.CornerRadius(thumbW / 2))
        }
    }
}

/** "FLAC • 96 kHz • 1024 kbps": what is really being played. Tap to open the song info. */
@Composable
fun AudioSpecPill(c: PlayerController, t: Track, onClick: () -> Unit) {
    val spec by produceState("", t.id, c.isPlaying) {
        // the decoder reports its format a moment after the song starts
        for (wait in longArrayOf(0, 400, 1200)) {
            delay(wait)
            val f = try { c.player.audioFormat } catch (_: Throwable) { null }
            val ext = t.path.substringAfterLast('.', "").uppercase().ifEmpty { "AUDIO" }
            val parts = ArrayList<String>()
            parts.add(ext)
            val rate = f?.sampleRate?.takeIf { it > 0 }
            if (rate != null) parts.add(if (rate % 1000 == 0) "${rate / 1000} kHz" else "%.1f kHz".format(rate / 1000.0))
            val kbps = f?.bitrate?.takeIf { it > 0 }?.let { it / 1000 }
                ?: if (t.durationMs > 0 && t.size > 0) (t.size * 8 / t.durationMs).toInt() else null
            if (kbps != null && kbps > 0) parts.add("$kbps kbps")
            value = parts.joinToString(" • ")
            if (rate != null) break
        }
    }
    if (spec.isNotEmpty()) Box(
        Modifier.padding(top = 8.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center,
    ) { Text(spec, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
}
