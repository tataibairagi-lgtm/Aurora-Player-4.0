package com.aurora.player.lyrics

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.aurora.player.controller
import com.aurora.player.ui.OverlayContent

private class ServiceOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val saved = SavedStateRegistryController.create(this)
    override val viewModelStore = ViewModelStore()
    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = saved.savedStateRegistry

    fun start() {
        saved.performAttach()
        saved.performRestore(null)
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun stop() {
        registry.currentState = Lifecycle.State.DESTROYED
        viewModelStore.clear()
    }
}

/** Floating, draggable "desktop lyrics" window drawn over every other app. */
class LyricsOverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: ComposeView? = null
    private val owner = ServiceOwner()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        val c = controller
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        owner.start()

        val width = (resources.displayMetrics.widthPixels * 0.94f).toInt()
        lp = WindowManager.LayoutParams(
            width,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = c.store.data.overlayX.coerceAtLeast(0)
            y = c.store.data.overlayY
        }
        applyLock(c.store.data.overlayLocked)

        val v = ComposeView(this)
        v.setViewTreeLifecycleOwner(owner)
        v.setViewTreeViewModelStoreOwner(owner)
        v.setViewTreeSavedStateRegistryOwner(owner)
        v.setContent {
            OverlayContent(
                c = c,
                onDrag = { dx, dy ->
                    lp.x += dx.toInt()
                    lp.y += dy.toInt()
                    wm.updateViewLayout(v, lp)
                },
                onDragEnd = { c.store.update { it.copy(overlayX = lp.x, overlayY = lp.y) } },
                onClose = { stopSelf() },
                onLock = {
                    c.store.update { it.copy(overlayLocked = true) }
                    applyLock(true)
                },
            )
        }
        view = v
        wm.addView(v, lp)
        c.overlayActive = true
    }

    private fun applyLock(locked: Boolean) {
        lp.flags = if (locked) lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        else lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        view?.let { runCatching { wm.updateViewLayout(it, lp) } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_LOCK -> applyLock(true)
            ACTION_UNLOCK -> applyLock(false)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        controller.overlayActive = false
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        owner.stop()
        super.onDestroy()
    }

    companion object {
        const val ACTION_LOCK = "aurora.overlay.LOCK"
        const val ACTION_UNLOCK = "aurora.overlay.UNLOCK"

        fun start(ctx: Context) {
            ctx.startService(Intent(ctx, LyricsOverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, LyricsOverlayService::class.java))
        }

        fun setLocked(ctx: Context, locked: Boolean) {
            ctx.controller.store.update { it.copy(overlayLocked = locked) }
            ctx.startService(
                Intent(ctx, LyricsOverlayService::class.java)
                    .setAction(if (locked) ACTION_LOCK else ACTION_UNLOCK)
            )
        }
    }
}
