package com.aurora.player

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps the last crash / playback error in a small file so it can be read in Settings > About (no computer needed). */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_error.txt")

    fun install(ctx: Context) {
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            write(ctx, "Crash in thread ${t.name}", e)
            old?.uncaughtException(t, e)
        }
    }

    fun write(ctx: Context, what: String, e: Throwable) {
        try {
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            file(ctx).writeText("$time\n$what\n${android.util.Log.getStackTraceString(e).take(6000)}")
        } catch (_: Throwable) {}
    }

    fun read(ctx: Context): String = try { file(ctx).takeIf { it.exists() }?.readText().orEmpty() } catch (_: Throwable) { "" }
    fun clear(ctx: Context) { try { file(ctx).delete() } catch (_: Throwable) {} }
}
