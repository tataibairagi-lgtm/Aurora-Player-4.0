package com.aurora.player.widget

import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import androidx.core.graphics.ColorUtils

/**
 * Colours for the queue widget.
 *  - Wallpaper mode on Android 12+: the system's Material You palette, which Android derives from your wallpaper.
 *  - Wallpaper mode on Android 8.1-11: the wallpaper's dominant colour, turned into a light or dark palette.
 *  - Light / Dark modes: a fixed Aurora palette.
 * Light vs dark follows the phone's dark mode in wallpaper mode.
 */
object WidgetTheme {
    class Colors(
        val header: Int, val headerAlpha: Int,
        val panel: Int, val panelAlpha: Int,
        val text: Int, val sub: Int, val accent: Int, val divider: Int, val onAccent: Int = Color.WHITE,
    )

    /** Colour of the current cover, set by WidgetUpdater; used by the "Adapt from album art" theme. */
    @Volatile var artSeed: Int? = null

    private const val AURORA_SEED = 0xFF7C6CF0.toInt()

    fun resolve(ctx: Context, mode: Int): Colors {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        return when (mode) {
            1 -> fromSeed(AURORA_SEED, dark = false)
            2 -> fromSeed(AURORA_SEED, dark = true)
            3 -> fromSeed(artSeed ?: AURORA_SEED, night)
            else -> if (Build.VERSION.SDK_INT >= 31) dynamic(ctx, night)
            else fromSeed(wallpaperSeed(ctx) ?: AURORA_SEED, night)
        }
    }

    @SuppressLint("NewApi")
    private fun dynamic(ctx: Context, dark: Boolean): Colors {
        fun c(id: Int) = ctx.getColor(id)
        return if (!dark) Colors(
            header = c(android.R.color.system_accent1_100), headerAlpha = 0xE6,
            panel = c(android.R.color.system_accent1_50), panelAlpha = 0xCC,
            text = c(android.R.color.system_neutral1_900), sub = c(android.R.color.system_neutral2_700),
            accent = c(android.R.color.system_accent1_600), divider = c(android.R.color.system_accent1_200),
            onAccent = c(android.R.color.system_accent1_0),
        ) else Colors(
            header = c(android.R.color.system_accent2_800), headerAlpha = 0xE6,
            panel = c(android.R.color.system_neutral1_900), panelAlpha = 0xD9,
            text = c(android.R.color.system_neutral1_100), sub = c(android.R.color.system_neutral2_300),
            accent = c(android.R.color.system_accent1_200), divider = c(android.R.color.system_accent2_700),
            onAccent = c(android.R.color.system_accent1_800),
        )
    }

    @Volatile private var cachedSeed: Int? = null
    @Volatile private var seedLoaded = false

    /** Forget the wallpaper colour (call when the wallpaper changes). */
    fun invalidate() { seedLoaded = false }

    private fun wallpaperSeed(ctx: Context): Int? {
        if (seedLoaded) return cachedSeed
        val seed = fromWallpaperColors(ctx)?.takeIf { vivid(it) } ?: fromBitmap(ctx) ?: fromWallpaperColors(ctx)
        cachedSeed = seed; seedLoaded = true
        return seed
    }

    private fun vivid(c: Int): Boolean { val h = FloatArray(3); ColorUtils.colorToHSL(c, h); return h[1] > 0.22f && h[2] in 0.12f..0.88f }

    private fun fromWallpaperColors(ctx: Context): Int? {
        if (Build.VERSION.SDK_INT < 27) return null
        return try {
            val wc = WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM) ?: return null
            // the most colourful of the three colours, not simply the biggest one (which is often grey)
            listOfNotNull(wc.primaryColor, wc.secondaryColor, wc.tertiaryColor).map { it.toArgb() }
                .maxByOrNull { val h = FloatArray(3); ColorUtils.colorToHSL(it, h); h[1] * (1f - kotlin.math.abs(2 * h[2] - 1f)) }
        } catch (_: Throwable) {
            null
        }
    }

    /** Reads the real wallpaper, shrinks it and picks the most vivid hue (weighted by how colourful each pixel is). */
    private fun fromBitmap(ctx: Context): Int? = try {
        val d = WallpaperManager.getInstance(ctx).peekDrawable()
        val src = (d as? android.graphics.drawable.BitmapDrawable)?.bitmap
        val w = 48; val h = 48
        val soft = src?.copy(android.graphics.Bitmap.Config.ARGB_8888, false)
        val bmp = soft?.let { android.graphics.Bitmap.createScaledBitmap(it, w, h, true) }
        if (bmp == null) null else {
        val weight = FloatArray(36); val sat = FloatArray(36); val lig = FloatArray(36)
        val hsl = FloatArray(3)
        var total = 0f
        for (x in 0 until w) for (y in 0 until h) {
            ColorUtils.colorToHSL(bmp.getPixel(x, y), hsl)
            val colourful = hsl[1] * (1f - kotlin.math.abs(2 * hsl[2] - 1f))
            val k = colourful * colourful
            val bin = (hsl[0] / 10f).toInt().coerceIn(0, 35)
            weight[bin] += k; sat[bin] += hsl[1] * k; lig[bin] += hsl[2] * k
            total += k
        }
        if (total < 4f) null // basically a grey wallpaper: let the caller fall back
        else {
            // smooth over neighbouring bins so a hue that straddles two bins still wins
            var best = 0; var bestW = -1f
            for (i in 0 until 36) {
                val ww = weight[i] + 0.5f * (weight[(i + 35) % 36] + weight[(i + 1) % 36])
                if (ww > bestW) { bestW = ww; best = i }
            }
            val bw = weight[best].coerceAtLeast(0.0001f)
            ColorUtils.HSLToColor(floatArrayOf(best * 10f + 5f, (sat[best] / bw).coerceIn(0f, 1f), (lig[best] / bw).coerceIn(0.25f, 0.7f)))
        }
        }
    } catch (_: Throwable) {
        null
    }

    private fun fromSeed(seed: Int, dark: Boolean): Colors {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(seed, hsl)
        val h = hsl[0]
        val s = hsl[1].coerceIn(0.45f, 0.95f)
        fun hsl(sat: Float, light: Float) = ColorUtils.HSLToColor(floatArrayOf(h, sat.coerceIn(0f, 1f), light.coerceIn(0f, 1f)))
        // yellows and greens look muddy at the same lightness as blues: nudge them
        val warm = h in 45f..160f
        fun onColor(bg: Int) = if (ColorUtils.calculateContrast(Color.WHITE, bg) >= 3.0) Color.WHITE else hsl(0.35f, 0.08f)
        /** Moves [fg] lighter/darker until it reads clearly (>= 4.5:1) on [bg]. */
        fun readable(fg: Int, bg: Int, darkText: Boolean): Int {
            var c = fg; var n = 0
            val f = FloatArray(3)
            while (ColorUtils.calculateContrast(c, bg) < 4.5 && n++ < 12) {
                ColorUtils.colorToHSL(c, f)
                f[2] = (f[2] + if (darkText) -0.04f else 0.04f).coerceIn(0f, 1f)
                c = ColorUtils.HSLToColor(f)
            }
            return c
        }
        return if (!dark) {
            val header = hsl(s * 0.75f, 0.84f)
            val panel = hsl(s * 0.70f, 0.93f)
            val accent = hsl(s, if (warm) 0.28f else 0.42f)
            Colors(
                header = header, headerAlpha = 0xF2,
                panel = panel, panelAlpha = 0xE6,
                text = hsl(s * 0.50f, 0.09f), sub = readable(hsl(s * 0.30f, 0.38f), panel, true),
                accent = readable(accent, header, true), divider = hsl(s * 0.60f, 0.76f), onAccent = onColor(accent),
            )
        } else {
            val header = hsl(s * 0.50f, 0.23f)
            val panel = hsl(s * 0.35f, 0.12f)
            val accent = hsl((s * 0.95f).coerceAtMost(0.90f), if (warm) 0.62f else 0.78f)
            Colors(
                header = header, headerAlpha = 0xF2,
                panel = panel, panelAlpha = 0xE6,
                text = hsl(s * 0.30f, 0.95f), sub = readable(hsl(s * 0.25f, 0.72f), panel, false),
                accent = readable(accent, header, false), divider = hsl(s * 0.35f, 0.28f), onAccent = hsl(0.4f, 0.10f).let { if (ColorUtils.calculateContrast(Color.WHITE, accent) >= 3.0) Color.WHITE else it },
            )
        }
    }
}
