package com.aurora.player.player

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.aurora.player.data.Track
import com.aurora.player.data.albumKey

/**
 * The browse tree shown by Android Auto (and other media browsers): Songs, Albums, Artists, Playlists and Favourites.
 * Ids: "songs", "albums", "artists", "playlists", "fav"; "a:<album key>", "r:<artist>", "p:<playlist id>";
 * a song is "t:<parent id>|<track id>" so tapping it queues the list it was in.
 */
class AutoLibrary(private val c: PlayerController, private val pkg: String) {
    companion object {
        const val ROOT = "root"
        const val MAX = 400
    }

    private fun folder(id: String, title: String, subtitle: String? = null, type: Int = MediaMetadata.MEDIA_TYPE_FOLDER_MIXED): MediaItem =
        MediaItem.Builder().setMediaId(id).setMediaMetadata(
            MediaMetadata.Builder().setTitle(title).setSubtitle(subtitle).setIsBrowsable(true).setIsPlayable(false).setMediaType(type).build(),
        ).build()

    fun root(): MediaItem = folder(ROOT, "Aurora")

    fun song(t: Track, parent: String): MediaItem =
        MediaItem.Builder()
            .setMediaId("t:$parent|${t.id}")
            .setUri(t.uri)
            .setMediaMetadata(
                MediaMetadata.Builder().setTitle(t.title).setArtist(t.artist).setAlbumTitle(t.album)
                    .setArtworkUri(Uri.parse("content://$pkg.art/${t.id}"))
                    .setIsBrowsable(false).setIsPlayable(true).setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC).build(),
            ).build()

    /** The songs behind a list id, or null when [id] is not a list of songs. */
    fun tracksOf(id: String): List<Track>? {
        val lib = c.library
        val d = c.store.data
        return when {
            id == "songs" -> lib.sortedBy { it.title.lowercase() }
            id == "fav" -> d.favourites.mapNotNull { c.track(it) }
            id.startsWith("a:") -> lib.filter { it.albumKey() == id.substring(2) }.sortedWith(compareBy({ it.trackNo }, { it.title.lowercase() }))
            id.startsWith("r:") -> lib.filter { it.artist == id.substring(2) }.sortedBy { it.title.lowercase() }
            id.startsWith("p:") -> d.playlists.firstOrNull { it.id == id.substring(2) }?.trackIds?.mapNotNull { c.track(it) }
            else -> null
        }
    }

    fun children(parent: String): List<MediaItem> {
        val lib = c.library
        return when (parent) {
            ROOT -> listOf(
                folder("songs", "Songs"), folder("albums", "Albums", null, MediaMetadata.MEDIA_TYPE_FOLDER_ALBUMS),
                folder("artists", "Artists", null, MediaMetadata.MEDIA_TYPE_FOLDER_ARTISTS),
                folder("playlists", "Playlists", null, MediaMetadata.MEDIA_TYPE_FOLDER_PLAYLISTS), folder("fav", "Favourites"),
            )
            "albums" -> lib.groupBy { it.albumKey() }.entries.sortedBy { it.value.first().album.lowercase() }.take(MAX)
                .map { (k, l) -> folder("a:$k", l.first().album.ifBlank { "Unknown album" }, l.first().artist, MediaMetadata.MEDIA_TYPE_ALBUM) }
            "artists" -> lib.groupBy { it.artist }.entries.sortedBy { it.key.lowercase() }.take(MAX)
                .map { (a, l) -> folder("r:$a", a.ifBlank { "Unknown artist" }, "${l.size} songs", MediaMetadata.MEDIA_TYPE_ARTIST) }
            "playlists" -> c.store.data.playlists.map { folder("p:${it.id}", it.name, "${it.trackIds.size} songs", MediaMetadata.MEDIA_TYPE_PLAYLIST) }
            else -> tracksOf(parent)?.take(MAX)?.map { song(it, parent) } ?: emptyList()
        }
    }

    /** What a browser asked to play: ids made by [song] become the whole list starting at that song. Returns the queue index or null. */
    fun play(ids: List<String>, startIndex: Int): Boolean {
        val first = ids.getOrNull(startIndex.coerceAtLeast(0)) ?: ids.firstOrNull() ?: return false
        if (first.startsWith("t:")) {
            val parent = first.substring(2).substringBefore('|')
            val tid = first.substringAfter('|').toLongOrNull() ?: return false
            val list = (tracksOf(parent) ?: c.library).ifEmpty { return false }
            val at = list.indexOfFirst { it.id == tid }.coerceAtLeast(0)
            c.playTracks(list, at)
            return true
        }
        // a whole folder (album, artist, playlist...) or a plain track id
        tracksOf(first)?.takeIf { it.isNotEmpty() }?.let { c.playTracks(it, 0); return true }
        first.toLongOrNull()?.let { id -> c.track(id)?.let { c.playTracks(listOf(it)); return true } }
        return false
    }

    fun item(id: String): MediaItem? {
        if (id == ROOT) return root()
        if (id.startsWith("t:")) {
            val parent = id.substring(2).substringBefore('|')
            val t = id.substringAfter('|').toLongOrNull()?.let { c.track(it) } ?: return null
            return song(t, parent)
        }
        return children(ROOT).firstOrNull { it.mediaId == id }
    }
}
